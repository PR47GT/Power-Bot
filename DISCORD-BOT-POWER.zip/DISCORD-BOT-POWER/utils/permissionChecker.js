/**
 * التحقق من صلاحيات العضو لاستخدام الأمر
 * الأولوية: Denied > Allowed
 */
function checkPermissions(member, channelId, commandConfig) {
    // إذا لم تكن هناك إعدادات، اسمح بالاستخدام
    if (!commandConfig) {
        return { allowed: true, reason: 'مقبول' };
    }

    // ========== 1. فحص الأدوار الممنوعة (أولوية أعلى) ==========
    if (commandConfig.deniedRoles && Array.isArray(commandConfig.deniedRoles) && commandConfig.deniedRoles.length > 0) {
        const validDeniedRoles = commandConfig.deniedRoles.filter(r => 
            r && r !== 'false' && r !== 'null' && r !== '' && typeof r === 'string'
        );
        
        if (validDeniedRoles.length > 0) {
            const hasDeniedRole = member.roles.cache.some(role => 
                validDeniedRoles.includes(role.id)
            );
            
            if (hasDeniedRole) {
                return { 
                    allowed: false, 
                    reason: '⚠️ عذرًا، لا تملك صلاحية استخدام هذا الأمر   ' 
                };
            }
        }
    }

    // ========== 2. فحص الأدوار المسموحة ==========
    if (commandConfig.allowedRoles && Array.isArray(commandConfig.allowedRoles) && commandConfig.allowedRoles.length > 0) {
        const validAllowedRoles = commandConfig.allowedRoles.filter(r => 
            r && r !== 'false' && r !== 'null' && r !== '' && typeof r === 'string'
        );
        
        if (validAllowedRoles.length > 0) {
            const hasAllowedRole = member.roles.cache.some(role => 
                validAllowedRoles.includes(role.id)
            );
            
            if (!hasAllowedRole) {
                return { 
                    allowed: false, 
                    reason: '⚠️ عذرًا، تحتاج إلى رتبة معينة لاستخدام هذا الأمر' 
                };
            }
        }
    }

    // ========== 3. فحص الرومات الممنوعة ==========
    if (commandConfig.deniedChannels && Array.isArray(commandConfig.deniedChannels) && commandConfig.deniedChannels.length > 0) {
        const validDeniedChannels = commandConfig.deniedChannels.filter(c => 
            c && c !== 'false' && c !== 'null' && c !== '' && typeof c === 'string'
        );
        
        if (validDeniedChannels.length > 0) {
            if (validDeniedChannels.includes(channelId)) {
                return { 
                    allowed: false, 
                    reason: '⚠️  لا يمكن استخدام هذا الأمر في هذه القناة ' 
                };
            }
        }
    }

    // ========== 4. فحص الرومات المسموحة ==========
    if (commandConfig.allowedChannels && Array.isArray(commandConfig.allowedChannels) && commandConfig.allowedChannels.length > 0) {
        const validAllowedChannels = commandConfig.allowedChannels.filter(c => 
            c && c !== 'false' && c !== 'null' && c !== '' && typeof c === 'string'
        );
        
        if (validAllowedChannels.length > 0 && !validAllowedChannels.includes(channelId)) {
            return { 
                allowed: false, 
                reason: '⚠️ يمكن استخدام هذا الأمر في قنوات معينة فقط' 
            };
        }
    }

    // ========== السماح بالاستخدام ==========
    return { allowed: true, reason: 'مقبول' };
}

module.exports = { checkPermissions };