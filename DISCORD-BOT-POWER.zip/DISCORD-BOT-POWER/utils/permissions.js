/**
 * utils/permissions.js
 * التحقق من صلاحيات استخدام الأمر
 * الأولوية: Owner > Administrator > Denied > Allowed
 */

function checkPermissions(member, channelId, commandConfig) {
    // 0. مالك السيرفر (أعلى صلاحية)
    if (member.id === member.guild.ownerId) {
        return { allowed: true, reason: 'مالك السيرفر' };
    }
    
    // 0.5. صلاحية Administrator (تتجاوز كل القيود)
    if (member.permissions.has('Administrator')) {
        return { allowed: true, reason: 'أدمن' };
    }
    
    // 1. فحص الأدوار الممنوعة (أولوية أعلى من المسموحة)
    if (commandConfig.deniedRoles && commandConfig.deniedRoles.length > 0) {
        const hasDeniedRole = member.roles.cache.some(r => commandConfig.deniedRoles.includes(r.id));
        if (hasDeniedRole) {
            return { 
                allowed: false, 
                reason: '⛔ لديك رتبة تمنعك من استخدام هذا الأمر.' 
            };
        }
    }
    
    // 2. فحص الأدوار المسموحة
    if (commandConfig.allowedRoles && commandConfig.allowedRoles.length > 0) {
        const hasAllowedRole = member.roles.cache.some(r => commandConfig.allowedRoles.includes(r.id));
        if (!hasAllowedRole) {
            return { 
                allowed: false, 
                reason: '🔒 ليس لديك الصلاحية لاستخدام هذا الأمر.' 
            };
        }
    }
    
    // 3. فحص الرومات الممنوعة
    if (commandConfig.deniedChannels && commandConfig.deniedChannels.length > 0) {
        if (commandConfig.deniedChannels.includes(channelId)) {
            return { 
                allowed: false, 
                reason: '⛔ لا يمكن استخدام هذا الأمر في هذا الروم.' 
            };
        }
    }
    
    // 4. فحص الرومات المسموحة
    if (commandConfig.allowedChannels && commandConfig.allowedChannels.length > 0) {
        if (!commandConfig.allowedChannels.includes(channelId)) {
            return { 
                allowed: false, 
                reason: '🔒 هذا الأمر لا يعمل في هذا الروم.' 
            };
        }
    }
    
    return { allowed: true, reason: 'مقبول' };
}

module.exports = { checkPermissions };