const { EmbedBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');

function getAutoReplies() {
    try {
        const filePath = path.join(__dirname, '..', 'autoReply.json');
        if (!fs.existsSync(filePath)) return [];
        const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        return data.replies || [];
    } catch { return []; }
}

function dataUrlToAttachment(dataUrl) {
    try {
        const [meta, base64] = dataUrl.split(',');
        const mime = meta.match(/:(.*?);/)[1];
        const ext  = mime.split('/')[1].replace('jpeg', 'jpg').replace('svg+xml', 'svg');
        const buffer = Buffer.from(base64, 'base64');
        return { buffer, name: `image.${ext}` };
    } catch {
        return null;
    }
}

module.exports = {
    name: 'messageCreate',

    async execute(client, settings, message) {
        if (!message.guild)     return;
        if (message.author.bot) return;

        const replies = getAutoReplies();
        if (!replies.length) return;

        const content = message.content.toLowerCase();

        for (const reply of replies) {
            if (!reply.trigger) continue;

            if (!content.includes(reply.trigger.toLowerCase())) continue;

            if (reply.channels && reply.channels.length > 0) {
                if (!reply.channels.includes(message.channel.id)) continue;
            }

            const payload = {};
            const imagePos = reply.imagePosition || 'embed';

            // نص الرسالة
            const text = reply.message || '';
            if (text) payload.content = text;

            // معالجة الصورة بناءً على imagePosition
            const imageUrl = reply.imageUrl || '';
            if (imageUrl) {
                if (imageUrl.startsWith('data:')) {
                    // base64 → buffer
                    const att = dataUrlToAttachment(imageUrl);
                    if (att) {
                        if (imagePos === 'attachment') {
                            // خارج البيت: مرفق مستقل بدون embed
                            payload.files = [{ attachment: att.buffer, name: att.name }];
                        } else {
                            // داخل البيت: مرفق + embed يحتوي الصورة
                            payload.files = [{ attachment: att.buffer, name: att.name }];
                            const embed = new EmbedBuilder().setImage(`attachment://${att.name}`);
                            if (reply.embedColor) embed.setColor(reply.embedColor);
                            payload.embeds = [embed];
                        }
                    }
                } else if (imageUrl.startsWith('http://') || imageUrl.startsWith('https://')) {
                    if (imagePos === 'attachment') {
                        // خارج البيت: الصورة كـ URL منفصل في المحتوى
                        payload.content = [text, imageUrl].filter(Boolean).join('\n');
                    } else {
                        // داخل البيت: embed يحتوي الصورة
                        const embed = new EmbedBuilder().setImage(imageUrl);
                        if (reply.embedColor) embed.setColor(reply.embedColor);
                        payload.embeds = [embed];
                    }
                }
            }

            // إذا ما في محتوى نصي ولا embed ولا ملف مرفق، تجاهل الإرسال بالكامل
            const hasContent = !!payload.content;
            const hasEmbeds  = !!(payload.embeds && payload.embeds.length);
            const hasFiles   = !!(payload.files && payload.files.length);

            if (!hasContent && !hasEmbeds && !hasFiles) {
                break;
            }

            try {
                if (reply.mentionUser) {
                    await message.reply(payload);
                } else {
                    await message.channel.send(payload);
                }
            } catch (err) {
                console.error('[AutoReply] فشل إرسال الرد:', err.message);
            }

            break;
        }
    }
};
