// features/giveaway/giveawayButton.js
'use strict';

const { MessageFlags, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');
const { loadGiveaways, saveGiveaways, t }                            = require('./giveaway');

// Per-giveaway lock to prevent race conditions on simultaneous button clicks
const _locks = new Set();

async function handleGiveawayButton(interaction, client, settings) {
    const messageId = interaction.message.id;

    // Acquire per-giveaway lock
    if (_locks.has(messageId)) {
        return interaction.reply({
            content: settings?.botLanguage === 'ar'
                ? '⏳ يتم معالجة طلب آخر، حاول مجدداً.'
                : '⏳ Another request is being processed, please try again.',
            flags: MessageFlags.Ephemeral
        }).catch(() => {});
    }
    _locks.add(messageId);

    try {
        await _processEntry(interaction, messageId, settings);
    } finally {
        _locks.delete(messageId);
    }
}

async function _processEntry(interaction, messageId, settings) {
    const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';

    const data     = loadGiveaways();
    const giveaway = data.giveaways.find(g => g.messageId === messageId);

    if (!giveaway) {
        return interaction.reply({
            content: t(lang, '❌ هذا السحب غير موجود.', '❌ This giveaway does not exist.'),
            flags:   MessageFlags.Ephemeral
        });
    }

    if (giveaway.status === 'paused') {
        return interaction.reply({
            content: t(lang, '⏸️ هذا السحب متوقف مؤقتاً.', '⏸️ This giveaway is currently paused.'),
            flags:   MessageFlags.Ephemeral
        });
    }

    if (giveaway.status !== 'active') {
        return interaction.reply({
            content: t(lang, '❌ هذا السحب قد انتهى.', '❌ This giveaway has ended.'),
            flags:   MessageFlags.Ephemeral
        });
    }

    const userId = interaction.user.id;
    const member = interaction.member;

    // --- Requirement checks ---
    const reqs = giveaway.requirements || {};

    if (reqs.requiredRole) {
        if (!member?.roles?.cache?.has(reqs.requiredRole)) {
            return interaction.reply({
                content: t(
                    lang,
                    '❌ لا تملك الرتبة المطلوبة للمشاركة في هذا السحب.',
                    '❌ You do not have the required role to enter this giveaway.'
                ),
                flags: MessageFlags.Ephemeral
            });
        }
    }

    if (reqs.blacklistRole) {
        if (member?.roles?.cache?.has(reqs.blacklistRole)) {
            return interaction.reply({
                content: t(
                    lang,
                    '❌ أنت محظور من المشاركة في هذا السحب.',
                    '❌ You are not eligible to enter this giveaway.'
                ),
                flags: MessageFlags.Ephemeral
            });
        }
    }

    if (reqs.minAccountAge) {
        const accountAgeDays = (Date.now() - interaction.user.createdTimestamp) / 86400000;
        if (accountAgeDays < reqs.minAccountAge) {
            return interaction.reply({
                content: t(
                    lang,
                    `❌ يجب أن يكون عمر حسابك أكثر من ${reqs.minAccountAge} يوم.`,
                    `❌ Your account must be at least ${reqs.minAccountAge} days old.`
                ),
                flags: MessageFlags.Ephemeral
            });
        }
    }

    if (reqs.minServerAge) {
        const joinedAt     = member?.joinedTimestamp;
        const serverAgeDays = joinedAt ? (Date.now() - joinedAt) / 86400000 : 0;
        if (serverAgeDays < reqs.minServerAge) {
            return interaction.reply({
                content: t(
                    lang,
                    `❌ يجب أن تكون عضواً في السيرفر لأكثر من ${reqs.minServerAge} يوم.`,
                    `❌ You must have been a server member for at least ${reqs.minServerAge} days.`
                ),
                flags: MessageFlags.Ephemeral
            });
        }
    }

    const alreadyEntered = giveaway.participants.includes(userId);

    if (alreadyEntered) {
        giveaway.participants = giveaway.participants.filter(id => id !== userId);
        saveGiveaways(data);
        await _updateButtonCount(interaction, giveaway, lang);
        return interaction.reply({
            content: t(lang, '👋 تم إلغاء مشاركتك في السحب.', '👋 You have been removed from the giveaway.'),
            flags:   MessageFlags.Ephemeral
        });
    }

    giveaway.participants.push(userId);
    saveGiveaways(data);
    await _updateButtonCount(interaction, giveaway, lang);

    return interaction.reply({
        content: t(lang, '🎉 تم تسجيل مشاركتك بنجاح!', '🎉 You have successfully entered the giveaway!'),
        flags:   MessageFlags.Ephemeral
    });
}

async function _updateButtonCount(interaction, giveaway, lang) {
    try {
        const count  = giveaway.participants.length;
        const config = loadGiveaways().config;
        const emoji  = (config && config.entryEmoji) ? config.entryEmoji : '🎉';
       const label  = `${t(lang, 'شارك', 'Enter')} (${count})`;

        const newRow = new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setCustomId('giveaway_enter')
                .setLabel(label)
                .setEmoji(emoji)
                .setStyle(ButtonStyle.Primary)
        );

        await interaction.message.edit({ components: [newRow] }).catch(() => {});
    } catch (_) {}
}

module.exports = { handleGiveawayButton };
