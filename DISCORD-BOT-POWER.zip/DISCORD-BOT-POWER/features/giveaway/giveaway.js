// features/giveaway/giveaway.js
'use strict';

const fs   = require('fs');
const path = require('path');

const GIVEAWAY_FILE = path.join(__dirname, '../../giveaway.json');

// ==================== In-Memory Cache ====================
let _cache     = null;
let _dirty     = false;
let _saveTimer = null;

function _scheduleWrite() {
    if (_saveTimer) return;
    _saveTimer = setTimeout(() => {
        _saveTimer = null;
        if (_dirty && _cache) {
            try {
                fs.writeFileSync(GIVEAWAY_FILE, JSON.stringify(_cache, null, 2), 'utf8');
                _dirty = false;
            } catch (e) {
                console.error('[Giveaway] Failed to persist data:', e);
            }
        }
    }, 300);
}

function loadGiveaways() {
    if (_cache) return _cache;
    if (fs.existsSync(GIVEAWAY_FILE)) {
        try {
            _cache = JSON.parse(fs.readFileSync(GIVEAWAY_FILE, 'utf8'));
        } catch (e) {
            console.error('[Giveaway] Corrupt giveaway.json — using defaults:', e);
            _cache = { giveaways: [], config: getDefaultConfig() };
        }
    } else {
        _cache = { giveaways: [], config: getDefaultConfig() };
    }
    if (!Array.isArray(_cache.giveaways)) _cache.giveaways = [];
    if (!_cache.config) _cache.config = getDefaultConfig();
    if (!Array.isArray(_cache.winners)) _cache.winners = [];
    return _cache;
}

function saveGiveaways(data) {
    _cache = data;
    _dirty = true;
    _scheduleWrite();
}

function flushSync() {
    if (_dirty && _cache) {
        try {
            fs.writeFileSync(GIVEAWAY_FILE, JSON.stringify(_cache, null, 2), 'utf8');
            _dirty = false;
        } catch (e) {
            console.error('[Giveaway] Flush failed:', e);
        }
    }
}

// ==================== Default Config ====================
function getDefaultConfig() {
    return {
        defaultColor:         '#5865F2',
        entryEmoji:           '🎉',
        winnersChannel:       '',
        maxWinners:           10,
        dmWinners:            false,
        deleteOnEnd:          false,
        allowMultipleEntries: false,
        endReminder:          false,
        noDuplicateWinners:   true,
        startTitle:           '',
        endTitle:             '',
        winnerDm:             '',
        rerollMsg:            ''
    };
}

// ==================== i18n helpers ====================
function t(lang, ar, en) {
    return (lang === 'ar') ? ar : en;
}

function getLang(settings) {
    return (settings && settings.botLanguage === 'ar') ? 'ar' : 'en';
}

function getStartTitle(config, lang) {
    if (config.startTitle && config.startTitle.trim()) return config.startTitle;
    return lang === 'ar' ? '🎉 سحب! 🎉' : '🎉 GIVEAWAY! 🎉';
}

function getEndTitle(config, lang) {
    if (config.endTitle && config.endTitle.trim()) return config.endTitle;
    return lang === 'ar' ? '🎊 انتهى السحب! 🎊' : '🎊 GIVEAWAY ENDED! 🎊';
}

// ==================== Duration Formatter ====================
function msToStr(ms, lang) {
    const d = Math.floor(ms / 86400000);
    const h = Math.floor((ms % 86400000) / 3600000);
    const m = Math.floor((ms % 3600000) / 60000);
    const s = Math.floor((ms % 60000) / 1000);
    const parts = [];
    if (d > 0) parts.push(lang === 'ar' ? `${d} يوم`    : `${d}d`);
    if (h > 0) parts.push(lang === 'ar' ? `${h} ساعة`   : `${h}h`);
    if (m > 0) parts.push(lang === 'ar' ? `${m} دقيقة`  : `${m}m`);
    if (s > 0 || parts.length === 0) parts.push(lang === 'ar' ? `${s} ثانية` : `${s}s`);
    return parts.join(' ');
}

// ==================== Winner Selection ====================
/**
 * Pick winners from the participant pool.
 *
 * @param {string[]} participants    - Array of Discord user IDs
 * @param {number}   count           - How many winners to pick
 * @param {Array}    bonusEntries     - [{roleId, amount}]
 * @param {string[]} exclude          - User IDs to exclude (previously won)
 * @param {Object}   memberRolesMap   - { userId: Set<roleId> } for bonus checking
 * @returns {string[]}
 */
function pickWinners(participants, count, bonusEntries = [], exclude = [], memberRolesMap = {}) {
    if (!Array.isArray(participants) || participants.length === 0) return [];
    const safeCount = Math.max(1, Math.floor(count));

    const pool = [];
    for (const userId of participants) {
        if (exclude.includes(userId)) continue;

        let entries = 1;
        const userRoles = memberRolesMap[userId] || new Set();

        for (const bonus of bonusEntries) {
            if (!bonus.roleId || !bonus.amount) continue;
            const bonusAmount = Math.max(1, parseInt(bonus.amount, 10) || 1);
            // Only grant bonus if the member actually has the bonus role
            if (userRoles && userRoles.has(bonus.roleId)) {
                entries += bonusAmount;
            }
        }

        for (let i = 0; i < entries; i++) pool.push(userId);
    }

    if (pool.length === 0) return [];

    const winners   = [];
    const usedIds   = new Set();
    let   attempts  = 0;
    const maxAttempts = pool.length * 10;

    while (winners.length < safeCount && pool.length > 0 && attempts < maxAttempts) {
        attempts++;
        const idx    = Math.floor(Math.random() * pool.length);
        const userId = pool[idx];
        if (!usedIds.has(userId)) {
            usedIds.add(userId);
            winners.push(userId);
        }
    }

    return winners;
}

// ==================== Build Member Roles Map ====================
async function buildMemberRolesMap(guild, userIds) {
    const map = {};
    if (!guild) return map;

    const chunks  = [];
    const ids     = [...new Set(userIds)];
    for (let i = 0; i < ids.length; i += 50) chunks.push(ids.slice(i, i + 50));

    for (const chunk of chunks) {
        await Promise.all(chunk.map(async (userId) => {
            try {
                const member = guild.members.cache.get(userId)
                            || await guild.members.fetch(userId).catch(() => null);
                if (member) {
                    map[userId] = new Set(member.roles.cache.keys());
                }
            } catch (_) {}
        }));
    }
    return map;
}

// ==================== Create Giveaway ====================
async function createGiveaway(client, options, settings) {
    const {
        channelId, prize, winnersCount, durationMs,
        description, hostedBy, pingRole, imageUrl,
        requiredRole, minAccountAge, minServerAge,
        blacklistRole, minInvites, minMessages,
        bonusRoles, bonusAmounts
    } = options;

    // --- Input validation ---
    if (!channelId || typeof channelId !== 'string') throw new Error('Invalid channelId');
    if (!prize     || typeof prize     !== 'string') throw new Error('Invalid prize');
    const safeWinnersCount = Math.max(1, Math.min(parseInt(winnersCount, 10) || 1, 50));
    const safeDurationMs   = Math.max(10000, parseInt(durationMs, 10) || 0);

    const data   = loadGiveaways();
    const config = data.config || getDefaultConfig();
    const lang   = getLang(settings);
    const emoji  = config.entryEmoji || '🎉';
    const color  = config.defaultColor || '#5865F2';
    const endAt  = Date.now() + safeDurationMs;

    const channel = client.channels.cache.get(channelId);
    if (!channel) throw new Error('Channel not found');

    const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } = require('discord.js');

    const durationStr = msToStr(safeDurationMs, lang);

    const descText = (description ? description + '\n\n' : '') +
        t(lang, `اضغط على ${emoji} للمشاركة!`, `Press ${emoji} to enter!`);

    const embed = new EmbedBuilder()
        .setTitle(getStartTitle(config, lang))
        .setDescription(descText)
        .setColor(color)
        .addFields(
            { name: t(lang, 'الجائزة',     'Prize'),       value: String(prize),             inline: true },
            { name: t(lang, 'الفائزون',    'Winners'),     value: String(safeWinnersCount),   inline: true },
            { name: t(lang, 'ينتهي خلال',  'Ends In'),     value: durationStr,                inline: true }
        )
        .setFooter({ text: t(lang, `بواسطة ${hostedBy || 'السيرفر'} • ينتهي:`, `Hosted by ${hostedBy || 'Server'} • Ends:`) })
        .setTimestamp(endAt);

    if (imageUrl && /^https?:\/\/.+/.test(imageUrl)) embed.setImage(imageUrl);

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('giveaway_enter')
            .setLabel(t(lang, 'شارك', 'Enter'))
            .setEmoji(emoji)
            .setStyle(ButtonStyle.Primary)
    );
    let content;
    if (pingRole === '@everyone' || pingRole === '@here') {
        content = pingRole;
    } else if (pingRole && /^\d+$/.test(pingRole)) {
        content = `<@&${pingRole}>`;
    }

    const msg = await channel.send({ content, embeds: [embed], components: [row] });

    // Requirements
    const requirements = {};
    if (requiredRole)  requirements.requiredRole  = requiredRole;
    if (minAccountAge) requirements.minAccountAge = Math.max(0, parseInt(minAccountAge, 10) || 0);
    if (minServerAge)  requirements.minServerAge  = Math.max(0, parseInt(minServerAge,  10) || 0);
    if (blacklistRole) requirements.blacklistRole = blacklistRole;
    if (minInvites)    requirements.minInvites    = Math.max(0, parseInt(minInvites,    10) || 0);
    if (minMessages)   requirements.minMessages   = Math.max(0, parseInt(minMessages,   10) || 0);

    // Bonus entries
    const bonusEntries = [];
    if (Array.isArray(bonusRoles)) {
        bonusRoles.forEach((roleId, i) => {
            if (roleId && /^\d+$/.test(roleId)) {
                const amount = Math.max(1, parseInt(bonusAmounts?.[i], 10) || 1);
                bonusEntries.push({ roleId, amount });
            }
        });
    }

    const giveaway = {
        messageId:    msg.id,
        channelId,
        guildId:      channel.guild.id,
        prize:        prize.slice(0, 200),
        winnersCount: safeWinnersCount,
        endAt,
        status:       'active',
        participants: [],
        winners:      [],
        hostedBy:     (hostedBy || '').slice(0, 100),
        description:  (description || '').slice(0, 500),
        imageUrl:     imageUrl || '',
        requirements,
        bonusEntries,
        createdAt:    Date.now()
    };

    data.giveaways.push(giveaway);
    saveGiveaways(data);

    return giveaway;
}

// ==================== End Giveaway ====================
async function endGiveaway(client, messageId, settings) {
    const data     = loadGiveaways();
    const config   = data.config || getDefaultConfig();
    const giveaway = data.giveaways.find(g => g.messageId === messageId);
    if (!giveaway || giveaway.status === 'ended') return;

    giveaway.status = 'ended';

    const channel = client.channels.cache.get(giveaway.channelId);
    if (!channel) {
        saveGiveaways(data);
        return;
    }

    const lang  = getLang(settings);
    const guild = client.guilds.cache.get(giveaway.guildId);

    // Build member roles map for proper bonus entry calculation
    const memberRolesMap = await buildMemberRolesMap(guild, giveaway.participants);

    const winners = pickWinners(
        giveaway.participants,
        giveaway.winnersCount,
        giveaway.bonusEntries || [],
        [],
        memberRolesMap
    );
    giveaway.winners = winners;

    const { EmbedBuilder } = require('discord.js');

    const winnersText = winners.length > 0
        ? winners.map(id => `<@${id}>`).join(', ')
        : t(lang, 'لا يوجد مشاركون مؤهلون', 'No eligible participants');

    const embed = new EmbedBuilder()
        .setTitle(getEndTitle(config, lang))
        .setDescription(
            `**${t(lang, 'الجائزة', 'Prize')}:** ${giveaway.prize}\n` +
            `**${t(lang, 'الفائزون', 'Winners')}:** ${winnersText}`
        )
        .setColor('#ED4245')
        .setFooter({ text: t(lang, 'انتهى السحب', 'Giveaway ended') })
        .setTimestamp();

    try {
        const msg = await channel.messages.fetch(messageId).catch(() => null);
        if (msg) {
            if (config.deleteOnEnd) {
                await msg.delete().catch(() => {});
            } else {
                await msg.edit({ embeds: [embed], components: [] }).catch(() => {});
            }
        }
    } catch (_) {}

   if (winners.length > 0) {
        const announceChannel = config.winnersChannel
            ? (client.channels.cache.get(config.winnersChannel) || channel)
            : channel;

        const winEmoji = config.entryEmoji || '🎉';

        await announceChannel.send({
            content: t(
                lang,
                `${winEmoji} تهانينا ${winnersText}! لقد فزتم بـ **${giveaway.prize}**!`,
                `${winEmoji} Congratulations ${winnersText}! You won **${giveaway.prize}**!`
            )
        }).catch(() => {});;

        // DM winners
        if (config.dmWinners && config.winnerDm) {
            for (const userId of winners) {
                try {
                    const member = guild?.members.cache.get(userId)
                                || await guild?.members.fetch(userId).catch(() => null);
                    if (member) {
                        await member.send(
                            config.winnerDm.replace(/\{prize\}/g, giveaway.prize)
                        ).catch(() => {});
                    }
                } catch (_) {}
            }
        }
    }

    // Record winners
 if (!Array.isArray(data.winners)) data.winners = [];
    for (const userId of winners) {
        let username  = userId;
        let avatarURL = null;
        try {
            const member = guild?.members.cache.get(userId)
                        || await guild?.members.fetch(userId).catch(() => null);
            if (member) {
                username  = member.user.username;
                avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 64 });
            }
        } catch (_) {}

        data.winners.push({
            giveawayId:  messageId,
            userId,
            username,
            avatarURL,
            prize:       giveaway.prize,
            wonAt:       Date.now(),
            channelId:   giveaway.channelId,
            channelName: channel.name || giveaway.channelId
        });
    }

    saveGiveaways(data);
    flushSync();
}

// ==================== Pause / Resume ====================
function pauseGiveaway(messageId) {
    const data = loadGiveaways();
    const gw   = data.giveaways.find(g => g.messageId === messageId);
    if (!gw) return false;

    if (gw.status === 'active') {
        gw.status        = 'paused';
        gw.pausedAt      = Date.now();
        gw.remainingTime = Math.max(0, gw.endAt - Date.now());
        saveGiveaways(data);
        return true;
    }
    if (gw.status === 'paused') {
        gw.status = 'active';
        gw.endAt  = Date.now() + (gw.remainingTime || 60000);
        delete gw.pausedAt;
        delete gw.remainingTime;
        saveGiveaways(data);
        return true;
    }
    return false;
}

// ==================== Check Expired Giveaways ====================
async function checkExpiredGiveaways(client, settings) {
    const data = loadGiveaways();
    const now  = Date.now();
    const expired = data.giveaways.filter(
        gw => gw.status === 'active' && gw.endAt <= now
    );
    for (const gw of expired) {
        await endGiveaway(client, gw.messageId, settings).catch(err => {
            console.error(`[Giveaway] Failed to end giveaway ${gw.messageId}:`, err);
        });
    }
}

// ==================== Exports ====================
module.exports = {
    loadGiveaways,
    saveGiveaways,
    flushSync,
    getDefaultConfig,
    createGiveaway,
    endGiveaway,
    pauseGiveaway,
    pickWinners,
    buildMemberRolesMap,
    checkExpiredGiveaways,
    
    msToStr,
    t,
    getLang,
    getStartTitle,
    getEndTitle
};
