const express = require('express');
const { EmbedBuilder, AttachmentBuilder } = require('discord.js');

module.exports = (client, helpers) => {
    const { loadData, getSettings, getGuildChannels, loadEmbedsList, saveEmbedsList, base64ToBuffer } = helpers;
    const router = express.Router();

    // ===== Render Embed Builder Page =====
    router.get('/', async (req, res) => {
        try { await loadData(true); } catch(e) {}
        const embeds = loadEmbedsList();
        res.render('embed-builder', {
            settings:      getSettings(),
            guildChannels: getGuildChannels(),
            embeds
        });
    });

    // ===== List Embeds =====
    router.get('/list', (req, res) => {
        try {
            const embeds = loadEmbedsList();
            res.json({ success: true, embeds });
        } catch(err) {
            res.json({ success: false, error: err.message, embeds: [] });
        }
    });

    // ===== Create Embed =====
    router.post('/create', (req, res) => {
        try {
            const embeds = loadEmbedsList();
            const newEmbed = {
                id: Date.now().toString(),
                createdAt: new Date().toISOString(),
                ...req.body
            };
            embeds.push(newEmbed);
            saveEmbedsList(embeds);
            res.json({ success: true, id: newEmbed.id });
        } catch(err) {
            console.error('❌ خطأ في إنشاء الإمبد:', err);
            res.json({ success: false, error: err.message });
        }
    });

    // ===== Update Embed =====
    router.post('/update/:id', (req, res) => {
        try {
            const embeds = loadEmbedsList();
            const idx = embeds.findIndex(e => e.id === req.params.id);
            if (idx === -1) return res.json({ success: false, error: 'Embed not found' });
            embeds[idx] = { ...embeds[idx], ...req.body, id: req.params.id };
            saveEmbedsList(embeds);
            res.json({ success: true });
        } catch(err) {
            console.error('❌ خطأ في تحديث الإمبد:', err);
            res.json({ success: false, error: err.message });
        }
    });

    // ===== Delete Embed =====
    router.delete('/delete/:id', (req, res) => {
        try {
            let embeds = loadEmbedsList();
            embeds = embeds.filter(e => e.id !== req.params.id);
            saveEmbedsList(embeds);
            res.json({ success: true });
        } catch(err) {
            res.json({ success: false, error: err.message });
        }
    });

    // ===== Send Embed =====
    router.post('/send', async (req, res) => {
        const lang = (req.body && req.body.uiLanguage === 'ar') ? 'ar' : 'en';
        const msg = {
            noChannel:    lang === 'ar' ? 'الرجاء اختيار روم' : 'Please select a channel',
            embedMissing: lang === 'ar' ? 'الإمبد غير موجود' : 'Embed not found',
            chMissing:    lang === 'ar' ? 'الروم غير موجود' : 'Channel not found',
            emptyContent: lang === 'ar' ? 'يجب إضافة محتوى للإمبد' : 'You must add content to the embed',
            sendFail:     lang === 'ar' ? 'حدث خطأ أثناء الإرسال' : 'An error occurred while sending'
        };
        try {
            const { channelId, embedId, embedData } = req.body;
            if (!channelId) return res.json({ success: false, error: msg.noChannel });

            let data = embedData;
            if (embedId) {
                const embeds = loadEmbedsList();
                data = embeds.find(e => e.id === embedId);
                if (!data) return res.json({ success: false, error: msg.embedMissing });
            }

            const channel = client.channels.cache.get(channelId);
            if (!channel) return res.json({ success: false, error: msg.chMissing });

            const hasContent = data.title || data.description || data.authorName || data.footer ||
                (data.fields && data.fields.some(f => f.name || f.value));
            if (!hasContent) {
                return res.json({ success: false, error: msg.emptyContent });
            }

            const embed = new EmbedBuilder();
            const attachments = [];

            if (data.color) embed.setColor(data.color);

            if (data.authorName) {
                const authorObj = { name: data.authorName };
                if (data.authorUrl && data.authorUrl.trim() !== '') {
                    try { new URL(data.authorUrl); authorObj.url = data.authorUrl; } catch(e) {}
                }
                if (data.authorIcon && data.authorIcon.startsWith('data:image')) {
                    const result = base64ToBuffer(data.authorIcon);
                    if (result) {
                        attachments.push(new AttachmentBuilder(result.buffer, { name: `author_icon_${Date.now()}.${result.ext}` }));
                        authorObj.iconURL = `attachment://author_icon_${Date.now()}.${result.ext}`;
                    }
                } else if (data.authorIcon && data.authorIcon.startsWith('http')) {
                    authorObj.iconURL = data.authorIcon;
                }
                embed.setAuthor(authorObj);
            }

            if (data.footer) {
                const footerObj = { text: data.footer };
                if (data.footerIcon && data.footerIcon.startsWith('data:image')) {
                    const result = base64ToBuffer(data.footerIcon);
                    if (result) {
                        attachments.push(new AttachmentBuilder(result.buffer, { name: `footer_icon_${Date.now()}.${result.ext}` }));
                        footerObj.iconURL = `attachment://footer_icon_${Date.now()}.${result.ext}`;
                    }
                } else if (data.footerIcon && data.footerIcon.startsWith('http')) {
                    footerObj.iconURL = data.footerIcon;
                }
                embed.setFooter(footerObj);
            }

            if (data.title) embed.setTitle(data.title);
            if (data.description) embed.setDescription(data.description);

            if (data.fields && data.fields.length > 0) {
                const validFields = data.fields
                    .filter(f => f.name && f.value)
                    .map(f => ({ name: f.name, value: f.value, inline: !!f.inline }));
                if (validFields.length > 0) embed.addFields(validFields);
            }

            const msgPayload = {};
            if (data.msgContent) msgPayload.content = data.msgContent;

            if (data.thumbnail && data.thumbnail.startsWith('data:image')) {
                const result = base64ToBuffer(data.thumbnail);
                if (result) {
                    attachments.push(new AttachmentBuilder(result.buffer, { name: `thumbnail_${Date.now()}.${result.ext}` }));
                    embed.setThumbnail(`attachment://thumbnail_${Date.now()}.${result.ext}`);
                }
            } else if (data.thumbnail && data.thumbnail.startsWith('http')) {
                embed.setThumbnail(data.thumbnail);
            }

            if (data.image && data.image.startsWith('data:image')) {
                const result = base64ToBuffer(data.image);
                if (result) {
                    attachments.push(new AttachmentBuilder(result.buffer, { name: `image_${Date.now()}.${result.ext}` }));
                    embed.setImage(`attachment://image_${Date.now()}.${result.ext}`);
                }
            } else if (data.image && data.image.startsWith('http')) {
                embed.setImage(data.image);
            }

            if (attachments.length > 0) {
                msgPayload.files = attachments;
            }

            msgPayload.embeds = [embed];

            await channel.send(msgPayload);
            res.json({ success: true });

        } catch(err) {
            console.error('❌ خطأ في إرسال الإمبد:', err);
            res.json({ success: false, error: msg.sendFail });
        }
    });

    return router;
}; 