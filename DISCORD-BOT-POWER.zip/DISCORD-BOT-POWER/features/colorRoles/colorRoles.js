const fs = require('fs');
const path = require('path');
const { MessageFlags } = require('discord.js');
const { COLOR_PALETTES } = require('../../slash-commands/color');

// features/colorRoles/colorRoles.js -> يطلع مستويين لفوق عشان يوصل لجذر المشروع
const COLOR_ROLES_FILE = path.join(__dirname, '..', '..', 'colorRolesSettings.json');

function loadColorSettings() {
    if (fs.existsSync(COLOR_ROLES_FILE)) {
        try { return JSON.parse(fs.readFileSync(COLOR_ROLES_FILE, 'utf8')); } catch(e) {}
    }
    return {
        enabled: false,
        selectedPalette: 'rainbow',
        selectedShape: 'circle',
        pickerTitle: 'Colors Picker',
        bgImage: '',
        colorRoleIds: {},
        commands: {
            color:  { enabled: true },
            colors: { enabled: true }
        }
    };
}

function saveColorSettings(data) {
    fs.writeFileSync(COLOR_ROLES_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function registerColorRolesRoutes(app, client, getSettings, loadData, getGuildRoles, getGuildChannels, config) {

    // ==================== عرض صفحة ألوان الرتب ====================
    app.get('/color-roles', async (req, res) => {
        await loadData(true);
        const settings = getSettings();
        const guildRoles = getGuildRoles();
        const guildChannels = getGuildChannels();
        const colorSettings = loadColorSettings();
        const success = req.query.success === 'true';
        res.render('color-roles', { settings, colorSettings, success, guildRoles, guildChannels });
    });

    // ==================== حفظ الإعدادات العامة ====================
    app.post('/color-roles', (req, res) => {
        try {
            const body = req.body;
            const cs   = loadColorSettings();
            cs.enabled         = body.enabled === '1' || body.enabled === 'true' || body.enabled === true;
            cs.selectedPalette = body.selectedPalette || 'rainbow';
            cs.selectedShape   = body.selectedShape   || 'circle';
            cs.pickerTitle     = body.pickerTitle !== undefined ? body.pickerTitle : 'Colors Picker';
            if (body.bgImageData === 'REMOVE') {
                cs.bgImage = '';
            } else if (body.bgImageData && body.bgImageData.startsWith('data:image/')) {
                cs.bgImage = body.bgImageData;
            }
            if (!cs.commands) cs.commands = {};
            cs.commands.color  = Object.assign(cs.commands.color  || {}, { enabled: body.cmd_color  === '1' || body.cmd_color  === 'true' });
            cs.commands.colors = Object.assign(cs.commands.colors || {}, { enabled: body.cmd_colors === '1' || body.cmd_colors === 'true' });
            saveColorSettings(cs);
            res.json({ success: true });
        } catch(e) {
            console.error('❌ خطأ في حفظ color-roles:', e);
            res.json({ success: false, error: e.message });
        }
    });

    // ==================== حفظ إعدادات أمر معين (color/colors) ====================
    app.post('/color-roles/command', (req, res) => {
        try {
            const { cmdKey, aliases, allowedRoles, deniedRoles, allowedChannels, deniedChannels, deleteResponse, deleteCommand } = req.body;
            const validCmds = ['color', 'colors'];
            if (!validCmds.includes(cmdKey)) {
                return res.json({ success: false, error: 'Invalid command' });
            }
            const cs = loadColorSettings();
            if (!cs.commands) cs.commands = {};
            if (!cs.commands[cmdKey]) cs.commands[cmdKey] = { enabled: true };
            cs.commands[cmdKey].aliases         = Array.isArray(aliases)         ? aliases         : (aliases ? [aliases] : []);
            cs.commands[cmdKey].allowedRoles    = Array.isArray(allowedRoles)    ? allowedRoles    : (allowedRoles ? [allowedRoles] : []);
            cs.commands[cmdKey].deniedRoles     = Array.isArray(deniedRoles)     ? deniedRoles     : (deniedRoles ? [deniedRoles] : []);
            cs.commands[cmdKey].allowedChannels = Array.isArray(allowedChannels) ? allowedChannels : (allowedChannels ? [allowedChannels] : []);
            cs.commands[cmdKey].deniedChannels  = Array.isArray(deniedChannels)  ? deniedChannels  : (deniedChannels ? [deniedChannels] : []);
            cs.commands[cmdKey].deleteResponse  = deleteResponse === true || deleteResponse === 'true';
            cs.commands[cmdKey].deleteCommand   = deleteCommand  === true || deleteCommand  === 'true';
            saveColorSettings(cs);
            res.json({ success: true });
        } catch(e) {
            console.error('❌ خطأ في حفظ color-roles/command:', e);
            res.json({ success: false, error: e.message });
        }
    });

    // ==================== إنشاء رتب الألوان فعلياً بالسيرفر ====================
    app.post('/color-roles/create-roles', async (req, res) => {
        try {
            const { palette: paletteKey } = req.body;
            const palette = COLOR_PALETTES[paletteKey];
            if (!palette) return res.json({ success: false, error: 'Invalid palette' });

            const guild = client.guilds.cache.first();
            if (!guild) return res.json({ success: false, error: 'Bot is not in any server' });

            const me = guild.members.me || await guild.members.fetchMe();
            if (!me.permissions.has('ManageRoles')) {
                return res.json({ success: false, error: 'Bot lacks Manage Roles permission' });
            }

            const cs = loadColorSettings();
            if (!cs.colorRoleIds) cs.colorRoleIds = {};

            let created = 0;
            let skipped = 0;

            for (let i = 0; i < palette.colors.length; i++) {
                const color = palette.colors[i];
                const roleName = `Color ${i + 1}`;

                const existingId = cs.colorRoleIds[color.id];
                if (existingId) {
                    const existingRole = guild.roles.cache.get(existingId);
                    if (existingRole) { skipped++; continue; }
                }

                let role = guild.roles.cache.find(r => r.name === roleName);

                if (!role) {
                 role = await guild.roles.create({
                    name:        roleName,
                    colors:      { primaryColor: color.hex },
                    permissions: 0n,
                    mentionable: false,
                    hoist:       false,
                    reason:      'Color Roles System'
                });
                    created++;
                }

                cs.colorRoleIds[color.id] = role.id;
            }

            cs.selectedPalette = paletteKey;
            saveColorSettings(cs);
            await loadData(true);

            res.json({ success: true, created, skipped });

        } catch(e) {
            console.error('❌ خطأ في create-roles:', e);
            res.json({ success: false, error: e.message });
        }
    });

    // ==================== حذف جميع رتب الألوان من السيرفر ====================
    app.post('/color-roles/delete-roles', async (req, res) => {
        try {
            const guild = client.guilds.cache.first();
            if (!guild) return res.json({ success: false, error: 'Bot is not in any server' });

            const me = guild.members.me || await guild.members.fetchMe();
            if (!me.permissions.has('ManageRoles')) {
                return res.json({ success: false, error: 'Bot lacks Manage Roles permission' });
            }

            const cs = loadColorSettings();
            if (!cs.colorRoleIds) cs.colorRoleIds = {};

            const roleIds = Object.values(cs.colorRoleIds);
            let deleted = 0;
            let failed  = 0;

            for (const roleId of roleIds) {
                const role = guild.roles.cache.get(roleId);
                if (!role) continue;
                try {
                    await role.delete('Color Roles System - Delete All');
                    deleted++;
                } catch(err) {
                    console.error(`⚠️ فشل حذف رتبة ${roleId}:`, err.message);
                    failed++;
                }
            }

            cs.colorRoleIds = {};
            saveColorSettings(cs);
            await loadData(true);

            res.json({ success: true, deleted, failed });

        } catch(e) {
            console.error('❌ خطأ في delete-roles:', e);
            res.json({ success: false, error: e.message });
        }
    });
}

// ==================== معالج اختيار اللون من القائمة (Discord) ====================
async function handleColorRolePicker(interaction, client, settings) {
    try {
        const colorCmd = require('../../slash-commands/color');
        await colorCmd.handleColorPicker(interaction, client, settings);
    } catch(e) {
        console.error('❌ خطأ في color_role_picker:', e);
        if (!interaction.replied && !interaction.deferred) {
            await interaction.reply({
                content: '❌ حدث خطأ.',
                flags: MessageFlags.Ephemeral
            }).catch(() => {});
        }
    }
}

module.exports = {
    registerColorRolesRoutes,
    handleColorRolePicker,
    loadColorSettings,
    saveColorSettings
};