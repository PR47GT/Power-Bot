module.exports = {
    name: 'guildMemberAdd',
    once: false,

    async execute(client, settings, member) {
        // التحقق من وجود إعدادات الرتب التلقائية
        if (!settings.autoRole) return;

        // ==================== أشخاص محددين (تُعطى بالإضافة لرتبة العضو/البوت) ====================
        // إذا كان معرف العضو ضمن القائمة، يأخذ رتبته المخصصة ثم نكمل لإعطائه رتبة العضو/البوت أيضاً
        if (Array.isArray(settings.autoRole.specificUsers) && settings.autoRole.specificUsers.length > 0) {
            const entry = settings.autoRole.specificUsers.find(
                (e) => e && e.userId && e.userId === member.user.id
            );

            if (entry && entry.roleId) {
                try {
                    const role = member.guild.roles.cache.get(entry.roleId);
                    if (role) {
                        await member.roles.add(role);
                    }
                } catch (error) {
                    console.error(`❌ Failed to add specific user role:`, error.message);
                }
            }
        }

        // ==================== إذا كان العضو بوتاً ====================
        if (member.user.bot) {
            if (settings.autoRole.botRoleId && settings.autoRole.botRoleId !== '') {
                try {
                    const role = member.guild.roles.cache.get(settings.autoRole.botRoleId);
                    if (role) {
                        await member.roles.add(role);

                    }
                } catch (error) {
                    // فقط الأخطاء تظهر
                    console.error(`❌ Failed to add bot role:`, error.message);
                }
            }
            return;
        }

        // ==================== إذا كان العضو مستخدماً عادياً ====================
        if (settings.autoRole.memberRoleId && settings.autoRole.memberRoleId !== '') {
            try {
                const role = member.guild.roles.cache.get(settings.autoRole.memberRoleId);
                if (role) {
                    await member.roles.add(role);

                }
            } catch (error) {
                console.error(`❌ Failed to add member role:`, error.message);
            }
        }
    }
};
