const fs = require('fs');
const path = require('path');

const LEVEL_DATA_FILE   = path.join(__dirname, '../levelData.json');
const LEVEL_SYSTEM_FILE = path.join(__dirname, '../levelSystem.json');

const XP_COOLDOWN = 60 * 1000;
const XP_MIN = 15;
const XP_MAX = 25;

const cooldowns = new Map();

function loadLevelData() {
    if (fs.existsSync(LEVEL_DATA_FILE)) {
        try { return JSON.parse(fs.readFileSync(LEVEL_DATA_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function saveLevelData(data) {
    fs.writeFileSync(LEVEL_DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function loadLevelSystem() {
    if (fs.existsSync(LEVEL_SYSTEM_FILE)) {
        try { return JSON.parse(fs.readFileSync(LEVEL_SYSTEM_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function calcLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp));
}

function xpForLevel(level) {
    return Math.pow(level / 0.1, 2);
}

module.exports = {
    name: 'messageCreate',

    async execute(client, settings, message) {
        try {
            if (message.author.bot) return;
            if (!message.guild) return;

            const levelSystem = loadLevelSystem();
            const xpSettings  = levelSystem.xpSettings || {};

            // ── قنوات معطّلة ──
            if (xpSettings.disabledChannels && xpSettings.disabledChannels.includes(message.channelId)) return;

            // ── رتب معطّلة ──
            if (xpSettings.disabledRoles && xpSettings.disabledRoles.length > 0) {
                const hasDisabledRole = xpSettings.disabledRoles.some(roleId => message.member.roles.cache.has(roleId));
                if (hasDisabledRole) return;
            }

            const userId = message.author.id;

            const lastTime = cooldowns.get(userId) || 0;
            const now = Date.now();
            if (now - lastTime < XP_COOLDOWN) return;
            cooldowns.set(userId, now);

            const levelData = loadLevelData();
            if (!levelData[userId]) {
                levelData[userId] = { chatXP: 0, voiceXP: 0, chatLevel: 0, voiceLevel: 0 };
            }

            if (levelData[userId].xp !== undefined && levelData[userId].chatXP === undefined) {
                levelData[userId].chatXP    = levelData[userId].xp || 0;
                levelData[userId].voiceXP   = 0;
                levelData[userId].chatLevel  = calcLevel(levelData[userId].chatXP);
                levelData[userId].voiceLevel = 0;
                delete levelData[userId].xp;
            }

            let gainedXP = Math.floor(Math.random() * (XP_MAX - XP_MIN + 1)) + XP_MIN;

            // ── مضاعف الرتبة ──
            const roleMultipliers = xpSettings.roleMultipliers || [];
            if (roleMultipliers.length > 0) {
                const hasMultiplierRole = roleMultipliers.some(roleId => message.member.roles.cache.has(roleId));
                if (hasMultiplierRole) gainedXP = Math.floor(gainedXP * 2);
            }

            // ── مضاعف القناة ──
            const channelMultipliers = xpSettings.channelMultipliers || [];
            if (channelMultipliers.includes(message.channelId)) {
                gainedXP = Math.floor(gainedXP * 2);
            }

            const oldLevel = levelData[userId].chatLevel || 0;
            levelData[userId].chatXP = (levelData[userId].chatXP || 0) + gainedXP;
            const newLevel = calcLevel(levelData[userId].chatXP);
            levelData[userId].chatLevel = newLevel;

            saveLevelData(levelData);

            if (newLevel > oldLevel) {
                const notifications  = levelSystem.levelUpNotifications || {};
                const notifChannelId = notifications.channelId || '';
                const msgTemplate    = notifications.message || 'Congratulations {user}! You reached level {level}!';
                const notifMessage   = msgTemplate
                    .replace('{user}',  `<@${userId}>`)
                    .replace('{level}', newLevel);

                const targetChannel = notifChannelId
                    ? message.guild.channels.cache.get(notifChannelId)
                    : message.channel;

                if (targetChannel) {
                    targetChannel.send(notifMessage).catch(() => {});
                }

                const levelRewards = levelSystem.levelRewards || [];
                for (const reward of levelRewards) {
                    if (
                        reward.roleId &&
                        reward.xpLevel > 0 &&
                        oldLevel < reward.xpLevel &&
                        newLevel >= reward.xpLevel
                    ) {
                        try {
                            const guild = message.guild;

                            const member = await guild.members.fetch(userId).catch(() => null);
                            if (!member) continue;

                            if (reward.removeHigherRoles) {
                                for (const otherReward of levelRewards) {
                                    if (otherReward.roleId && otherReward.xpLevel < reward.xpLevel) {
                                        await member.roles.remove(otherReward.roleId).catch(() => {});
                                    }
                                }
                            }

                            const freshMember = await guild.members.fetch(userId).catch(() => null);
                            if (!freshMember) continue;

                            await freshMember.roles.add(reward.roleId).catch((e) => {
                                console.error(`❌ فشل إضافة رتبة المكافأة ${reward.roleId}:`, e.message);
                            });

                            if (reward.sendDM) {
                                const isAr = settings?.botLanguage === 'ar';
                                const dmMsg = isAr
                                    ? `🎉 حصلت على رتبة مكافأة لوصولك إلى المستوى ${newLevel}!`
                                    : `🎉 You've been given a role reward for reaching level ${newLevel}!`;
                                message.author.send(dmMsg).catch(() => {});
                            }
                        } catch(e) {
                            console.error('❌ خطأ في إضافة رتبة المكافأة:', e.message);
                        }
                    }
                }
            }

        } catch(err) {
            console.error('❌ خطأ في chat XP tracker:', err.message);
        }
    }
};