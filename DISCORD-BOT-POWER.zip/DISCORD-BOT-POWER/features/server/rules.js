const fs = require('fs');
const path = require('path');
const {
    EmbedBuilder, StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
    ActionRowBuilder, MessageFlags
} = require('discord.js');

// features/server/rules.js -> يطلع مستويين لفوق عشان يوصل لجذر المشروع
const RULES_FILE = path.join(__dirname, '..', '..', 'rulesSystem.json');

function loadRulesSettings() {
    if (fs.existsSync(RULES_FILE)) {
        try { return JSON.parse(fs.readFileSync(RULES_FILE, 'utf8')); } catch(e) {}
    }
    return { rulesChannelId: '', useEmbed: true, embedDescription: '', embedColor: '#5865F2', rules: [] };
}

function saveRulesSettings(data) {
    fs.writeFileSync(RULES_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function registerRulesRoutes(app, client, getSettings, loadData, getGuildChannels, config) {

    // ==================== عرض صفحة القواعد بالداشبورد ====================
    app.get('/rules', async (req, res) => {
        await loadData(true);
        const settings = getSettings();
        const guildChannels = getGuildChannels();
        const rulesSettings = loadRulesSettings();
        const success = req.query.success === 'true';
        const error   = req.query.error === 'true';
        const guildEmojis = [];
        try {
            const guild = client.guilds.cache.first();
            if (guild) {
                guild.emojis.cache.forEach(e => {
                    guildEmojis.push({ id: e.id, name: e.name, animated: e.animated });
                });
                guildEmojis.sort((a, b) => a.name.localeCompare(b.name));
            }
        } catch(e) {}
        res.render('rules', { settings, guildChannels, rulesSettings, guildEmojis, success, error });
    });

    // ==================== حفظ إعدادات القواعد ====================
    app.post('/rules', (req, res) => {
        try {
            const rs = loadRulesSettings();
            rs.rulesChannelId   = req.body.rulesChannelId   || '';
            rs.useEmbed         = req.body.useEmbed === '1';
            rs.embedDescription = req.body.embedDescription || '';
            rs.embedColor       = req.body.embedColor       || '#5865F2';
            try { rs.rules = JSON.parse(req.body.rulesData || '[]'); } catch(e) { rs.rules = []; }
            saveRulesSettings(rs);
            if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
                return res.json({ success: true });
            }
            res.redirect('/rules?success=true');
        } catch(e) {
            console.error('خطأ في حفظ القواعد:', e);
            if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
                return res.json({ success: false, error: e.message });
            }
            res.redirect('/rules?error=true');
        }
    });

    // ==================== إرسال رسالة القواعد للقناة ====================
    app.post('/api/rules/send', async (req, res) => {
        try {
            const settings = getSettings();
            const rs = loadRulesSettings();
            const channelId = req.body.channelId || rs.rulesChannelId;
            if (!channelId) return res.json({ ok: false, error: 'No channel configured' });

            const guild = client.guilds.cache.first();
            if (!guild) return res.json({ ok: false, error: 'Bot not in guild' });

            const channel = guild.channels.cache.get(channelId)
                         || await guild.channels.fetch(channelId).catch(() => null);
            if (!channel) return res.json({ ok: false, error: 'Channel not found' });

            const rules = rs.rules || [];
            if (rules.length === 0) return res.json({ ok: false, error: 'No rules configured' });

            const isEn = (settings.botLanguage === 'en');

            const options = rules.slice(0, 25).map((rule, i) => {
                const label = (rule.title || `${isEn ? 'Rule' : 'القاعدة'} ${i + 1}`).substring(0, 100);
                const opt = new StringSelectMenuOptionBuilder()
                    .setLabel(label)
                    .setValue(String(i))
                    .setDescription(isEn ? 'Click to view rule details' : 'انقر لعرض تفاصيل القاعدة');

                const em = rule.emoji ? rule.emoji.match(/<(a?):(\w+):(\d+)>/) : null;
                if (em) opt.setEmoji({ id: em[3], name: em[2] });
                else if (rule.emoji && rule.emoji.trim()) opt.setEmoji(rule.emoji.trim());
                else opt.setEmoji('📜');

                return opt;
            });

            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('view_rule_select')
                .setPlaceholder(isEn ? 'Select a rule to view…' : 'اختر قاعدة للعرض…')
                .addOptions(options);

            const row = new ActionRowBuilder().addComponents(selectMenu);

            const mainEmbed = new EmbedBuilder()
                .setColor(rs.embedColor || '#5865F2')
                .setTitle(isEn ? '📜 Server Rules' : '📜 قواعد السيرفر')
                .setDescription(rs.embedDescription || (isEn ? 'Please read and follow all rules.' : 'يرجى قراءة وإتباع جميع القواعد.'))
                .setTimestamp();

            await channel.send({ embeds: [mainEmbed], components: [row] });
            res.json({ ok: true });
        } catch(err) {
            console.error('خطأ في إرسال القواعد:', err);
            res.json({ ok: false, error: err.message });
        }
    });
}

// ==================== معالج اختيار القاعدة من القائمة (Discord) ====================
async function handleRuleSelectMenu(interaction, client, settings) {
    try {
        const ruleIdx = parseInt(interaction.values[0]);
        const rs = loadRulesSettings();
        const rule = (rs.rules || [])[ruleIdx];
        const isEn = (settings.botLanguage === 'en');

        if (!rule) {
            return interaction.reply({
                content: isEn ? '❌ Rule not found.' : '❌ القاعدة غير موجودة.',
                flags: MessageFlags.Ephemeral
            });
        }

        const emojiPrefix = rule.emoji ? rule.emoji + ' ' : '';
        const ruleTitle = `${emojiPrefix}${ruleIdx + 1}. ${rule.title || (isEn ? 'Rule' : 'القاعدة')}`;
        const ruleDesc = rule.description || (isEn ? '*No description.*' : '*لا يوجد وصف.*');

        if (rs.useEmbed !== false) {
            const detailEmbed = new EmbedBuilder()
                .setTitle(ruleTitle)
                .setDescription(ruleDesc)
                .setColor(rs.embedColor || '#5865F2')
                .setFooter({ text: isEn ? 'Only you can see this message.' : 'هذه الرسالة مرئية لك فقط.' });
            await interaction.reply({ embeds: [detailEmbed], flags: MessageFlags.Ephemeral });
        } else {
            await interaction.reply({
                content: `**${ruleTitle}**\n${ruleDesc}`,
                flags: MessageFlags.Ephemeral
            });
        }
    } catch(e) {
        console.error('view_rule_select error:', e);
        await interaction.reply({
            content: '❌ Error loading rule.',
            flags: MessageFlags.Ephemeral
        }).catch(() => {});
    }
}

module.exports = {
    registerRulesRoutes,
    handleRuleSelectMenu,
    loadRulesSettings,
    saveRulesSettings
};