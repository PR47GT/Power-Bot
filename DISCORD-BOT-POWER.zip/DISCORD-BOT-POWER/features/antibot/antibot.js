// ==================== features/antibot/antibot.js ====================
// Anti-Bot Protection — handles detection & action for bot accounts ONLY.
//
// Human member verification (button/captcha/DM, suspicious-pattern scoring,
// account-age checks, raid detection, similar-name heuristics, whitelist
// roles for humans, verification timeout, member logs) lives in
// `./verification.js`. This module returns early for any non-bot account.
//
// Public surface (kept stable for the central interaction router):
//   • name         : 'guildMemberAdd'
//   • once         : false
//   • execute()    : guildMemberAdd handler
//   • handleBotApproval(interaction, client)
//   • pendingBotApprovals : Map<botId, approvalState>
// ─────────────────────────────────────────────────────────────────────

'use strict';

const fs   = require('fs');
const path = require('path');
const {
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    MessageFlags
} = require('discord.js');


// ════════════════════════════════════════════════════════════════════
//  1. CONSTANTS
// ════════════════════════════════════════════════════════════════════

const ANTIBOT_FILE  = path.join(__dirname, '../../antibot.json');
const SETTINGS_FILE = path.join(__dirname, '../../data.json');

const APPROVAL_TIMEOUT_DEFAULT_MIN = 15;
const APPROVAL_TIMEOUT_MIN_MIN     = 1;
const APPROVAL_TIMEOUT_MAX_MIN     = 60;

const REASON_PREFIX              = '[Anti-Bot]';
const REASON_APPROVAL_TIMEOUT    = '[Anti-Bot] Approval timeout';
const REASON_NO_APPROVAL_CHANNEL = '[Anti-Bot] No approval channel configured';
const REASON_OWNER_REJECTION     = '[Anti-Bot] Rejected by server owner';

const COLOR_BOT_LOG    = '#FF6B35';
const COLOR_APPROVAL   = '#FAA61A';
const COLOR_EXPIRED    = '#ED4245';
const COLOR_APPROVED   = '#57F287';
const COLOR_REJECTED   = '#ED4245';


// ════════════════════════════════════════════════════════════════════
//  2. INTERNAL STATE
// ════════════════════════════════════════════════════════════════════

/** botId → { guildId, timeoutId, approvalMessage, botTag, joinedAt } */
const pendingBotApprovals = new Map();


// ════════════════════════════════════════════════════════════════════
//  3. CONFIGURATION  —  file I/O, language, localized strings
// ════════════════════════════════════════════════════════════════════

function getBotLang() {
    try {
        const s = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
        return s.botLanguage === 'en' ? 'en' : 'ar';
    } catch {
        return 'ar';
    }
}

function t() {
    return LANG[getBotLang()];
}

const LANG = {
    ar: {
        // Detection
        unauthorizedBot:     'بوت Discord غير مصرح به',

        // Action labels (bot-only)
        actionKick:          '🦵 طرد',
        actionBan:           '🔨 حظر',
        actionNone:          '👁️ مراقبة فقط',
        actionApprove:       '⏳ في انتظار الموافقة',

        // Bot log embed
        titleBot:            '🤖 بوت غير مصرح به',
        fieldUser:           '👤 المستخدم',
        fieldType:           '🤖 النوع',
        fieldReasons:        '⚠️ أسباب الكشف',
        fieldAction:         '⚡ الإجراء',
        botTypeValue:        'بوت Discord رسمي',
        notifyMention:       (role) => `${role} 🚨 تنبيه: تم كشف بوت غير مصرح به!`,

        // Approval request
        approvalTitle:       '🤖 بوت جديد يطلب الانضمام — يحتاج موافقة',
        fieldBotName:        '🤖 اسم البوت',
        fieldBotId:          '🆔 ID',
        fieldCreatedAt:      '📅 تاريخ الإنشاء',
        fieldTimeout:        '⏰ المهلة',
        timeoutValue:        (min) => `إذا لم يُتخذ قرار خلال **${min} دقيقة** سيُطرد البوت تلقائياً`,
        approveBtn:          '✅ قبول البوت',
        rejectKickBtn:       '🦵 رفض (طرد)',
        rejectBanBtn:        '🔨 رفض (حظر)',
        ownerMentionText:    '🔔 بوت جديد يحتاج موافقتك:',
        noApprovalChannel:   REASON_NO_APPROVAL_CHANNEL,

        // Approval handler
        notGuildError:       '❌ لا يمكن تنفيذ هذا الإجراء.',
        ownerOnlyError:      '❌ فقط صاحب السيرفر يستطيع قبول أو رفض البوتات.',
        approvedTitle:       '✅ تم قبول البوت',
        approvedDesc:        (tag, id, userId) =>
            `البوت **${tag || id}** تم قبوله وإضافته للقائمة البيضاء.\nقرار: <@${userId}>`,
        bannedTitle:         '🔨 تم حظر البوت',
        kickedTitle:         '🦵 تم طرد البوت',
        rejectedDesc:        (tag, id, isBan, userId) =>
            `البوت **${tag || id}** تم ${isBan ? 'حظره' : 'طرده'}.\nقرار: <@${userId}>`,
        rejectReason:        REASON_OWNER_REJECTION,
        expiredTitle:        '⏰ انتهت المهلة — تم طرد البوت تلقائياً',
        expiredDesc:         (tag, min) =>
            `البوت **${tag}** تم طرده لعدم الرد خلال ${min} دقيقة.`,
    },
    en: {
        // Detection
        unauthorizedBot:     'Unauthorized Discord bot',

        // Action labels (bot-only)
        actionKick:          '🦵 Kick',
        actionBan:           '🔨 Ban',
        actionNone:          '👁️ Monitor only',
        actionApprove:       '⏳ Pending approval',

        // Bot log embed
        titleBot:            '🤖 Unauthorized Bot',
        fieldUser:           '👤 User',
        fieldType:           '🤖 Type',
        fieldReasons:        '⚠️ Detection Reasons',
        fieldAction:         '⚡ Action',
        botTypeValue:        'Official Discord Bot',
        notifyMention:       (role) => `${role} 🚨 Alert: Detected an unauthorized bot!`,

        // Approval request
        approvalTitle:       '🤖 New Bot Requesting to Join — Needs Approval',
        fieldBotName:        '🤖 Bot Name',
        fieldBotId:          '🆔 ID',
        fieldCreatedAt:      '📅 Created',
        fieldTimeout:        '⏰ Timeout',
        timeoutValue:        (min) => `If no decision is made within **${min} minutes**, the bot will be kicked automatically.`,
        approveBtn:          '✅ Approve Bot',
        rejectKickBtn:       '🦵 Reject (Kick)',
        rejectBanBtn:        '🔨 Reject (Ban)',
        ownerMentionText:    '🔔 A new bot needs your approval:',
        noApprovalChannel:   REASON_NO_APPROVAL_CHANNEL,

        // Approval handler
        notGuildError:       '❌ Cannot perform this action.',
        ownerOnlyError:      '❌ Only the server owner can approve or reject bots.',
        approvedTitle:       '✅ Bot Approved',
        approvedDesc:        (tag, id, userId) =>
            `Bot **${tag || id}** has been approved and whitelisted.\nDecision by: <@${userId}>`,
        bannedTitle:         '🔨 Bot Banned',
        kickedTitle:         '🦵 Bot Kicked',
        rejectedDesc:        (tag, id, isBan, userId) =>
            `Bot **${tag || id}** has been ${isBan ? 'banned' : 'kicked'}.\nDecision by: <@${userId}>`,
        rejectReason:        REASON_OWNER_REJECTION,
        expiredTitle:        '⏰ Timeout — Bot was automatically kicked',
        expiredDesc:         (tag, min) =>
            `Bot **${tag}** was kicked for no response within ${min} minutes.`,
    }
};

// ── Settings I/O ───────────────────────────────────────────────────

function loadAntibot() {
    if (!fs.existsSync(ANTIBOT_FILE)) return { enabled: false };
    try {
        return JSON.parse(fs.readFileSync(ANTIBOT_FILE, 'utf8'));
    } catch (err) {
        console.error('❌ [Anti-Bot] Failed to parse antibot.json:', err.message);
        return { enabled: false };
    }
}

function saveAntibot(data) {
    try {
        fs.writeFileSync(ANTIBOT_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (err) {
        console.error('❌ [Anti-Bot] Failed to write antibot.json:', err.message);
    }
}

 


// ════════════════════════════════════════════════════════════════════
//  4. WHITELIST MANAGEMENT  —  trusted/approved bot IDs
// ════════════════════════════════════════════════════════════════════

function getTrustedBots(antibot) {
    return Array.isArray(antibot.trustedBots) ? antibot.trustedBots : [];
}

function isTrustedBot(antibot, botId) {
    return getTrustedBots(antibot).includes(botId);
}

function addTrustedBot(antibot, botId) {
    antibot.trustedBots = getTrustedBots(antibot);
    if (!antibot.trustedBots.includes(botId)) {
        antibot.trustedBots.push(botId);
        saveAntibot(antibot);
    }
}


// ════════════════════════════════════════════════════════════════════
//  5. DETECTION  —  bot gating
// ════════════════════════════════════════════════════════════════════

/**
 * Should this module act on the given member?
 *  • Anti-Bot must be enabled
 *  • Member must be a Discord bot account
 *  • Bot must not already be on the trusted list
 */
function shouldHandle(antibot, member) {
    if (!antibot.enabled)          return false;
    if (!member.user || !member.user.bot) return false;
    return true;
}


// ════════════════════════════════════════════════════════════════════
//  6. ACTIONS  —  execute the configured bot action
// ════════════════════════════════════════════════════════════════════

/**
 * Apply the configured bot action.
 *
 * @param {GuildMember} member
 * @param {'kick'|'ban'|'none'} action
 * @param {string[]}   reasons
 * @param {object}     antibot   antibot settings (botLogsChannel, logsChannel, notifyAdmins, stats)
 * @returns {Promise<void>}
 */
async function applyBotAction(member, action, reasons, antibot) {
    const reasonText = `${REASON_PREFIX} ${reasons.join(', ')}`;

    try {
        switch (action) {
            case 'kick':
                if (member.kickable) {
                    await member.kick(reasonText);
                }
                break;
            case 'ban':
                if (member.bannable) {
                    await member.ban({ reason: reasonText, deleteMessageSeconds: 0 });
                }
                break;
            case 'none':
            default:
                // monitor-only — still log it
                break;
        }
    } catch (err) {
        console.error(`❌ [Anti-Bot] Bot action error (${action}):`, err.message);
    }

    incrementBlockedStat(antibot);
    await sendBotLog(member, reasons, action, antibot);
}

function incrementBlockedStat(antibot) {
    antibot.stats = antibot.stats || {};
    antibot.stats.blockedWeek = (antibot.stats.blockedWeek || 0) + 1;
    saveAntibot(antibot);
}


// ════════════════════════════════════════════════════════════════════
//  7. LOGGING  —  bot log embed + approval request
// ════════════════════════════════════════════════════════════════════

/**
 * Resolve the configured bot-logs channel (fallback to general logs).
 */
function resolveBotLogChannel(member, antibot) {
    const channelId = antibot.botLogsChannel || antibot.logsChannel;
    if (!channelId) return null;
    return member.guild.channels.cache.get(channelId) || null;
}

 

/**
 * Send a detection log embed to the bot-logs channel.
 */
async function sendBotLog(member, reasons, action, antibot) {
    try {
        const channel = resolveBotLogChannel(member, antibot);
        if (!channel) return;

        const T = t();
        const actionLabels = {
            kick:    T.actionKick,
            ban:     T.actionBan,
            none:    T.actionNone,
            approve: T.actionApprove
        };

        const embed = new EmbedBuilder()
            .setTitle(T.titleBot)
            .setColor(action === 'approve' ? COLOR_APPROVAL : COLOR_BOT_LOG)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: T.fieldUser,    value: `${member.user.tag} (${member.id})`, inline: true  },
                { name: T.fieldType,    value: T.botTypeValue,                       inline: true  },
                { name: T.fieldReasons, value: reasons.length ? reasons.map(r => `• ${r}`).join('\n') : '—' },
                { name: T.fieldAction,  value: actionLabels[action] || action,       inline: true  }
            )
            .setTimestamp()
            .setFooter({ text: 'Bot Detection' });

let mention = null;
if (antibot.notifyAdmins) {
    mention = T.notifyMention('@here');
}

const actionDetails = {
    kick:    '🦵 ' + (getBotLang() === 'ar' ? 'تم الطرد فوراً'              : 'Kicked immediately'),
    ban:     '🔨 ' + (getBotLang() === 'ar' ? 'تم الحظر فوراً'              : 'Banned immediately'),
    none:    '👁️ ' + (getBotLang() === 'ar' ? 'مراقبة فقط'                 : 'Monitoring only'),
    approve: '⏳ ' + (getBotLang() === 'ar' ? 'في انتظار موافقة صاحب السيرفر' : 'Pending owner approval')
};

embed.addFields(
    { name: getBotLang() === 'ar' ? '🕐 وقت الدخول' : '🕐 Joined At',
      value: `<t:${Math.floor(Date.now() / 1000)}:R>`, inline: true },
    { name: getBotLang() === 'ar' ? '📅 تاريخ إنشاء الحساب' : '📅 Account Created',
      value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
    { name: getBotLang() === 'ar' ? '📋 تفاصيل الإجراء' : '📋 Action Details',
      value: actionDetails[action] || action, inline: false }
);

await channel.send({ content: mention, embeds: [embed], allowedMentions: { parse: ['everyone'] } });
    } catch (err) {
        console.error('❌ [Anti-Bot] Bot log send error:', err.message);
    }
}

/**
 * Send an approval request for an unauthorized bot.
 * The server owner can approve, reject-kick, or reject-ban.
 */
async function sendBotApprovalRequest(member, antibot) {
    const guild          = member.guild;
    const T              = t();

    const timeoutMinutes = Math.min(
        Math.max(antibot.botApprovalTimeout || APPROVAL_TIMEOUT_DEFAULT_MIN, APPROVAL_TIMEOUT_MIN_MIN),
        APPROVAL_TIMEOUT_MAX_MIN
    );
    const approvalMs = timeoutMinutes * 60 * 1000;

    const channelId = antibot.botApprovalChannel || antibot.botLogsChannel || antibot.logsChannel;
    const approvalChannel = channelId ? guild.channels.cache.get(channelId) : null;

    if (!approvalChannel) {
        console.warn('⚠️ [Anti-Bot] No approval channel configured — kicking bot immediately');
        try {
            if (member.kickable) await member.kick(T.noApprovalChannel);
        } catch (err) {
            console.error('❌ [Anti-Bot] Fallback kick failed:', err.message);
        }
        return;
    }

    const embed = new EmbedBuilder()
        .setTitle(T.approvalTitle)
        .setColor(COLOR_APPROVAL)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .addFields(
            { name: T.fieldBotName,   value: `**${member.user.tag}**`,                                    inline: true },
            { name: T.fieldBotId,     value: `\`${member.id}\``,                                           inline: true },
            { name: T.fieldCreatedAt, value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: false },
            { name: T.fieldTimeout,   value: T.timeoutValue(timeoutMinutes),                              inline: false }
        )
        .setTimestamp()
        .setFooter({ text: 'Anti-Bot Approval System' });

    const row = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`bot_approve_${member.id}_${guild.id}`)
            .setLabel(T.approveBtn)
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId(`bot_reject_kick_${member.id}_${guild.id}`)
            .setLabel(T.rejectKickBtn)
            .setStyle(ButtonStyle.Danger),
        new ButtonBuilder()
            .setCustomId(`bot_reject_ban_${member.id}_${guild.id}`)
            .setLabel(T.rejectBanBtn)
            .setStyle(ButtonStyle.Danger)
    );

    const owner = await guild.fetchOwner().catch(() => null);
    const ownerMention = owner ? `<@${owner.id}>` : '';

    let approvalMessage = null;
    try {
        approvalMessage = await approvalChannel.send({
            content: ownerMention ? `${ownerMention} ${T.ownerMentionText}` : null,
            embeds: [embed],
            components: [row]
        });
    } catch (err) {
        console.error('❌ [Anti-Bot] Failed to send approval message:', err.message);
        return;
    }

    const botId  = member.id;
    const botTag = member.user.tag;

    const timeoutId = setTimeout(async () => {
        pendingBotApprovals.delete(botId);

        if (approvalMessage) {
            try {
                const expiredEmbed = new EmbedBuilder()
                    .setTitle(T.expiredTitle)
                    .setColor(COLOR_EXPIRED)
                    .setDescription(T.expiredDesc(botTag, timeoutMinutes))
                    .setTimestamp();
                await approvalMessage.edit({ embeds: [expiredEmbed], components: [] });
            } catch { /* message may have been deleted — ignore */ }
        }

        const stillMember = await guild.members.fetch(botId).catch(() => null);
        if (stillMember && stillMember.kickable) {
            await stillMember.kick(REASON_APPROVAL_TIMEOUT).catch(() => {});
        }
    }, approvalMs);

    pendingBotApprovals.set(botId, {
        guildId:         guild.id,
        timeoutId,
        approvalMessage,
        botTag,
        joinedAt:        Date.now()
    });
}


// ════════════════════════════════════════════════════════════════════
//  8. EVENT HANDLERS  —  guildMemberAdd + approval buttons
// ════════════════════════════════════════════════════════════════════

/**
 * Process approve/reject button interactions for pending bot approvals.
 * Called from the central interaction router.
 *
 * @param  {Interaction} interaction
 * @param  {Client}      _client  (kept for signature compatibility — unused)
 * @returns {Promise<boolean>} true if this handler consumed the interaction
 */
async function handleBotApproval(interaction, _client) {
    const customId = interaction.customId;
    if (!customId.startsWith('bot_approve_') && !customId.startsWith('bot_reject_')) {
        return false;
    }

    const T = t();

    const guild = interaction.guild;
    if (!guild) {
        await interaction.reply({ content: T.notGuildError, flags: MessageFlags.Ephemeral });
        return true;
    }

    if (interaction.user.id !== guild.ownerId) {
        await interaction.reply({ content: T.ownerOnlyError, flags: MessageFlags.Ephemeral });
        return true;
    }

    // customId format: bot_approve_<botId>_<guildId>
    //                  bot_reject_kick_<botId>_<guildId>
    //                  bot_reject_ban_<botId>_<guildId>
    const parts = customId.split('_');
    const botId = parts[parts.length - 2];

    const pending = pendingBotApprovals.get(botId);
    if (pending) {
        clearTimeout(pending.timeoutId);
        pendingBotApprovals.delete(botId);
    }

    const antibot = loadAntibot();

    // ─── Approve ────────────────────────────────────────────
    if (customId.startsWith('bot_approve_')) {
        await interaction.update({
            content: null,
            embeds: [new EmbedBuilder()
                .setTitle(T.approvedTitle)
                .setColor(COLOR_APPROVED)
                .setDescription(T.approvedDesc(pending?.botTag, botId, interaction.user.id))
                .setTimestamp()],
            components: []
        });
        return true;
    }

    // ─── Reject ─────────────────────────────────────────────
    const isBan = customId.startsWith('bot_reject_ban_');

    await interaction.deferUpdate().catch(() => {});

    const botMember = await guild.members.fetch(botId).catch(() => null);

    if (botMember) {
        try {
            if (isBan) {
                await botMember.ban({ reason: T.rejectReason, deleteMessageSeconds: 0 });
            } else {
                await botMember.kick(T.rejectReason);
            }
        } catch (err) {
            console.error('❌ [Anti-Bot] Rejection action failed:', err.message);
        }
    }

    await interaction.editReply({
        content: null,
        embeds: [new EmbedBuilder()
            .setTitle(isBan ? T.bannedTitle : T.kickedTitle)
            .setColor(COLOR_REJECTED)
            .setDescription(T.rejectedDesc(pending?.botTag, botId, isBan, interaction.user.id))
            .setTimestamp()],
        components: []
    }).catch(() => {});

    incrementBlockedStat(antibot);
    return true;
}


// ════════════════════════════════════════════════════════════════════
//  9. EXPORTS
// ════════════════════════════════════════════════════════════════════

module.exports = {
    /** Event name expected by the central event loader */
    name:  'guildMemberAdd',
    once:  false,

    /** Public state — exposed for inspection / debugging by other modules */
    pendingBotApprovals,

    /** Public API — called from the central interaction router */
    handleBotApproval,

    /**
     * guildMemberAdd handler.
     * Returns immediately for non-bot members; verification.js owns those.
     */
async execute(client, _settings, member) {
        try {
            const antibot = loadAntibot();
            if (!shouldHandle(antibot, member)) return;

            const T         = t();
            const botAction = antibot.botAction || 'kick';

            if (botAction === 'approve') {
                await sendBotApprovalRequest(member, antibot);
            } else {
                await applyBotAction(member, botAction, [T.unauthorizedBot], antibot);
            }
        } catch (err) {
            console.error('❌ [Anti-Bot] guildMemberAdd error:', err.message);
        }
    }
};