
'use strict';

const fs   = require('fs');
const path = require('path');
const {
    EmbedBuilder,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder,
    MessageFlags
} = require('discord.js');


// ════════════════════════════════════════════════════════════════════
//  1. CONSTANTS
// ════════════════════════════════════════════════════════════════════

const VERIFICATION_FILE = path.join(__dirname, '../../antibot.json');
const SETTINGS_FILE     = path.join(__dirname, '../../data.json');

const DEFAULT_TIMEOUT_MIN     = 5;
const TIMEOUT_MIN_MIN         = 1;
const TIMEOUT_MAX_MIN         = 60;
const MAX_VERIFY_ATTEMPTS     = 3;
const CODE_LENGTH_CAPTCHA     = 5;
const CODE_LENGTH_DM          = 8;
const SUCCESS_MSG_DELETE_MS   = 5000;
const WARN_MSG_DELETE_MS      = 4000;
const DEFAULT_MUTE_HOURS      = 1;

const REASON_PREFIX           = '[Verification]';
const REASON_TIMEOUT          = 'Verification timed out';
const REASON_FAILED_ATTEMPTS  = 'Verification failed (3 wrong attempts)';
const REASON_DM_CLOSED        = 'Cannot complete verification (DMs closed + no verify channel)';

const COLOR_BUTTON            = '#5865F2';
const COLOR_CAPTCHA           = '#FAA61A';
const COLOR_DM_SENT           = '#5865F2';
const COLOR_DM_FAILED         = '#ED4245';
const COLOR_SUCCESS           = '#57F287';

const VERIFICATION_METHODS = {
    BUTTON:  'button',
    CAPTCHA: 'captcha',
    DM:      'dm'
};

const VERIFICATION_ACTIONS = {
    KICK:       'kick',
    BAN:        'ban',
    MUTE:       'mute',
    QUARANTINE: 'quarantine',
    NONE:       'none'
};


// ════════════════════════════════════════════════════════════════════
//  2. INTERNAL STATE
// ════════════════════════════════════════════════════════════════════

const pendingVerification = new Map();


// ════════════════════════════════════════════════════════════════════
//  3. CONFIGURATION — file I/O, language, localized strings
// ════════════════════════════════════════════════════════════════════

function getBotLang() {
    try {
        const s = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
        return s.botLanguage === 'en' ? 'en' : 'ar';
    } catch {
        return 'ar';
    }
}

function t() {
    return LANG[getBotLang()];
}

const LANG = {
    ar: {
        btnTitle:        '🔒 التحقق من هويتك',
        btnDesc:         (member, timeout, actionLabel) =>
            `مرحباً ${member}!\n\n` +
            `للوصول إلى السيرفر، يرجى الضغط على زر **"أنا لست بوت"** أدناه.\n\n` +
            `⏰ لديك **${timeout} دقائق** للتحقق وإلا سيُطبَّق: **${actionLabel}**`,
        btnLabel:        '✅ أنا لست بوت',
        btnFooter:       'نظام التحقق | Member Verification',

        captchaTitle:   '🔒 التحقق من هويتك - كابتشا',
        captchaDesc:    (member, code, timeout, actionLabel) =>
            `مرحباً ${member}!\n\n` +
            `اكتب الكود التالي بالضبط للتحقق:\n\n` +
            `\`\`\`\n${code}\n\`\`\`\n\n` +
            `⏰ لديك **${timeout} دقائق** وإلا سيُطبَّق: **${actionLabel}**`,
        captchaFooter:  'اكتب الكود في نفس هذا الروم | Verification Captcha',

        dmTitle:        '🔒 تحقق من هويتك في السيرفر',
        dmDesc:         (guildName, code, timeout) =>
            `مرحباً! لإتمام التحقق في **${guildName}**، استخدم الكود التالي:\n\n` +
            `\`\`\`\n${code}\n\`\`\`\n\n` +
            `اكتبه في قناة التحقق في السيرفر خلال **${timeout} دقائق**.`,
        dmChannelTitle: '🔒 التحقق عبر الخاص',
        dmChannelDescSent: (member, timeout, actionLabel) =>
            `مرحباً ${member}!\n\n` +
            `📨 تم إرسال كود التحقق في رسائلك الخاصة.\nاكتب الكود هنا لإتمام التحقق.` +
            `\n\n⏰ لديك **${timeout} دقائق** وإلا سيُطبَّق: **${actionLabel}**`,
        dmChannelDescFailed: (member, timeout, actionLabel) =>
            `مرحباً ${member}!\n\n` +
            `⚠️ لم نتمكن من إرسال الكود في الخاص.\nيرجى فتح الرسائل الخاصة وإعادة الانضمام.` +
            `\n\n⏰ لديك **${timeout} دقائق** وإلا سيُطبَّق: **${actionLabel}**`,
        dmNoChannelReason: REASON_DM_CLOSED,

        notYourButton:   '❌ هذا الزر ليس لك!',
        expiredVerif:    '❌ انتهت صلاحية التحقق أو تم التحقق مسبقاً.',

        wrongCode:       (remaining) => `❌ كود خاطئ! تبقى **${remaining}** محاولات.`,
        failedVerif:     REASON_FAILED_ATTEMPTS,
        timeoutReason:   REASON_TIMEOUT,

        successTitle:    '✅ تم التحقق بنجاح!',
        successDesc:     (member) => `مرحباً ${member}! تم التحقق من هويتك، يمكنك الآن الوصول للسيرفر.`,

        actionKick:       '🦵 طرد',
        actionBan:        '🔨 حظر',
        actionMute:       '🔇 كتم',
        actionQuarantine: '🔒 عزل',
        actionNone:       '👁️ مراقبة فقط',
    },
    en: {
        btnTitle:        '🔒 Verify Your Identity',
        btnDesc:         (member, timeout, actionLabel) =>
            `Hello ${member}!\n\n` +
            `To access the server, please click the **"I\'m not a bot"** button below.\n\n` +
            `⏰ You have **${timeout} minutes** to verify, otherwise: **${actionLabel}** will be applied.`,
        btnLabel:        '✅ I\'m not a bot',
        btnFooter:       'Member Verification System',

        captchaTitle:   '🔒 Verify Your Identity - Captcha',
        captchaDesc:    (member, code, timeout, actionLabel) =>
            `Hello ${member}!\n\n` +
            `Type the following code exactly to verify:\n\n` +
            `\`\`\`\n${code}\n\`\`\`\n\n` +
            `⏰ You have **${timeout} minutes**, otherwise: **${actionLabel}** will be applied.`,
        captchaFooter:  'Type the code in this channel | Verification Captcha',

        dmTitle:        '🔒 Verify Your Identity in the Server',
        dmDesc:         (guildName, code, timeout) =>
            `Hello! To complete verification in **${guildName}**, use this code:\n\n` +
            `\`\`\`\n${code}\n\`\`\`\n\n` +
            `Type it in the verification channel within **${timeout} minutes**.`,
        dmChannelTitle: '🔒 DM Verification',
        dmChannelDescSent: (member, timeout, actionLabel) =>
            `Hello ${member}!\n\n` +
            `📨 A verification code has been sent to your DMs.\nType the code here to complete verification.` +
            `\n\n⏰ You have **${timeout} minutes**, otherwise: **${actionLabel}** will be applied.`,
        dmChannelDescFailed: (member, timeout, actionLabel) =>
            `Hello ${member}!\n\n` +
            `⚠️ We couldn't send you a DM code.\nPlease open your DMs and rejoin.` +
            `\n\n⏰ You have **${timeout} minutes**, otherwise: **${actionLabel}** will be applied.`,
        dmNoChannelReason: REASON_DM_CLOSED,

        notYourButton:   '❌ This button is not for you!',
        expiredVerif:    '❌ Verification has expired or was already completed.',

        wrongCode:       (remaining) => `❌ Wrong code! **${remaining}** attempts remaining.`,
        failedVerif:     REASON_FAILED_ATTEMPTS,
        timeoutReason:   REASON_TIMEOUT,

        successTitle:    '✅ Verified Successfully!',
        successDesc:     (member) => `Welcome ${member}! Your identity has been verified. You can now access the server.`,

        actionKick:       '🦵 Kick',
        actionBan:        '🔨 Ban',
        actionMute:       '🔇 Mute',
        actionQuarantine: '🔒 Quarantine',
        actionNone:       '👁️ Monitor only',
    }
};


// ════════════════════════════════════════════════════════════════════
//  4. VERIFICATION SETTINGS
// ════════════════════════════════════════════════════════════════════

function loadVerificationConfig() {
    if (!fs.existsSync(VERIFICATION_FILE)) {
        return getDefaultVerificationConfig();
    }
    try {
        const raw = JSON.parse(fs.readFileSync(VERIFICATION_FILE, 'utf8'));

        return {
            enabled:            raw.verificationEnabled === true,
            method:             raw.verificationMethod || VERIFICATION_METHODS.BUTTON,
            timeout:            clampTimeout(raw.verificationTimeout || DEFAULT_TIMEOUT_MIN),
            channel:            raw.verifyChannel || null,
            logsChannel:        raw.logsChannel || null,
            action:             raw.action || VERIFICATION_ACTIONS.KICK,
            muteDuration:       raw.muteDuration || DEFAULT_MUTE_HOURS,
            whitelistRoles:     Array.isArray(raw.whitelistRoles) ? raw.whitelistRoles : [],
            minAccountAge:      raw.minAccountAge || 0,
            joinRateLimit:      raw.joinRateLimit || 10,
            suspiciousPatterns: raw.suspiciousPatterns || {}
        };
    } catch (err) {
        console.error('❌ [Verification] Failed to parse antibot.json:', err.message);
        return getDefaultVerificationConfig();
    }
}

function getDefaultVerificationConfig() {
    return {
        enabled:      false,
        method:       VERIFICATION_METHODS.BUTTON,
        timeout:      DEFAULT_TIMEOUT_MIN,
        channel:      null,
        logsChannel:  null,
        action:       VERIFICATION_ACTIONS.KICK,
        muteDuration: DEFAULT_MUTE_HOURS
    };
}

function clampTimeout(minutes) {
    return Math.min(Math.max(minutes, TIMEOUT_MIN_MIN), TIMEOUT_MAX_MIN);
}

function saveVerificationConfig(config) {
    try {
        const raw = fs.existsSync(VERIFICATION_FILE)
            ? JSON.parse(fs.readFileSync(VERIFICATION_FILE, 'utf8'))
            : {};

        raw.verificationEnabled = config.enabled;
        raw.verificationMethod  = config.method;
        raw.verificationTimeout = config.timeout;
        raw.verifyChannel       = config.channel;
        raw.logsChannel         = config.logsChannel;
        raw.action              = config.action;
        raw.muteDuration        = config.muteDuration;

        fs.writeFileSync(VERIFICATION_FILE, JSON.stringify(raw, null, 2), 'utf8');
    } catch (err) {
        console.error('❌ [Verification] Failed to write antibot.json:', err.message);
    }
}

function incrementVerifiedStat(config) {
    try {
        const raw = fs.existsSync(VERIFICATION_FILE)
            ? JSON.parse(fs.readFileSync(VERIFICATION_FILE, 'utf8'))
            : {};
        raw.stats = raw.stats || {};
        raw.stats.verified = (raw.stats.verified || 0) + 1;
        fs.writeFileSync(VERIFICATION_FILE, JSON.stringify(raw, null, 2), 'utf8');
    } catch (err) {
        console.error('❌ [Verification] Failed to update stats:', err.message);
    }
}

function incrementBlockedStat() {
    try {
        const raw = fs.existsSync(VERIFICATION_FILE)
            ? JSON.parse(fs.readFileSync(VERIFICATION_FILE, 'utf8'))
            : {};
        raw.stats = raw.stats || {};
        raw.stats.blockedWeek = (raw.stats.blockedWeek || 0) + 1;
        fs.writeFileSync(VERIFICATION_FILE, JSON.stringify(raw, null, 2), 'utf8');
    } catch (err) {
        console.error('❌ [Verification] Failed to update stats:', err.message);
    }
}


// ════════════════════════════════════════════════════════════════════
//  5. UTILITIES
// ════════════════════════════════════════════════════════════════════

function generateCode(length = 6) {
    const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
    let code = '';
    for (let i = 0; i < length; i++) {
        code += chars[Math.floor(Math.random() * chars.length)];
    }
    return code;
}

function generateCaptchaCode() {
    return generateCode(CODE_LENGTH_CAPTCHA);
}

function getActionLabel(action) {
    const lang = t();
    const labels = {
        [VERIFICATION_ACTIONS.KICK]:       lang.actionKick,
        [VERIFICATION_ACTIONS.BAN]:        lang.actionBan,
        [VERIFICATION_ACTIONS.MUTE]:       lang.actionMute,
        [VERIFICATION_ACTIONS.QUARANTINE]: lang.actionQuarantine,
        [VERIFICATION_ACTIONS.NONE]:       lang.actionNone
    };
    return labels[action] || action || lang.actionKick;
}

async function resolveVerificationChannel(guild, config) {
    if (config.channel) {
        const ch = guild.channels.cache.get(config.channel)
            || await guild.channels.fetch(config.channel).catch(() => null);
        if (ch && ch.type === 0) return ch;
    }

    const keywordChannel = guild.channels.cache.find(c =>
        c.type === 0 && (
            c.name.toLowerCase().includes('verify') ||
            c.name.includes('تحقق') ||
            c.name.toLowerCase().includes('verification')
        )
    );
    if (keywordChannel) return keywordChannel;

    return guild.channels.cache.find(c =>
        c.type === 0 &&
        c.permissionsFor(guild.members.me)?.has('SendMessages')
    ) || null;
}

function cancelVerification(memberId) {
    const pending = pendingVerification.get(memberId);
    if (pending) {
        clearTimeout(pending.timeoutId);
        pendingVerification.delete(memberId);
    }
}

function shouldHandleVerification(config, member) {
    if (!config.enabled) return false;
    if (member.user && member.user.bot) return false;
    if (config.whitelistRoles && config.whitelistRoles.length > 0) {
        const hasWhitelistedRole = member.roles.cache.some(r => config.whitelistRoles.includes(r.id));
        if (hasWhitelistedRole) return false;
    }
    return true;
}

function normalizeCode(input) {
    return input.trim().toUpperCase().replace(/\s+/g, '');
}

// ────────────────────────────────────────────────────────────────
//  Suspicion detection helpers — للأعضاء البشريين فقط (Raid/Alt accounts)
// ────────────────────────────────────────────────────────────────

const DEFAULT_NAME_REGEX = /^[a-zA-Z]+\d{4,}$/;      // مثل: user1234
const INVITE_REGEX       = /discord(\.gg|app\.com\/invite)/i;

const recentMemberJoinTimes     = [];
const recentMemberJoinUsernames = [];

function pruneOldMemberJoins() {
    const cutoff = Date.now() - 60 * 1000; // آخر دقيقة
    while (recentMemberJoinTimes.length && recentMemberJoinTimes[0] < cutoff) {
        recentMemberJoinTimes.shift();
    }
}

function pruneOldMemberUsernames() {
    const cutoff = Date.now() - 5 * 60 * 1000; // آخر 5 دقائق
    while (recentMemberJoinUsernames.length && recentMemberJoinUsernames[0].time < cutoff) {
        recentMemberJoinUsernames.shift();
    }
}

function isSimilarToRecentMemberJoin(username) {
    pruneOldMemberUsernames();
    const normalized = username.toLowerCase().replace(/[0-9_.]/g, '');
    const isSimilar = normalized.length >= 3 && recentMemberJoinUsernames.some(entry => {
        const otherNormalized = entry.name.toLowerCase().replace(/[0-9_.]/g, '');
        if (otherNormalized.length < 3) return false;
        return otherNormalized === normalized
            || otherNormalized.startsWith(normalized.slice(0, 5))
            || normalized.startsWith(otherNormalized.slice(0, 5));
    });
    recentMemberJoinUsernames.push({ name: username, time: Date.now() });
    return isSimilar;
}

function isMemberJoinRateExceeded(config) {
    pruneOldMemberJoins();
    recentMemberJoinTimes.push(Date.now());
    const limit = config.joinRateLimit || 10;
    return recentMemberJoinTimes.length > limit;
}

/**
 * يبني قائمة أسباب الاشتباه بعضو بشري بناءً على "Detection Rules".
 * لا تُستخدم لمنع أو تغيير إجراء التحقق — فقط للتسجيل والإشعار.
 */
function computeSuspicionReasons(member, config) {
    const isAr    = getBotLang() === 'ar';
    const reasons = [];

    const minAgeDays = config.minAccountAge || 0;
    if (minAgeDays > 0) {
        const ageDays = (Date.now() - member.user.createdTimestamp) / (1000 * 60 * 60 * 24);
        if (ageDays < minAgeDays) {
            reasons.push(isAr
                ? `حساب حديث الإنشاء (${Math.floor(ageDays)} يوم)`
                : `Recently created account (${Math.floor(ageDays)} days old)`);
        }
    }

    const patterns = config.suspiciousPatterns || {};

    if (patterns.noAvatar && !member.user.avatar) {
        reasons.push(isAr ? 'بدون صورة شخصية' : 'No avatar');
    }

    if (patterns.defaultName && DEFAULT_NAME_REGEX.test(member.user.username)) {
        reasons.push(isAr ? 'اسم افتراضي (مثل User1234)' : 'Default-style username (e.g. User1234)');
    }

    if (patterns.invite && INVITE_REGEX.test(member.user.username)) {
        reasons.push(isAr ? 'رابط دعوة في الاسم' : 'Invite link in username');
    }

    if (patterns.similar && isSimilarToRecentMemberJoin(member.user.username)) {
        reasons.push(isAr ? 'اسم مشابه لعضو انضم مؤخراً (هجوم منظم محتمل)' : 'Similar to a recently joined name (possible raid)');
    }

    if (isMemberJoinRateExceeded(config)) {
        reasons.push(isAr ? '⚠️ تجاوز معدل الانضمام المسموح (هجوم منظم محتمل)' : '⚠️ Join rate limit exceeded (possible raid)');
    }

    return reasons;
}


// ════════════════════════════════════════════════════════════════════
//  6. VERIFICATION METHODS
// ════════════════════════════════════════════════════════════════════

async function startVerification(member, config, client, reasons = []) {
    const timeoutMs = config.timeout * 60 * 1000;
    cancelVerification(member.id);

    try {
        switch (config.method) {
            case VERIFICATION_METHODS.BUTTON:
                await startButtonVerification(member, config, client, timeoutMs, reasons);
                break;
            case VERIFICATION_METHODS.CAPTCHA:
                await startCaptchaVerification(member, config, client, timeoutMs, reasons);
                break;
            case VERIFICATION_METHODS.DM:
                await startDMVerification(member, config, client, timeoutMs, reasons);
                break;
            default:
                console.warn(`⚠️ [Verification] Unknown method: ${config.method}, falling back to button`);
                await startButtonVerification(member, config, client, timeoutMs, reasons);
        }
    } catch (err) {
        console.error('❌ [Verification] Start error:', err.message);
    }
}

async function startButtonVerification(member, config, client, timeoutMs, reasons) {
    const channel = await resolveVerificationChannel(member.guild, config);
    if (!channel) {
        console.warn('⚠️ [Verification] No verification channel available');
        return;
    }

   

    const lang        = t();
    const actionLabel = getActionLabel(config.action);

    const embed = new EmbedBuilder()
        .setTitle(lang.btnTitle)
        .setDescription(lang.btnDesc(member, config.timeout, actionLabel))
        .setColor(COLOR_BUTTON)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: lang.btnFooter });

    const button = new ButtonBuilder()
        .setCustomId(`verify_button_${member.id}`)
        .setLabel(lang.btnLabel)
        .setStyle(ButtonStyle.Success);

    const row = new ActionRowBuilder().addComponents(button);

    let message;
    try {
        message = await channel.send({
            content: `${member}`,
            embeds: [embed],
            components: [row]
        });
        
    } catch (err) {
        console.error('❌ [Verification] Failed to send button message:', err.message);
        return;
    }

    const timeoutId = setTimeout(() => {
        handleVerificationTimeout(member, message, config, client, reasons);
    }, timeoutMs);

    pendingVerification.set(member.id, {
        guildId:   member.guild.id,
        method:    VERIFICATION_METHODS.BUTTON,
        channelId: channel.id,
        messageId: message.id,
        timeoutId,
        config,
        client,
        reasons
    });
}

async function startCaptchaVerification(member, config, client, timeoutMs, reasons) {
    const code    = generateCaptchaCode();
    const channel = await resolveVerificationChannel(member.guild, config);
    if (!channel) {
        console.warn('⚠️ [Verification] No verification channel available');
        return;
    }

    

    const lang        = t();
    const displayCode = code.split('').join(' ');
    const actionLabel = getActionLabel(config.action);

    const embed = new EmbedBuilder()
        .setTitle(lang.captchaTitle)
        .setDescription(lang.captchaDesc(member, displayCode, config.timeout, actionLabel))
        .setColor(COLOR_CAPTCHA)
        .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
        .setFooter({ text: lang.captchaFooter });

    let message;
    try {
        message = await channel.send({
            content: `${member}`,
            embeds: [embed]
        });
        
    } catch (err) {
        console.error('❌ [Verification] Failed to send captcha message:', err.message);
        return;
    }

    const timeoutId = setTimeout(() => {
        handleVerificationTimeout(member, message, config, client, reasons);
    }, timeoutMs);

    pendingVerification.set(member.id, {
        guildId:   member.guild.id,
        method:    VERIFICATION_METHODS.CAPTCHA,
        code,
        channelId: channel.id,
        messageId: message.id,
        timeoutId,
        attempts:  0,
        config,
        client,
        reasons
    });
}

async function startDMVerification(member, config, client, timeoutMs, reasons) {
    const code        = generateCode(CODE_LENGTH_DM);
    const lang        = t();
    const actionLabel = getActionLabel(config.action);

    let dmSent = false;
    try {
        const dmEmbed = new EmbedBuilder()
            .setTitle(lang.dmTitle)
            .setDescription(lang.dmDesc(member.guild.name, code, config.timeout))
            .setColor(COLOR_DM_SENT)
            .setThumbnail(member.guild.iconURL({ dynamic: true }))
            .setFooter({ text: 'Verification DM' });

        await member.user.send({ embeds: [dmEmbed] });
        dmSent = true;
        
    } catch (err) {
        console.warn(`⚠️ [Verification] Cannot DM ${member.user.tag}`);
    }

    const channel = await resolveVerificationChannel(member.guild, config);

    if (!dmSent && !channel) {
        await handleVerificationTimeout(
            member, null, config, client,
            [...reasons, lang.dmNoChannelReason]
        );
        return;
    }

    let message;
    if (channel) {
        const embed = new EmbedBuilder()
            .setTitle(lang.dmChannelTitle)
            .setDescription(
                dmSent
                    ? lang.dmChannelDescSent(member, config.timeout, actionLabel)
                    : lang.dmChannelDescFailed(member, config.timeout, actionLabel)
            )
            .setColor(dmSent ? COLOR_DM_SENT : COLOR_DM_FAILED)
            .setFooter({ text: 'Verification DM' });

        try {
            message = await channel.send({
                content: `${member}`,
                embeds: [embed]
            });
            
        } catch (err) {
            console.error('❌ [Verification] Failed to send DM channel message:', err.message);
        }
    }

    const timeoutId = setTimeout(() => {
        handleVerificationTimeout(member, message, config, client, reasons);
    }, timeoutMs);

    pendingVerification.set(member.id, {
        guildId:   member.guild.id,
        method:    VERIFICATION_METHODS.DM,
        code,
        channelId: channel?.id || null,
        messageId: message?.id || null,
        timeoutId,
        attempts:  0,
        dmFailed:  !dmSent,
        config,
        client,
        reasons
    });
}

async function sendAdminNotification(member, config, eventType, details) {
    try {
        const raw = fs.existsSync(VERIFICATION_FILE)
            ? JSON.parse(fs.readFileSync(VERIFICATION_FILE, 'utf8'))
            : {};

        const channelId = raw.logsChannel || raw.botLogsChannel;
        if (!channelId) return;

        const channel = member.guild.channels.cache.get(channelId)
            || await member.guild.channels.fetch(channelId).catch(() => null);
        if (!channel) return;

        const isAr = getBotLang() === 'ar';

        const colors = {
            success: '#57F287',
            failed:  '#ED4245',
            timeout: '#FAA61A'
        };

        const titles = {
            success: isAr ? '✅ عضو تحقق بنجاح'             : '✅ Member Verified Successfully',
            failed:  isAr ? '❌ فشل التحقق (محاولات خاطئة)' : '❌ Verification Failed (Wrong Attempts)',
            timeout: isAr ? '⏰ انتهت مهلة التحقق'           : '⏰ Verification Timeout'
        };

        const actionText = {
            kick:       isAr ? '🦵 تم الطرد'     : '🦵 Kicked',
            ban:        isAr ? '🔨 تم الحظر'     : '🔨 Banned',
            mute:       isAr ? '🔇 تم الكتم'     : '🔇 Muted',
            quarantine: isAr ? '🔒 تم العزل'     : '🔒 Quarantined',
            none:       isAr ? '👁️ مراقبة فقط'  : '👁️ Monitor only'
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[eventType] || eventType)
            .setColor(colors[eventType] || '#5865F2')
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                { name: isAr ? '👤 العضو'              : '👤 Member',
                  value: `${member.user.tag} (<@${member.id}>)`, inline: true },
                { name: isAr ? '🆔 ID'                 : '🆔 ID',
                  value: `\`${member.id}\``, inline: true },
                { name: isAr ? '📅 تاريخ إنشاء الحساب' : '📅 Account Created',
                  value: `<t:${Math.floor(member.user.createdTimestamp / 1000)}:R>`, inline: true },
                { name: isAr ? '🔒 طريقة التحقق'       : '🔒 Verification Method',
                  value: config.method || 'button', inline: true },
                { name: isAr ? '⚡ الإجراء المتخذ'      : '⚡ Action Taken',
                  value: eventType === 'success'
                      ? (isAr ? '✅ تم منح الوصول' : '✅ Access granted')
                      : (actionText[config.action] || config.action), inline: true },
                { name: isAr ? '📋 التفاصيل'           : '📋 Details',
                  value: details || '—', inline: false }
            )
            .setTimestamp()
            .setFooter({ text: isAr ? 'نظام التحقق' : 'Member Verification System' });

        const mentionText = raw.notifyAdmins ? '@here 🔔' : null;

        await channel.send({
            content: mentionText,
            embeds: [embed],
            allowedMentions: { parse: ['everyone'] }
        });

    } catch (err) {
        console.error('❌ [Verification] Admin notification error:', err.message);
    }
}


// ════════════════════════════════════════════════════════════════════
//  7. VERIFICATION COMPLETION & TIMEOUT
// ════════════════════════════════════════════════════════════════════

async function completeVerification(member, pending, interaction, client, channel) {
    clearTimeout(pending.timeoutId);
    pendingVerification.delete(member.id);

    await deleteOriginalMessage(member.guild, pending);

    incrementVerifiedStat(pending.config);

    const isAr = getBotLang() === 'ar';
    let successDetails = isAr
        ? `تحقق بطريقة: ${pending.config.method}`
        : `Verified via: ${pending.config.method}`;

    if (pending.reasons && pending.reasons.length > 0) {
        successDetails += isAr
            ? `\n⚠️ أسباب اشتباه مسجّلة: ${pending.reasons.join(', ')}`
            : `\n⚠️ Recorded suspicion reasons: ${pending.reasons.join(', ')}`;
    }

    await sendAdminNotification(member, pending.config, 'success', successDetails);

    const lang = t();
    const successEmbed = new EmbedBuilder()
        .setTitle(lang.successTitle)
        .setDescription(lang.successDesc(member))
        .setColor(COLOR_SUCCESS)
        .setTimestamp();

    if (interaction) {
        await interaction.reply({
            embeds: [successEmbed],
            flags: MessageFlags.Ephemeral
        }).catch(() => {});
    } else if (channel) {
        const msg = await channel.send({
            content: `${member}`,
            embeds: [successEmbed]
        }).catch(() => null);
        if (msg) {
            setTimeout(() => msg.delete().catch(() => {}), SUCCESS_MSG_DELETE_MS);
        }
    }

}

async function handleVerificationTimeout(member, originalMessage, config, client, reasons = []) {
    pendingVerification.delete(member.id);
await sendAdminNotification(
    member, config, 'timeout',
    getBotLang() === 'ar'
        ? `انتهت المهلة (${config.timeout} دقيقة) — الإجراء: ${config.action}`
        : `Timeout after ${config.timeout} min — Action: ${config.action}`
);
    if (originalMessage) {
        try { await originalMessage.delete(); } catch (err) { /* ignore */ }
    }

    const lang     = t();
    const action   = config.action || VERIFICATION_ACTIONS.KICK;
    const muteMs   = (config.muteDuration || DEFAULT_MUTE_HOURS) * 60 * 60 * 1000;
    const reason   = reasons.length > 0
        ? reasons.join(', ')
        : lang.timeoutReason;
    const fullReason = `${REASON_PREFIX} ${reason}`;

    

    try {
        switch (action) {
            case VERIFICATION_ACTIONS.KICK:
                if (member.kickable) {
                    await member.kick(fullReason);
                }
                break;

            case VERIFICATION_ACTIONS.BAN:
                if (member.bannable) {
                    await member.ban({ reason: fullReason, deleteMessageSeconds: 0 });
                }
                break;

            case VERIFICATION_ACTIONS.MUTE:
                if (member.moderatable) {
                    await member.timeout(muteMs, fullReason);
                }
                break;

            case VERIFICATION_ACTIONS.QUARANTINE: {
                const quarRole = member.guild.roles.cache.find(r =>
                    r.name.toLowerCase().includes('quarantine') ||
                    r.name.toLowerCase().includes('عزل') ||
                    r.name.toLowerCase().includes('isolated')
                );
                if (quarRole && member.manageable) {
                    await member.roles.add(quarRole, fullReason);
                }
                break;
            }

            case VERIFICATION_ACTIONS.NONE:
            default:
                break;
        }
    } catch (err) {
        console.error('❌ [Verification] Timeout action failed:', err.message);
    }

    incrementBlockedStat();
}

async function handleFailedAttempts(member, pending) {
    clearTimeout(pending.timeoutId);
    pendingVerification.delete(member.id);
await sendAdminNotification(
    member, pending.config, 'failed',
    getBotLang() === 'ar'
        ? `أدخل كوداً خاطئاً 3 مرات — الإجراء: ${pending.config.action}`
        : `Entered wrong code 3 times — Action: ${pending.config.action}`
);
    await deleteOriginalMessage(member.guild, pending);

    const lang = t();
    await handleVerificationTimeout(
        member, null, pending.config, pending.client,
        [...(pending.reasons || []), lang.failedVerif]
    );
}


 


// ════════════════════════════════════════════════════════════════════
//  9. MESSAGE CLEANUP
// ════════════════════════════════════════════════════════════════════

async function deleteOriginalMessage(guild, pending) {
    if (!pending.channelId || !pending.messageId) return;

    try {
        const channel = guild.channels.cache.get(pending.channelId)
            || await guild.channels.fetch(pending.channelId).catch(() => null);
        if (channel) {
            const message = await channel.messages.fetch(pending.messageId).catch(() => null);
            if (message) {
                await message.delete().catch(() => {});
            }
        }
    } catch (err) {
        // Message may already be deleted — ignore
    }
}


// ════════════════════════════════════════════════════════════════════
//  10. INTERACTION HANDLER — button verification
// ════════════════════════════════════════════════════════════════════

async function handleInteraction(interaction, client) {
    if (!interaction.isButton()) return false;
    if (!interaction.customId.startsWith('verify_button_')) return false;

    const lang     = t();
    const memberId = interaction.customId.replace('verify_button_', '');

    if (interaction.user.id !== memberId) {
        await interaction.reply({
            content: lang.notYourButton,
            flags: MessageFlags.Ephemeral
        });
        return true;
    }

    const pending = pendingVerification.get(memberId);
    if (!pending) {
        await interaction.reply({
            content: lang.expiredVerif,
            flags: MessageFlags.Ephemeral
        });
        return true;
    }

    const member = interaction.member
        || await interaction.guild.members.fetch(memberId).catch(() => null);
    if (!member) return false;

    await completeVerification(member, pending, interaction, client);
    return true;
}


// ════════════════════════════════════════════════════════════════════
//  11. MESSAGE HANDLER — captcha & DM code verification
// ════════════════════════════════════════════════════════════════════

async function handleMessage(message, client) {
    if (message.author.bot) return false;
    if (!message.guild)     return false;

    const pending = pendingVerification.get(message.author.id);
    if (!pending) return false;

    if (pending.method !== VERIFICATION_METHODS.CAPTCHA
        && pending.method !== VERIFICATION_METHODS.DM) {
        return false;
    }

    if (pending.channelId && message.channelId !== pending.channelId) {
        return false;
    }

    const lang       = t();
    const userInput  = normalizeCode(message.content);
    const expected   = pending.code.toUpperCase();

    if (userInput === expected) {
        try { await message.delete(); } catch (err) { /* ignore */ }

        const member = message.member
            || await message.guild.members.fetch(message.author.id).catch(() => null);
        if (member) {
            await completeVerification(member, pending, null, client, message.channel);
        }
        return true;
    }

    pending.attempts = (pending.attempts || 0) + 1;

    if (pending.attempts >= MAX_VERIFY_ATTEMPTS) {
        try { await message.delete(); } catch (err) { /* ignore */ }

        const member = message.member
            || await message.guild.members.fetch(message.author.id).catch(() => null);
        if (member) {
            await handleFailedAttempts(member, pending);
        }
    } else {
        const remaining = MAX_VERIFY_ATTEMPTS - pending.attempts;
        const warn = await message.channel.send({
            content: `${message.author} ${lang.wrongCode(remaining)}`
        }).catch(() => null);

        try { await message.delete(); } catch (err) { /* ignore */ }

        if (warn) {
            setTimeout(() => warn.delete().catch(() => {}), WARN_MSG_DELETE_MS);
        }
    }

    return true;
}


// ════════════════════════════════════════════════════════════════════
//  12. EVENT HANDLER — guildMemberAdd
// ════════════════════════════════════════════════════════════════════

async function execute(client, _settings, member) {
    try {
        const config = loadVerificationConfig();

        // ننتظر قليلاً حتى تُطبَّق أي رتب تلقائية (Auto Role) قبل فحص الـ Whitelist
        await new Promise(resolve => setTimeout(resolve, 1500));

        const freshMember = await member.guild.members.fetch(member.id).catch(() => member);

        if (!shouldHandleVerification(config, freshMember)) {
            return;
        }

        const suspicionReasons = computeSuspicionReasons(freshMember, config);

        await startVerification(freshMember, config, client, suspicionReasons);
    } catch (err) {
        console.error('❌ [Verification] guildMemberAdd error:', err.message);
    }
}


// ════════════════════════════════════════════════════════════════════
//  13. EXPORTS
// ════════════════════════════════════════════════════════════════════

module.exports = {
    name: 'guildMemberAdd',
    once: false,

    pendingVerification,

    handleInteraction,
    handleMessage,

    startVerification,

    execute
};