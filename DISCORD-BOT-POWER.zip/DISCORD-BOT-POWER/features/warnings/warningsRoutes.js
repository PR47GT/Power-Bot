const fs   = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../../botData.json');

function loadData() {
    if (fs.existsSync(DATA_FILE)) {
        try { return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8')); }
        catch(e) { return { warns: {}, tempRoles: {} }; }
    }
    return { warns: {}, tempRoles: {} };
}

function saveData(data) {
    fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

module.exports = function registerWarningsRoutes(app, client, getSettings, saveSettings, loadDataFn, getChannels, config) {

    function getGuildWarns() {
        const all = loadData();
        return (all.warns || {})[config.guildId] || {};
    }

    function setGuildWarns(guildWarns) {
        const all = loadData();
        if (!all.warns) all.warns = {};
        all.warns[config.guildId] = guildWarns;
        saveData(all);
    }

    async function fetchUserInfo(userId) {
        try {
            const user = await client.users.fetch(userId);
            return {
                username: user.globalName || user.username || userId,
                avatar: user.displayAvatarURL({ extension: 'png', size: 64 })
            };
        } catch (e) {
            return { username: userId, avatar: null };
        }
    }

    // GET /warnings
    app.get('/warnings', async (req, res) => {
        await loadDataFn(true);
        const settings      = getSettings();
        const guildWarns    = getGuildWarns();
        const guildChannels = getChannels();

        const guild = client.guilds.cache.get(config.guildId);
        const guildRoles = guild
            ? guild.roles.cache
                .filter(r => r.id !== guild.id && !r.managed)
                .sort((a, b) => b.position - a.position)
                .map(r => ({ id: r.id, name: r.name }))
            : [];

        const allIds = new Set();
        Object.keys(guildWarns).forEach(uid => {
            allIds.add(uid);
            (guildWarns[uid] || []).forEach(w => { if (w.moderator) allIds.add(w.moderator); });
        });

        const userInfo = {};
        await Promise.all([...allIds].map(async id => {
            userInfo[id] = await fetchUserInfo(id);
        }));

        res.render('warnings', {
            settings,
            warns: guildWarns,
            guildChannels,
            guildRoles,
            userInfo,
            query: req.query
        });
    });

    // POST /warnings/settings
    app.post('/warnings/settings', (req, res) => {
        try {
            const settings = getSettings();
            if (!settings.warnActions) settings.warnActions = {};

            settings.warnActions.enabled    = req.body.enabled === 'true';
            settings.warnActions.logChannel = req.body.logChannel || '';

            // Dynamic thresholds
            let thresholds = [];
            try {
                const raw = JSON.parse(req.body.thresholds_json || '[]');
                thresholds = raw
                    .filter(th => th && parseInt(th.count) >= 1)
                    .map(th => ({
                        count:    Math.max(1, parseInt(th.count)    || 1),
                        action:   ['mute','kick','ban','role'].includes(th.action) ? th.action : 'mute',
                        duration: Math.max(0, parseInt(th.duration) || 0),
                        roleId:   th.roleId || ''
                    }));
            } catch(e) {
                thresholds = [];
            }

            // Fallback to old t1/t2/t3 if thresholds_json is missing (backward compat)
            if (thresholds.length === 0 && req.body.t1_count) {
                ['t1','t2','t3'].forEach(function(p) {
                    if (req.body[p + '_count']) {
                        thresholds.push({
                            count:    parseInt(req.body[p + '_count'])    || 1,
                            action:   req.body[p + '_action']             || 'mute',
                            duration: parseInt(req.body[p + '_duration']) || 0,
                            roleId:   req.body[p + '_roleId']             || ''
                        });
                    }
                });
            }

            settings.warnActions.thresholds = thresholds;
            saveSettings();
            res.redirect('/warnings?success=true');
        } catch(err) {
            console.error('❌ خطأ في حفظ إعدادات التحذيرات:', err);
            res.redirect('/warnings?error=true');
        }
    });

    // POST /warnings/remove-one
    app.post('/warnings/remove-one', (req, res) => {
        try {
            const { userId, index } = req.body;
            const guildWarns = getGuildWarns();
            if (guildWarns[userId]) {
                const idx = parseInt(index);
                if (!isNaN(idx) && idx >= 0 && idx < guildWarns[userId].length) {
                    guildWarns[userId].splice(idx, 1);
                    if (guildWarns[userId].length === 0) delete guildWarns[userId];
                    setGuildWarns(guildWarns);
                }
            }
            res.redirect('/warnings?success=true');
        } catch(err) {
            console.error('❌ خطأ في حذف تحذير:', err);
            res.redirect('/warnings?error=true');
        }
    });

    // POST /warnings/clear-user
    app.post('/warnings/clear-user', (req, res) => {
        try {
            const { userId } = req.body;
            const guildWarns = getGuildWarns();
            if (guildWarns[userId]) {
                delete guildWarns[userId];
                setGuildWarns(guildWarns);
            }
            res.redirect('/warnings?success=true');
        } catch(err) {
            console.error('❌ خطأ في مسح تحذيرات العضو:', err);
            res.redirect('/warnings?error=true');
        }
    });
};