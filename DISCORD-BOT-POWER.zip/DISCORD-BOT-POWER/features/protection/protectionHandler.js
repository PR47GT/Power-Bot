const { AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'clientReady',
    once: true,
    async execute(client, settings, ...args) {
        if (client.isReady()) {
            setupProtectionListeners(client);
        } else {
            client.once('clientReady', () => setupProtectionListeners(client));
        }
    }
};

function setupProtectionListeners(client) {
    const fs   = require('fs');
    const path = require('path');
    const PROTECTION_FILE = path.join(__dirname, '..', '..', 'protection.json');
    const BOTDATA_FILE    = path.join(__dirname, '..', '..', 'botData.json');
    const CONFIG_FILE     = path.join(__dirname, '..', '..', 'config.js');
    const config          = require(CONFIG_FILE);
const DATA_FILE = path.join(__dirname, '..', '..', 'data.json');

function loadSettings() {
    try {
        if (fs.existsSync(DATA_FILE))
            return JSON.parse(fs.readFileSync(DATA_FILE, 'utf8'));
    } catch(e) {}
    return {};
}

async function checkWarnThresholds(guild, userId) {
    try {
        const settings   = loadSettings();
        const warnActions = settings.warnActions;
        if (!warnActions || !warnActions.enabled) return;
        const lang = settings.botLanguage === 'ar' ? 'ar' : 'en';
const autoMsg = lang === 'ar'
    ? (count) => `إجراء تلقائي: بلغ ${count} تحذيرات`
    : (count) => `Auto action: reached ${count} warnings`;
const dmMsg = lang === 'ar'
    ? `⚠️ تلقيت تحذيراً بسبب تجاوز الحد في [${'{action}'}] - ${'{guild}'}`
    : `⚠️ You received a warning for exceeding the limit in [${'action'}] - ${'guild'}`;
      const all      = loadBotData();
        const guildId  = config.guildId;
        const warnCount = (all.warns?.[guildId]?.[userId] || []).length;

        const thresholds = warnActions.thresholds || [];
        const matched = thresholds
            .filter(th => warnCount === th.count)
            .sort((a, b) => b.count - a.count)[0];

        if (!matched) return;

        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member) return;

if (matched.action === 'mute') {
    const ms = (matched.duration || 60) * 60 * 1000;
    await member.timeout(ms, autoMsg(warnCount)).catch(() => {});
} else if (matched.action === 'kick') {
    await member.kick(autoMsg(warnCount)).catch(() => {});
} else if (matched.action === 'ban') {
    await guild.members.ban(userId, { reason: autoMsg(warnCount) }).catch(() => {});
} else if (matched.action === 'role') {
    if (matched.roleId) {
        await member.roles.add(matched.roleId, autoMsg(warnCount)).catch(() => {});
    }
}

        // لوق في القناة
        if (warnActions.logChannel) {
            const { EmbedBuilder } = require('discord.js');
            const logCh = guild.channels.cache.get(warnActions.logChannel);
            if (logCh) {
               const colors = { mute: '#FED130', kick: '#FFA500', ban: '#ED4245', role: '#5865F2' };
                const embed = new EmbedBuilder()
                    .setColor(colors[matched.action] || '#5865F2')
                    .setTitle('⚠️ Auto Warn Action')
                    .addFields(
                        { name: 'Member',   value: `<@${userId}>`,           inline: true },
                        { name: 'Warnings', value: `${warnCount}`,           inline: true },
                        { name: 'Action',   value: matched.action.toUpperCase(), inline: true }
                    )
                    .setTimestamp();
                logCh.send({ embeds: [embed] }).catch(() => {});
            }
        }
    } catch(e) {
        console.error('[Protection] خطأ في checkWarnThresholds:', e.message);
    }
}
   function loadBotData() {
        if (fs.existsSync(BOTDATA_FILE)) {
            try { return JSON.parse(fs.readFileSync(BOTDATA_FILE, 'utf8')); } catch(e) { return { warns: {}, tempRoles: {} }; }
        }
        return { warns: {}, tempRoles: {} };
    }

    function saveBotData(data) {
        fs.writeFileSync(BOTDATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    }

async function addProtectionWarn(userId, actionType, guild) {
    try {
        const all      = loadBotData();
        const guildId  = config.guildId;
        if (!all.warns) all.warns = {};
        if (!all.warns[guildId]) all.warns[guildId] = {};
        if (!all.warns[guildId][userId]) all.warns[guildId][userId] = [];
        all.warns[guildId][userId].push({
            reason: loadSettings().botLanguage === 'ar'
    ? `🛡️ الحماية: تجاوز الحد في [${actionType}]`
    : `🛡️ Protection: exceeded limit for [${actionType}]`,
            moderator: 'Protection System',
            timestamp: Date.now(),
            source:    'protection'
        });
        saveBotData(all);

        // ✅ أضف هذا السطر
        if (guild) await checkWarnThresholds(guild, userId);

    } catch(e) {
        console.error('[Protection] خطأ في إضافة تحذير:', e.message);
    }
}

    function loadProtection() {
        if (fs.existsSync(PROTECTION_FILE)) {
            try { return JSON.parse(fs.readFileSync(PROTECTION_FILE, 'utf8')); }
            catch(e) { return { enabled: false, protectionSettings: {} }; }
        }
        return { enabled: false, protectionSettings: {} };
    }

    const userActions = new Map();
    setInterval(() => {
        const now = Date.now();
        for (const [k, d] of userActions.entries()) {
            if (now - d.timestamp > 60000) userActions.delete(k);
        }
    }, 60000);

    // ─── اتخاذ الإجراء ────────────────────────────────────────────
    async function checkAndTakeAction(guild, userId, actionType) {
        const protection = loadProtection();
        
        if (!protection.enabled) return false;
        
        const featureSettings = protection.protectionSettings?.[actionType];
        if (!featureSettings) return false;

        const actionLimit      = parseInt(featureSettings.actionLimit) || 0;
        const protectionAction = featureSettings.protectionAction || featureSettings.action || 'none';

        if (actionLimit === 0 || protectionAction === 'none') return false;

        const moderationRoles = protection.moderationRoles || [];
        if (moderationRoles.length > 0) {
            const executor = await guild.members.fetch(userId).catch(() => null);
            if (executor?.roles.cache.some(r => moderationRoles.includes(r.id))) return false;
        }

        const key  = `${userId}_${actionType}`;
        const now  = Date.now();
        const data = userActions.get(key);

        if (!data || now - data.timestamp > 60000) {
            userActions.set(key, { count: 1, timestamp: now });
        } else {
            data.count++;
            userActions.set(key, data);
        }

        const currentCount = userActions.get(key).count;
        if (currentCount < actionLimit) return false;

        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member) return false;

        switch (protectionAction) {
           // بعد:
case 'remove_roles':
    try {
        const { PermissionFlagsBits } = require('discord.js');

        // الصلاحيات الخطرة التي تستوجب سحب الرتبة
        const DANGEROUS_PERMS = [
            PermissionFlagsBits.Administrator,
            PermissionFlagsBits.ManageGuild,
            PermissionFlagsBits.ManageRoles,
            PermissionFlagsBits.ManageChannels,
            PermissionFlagsBits.BanMembers,
            PermissionFlagsBits.KickMembers,
            PermissionFlagsBits.ManageMessages,
            PermissionFlagsBits.ManageWebhooks,
            PermissionFlagsBits.ManageNicknames,
            PermissionFlagsBits.MentionEveryone,
        ];

        const rolesToRemove = member.roles.cache.filter(role => {
            // تجاهل رتبة @everyone
            if (role.id === guild.id) return false;
            // تجاهل الرتب التي هي فوق رتبة البوت (البوت ما يقدر يشيلها)
            if (role.position >= guild.members.me.roles.highest.position) return false;
            // احذف فقط الرتب التي تحتوي صلاحية خطرة
            return DANGEROUS_PERMS.some(perm => role.permissions.has(perm));
        });

        if (rolesToRemove.size > 0) {
            await member.roles.remove(rolesToRemove, `حماية: تجاوز حد ${actionType}`);
        }
    } catch(e) {}
    break;
                break;
            case 'kick':
                try { await member.kick(`حماية: تجاوز حد ${actionType}`); } catch(e) {}
                break;
            case 'ban':
                try { await member.ban({ reason: `حماية: تجاوز حد ${actionType}` }); } catch(e) {}
                break;
    case 'warn':
    await addProtectionWarn(userId, actionType, guild);
               const _lang = loadSettings().botLanguage || 'en';
const _dmMsg = _lang === 'ar'
    ? `⚠️ تلقيت تحذيراً بسبب تجاوز الحد في [${actionType}] - ${guild.name}`
    : `⚠️ You received a warning for exceeding the limit in [${actionType}] - ${guild.name}`;
await member.send(_dmMsg).catch(() => {});
                break;
        }

        userActions.delete(key);
        return true;
    }

    // ─── جلب بسرعة (تقليل الانتظار) ──────────────────────────────
    async function fetchByType(guild, type, targetId, maxWaitMs = 2000) {
        const start = Date.now();
        while (Date.now() - start < maxWaitMs) {
            await new Promise(r => setTimeout(r, 200)); // تقليل من 500 إلى 200
            const logs = await guild.fetchAuditLogs({ limit: 3, type }).catch(() => null);
            if (!logs) continue;
            const entry = logs.entries.find(e => {
                const age = Date.now() - e.createdTimestamp;
                return age < 5000 && e.target?.id === targetId;
            });
            if (entry) return entry;
        }
        return null;
    }

    // ─── جلب بسرعة بدون فلتر نوع ────────────────────────────────
    async function fetchAny(guild, targetId, validTypes, maxWaitMs = 2000) {
        const start = Date.now();
        while (Date.now() - start < maxWaitMs) {
            await new Promise(r => setTimeout(r, 200)); // تقليل من 500 إلى 200
            const logs = await guild.fetchAuditLogs({ limit: 5 }).catch(() => null);
            if (!logs) continue;
            const entry = logs.entries.find(e => {
                const age = Date.now() - e.createdTimestamp;
                if (age > 6000) return false;
                if (!validTypes.includes(e.action)) return false;
                if (!targetId) return true;
                return e.target?.id === targetId || e.extra?.id === targetId;
            });
            if (entry) return entry;
        }
        return null;
    }

    // ==================== 1. الطرد ====================
    client.on('guildMemberRemove', async (member) => {
        if (!member.guild) return;
        const logs = await member.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberKick }).catch(() => null);
        if (!logs) return;
        const entry = logs.entries.first();
        if (!entry || Date.now() - entry.createdTimestamp > 3000) return;
        if (entry.target?.id === member.id) {
            await checkAndTakeAction(member.guild, entry.executor.id, 'memberKick');
        }
    });

    // ==================== 2. الحظر ====================
    client.on('guildBanAdd', async (ban) => {
        const logs = await ban.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanAdd }).catch(() => null);
        if (!logs) return;
        const entry = logs.entries.first();
        if (!entry || Date.now() - entry.createdTimestamp > 3000) return;
        if (entry.target?.id === ban.user.id) {
            await checkAndTakeAction(ban.guild, entry.executor.id, 'memberBan');
        }
    });

    // ==================== 3. تحديث الرتبة ====================
    client.on('roleUpdate', async (oldRole, newRole) => {
        const entry = await fetchAny(newRole.guild, newRole.id, [AuditLogEvent.RoleUpdate]);
        if (entry) await checkAndTakeAction(newRole.guild, entry.executor.id, 'roleUpdate');
    });

    // ==================== 4. تحديث القناة ====================
    client.on('channelUpdate', async (oldChannel, newChannel) => {
        if (!newChannel.guild) return;
        const entry = await fetchAny(
            newChannel.guild, newChannel.id,
            [
                AuditLogEvent.ChannelUpdate,
                AuditLogEvent.ChannelOverwriteCreate,
                AuditLogEvent.ChannelOverwriteUpdate,
                AuditLogEvent.ChannelOverwriteDelete
            ]
        );
        if (entry) await checkAndTakeAction(newChannel.guild, entry.executor.id, 'channelUpdate');
    });

    // ==================== 5. حذف القناة ====================
    client.on('channelDelete', async (channel) => {
        if (!channel.guild) return;
        const entry = await fetchByType(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
        if (entry) await checkAndTakeAction(channel.guild, entry.executor.id, 'channelDelete');
    });

    // ==================== 6. إنشاء القناة ====================
    client.on('channelCreate', async (channel) => {
        if (!channel.guild) return;
        const entry = await fetchByType(channel.guild, AuditLogEvent.ChannelCreate, channel.id);
        if (entry) await checkAndTakeAction(channel.guild, entry.executor.id, 'channelCreate');
    });

    // ==================== 7. حذف الرتبة ====================
    client.on('roleDelete', async (role) => {
        if (!role.guild) return;
        const entry = await fetchByType(role.guild, AuditLogEvent.RoleDelete, role.id);
        if (entry) await checkAndTakeAction(role.guild, entry.executor.id, 'roleDelete');
    });

    // ==================== 8. إنشاء الرتبة ====================
    client.on('roleCreate', async (role) => {
        if (!role.guild) return;
        const entry = await fetchByType(role.guild, AuditLogEvent.RoleCreate, role.id);
        if (entry) await checkAndTakeAction(role.guild, entry.executor.id, 'roleCreate');
    });

    // ==================== 9. تحديث السيرفر ====================
    client.on('guildUpdate', async (oldGuild, newGuild) => {
        const entry = await fetchAny(newGuild, null, [AuditLogEvent.GuildUpdate]);
        if (entry) await checkAndTakeAction(newGuild, entry.executor.id, 'guildUpdate');
    });

    // ==================== 10. إنشاء إيموجي ====================
    client.on('emojiCreate', async (emoji) => {
        if (!emoji.guild) return;
        const entry = await fetchByType(emoji.guild, AuditLogEvent.EmojiCreate, emoji.id);
        if (entry) await checkAndTakeAction(emoji.guild, entry.executor.id, 'emojiCreate');
    });

    // ==================== 11. حذف إيموجي ====================
    client.on('emojiDelete', async (emoji) => {
        if (!emoji.guild) return;
        const entry = await fetchByType(emoji.guild, AuditLogEvent.EmojiDelete, emoji.id);
        if (entry) await checkAndTakeAction(emoji.guild, entry.executor.id, 'emojiDelete');
    });

    // ==================== 12. تحديث إيموجي ====================
    client.on('emojiUpdate', async (oldEmoji, newEmoji) => {
        if (!newEmoji.guild) return;
        const entry = await fetchByType(newEmoji.guild, AuditLogEvent.EmojiUpdate, newEmoji.id);
        if (entry) await checkAndTakeAction(newEmoji.guild, entry.executor.id, 'emojiUpdate');
    });

    // ==================== 13. إنشاء ستيكر ====================
    client.on('stickerCreate', async (sticker) => {
        if (!sticker.guild) return;
        const entry = await fetchByType(sticker.guild, AuditLogEvent.StickerCreate, sticker.id);
        if (entry) await checkAndTakeAction(sticker.guild, entry.executor.id, 'stickerCreate');
    });

    // ==================== 14. حذف ستيكر ====================
    client.on('stickerDelete', async (sticker) => {
        if (!sticker.guild) return;
        const entry = await fetchByType(sticker.guild, AuditLogEvent.StickerDelete, sticker.id);
        if (entry) await checkAndTakeAction(sticker.guild, entry.executor.id, 'stickerDelete');
    });

    // ==================== 15. تحديث ستيكر ====================
    client.on('stickerUpdate', async (oldSticker, newSticker) => {
        if (!newSticker.guild) return;
        const entry = await fetchByType(newSticker.guild, AuditLogEvent.StickerUpdate, newSticker.id);
        if (entry) await checkAndTakeAction(newSticker.guild, entry.executor.id, 'stickerUpdate');
    });

    // ==================== 16. الويب هوك (إنشاء / حذف / تحديث) ====================
    // ملاحظة: Discord.js عنده حدث واحد فقط "webhookUpdate" يُطلق لأي تغيير
    // على ويب هوكات القناة (سواء إنشاء أو حذف أو تعديل)، فنفحص الـ Audit Log
    // لنعرف النوع الحقيقي ونوجهه للمفتاح الصحيح.
    client.on('webhooksUpdate', async (channel) => {
        if (!channel.guild) return;
        const start = Date.now();
        const validTypes = [
            AuditLogEvent.WebhookCreate,
            AuditLogEvent.WebhookDelete,
            AuditLogEvent.WebhookUpdate
        ];
        let entry = null;
        while (Date.now() - start < 2000) {
            await new Promise(r => setTimeout(r, 200));
            const logs = await channel.guild.fetchAuditLogs({ limit: 5 }).catch(() => null);
            if (!logs) continue;
            entry = logs.entries.find(e => {
                const age = Date.now() - e.createdTimestamp;
                return age < 5000 && validTypes.includes(e.action);
            });
            if (entry) break;
        }
        if (!entry) return;

        let actionType;
        if (entry.action === AuditLogEvent.WebhookCreate) actionType = 'webhookCreate';
        else if (entry.action === AuditLogEvent.WebhookDelete) actionType = 'webhookDelete';
        else actionType = 'webhookUpdate';

        await checkAndTakeAction(channel.guild, entry.executor.id, actionType);
    });
}