const fs = require('fs');
const path = require('path');

const PROTECTION_FILE = path.join(__dirname, '..', '..', 'protection.json');

let protection = {};

function loadProtection() {
    if (fs.existsSync(PROTECTION_FILE)) {
        try {
            protection = JSON.parse(fs.readFileSync(PROTECTION_FILE, 'utf8'));
        } catch(e) {
            protection = getDefaultProtection();
        }
    } else {
        protection = getDefaultProtection();
        saveProtection();
    }
}

function getDefaultProtection() {
    return {
        enabled: false,
        moderationRoles: [],
        restrictToOwner: false,
        dashboardPermission: "administrator",
        trustedBots: [],
        protectionSettings: {
            roleDelete: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            roleCreate: { enabled: false, action: "log", logChannel: "", embedColor: "#57F287", actionLimit: 0, protectionAction: "none" },
            roleUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFA500", actionLimit: 0, protectionAction: "none" },
            channelDelete: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            channelCreate: { enabled: false, action: "log", logChannel: "", embedColor: "#57F287", actionLimit: 0, protectionAction: "none" },
            channelUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFA500", actionLimit: 0, protectionAction: "none" },
            memberKick: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            memberBan: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            guildUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFA500", actionLimit: 0, protectionAction: "none" },
            webhookCreate: { enabled: false, action: "log", logChannel: "", embedColor: "#5865F2", actionLimit: 0, protectionAction: "none" },
            webhookDelete: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            webhookUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFA500", actionLimit: 0, protectionAction: "none" },
            emojiCreate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFD700", actionLimit: 0, protectionAction: "none" },
            emojiDelete: { enabled: false, action: "log", logChannel: "", embedColor: "#ED4245", actionLimit: 0, protectionAction: "none" },
            emojiUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#FFA500", actionLimit: 0, protectionAction: "none" },
            stickerCreate: { enabled: false, action: "log", logChannel: "", embedColor: "#9B59B6", actionLimit: 0, protectionAction: "none" },
            stickerDelete: { enabled: false, action: "log", logChannel: "", embedColor: "#E74C3C", actionLimit: 0, protectionAction: "none" },
            stickerUpdate: { enabled: false, action: "log", logChannel: "", embedColor: "#F1C40F", actionLimit: 0, protectionAction: "none" },
        suspiciousBots: { enabled: false, action: "kick", logChannel: "", embedColor: "#FF0000" }
        },
        protectedRoles: {
            enabled: false,
            roles: [],
            bypassRoles: [],
            action: 'remove',
            logChannel: ''
        }
    };
}

function saveProtection() {
    fs.writeFileSync(PROTECTION_FILE, JSON.stringify(protection, null, 2), 'utf8');
}

function registerProtectionRoutes(app, client, deps) {
    const { loadData, getGuildChannels, getGuildRoles, getSettings, config, takeBackup } = deps;

    // تحميل أولي عند التسجيل
    loadProtection();

    // ==================== صفحة الحماية ====================
    app.get('/protection', async (req, res) => {
        await loadData(true);
        res.render('protection', {
            protection,
            guildChannels: getGuildChannels(),
            guildRoles: getGuildRoles(),
            settings: getSettings()
        });
    });

    // ==================== حفظ إعدادات الحماية ====================
    app.post('/protection', (req, res) => {
        try {
            protection.enabled = req.body.protectionEnabled === 'on' || req.body.protectionEnabled === 'true';

            let moderationRoles = [];
            try {
                const rolesInput = req.body.moderationRoles;
                if (rolesInput && typeof rolesInput === 'string') {
                    moderationRoles = JSON.parse(rolesInput);
                }
            } catch(e) {}

            let trustedBots = [];
            try {
                const botsInput = req.body.trustedBots;
                if (botsInput && typeof botsInput === 'string') {
                    trustedBots = JSON.parse(botsInput);
                }
            } catch(e) {}

            protection.moderationRoles = moderationRoles;
            protection.restrictToOwner = req.body.restrictToOwner === 'on' || req.body.restrictToOwner === 'true';
            protection.dashboardPermission = req.body.dashboardPermission || 'administrator';
            protection.trustedBots = trustedBots;

            const protectionKeys = [
    'memberBan', 'memberKick', 'roleUpdate', 'channelUpdate',
    'channelDelete', 'roleDelete', 'channelCreate', 'roleCreate', 'guildUpdate',
    'webhookCreate', 'webhookDelete', 'webhookUpdate',
    'emojiCreate', 'emojiDelete', 'emojiUpdate',
    'stickerCreate', 'stickerDelete', 'stickerUpdate'
];

            const formSettings = req.body.protectionSettings || {};

            for (const key of protectionKeys) {
                if (!protection.protectionSettings[key]) {
                    protection.protectionSettings[key] = {};
                }

                if (formSettings[key] && formSettings[key].actionLimit !== undefined) {
                    protection.protectionSettings[key].actionLimit =
                        parseInt(formSettings[key].actionLimit) || 0;
                }

                if (formSettings[key] && formSettings[key].protectionAction !== undefined) {
                    protection.protectionSettings[key].protectionAction =
                        formSettings[key].protectionAction;
                }

                const limit = protection.protectionSettings[key].actionLimit || 0;
                const action = protection.protectionSettings[key].protectionAction || 'none';
                if (protection.enabled) {
                    protection.protectionSettings[key].enabled = (limit > 0 && action !== 'none');
                } else {
                    protection.protectionSettings[key].enabled = false;
                }
            }

            if (!protection.protectionSettings.suspiciousBots) {
                protection.protectionSettings.suspiciousBots = {};
            }
            if (protection.enabled) {
                protection.protectionSettings.suspiciousBots.enabled =
                    req.body['suspiciousBotsEnabled'] === 'on' || req.body['suspiciousBotsEnabled'] === 'true';
            } else {
                protection.protectionSettings.suspiciousBots.enabled = false;
            }
            if (req.body['suspiciousBotsChannel']) {
                protection.protectionSettings.suspiciousBots.logChannel = req.body['suspiciousBotsChannel'];
            }

            // حفظ إعدادات النسخ الاحتياطي
            let backupBypassRoles = [];
            try {
                const bkBypassRaw = req.body.backupBypassRoles;
                backupBypassRoles = (bkBypassRaw && typeof bkBypassRaw === 'string') ? JSON.parse(bkBypassRaw) : [];
            } catch(e) {
                backupBypassRoles = [];
            }

            protection.backup = {
                enabled:              req.body.backupEnabled === 'on',
                restoreChannels:      req.body.backupRestoreChannels   === 'on',
                restoreRoles:         req.body.backupRestoreRoles       === 'on',
                restoreServerName:    req.body.backupRestoreServerName  === 'on',
                restoreServerIcon:    req.body.backupRestoreServerIcon  === 'on',
                restoreChannelName:   req.body.backupRestoreChannelName === 'on',
                restoreRoleName:      req.body.backupRestoreRoleName    === 'on',
                logChannel:           req.body.backupLogChannel || null,
                bypassRoles:          backupBypassRoles,
                lastBackup:           protection.backup ? protection.backup.lastBackup : null
            };

            if (protection.backup.enabled) {
                const bkGuild = client.guilds.cache.get(config.guildId) || client.guilds.cache.first();
                if (bkGuild) takeBackup(bkGuild).catch(e => console.error('[Backup] خطأ:', e.message));
            }

            // حفظ إعدادات الرتب المحمية
            if (!protection.protectedRoles) protection.protectedRoles = {};
            protection.protectedRoles.enabled =
                req.body.protectedRolesEnabled === 'on' || req.body.protectedRolesEnabled === 'true';
            try {
                const rolesRaw = req.body.protectedRoles;
                protection.protectedRoles.roles =
                    (rolesRaw && typeof rolesRaw === 'string') ? JSON.parse(rolesRaw) : [];
            } catch(e) {
                protection.protectedRoles.roles = [];
            }
            try {
                const bypassRaw = req.body.protectedBypassRoles;
                protection.protectedRoles.bypassRoles =
                    (bypassRaw && typeof bypassRaw === 'string') ? JSON.parse(bypassRaw) : [];
            } catch(e) {
                protection.protectedRoles.bypassRoles = [];
            }
            protection.protectedRoles.action     = req.body.protectedRolesAction     || 'remove';
            protection.protectedRoles.logChannel = req.body.protectedRolesLogChannel || '';

            saveProtection();
            res.redirect('/protection?success=true');
        } catch (err) {
            console.error('❌ خطأ في حفظ إعدادات الحماية:', err);
            res.redirect('/protection?error=true');
        }
    });

    // ==================== نسخ احتياطي يدوي ====================
    app.post('/protection/backup', async (req, res) => {
        try {
            const guild = client.guilds.cache.get(config.guildId) || client.guilds.cache.first();
            if (!guild) return res.json({ ok: false, error: 'البوت غير موجود في أي سيرفر' });
            await takeBackup(guild);
            res.json({ ok: true });
        } catch(e) {
            console.error('[Backup] ❌ خطأ في النسخ اليدوي:', e.message);
            res.json({ ok: false, error: e.message });
        }
    });

    return {
        getProtection: () => protection,
        loadProtection
    };
}

module.exports = registerProtectionRoutes;