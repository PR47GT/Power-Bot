'use strict';

const { EmbedBuilder } = require('discord.js');

const LANG = {
    ar: {
        embedTitle:   '🔒 رتبة محمية — سُحبت تلقائياً',
        fieldMember:  'العضو',
        fieldRole:    'الرتبة',
        fieldExecutor:'المعطي',
        fieldAction:  'الإجراء',
        actionLog:    'سحب الرتبة',
        actionBan:    'سحب + حظر المعطي',
        unknownExec:  'غير معروف',
        banReason:    (roleName) => `[رتبة محمية] أعطى رتبة محمية: ${roleName}`,
        removeReason: '[رتبة محمية] سحب تلقائي'
    },
    en: {
        embedTitle:   '🔒 Protected Role — Auto Removed',
        fieldMember:  'Member',
        fieldRole:    'Role',
        fieldExecutor:'Given by',
        fieldAction:  'Action',
        actionLog:    'Role removed',
        actionBan:    'Removed + banned assigner',
        unknownExec:  'Unknown',
        banReason:    (roleName) => `[Protected Role] Assigned a protected role: ${roleName}`,
        removeReason: '[Protected Role] Auto remove'
    }
};

function getLang(getSettings) {
    try {
        const s = getSettings ? getSettings() : {};
        const lang = s && s.botLanguage;
        return LANG[lang] || LANG['ar'];
    } catch(e) {
        return LANG['ar'];
    }
}

function register(client, getProtection, getSettings) {

    client.on('guildMemberUpdate', async (oldMember, newMember) => {
        try {
            const fullProtection = getProtection ? getProtection() : {};
            const pr = fullProtection && fullProtection.protectedRoles;
            if (!pr || !pr.enabled || !pr.roles || pr.roles.length === 0) return;

            const addedRoles = newMember.roles.cache.filter(
                r => !oldMember.roles.cache.has(r.id)
            );
            if (addedRoles.size === 0) return;

            const hit = addedRoles.find(r => pr.roles.includes(r.id));
            if (!hit) return;

            // ─── تحديد من أعطى الرتبة أولاً قبل أي إجراء ─────────────────
            let executor = null;
            try {
                await new Promise(resolve => setTimeout(resolve, 600));
                const logs = await newMember.guild.fetchAuditLogs({ type: 25, limit: 5 });
                const entry = logs.entries.find(e =>
                    e.target.id === newMember.id &&
                    Date.now() - e.createdTimestamp < 6000
                );
                if (entry) executor = entry.executor;
            } catch(e) {}

            // ─── استثناء صاحب السيرفر — لا نتدخل ─────────────────────────
            if (executor && executor.id === newMember.guild.ownerId) return;

            // ─── استثناء أصحاب رتب البايباس — لا نتدخل ────────────────────
            if (executor && pr.bypassRoles && pr.bypassRoles.length > 0) {
                const execMember = await newMember.guild.members.fetch(executor.id).catch(() => null);
                if (execMember && pr.bypassRoles.some(id => execMember.roles.cache.has(id))) {
                    return;
                }
            }

            const t = getLang(getSettings);

            await newMember.roles.remove(hit.id, t.removeReason).catch(() => {});

            if ((pr.action === 'remove_log' || pr.action === 'remove_ban') && pr.logChannel) {
                const logCh = newMember.guild.channels.cache.get(pr.logChannel);
                if (logCh) {
                    const embed = new EmbedBuilder()
                        .setColor('#ED4245')
                        .setTitle(t.embedTitle)
                        .addFields(
                            { name: t.fieldMember,   value: `<@${newMember.id}> (${newMember.user.tag})`, inline: true },
                            { name: t.fieldRole,     value: `<@&${hit.id}> (${hit.name})`,               inline: true },
                            { name: t.fieldExecutor, value: executor ? `<@${executor.id}>` : t.unknownExec, inline: true },
                            { name: t.fieldAction,   value: pr.action === 'remove_ban' ? t.actionBan : t.actionLog, inline: true }
                        )
                        .setTimestamp();
                    await logCh.send({ embeds: [embed] }).catch(() => {});
                }
            }

            if (pr.action === 'remove_ban' && executor && executor.id !== client.user.id) {
                await newMember.guild.bans.create(executor.id, {
                    reason: t.banReason(hit.name)
                }).catch(() => {});
            }

        } catch(err) {}
    });
}

module.exports = { register };