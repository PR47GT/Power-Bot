// ==================== features/protection/backup.js ====================

const fs     = require('fs');
const path   = require('path');
const https  = require('https');
const http   = require('http');
const { EmbedBuilder, PermissionsBitField, AuditLogEvent } = require('discord.js');

const PROTECTION_FILE = path.join(__dirname, '../../protection.json');
const BACKUP_FILE     = path.join(__dirname, '../../server_backup.json');
const SETTINGS_FILE   = path.join(__dirname, '../../data.json');

const restoringRoles    = new Set();
const restoringChannels = new Set();

const roleRestoreQueue = [];
let   roleRestoreTimer = null;

let backupInProgress = false;

// ── الترجمات ────────────────────────────────────────────────────────────────
const T = {
    ar: {
        channelRestored:      '🔄 تمت استعادة روم محذوف',
        channelRestoredDesc:  (type, name, ch) => `تم حذف الروم **${type}${name}** وتمت استعادته تلقائياً.\nالروم الجديد: ${ch}`,
        roleRestored:         '🔄 تمت استعادة رتبة محذوفة',
        roleRestoredDesc:     (name, role) => `تم حذف الرتبة **@${name}** وتمت استعادتها تلقائياً.\nالرتبة الجديدة: ${role}`,
        serverRestored:       '🔄 تمت استعادة إعدادات السيرفر',
        nameChanged:          (newName, oldName) => `تم تغيير اسم السيرفر إلى **${newName}** وأُعيد إلى **${oldName}**`,
        iconRestored:         'تمت استعادة أيقونة السيرفر الأصلية',
        autoReason:           '[Anti-Nuke] استعادة تلقائية',
        footer:               'نظام النسخ الاحتياطي التلقائي',
        fieldType:            '📁 النوع',
        fieldName:            '🏷️ الاسم',
        fieldNew:             '✅ العنصر الجديد',
        fieldExecutor:        '👤 المنفذ',
        roleNameChanged: (newName, oldName) => `تم تغيير اسم الرتبة إلى **${newName}** وأُعيد إلى **${oldName}**`,
        channelNameChanged: (newName, oldName) => `تم تغيير اسم الروم إلى **${newName}** وأُعيد إلى **${oldName}**`,
        failureTitle:        '⚠️ فشلت عملية الاستعادة التلقائية',
        failureRole:         (name, reason) => `فشلت استعادة الرتبة **"${name}"**.\nالسبب: \`${reason}\`\nيرجى التحقق من صلاحيات البوت (Manage Roles).`,
        failureChannel:      (name, reason) => `فشلت استعادة الروم **"${name}"**.\nالسبب: \`${reason}\`\nيرجى التحقق من صلاحيات البوت (Manage Channels).`,
        failureGuild:        (reason) => `فشلت استعادة إعدادات السيرفر.\nالسبب: \`${reason}\`\nيرجى التحقق من صلاحيات البوت (Manage Server).`,
        failureRoleName:     (name, reason) => `فشل تغيير اسم الرتبة **"${name}"** للاسم الأصلي.\nالسبب: \`${reason}\``,
        failureChannelName:  (name, reason) => `فشل تغيير اسم الروم **"${name}"** للاسم الأصلي.\nالسبب: \`${reason}\``,
        failureBackup:       (reason) => `فشلت عملية أخذ النسخة الاحتياطية.\nالسبب: \`${reason}\`\nيرجى التحقق من صلاحيات البوت.`,
    },
    en: {
        channelRestored:      '🔄 Deleted Channel Restored',
        channelRestoredDesc:  (type, name, ch) => `The channel **${type}${name}** was deleted and has been automatically restored.\nNew channel: ${ch}`,
        roleRestored:         '🔄 Deleted Role Restored',
        roleRestoredDesc:     (name, role) => `The role **@${name}** was deleted and has been automatically restored.\nNew role: ${role}`,
        serverRestored:       '🔄 Server Settings Restored',
        nameChanged:          (newName, oldName) => `Server name was changed to **${newName}** and restored to **${oldName}**`,
        iconRestored:         'The original server icon has been restored',
        autoReason:           '[Anti-Nuke] Auto Restore',
        footer:               'Auto Backup & Restore System',
        fieldType:            '📁 Type',
        fieldName:            '🏷️ Name',
        fieldNew:             '✅ New Element',
        fieldExecutor:        '👤 Executed by',
        roleNameChanged: (newName, oldName) => `Role name was changed to **${newName}** and restored to **${oldName}**`,
        channelNameChanged: (newName, oldName) => `Channel name was changed to **${newName}** and restored to **${oldName}**`,
        failureTitle:        '⚠️ Auto-Restore Failed',
        failureRole:         (name, reason) => `Failed to restore role **"${name}"**.\nReason: \`${reason}\`\nPlease check the bot's permissions (Manage Roles).`,
        failureChannel:      (name, reason) => `Failed to restore channel **"${name}"**.\nReason: \`${reason}\`\nPlease check the bot's permissions (Manage Channels).`,
        failureGuild:        (reason) => `Failed to restore server settings.\nReason: \`${reason}\`\nPlease check the bot's permissions (Manage Server).`,
        failureRoleName:     (name, reason) => `Failed to revert the name of role **"${name}"**.\nReason: \`${reason}\``,
        failureChannelName:  (name, reason) => `Failed to revert the name of channel **"${name}"**.\nReason: \`${reason}\``,
        failureBackup:       (reason) => `Failed to take a backup snapshot.\nReason: \`${reason}\`\nPlease check the bot's permissions.`,
    }
};

function getLang() {
    try {
        if (fs.existsSync(SETTINGS_FILE)) {
            const s = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
            return T[s.botLanguage] || T.ar;
        }
    } catch(e) {}
    return T.ar;
}

// ── جلب منفذ العملية من الـ Audit Log ────────────────────────────────────────
async function getAuditLogExecutor(guild, actionType, targetId) {
    try {
        const logs = await guild.fetchAuditLogs({ type: actionType, limit: 5 });
        const entry = logs.entries.find(function(e) {
            return e.target?.id === targetId && (Date.now() - e.createdTimestamp) < 10000;
        });
        return entry ? entry.executor : null;
    } catch (e) {
        return null;
    }
}

function executorField(lang, executor) {
    if (!executor) return null;
    return { name: lang.fieldExecutor, value: `${executor} (\`${executor.tag}\`)`, inline: true };
}

// ── هل المنفذ مستثنى من الاستعادة التلقائية؟ ─────────────────────────────────
async function isExecutorBypassed(guild, executor, prot) {
    if (!executor) return false;
    if (executor.id === guild.ownerId) return true;

    const bypassRoles = prot?.backup?.bypassRoles || [];
    if (bypassRoles.length === 0) return false;

    try {
        const member = await guild.members.fetch(executor.id).catch(() => null);
        if (!member) return false;
        return member.roles.cache.some(r => bypassRoles.includes(r.id));
    } catch (e) {
        return false;
    }
}

// ── إرسال تنبيه عند فشل عملية استعادة ─────────────────────────────────────────
async function sendFailureLog(guild, prot, description) {
    console.error('[Backup Failure]', guild?.name || guild?.id, '-', description);
    const lang = getLang();
    await sendRestoreLog(guild, prot, lang.failureTitle, description, '#ED4245').catch(() => {});
}

// ── تحميل صورة من URL ────────────────────────────────────────────────────────
function fetchImageBuffer(url) {
    return new Promise(function(resolve, reject) {
        const client = url.startsWith('https') ? https : http;
        client.get(url, function(res) {
            if (res.statusCode === 301 || res.statusCode === 302) {
                return fetchImageBuffer(res.headers.location).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) return reject(new Error('HTTP ' + res.statusCode));
            const chunks = [];
            res.on('data', function(chunk) { chunks.push(chunk); });
            res.on('end',  function() { resolve(Buffer.concat(chunks)); });
            res.on('error', reject);
        }).on('error', reject);
    });
}

// ── تحميل وحفظ ───────────────────────────────────────────────────────────────
function loadProtection() {
    if (fs.existsSync(PROTECTION_FILE)) {
        try { return JSON.parse(fs.readFileSync(PROTECTION_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function loadBackup() {
    if (fs.existsSync(BACKUP_FILE)) {
        try { return JSON.parse(fs.readFileSync(BACKUP_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function saveBackup(data) {
    fs.writeFileSync(BACKUP_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// ── أخذ نسخة احتياطية كاملة ─────────────────────────────────────────────────
async function takeBackup(guild) {
    if (backupInProgress) return;
    backupInProgress = true;

    try {
        await guild.roles.fetch();
        await guild.channels.fetch();

        const channels = guild.channels.cache
            .filter(c => c.type !== undefined)
            .map(c => ({
                id:       c.id,
                name:     c.name,
                type:     c.type,
                parentId: c.parentId,
                position: c.position,
                topic:    c.topic     || null,
                nsfw:     c.nsfw      || false,
                bitrate:  c.bitrate   || null,
                userLimit: c.userLimit || null,
                permissionOverwrites: c.permissionOverwrites?.cache.map(o => ({
                    id:    o.id,
                    type:  o.type,
                    allow: o.allow.toArray(),
                    deny:  o.deny.toArray()
                })) || []
            }));

        const roles = guild.roles.cache
            .filter(r => r.id !== guild.id)
            .map(r => ({
                id:          r.id,
                name:        r.name,
               colors:      { primaryColor: r.color },
                hoist:       r.hoist,
                position:    r.position,
                permissions: r.permissions.toArray(),
                mentionable: r.mentionable
            }));

        const backup = {
            guildId:   guild.id,
            guildName: guild.name,
            guildIcon: await (async () => {
    const url = guild.iconURL({ format: 'png', size: 1024 });
    if (!url) return null;
    try {
        const buf = await fetchImageBuffer(url);
        return `data:image/png;base64,${buf.toString('base64')}`;
    } catch(e) {
        return url;
    }
})(),
            takenAt:   Date.now(),
            channels,
            roles
        };

        saveBackup(backup);

        const prot = loadProtection();
        if (!prot.backup) prot.backup = {};
        prot.backup.lastBackup = Date.now();
        fs.writeFileSync(PROTECTION_FILE, JSON.stringify(prot, null, 2), 'utf8');

    } catch(e) {
        const lang = getLang();
        await sendFailureLog(guild, loadProtection(), lang.failureBackup(e.message));
    } finally {
        backupInProgress = false;
    }
}

// ── إرسال لوق استعادة احترافي ────────────────────────────────────────────────
async function sendRestoreLog(guild, prot, title, description, color = '#57F287', fields = []) {
    const logChannelId = prot?.backup?.logChannel;
    if (!logChannelId) return;

    const channel = guild.channels.cache.get(logChannelId)
        || await guild.channels.fetch(logChannelId).catch(() => null);
    if (!channel) return;

    const lang = getLang();

    const embed = new EmbedBuilder()
        .setTitle(title)
        .setDescription(description)
        .setColor(color)
        .setAuthor({
            name: guild.name,
            iconURL: guild.iconURL({ dynamic: true }) ?? undefined
        })
        .setTimestamp()
        .setFooter({ text: lang.footer });

    if (fields.length > 0) embed.addFields(fields);

    await channel.send({ embeds: [embed] }).catch(() => {});
}

// ── طابور استعادة الرومات ────────────────────────────────────────────────────
const channelRestoreQueue = [];
let   channelRestoreTimer = null;

async function queueChannelRestore(guild, deletedChannel, prot, executor) {
    if (!prot?.backup?.enabled || !prot?.backup?.restoreChannels) return;
    if (restoringChannels.has(deletedChannel.id)) return;
    if (await isExecutorBypassed(guild, executor, prot)) return;

    const backup = loadBackup();
    if (!backup.channels) return;

    let saved = backup.channels.find(c => c.id === deletedChannel.id);
    if (!saved) saved = backup.channels.find(
        c => c.name === deletedChannel.name && c.type === deletedChannel.type
    );
    if (!saved) return;

    restoringChannels.add(deletedChannel.id);
    channelRestoreQueue.push({ guild, saved, executor });

    clearTimeout(channelRestoreTimer);
    channelRestoreTimer = setTimeout(() => processChannelQueue(prot), 600);
}

async function processChannelQueue(prot) {
    if (channelRestoreQueue.length === 0) return;

    const items = channelRestoreQueue.splice(0, channelRestoreQueue.length);
    const CATEGORY_TYPE = 4;

    items.sort((a, b) => {
        const aIsCat = a.saved.type === CATEGORY_TYPE ? 0 : 1;
        const bIsCat = b.saved.type === CATEGORY_TYPE ? 0 : 1;
        return aIsCat - bIsCat;
    });

    const idMap = {};
    const lang  = getLang();

    for (const { guild, saved, executor } of items) {
        try {
            let parent = null;
            if (saved.parentId) {
                parent = idMap[saved.parentId]
                    || guild.channels.cache.get(saved.parentId)
                    || await guild.channels.fetch(saved.parentId).catch(() => null);
            }

     const newChannel = await guild.channels.create({
    name:   saved.name,
    type:   saved.type,
    parent: parent,
    topic:  saved.topic  || undefined,
    nsfw:   saved.nsfw   || false,
    position: saved.position !== undefined ? saved.position : undefined,
    permissionOverwrites: saved.permissionOverwrites?.map(o => ({
        id:    o.id,
        type:  o.type,
        allow: BigInt(new PermissionsBitField(o.allow).bitfield),
        deny:  BigInt(new PermissionsBitField(o.deny).bitfield),
    })) || [],
    reason: lang.autoReason
});

            idMap[saved.id] = newChannel;

            const freshBackup = loadBackup();
            if (freshBackup.channels) {
                const oldId = saved.id;
                const newId = newChannel.id;
                const idx = freshBackup.channels.findIndex(c => c.id === oldId);
                if (idx !== -1) freshBackup.channels[idx].id = newId;

                if (saved.type === CATEGORY_TYPE) {
                    // ── إعادة الرومات التي لم تُحذف لكنها فُصلت عن الكاتيجوري المحذوفة ──
                    const orphanedChildren = freshBackup.channels
                        .filter(c => c.parentId === oldId)
                        .sort((a, b) => (a.position ?? 0) - (b.position ?? 0));

                    for (const child of orphanedChildren) {
                        const liveChannel = guild.channels.cache.get(child.id)
                            || await guild.channels.fetch(child.id).catch(() => null);

                        if (liveChannel && liveChannel.parentId !== newId) {
                            await liveChannel.setParent(newId, {
                                lockPermissions: false,
                                reason: lang.autoReason
                            }).catch(() => {});

                            if (typeof child.position === 'number') {
                                await liveChannel.setPosition(child.position).catch(() => {});
                            }
                        }
                    }

                    freshBackup.channels.forEach(c => {
                        if (c.parentId === oldId) c.parentId = newId;
                    });
                }

                saveBackup(freshBackup);
            }

            restoringChannels.add(newChannel.id);
            setTimeout(() => restoringChannels.delete(newChannel.id), 10000);

            const typeIcon = saved.type === CATEGORY_TYPE ? '📁 ' : '#';
            const chFields = [
                { name: lang.fieldName, value: `\`${saved.name}\``, inline: true },
                { name: lang.fieldNew,  value: `${newChannel}`,     inline: true },
            ];
            const chExecField = executorField(lang, executor);
            if (chExecField) chFields.push(chExecField);

            await sendRestoreLog(
                guild, prot,
                lang.channelRestored,
                lang.channelRestoredDesc(typeIcon, saved.name, newChannel),
                '#57F287',
                chFields
            );
        } catch(e) {
            await sendFailureLog(guild, prot, lang.failureChannel(saved.name, e.message));
        } finally {
            setTimeout(() => restoringChannels.delete(saved.id), 10000);
        }
    }

    // ── إعادة ترتيب كل الرومات دفعة وحدة حسب الباك أب الأصلي ──
    try {
        const firstGuild  = items[0].guild;
        const freshBackup = loadBackup();
        await firstGuild.channels.fetch();

        const positionsPayload = [];
        (freshBackup.channels || []).forEach(saved => {
            const liveChannel = firstGuild.channels.cache.get(saved.id);
            if (liveChannel && typeof saved.position === 'number') {
                positionsPayload.push({ channel: liveChannel.id, position: saved.position });
            }
        });

        if (positionsPayload.length > 0) {
            await firstGuild.channels.setPositions(positionsPayload).catch(() => {});
        }
    } catch(e) {}
}

// ── استعادة رتبة محذوفة ──────────────────────────────────────────────────────
async function queueRoleRestore(guild, deletedRole, prot, executor) {
    if (!prot?.backup?.enabled || !prot?.backup?.restoreRoles) return;
    if (restoringRoles.has(deletedRole.id)) return;
    if (await isExecutorBypassed(guild, executor, prot)) return;

    const backup = loadBackup();
    if (!backup.roles) return;

    let saved = backup.roles.find(r => r.id === deletedRole.id);
    if (!saved) saved = backup.roles.find(r => r.name === deletedRole.name);
    if (!saved) return;

    restoringRoles.add(deletedRole.id);
    roleRestoreQueue.push({ guild, saved, executor });

    clearTimeout(roleRestoreTimer);
    roleRestoreTimer = setTimeout(() => processRoleQueue(prot), 600);
}

async function processRoleQueue(prot) {
    if (roleRestoreQueue.length === 0) return;

    const items = roleRestoreQueue.splice(0, roleRestoreQueue.length);
    // نرتبهم تصاعدياً حسب موضعهم الأصلي (الأقل أولاً)
    items.sort((a, b) => (a.saved.position ?? 0) - (b.saved.position ?? 0));

    const lang    = getLang();
    const guild   = items[0].guild;
    const created = [];

    for (const { saved, executor } of items) {
        try {
            const perms = new PermissionsBitField(saved.permissions);
            const newRole = await guild.roles.create({
                name:        saved.name,
                colors:      { primaryColor: saved.colors?.primaryColor ?? 0 },
                hoist:       saved.hoist,
                permissions: perms,
                mentionable: saved.mentionable,
                reason:      lang.autoReason
            });

            const freshBackup = loadBackup();
            if (freshBackup.roles) {
                const idx = freshBackup.roles.findIndex(r => r.id === saved.id);
                if (idx !== -1) {
                    freshBackup.roles[idx].id = newRole.id;
                    saveBackup(freshBackup);
                }
            }

            restoringRoles.add(newRole.id);
            setTimeout(() => restoringRoles.delete(newRole.id), 10000);

            created.push({ newRole, saved, executor });
        } catch(e) {
            await sendFailureLog(guild, prot, lang.failureRole(saved.name, e.message));
        } finally {
            setTimeout(() => restoringRoles.delete(saved.id), 10000);
        }
    }

    if (created.length === 0) return;

    // ── إعادة ترتيب كل الرتب دفعة وحدة حسب الباك أب الأصلي ──
    try {
        const freshBackup = loadBackup();
        await guild.roles.fetch();

        const positionsPayload = [];
        (freshBackup.roles || []).forEach(saved => {
            const liveRole = guild.roles.cache.get(saved.id);
            if (liveRole && typeof saved.position === 'number') {
                positionsPayload.push({ role: liveRole.id, position: saved.position });
            }
        });

        if (positionsPayload.length > 0) {
            await guild.roles.setPositions(positionsPayload).catch(() => {});
        }
    } catch(e) {}

    for (const { newRole, saved, executor } of created) {
        const roleFields = [
            { name: lang.fieldName, value: `\`${saved.name}\``, inline: true },
            { name: lang.fieldNew,  value: `${newRole}`,        inline: true },
        ];
        const roleExecField = executorField(lang, executor);
        if (roleExecField) roleFields.push(roleExecField);

        await sendRestoreLog(
            guild, prot,
            lang.roleRestored,
            lang.roleRestoredDesc(saved.name, newRole),
            '#57F287',
            roleFields
        );
    }
}

// ── استعادة اسم/أيقونة السيرفر ──────────────────────────────────────────────
async function restoreGuildUpdate(oldGuild, newGuild, prot, executor) {
    if (!prot?.backup?.enabled) return;
    if (await isExecutorBypassed(newGuild, executor, prot)) return;

    const backup = loadBackup();
    if (!backup.guildId) return;

    const lang    = getLang();
    const changes = {};
    let changed   = false;
    const desc    = [];

    if (prot.backup.restoreServerName && oldGuild.name !== newGuild.name) {
        if (backup.guildName && newGuild.name !== backup.guildName) {
            changes.name = backup.guildName;
            changed = true;
            desc.push(lang.nameChanged(newGuild.name, backup.guildName));
        }
    }

    if (prot.backup.restoreServerIcon && oldGuild.icon !== newGuild.icon) {
if (backup.guildIcon) {
    try {
        let iconData;
        if (backup.guildIcon.startsWith('data:')) {
            const base64 = backup.guildIcon.split(',')[1];
            iconData = Buffer.from(base64, 'base64');
        } else {
            iconData = await fetchImageBuffer(backup.guildIcon);
        }
        changes.icon = iconData;
        changed = true;
        desc.push(lang.iconRestored);
    } catch(e) {
        // فشل تحميل الصورة
    }
}
    }

    if (!changed) return;

   try {
        await newGuild.edit({ ...changes, reason: lang.autoReason });
        const guildExecField = executorField(lang, executor);
        await sendRestoreLog(
            newGuild, prot, lang.serverRestored, desc.join('\n'), '#FFA500',
            guildExecField ? [guildExecField] : []
        );
    } catch(e) {
        await sendFailureLog(newGuild, prot, lang.failureGuild(e.message));
    }
}

// ── تسجيل الأحداث ────────────────────────────────────────────────────────────
function register(client) {
    client.once('clientReady', async () => {
        for (const guild of client.guilds.cache.values()) {
            const prot = loadProtection();
            if (prot?.backup?.enabled) {
                await takeBackup(guild).catch(() => {});
            }
        }
    });

    client.on('channelDelete', async (channel) => {
        if (!channel.guild) return;
        const prot = loadProtection();
        const executor = await getAuditLogExecutor(channel.guild, AuditLogEvent.ChannelDelete, channel.id);
        await queueChannelRestore(channel.guild, channel, prot, executor);
    });

    client.on('roleDelete', async (role) => {
        if (!role.guild) return;
        const prot = loadProtection();
        const executor = await getAuditLogExecutor(role.guild, AuditLogEvent.RoleDelete, role.id);
        await queueRoleRestore(role.guild, role, prot, executor).catch(() => {});
    });
client.on('channelUpdate', async (oldChannel, newChannel) => {
    if (!newChannel.guild) return;
    if (restoringChannels.has(newChannel.id)) return;  // ← هنا
    const prot = loadProtection();
    if (!prot?.backup?.enabled || !prot?.backup?.restoreChannelName) return;

    if (oldChannel.name !== newChannel.name) {
        const backup = loadBackup();
        const saved = backup.channels?.find(c => c.id === newChannel.id);
        if (!saved || saved.name === newChannel.name) return;

        const lang = getLang();
        const chUpdateExecutor = await getAuditLogExecutor(newChannel.guild, AuditLogEvent.ChannelUpdate, newChannel.id);
        if (await isExecutorBypassed(newChannel.guild, chUpdateExecutor, prot)) return;
try {
            restoringChannels.add(newChannel.id);  // ← هنا
            const chUpdateExecField = executorField(lang, chUpdateExecutor);
            await newChannel.setName(saved.name, lang.autoReason);
            await sendRestoreLog(
                newChannel.guild, prot,
                lang.channelRestored,
               lang.channelNameChanged(newChannel.name, saved.name),
                '#57F287',
                chUpdateExecField ? [chUpdateExecField] : []
            );
} catch(e) {
            await sendFailureLog(newChannel.guild, prot, lang.failureChannelName(saved.name, e.message));
        }
        finally {
            setTimeout(() => restoringChannels.delete(newChannel.id), 5000);  // ← هنا
        }
    }
});

client.on('roleUpdate', async (oldRole, newRole) => {
    if (!newRole.guild) return;
    if (restoringRoles.has(newRole.id)) return;  // ← هنا
    const prot = loadProtection();
    if (!prot?.backup?.enabled || !prot?.backup?.restoreRoleName) return;

    if (oldRole.name !== newRole.name) {
        const backup = loadBackup();
        const saved = backup.roles?.find(r => r.id === newRole.id);
        if (!saved || saved.name === newRole.name) return;

        const lang = getLang();
        const roleUpdateExecutor = await getAuditLogExecutor(newRole.guild, AuditLogEvent.RoleUpdate, newRole.id);
        if (await isExecutorBypassed(newRole.guild, roleUpdateExecutor, prot)) return;
  try {
            restoringRoles.add(newRole.id);  // ← هنا
            const roleUpdateExecField = executorField(lang, roleUpdateExecutor);
            await newRole.setName(saved.name, lang.autoReason);
            await sendRestoreLog(
                newRole.guild, prot,
                lang.roleRestored,
               lang.roleNameChanged(newRole.name, saved.name),
                '#57F287',
                roleUpdateExecField ? [roleUpdateExecField] : []
            );
} catch(e) {
            await sendFailureLog(newRole.guild, prot, lang.failureRoleName(saved.name, e.message));
        }
        finally {
            setTimeout(() => restoringRoles.delete(newRole.id), 5000);  // ← هنا
        }
    }
});
   client.on('guildUpdate', async (oldGuild, newGuild) => {
        const prot = loadProtection();
        const executor = await getAuditLogExecutor(newGuild, AuditLogEvent.GuildUpdate, newGuild.id);
        await restoreGuildUpdate(oldGuild, newGuild, prot, executor).catch(() => {});
    });
}

module.exports = { register, takeBackup };