const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const fs     = require('fs');
const path   = require('path');
const crypto = require('crypto');
const sharp  = require('sharp');

const spamTracker  = new Map();
const repeatTracker = new Map();
const imageFloodTracker = new Map();
const guildImageRaidTracker = new Map(); // guildId -> Map(hash -> [{userId, time, channelId, messageId}])
const floodedUsersTracker = new Map(); // key -> { hash, expiry } — مستخدم متلبس فعلاً، أي صورة مشابهة منه تُحذف فوراً

const contentFloodTracker = new Map(); // فيديوهات وروابط عبر عدة رومات
const guildContentRaidTracker = new Map();
const floodedContentUsersTracker = new Map();
const contentFloodLocks = new Map(); // key -> سلسلة Promise لضمان معالجة رسائل نفس المستخدم بالتسلسل الصحيح

const imageFloodLocks = new Map(); // نفس الفكرة لسبام الصور
function withLock(lockMap, key, fn) {
    const prev = lockMap.get(key) || Promise.resolve();
    const run  = prev.then(fn, fn); // ننتظر يلي قبلنا يخلص (حتى لو صار فيه خطأ) قبل ما نبلش
    lockMap.set(key, run.catch(() => {}));
    return run;
}

// ── الترجمات ────────────────────────────────────────────────
const T = {
    ar: {
        blocked:        '🛡️ **تم حجب هذه الرسالة بواسطة نظام الإشراف التلقائي**',
        user:           '👤 المستخدم',
        reason:         '📋 السبب',
        invisible:      '*-# هذه الرسالة مرئية لك فقط وستختفي تلقائياً*',
        member:         '👤 العضو',
        channel:        '📌 القناة',
        msgContent:     '💬 الرسالة',
        actions:        '⚡ الإجراءات',
        deleteMsg:      '🗑️ حذف الرسالة',
        warnInRoom:     '⚠️ تحذير في الروم',
        muteMin:        (m) => `⏱️ إسكات ${m} دقيقة`,
        kick:           '👢 طرد العضو',
        ban:            '🔨 حظر العضو',
        noActions:      'لا إجراءات',
        badWords:       { title: '🚫 كلمات محظورة',        reason: 'كلمات محظورة' },
        spam:           { title: '🚨 سبام',                 reason: (l, w) => `سبام (${l} رسائل في ${w}ث)` },
        link:           { title: '🔗 رابط محظور',           reason: 'رابط غير مسموح' },
        mentionSpam:    { title: '📣 سبام منشن',            reason: (n) => `سبام منشن (${n} منشن)` },
        massCaps:       { title: '🔠 كابس مفرط',            reason: (p) => `كابس مفرط (${p}%)` },
        discordInvite:  { title: '✉️ دعوة Discord محظورة',  reason: 'رابط دعوة Discord' },
        repeated:       { title: '🔁 تكرار الرسائل',        reason: (n) => `تكرار الرسالة (${n} مرات)` },
        nickLong:       (n, m) => `اسم طويل جداً (${n} حرف، الحد ${m})`,
        nickBad:        'اسم يحتوي على كلمات محظورة',
        nickDecorated:  'اسم يحتوي على أحرف مزخرفة غير مسموحة',
        nickname:       { title: '🏷️ اسم مخالف' },
        nickLabel:      (n) => `الاسم: \`${n}\``,
        emojiSpam:      { title: '😵 سبام إيموجي',          reason: (n) => `سبام إيموجي (${n} إيموجي)` },
        imageFlood:     { title: '🖼️ سبام صور بعدة رومات',   reason: (n) => `تم إرسال صور بـ ${n} رومات مختلفة خلال فترة قصيرة`, raidSuffix: (n) => `— ⚠️ هجوم منسّق من ${n} حساب` },
        contentFlood:   { title: '🎬 سبام فيديوهات/روابط بعدة رومات', reason: (n, type) => type === 'video' ? `تم إرسال نفس الفيديو بـ ${n} رومات مختلفة خلال فترة قصيرة` : `تم إرسال نفس الرابط بـ ${n} رومات مختلفة خلال فترة قصيرة`, raidSuffix: (n) => `— ⚠️ هجوم منسّق من ${n} حساب` },
    },
    en: {
        blocked:        '🛡️ **This message was blocked by the Auto-Moderation system**',
        user:           '👤 User',
        reason:         '📋 Reason',
        invisible:      '*-# This message is only visible to you and will disappear automatically*',
        member:         '👤 Member',
        channel:        '📌 Channel',
        msgContent:     '💬 Message',
        actions:        '⚡ Actions',
        deleteMsg:      '🗑️ Message deleted',
        warnInRoom:     '⚠️ Warning in channel',
        muteMin:        (m) => `⏱️ Muted for ${m} minute(s)`,
        kick:           '👢 Member kicked',
        ban:            '🔨 Member banned',
        noActions:      'No actions taken',
        badWords:       { title: '🚫 Banned Words',          reason: 'Banned words detected' },
        spam:           { title: '🚨 Spam',                  reason: (l, w) => `Spam (${l} messages in ${w}s)` },
        link:           { title: '🔗 Blocked Link',          reason: 'Link not allowed' },
        mentionSpam:    { title: '📣 Mention Spam',          reason: (n) => `Mention spam (${n} mentions)` },
        massCaps:       { title: '🔠 Excessive Caps',        reason: (p) => `Excessive caps (${p}%)` },
        discordInvite:  { title: '✉️ Discord Invite Blocked', reason: 'Discord invite link' },
        repeated:       { title: '🔁 Repeated Messages',     reason: (n) => `Repeated message (${n} times)` },
        nickLong:       (n, m) => `Name too long (${n} chars, max ${m})`,
        nickBad:        'Name contains banned words',
        nickDecorated:  'Name contains decorated/fancy characters',
        nickname:       { title: '🏷️ Invalid Nickname' },
        nickLabel:      (n) => `Name: \`${n}\``,
        emojiSpam:      { title: '😵 Emoji Spam',            reason: (n) => `Emoji spam (${n} emojis)` },
       imageFlood:     { title: '🖼️ Cross-Channel Image Spam', reason: (n) => `Images sent in ${n} different channels within a short time`, raidSuffix: (n) => `— ⚠️ Coordinated raid from ${n} accounts` },
       contentFlood:   { title: '🎬 Cross-Channel Video/Link Spam', reason: (n, type) => type === 'video' ? `Same video sent in ${n} different channels within a short time` : `Same link sent in ${n} different channels within a short time`, raidSuffix: (n) => `— ⚠️ Coordinated raid from ${n} accounts` },
    }
};

function getLang(settings) {
    return T[settings?.botLanguage] || T.ar;
}

// ── قراءة autoMod.json ──────────────────────────────────────
function getAutoModSettings() {
    try {
        const filePath = path.join(__dirname, '..', 'autoMod.json');
        if (!fs.existsSync(filePath)) return {};
        return JSON.parse(fs.readFileSync(filePath, 'utf8'));
    } catch { return {}; }
}

// ── قراءة badWords.json ─────────────────────────────────────
function getBadWords() {
    try {
        const filePath = path.join(__dirname, '..', 'badWords.json');
        if (!fs.existsSync(filePath)) return [];
        const data = JSON.parse(fs.readFileSync(filePath, 'utf8'));
        return data.words || [];
    } catch { return []; }
}

// ── هل القناة أو الرتبة مستثناة؟ ───────────────────────────
function isExcluded(message, cfg) {
    const excludedChannels = cfg.excludedChannels || [];
    const excludedRoles    = cfg.excludedRoles    || [];
    if (excludedChannels.includes(message.channel.id)) return true;
    if (message.member?.roles.cache.some(r => excludedRoles.includes(r.id))) return true;
    return false;
}

// ── رسالة تحذير داخل الروم ───────────────────────────────────
async function sendChannelWarn(message, reason, lang) {
    try {
        const embed = new EmbedBuilder()
            .setColor(0xED4245)
            .setAuthor({ name: message.guild.name, iconURL: message.guild.iconURL({ dynamic: true }) ?? undefined })
            .setDescription(
                `${lang.blocked}\n\n` +
                `${lang.user}: <@${message.author.id}>\n` +
                `${lang.reason}: **${reason}**\n\n` +
                `${lang.invisible}`
            )
            .setTimestamp();
        const warn = await message.channel.send({ embeds: [embed] });
        setTimeout(() => warn.delete().catch(() => null), 3000);
    } catch { /* ignore */ }
}

// ── إرسال لوق احترافي ─────────────────────────────────────────
async function sendLog(client, logChannelId, data, lang) {
    if (!logChannelId) return;
    try {
        const ch = await client.channels.fetch(logChannelId).catch(() => null);
        if (!ch) return;

        const embed = new EmbedBuilder()
            .setColor(data.color || 0x5865F2)
            .setAuthor({
                name: data.user.tag,
                iconURL: data.user.displayAvatarURL({ dynamic: true, size: 128 })
            })
            .setTitle(data.title)
            .addFields(
                { name: lang.member,  value: `<@${data.user.id}>\n\`${data.user.id}\``, inline: true },
                { name: lang.channel, value: `<#${data.channelId}>`,                    inline: true },
                { name: lang.reason,  value: `\`${data.description}\``,                 inline: true },
            )
            .setFooter({ text: `Auto-Mod • ID: ${data.user.id}` })
            .setTimestamp();

        if (data.content) {
            embed.addFields({
                name: lang.msgContent,
                value: `\`\`\`${String(data.content).slice(0, 900)}\`\`\``
            });
        }
        if (data.actions) {
            embed.addFields({ name: lang.actions, value: data.actions });
        }

        await ch.send({ embeds: [embed] });
    } catch (err) {
        console.error('[AutoMod] log error:', err.message);
    }
}

// ── تنفيذ الإجراءات ──────────────────────────────────────────
async function executeActions(message, cfg, reason, lang, deleteTargets = null) {
    const actions         = cfg.actions         || [];
    const timeoutDuration = cfg.timeoutDuration || 5;
    const member          = message.member;
    const guild           = message.guild;
    const taken           = [];

    if (actions.includes('delete')) {
        if (deleteTargets && deleteTargets.length > 0) {
            const deletable = deleteTargets.filter(m => Date.now() - m.createdTimestamp < 14 * 24 * 60 * 60 * 1000);
            if (deletable.length === 1) {
                await deletable[0].delete().catch(() => null);
            } else if (deletable.length > 1) {
                await message.channel.bulkDelete(deletable, true).catch(async () => {
                    for (const m of deletable) await m.delete().catch(() => null);
                });
            }
        } else {
            await message.delete().catch(() => null);
        }
        taken.push(lang.deleteMsg);
    }

    if (actions.includes('warn')) {
        await sendChannelWarn(message, reason, lang);
        taken.push(lang.warnInRoom);
    }

    if (actions.includes('timeout') && member?.moderatable) {
        const bot = guild.members.me;
        if (bot.permissions.has(PermissionFlagsBits.ModerateMembers)) {
            await member.timeout(timeoutDuration * 60 * 1000, reason).catch(() => null);
            taken.push(lang.muteMin(timeoutDuration));
        }
    }

    if (actions.includes('kick') && member?.kickable) {
        await member.kick(reason).catch(() => null);
        taken.push(lang.kick);
    }

    if (actions.includes('ban') && member?.bannable) {
        await guild.members.ban(message.author.id, { reason, deleteMessageSeconds: 86400 }).catch(() => null);
        taken.push(lang.ban);
    }

    return taken.join('\n') || lang.noActions;
}

// ── 1. كلمات محظورة ─────────────────────────────────────────
async function checkBadWords(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const words = getBadWords();
    if (!words.length) return;
    const lower = message.content.toLowerCase();
    if (!words.some(w => lower.includes(w.toLowerCase()))) return;
    const { title, reason } = lang.badWords;
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title, description: reason, color: 0xFF4444, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 2. سبام ─────────────────────────────────────────────────
async function checkSpam(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const limit    = cfg.messageCount || 5;
    const windowMs = (cfg.timeWindow  || 5) * 1000;
    const key      = `${message.guild.id}-${message.author.id}`;
    const now      = Date.now();
    const data     = spamTracker.get(key) || { entries: [] };
    data.entries   = data.entries.filter(e => now - e.time < windowMs);
    data.entries.push({ time: now, message });
    spamTracker.set(key, data);
    if (data.entries.length < limit) return;
    const spamMessages = data.entries.map(e => e.message);
    data.entries = [];
    spamTracker.set(key, data);
    const reason  = lang.spam.reason(limit, windowMs / 1000);
    const actions = await executeActions(message, cfg, reason, lang, spamMessages);
    await sendLog(client, cfg.logChannel, { title: lang.spam.title, description: reason, color: 0xFF6600, user: message.author, channelId: message.channel.id, actions }, lang);
}

// ── 3. روابط ────────────────────────────────────────────────
async function checkLinks(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+)/gi;
    const urls = message.content.match(urlRegex);
    if (!urls) return;
    const discordInviteRegex = /(discord\.gg\/|discord\.com\/invite\/|discordapp\.com\/invite\/)/i;
    const nonDiscordUrls = urls.filter(u => !discordInviteRegex.test(u));
    if (!nonDiscordUrls.length) return;
    const allowed = cfg.allowedDomains || [];
    const isOk = nonDiscordUrls.every(u => allowed.length > 0 && allowed.some(d => u.toLowerCase().includes(d.toLowerCase())));
    if (isOk) return;
    const { title, reason } = lang.link;
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title, description: reason, color: 0x4169E1, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 4. سبام منشن ────────────────────────────────────────────
async function checkMentionSpam(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const max   = cfg.maxMentions || 5;
    const total = message.mentions.users.size + message.mentions.roles.size + (message.mentions.everyone ? 1 : 0);
    if (total < max) return;
    const reason  = lang.mentionSpam.reason(total);
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title: lang.mentionSpam.title, description: reason, color: 0x9B59B6, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 5. كابس ─────────────────────────────────────────────────
async function checkMassCaps(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const threshold = cfg.capsPercentage || 70;
    const minLen    = cfg.minLength      || 10;
    const letters   = message.content.replace(/[^a-zA-Z]/g, '');
    if (letters.length < minLen) return;
    const upper = letters.split('').filter(c => c === c.toUpperCase() && c !== c.toLowerCase()).length;
    const pct   = (upper / letters.length) * 100;
    if (pct < threshold) return;
    const reason  = lang.massCaps.reason(Math.round(pct));
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title: lang.massCaps.title, description: reason, color: 0xE67E22, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 6. دعوات Discord ────────────────────────────────────────
async function checkDiscordInvites(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const inviteRegex = /(discord\.gg\/|discord\.com\/invite\/|discordapp\.com\/invite\/)([a-zA-Z0-9-]+)/gi;
    if (!inviteRegex.test(message.content)) return;
    const { title, reason } = lang.discordInvite;
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title, description: reason, color: 0x7289DA, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 7. تكرار الرسائل ────────────────────────────────────────
async function checkRepeatedMessage(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const repeatCount = cfg.repeatCount || 3;
    const windowMs    = (cfg.timeWindow || 30) * 1000;
    const key         = `${message.guild.id}-${message.author.id}`;
    const now         = Date.now();
    const normalized  = message.content.trim().toLowerCase();
    if (normalized.length < 3) return;
    const data = repeatTracker.get(key) || { entries: [] };
    data.entries = data.entries.filter(e => now - e.time < windowMs);
    data.entries.push({ time: now, content: normalized, message });
    repeatTracker.set(key, data);
    const sameMessages = data.entries.filter(e => e.content === normalized);
    if (sameMessages.length < repeatCount) return;
    data.entries = [];
    repeatTracker.set(key, data);
    const targets = sameMessages.map(e => e.message);
    const reason  = lang.repeated.reason(sameMessages.length);
    const actions = await executeActions(message, cfg, reason, lang, targets);
    await sendLog(client, cfg.logChannel, { title: lang.repeated.title, description: reason, color: 0xF1C40F, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── 8. فلتر الأسماء ─────────────────────────────────────────
const DECORATED_REGEX = /[\u{1D400}-\u{1D7FF}\u{1F100}-\u{1F1FF}\u{2100}-\u{214F}\u{2460}-\u{24FF}\u{2500}-\u{257F}\u{2580}-\u{259F}\u{25A0}-\u{25FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{FE00}-\u{FE0F}\u{FF00}-\u{FFEF}]/u;

async function checkNicknameFilter(message, client, cfg, lang) {
    if (!cfg?.enabled) return;
    const excludedRoles = cfg.excludedRoles || [];
    if (message.member?.roles.cache.some(r => excludedRoles.includes(r.id))) return;
    const displayName    = message.member?.displayName || '';
    if (!displayName) return;
    const maxLength      = cfg.maxLength      ?? 20;
    const blockBadWords  = cfg.blockBadWords  !== false;
    const blockDecorated = cfg.blockDecorated !== false;
    let reason = null;
    if (displayName.length > maxLength) reason = lang.nickLong(displayName.length, maxLength);
    if (!reason && blockBadWords) {
        const words = getBadWords();
        if (words.some(w => displayName.toLowerCase().includes(w.toLowerCase()))) reason = lang.nickBad;
    }
    if (!reason && blockDecorated && DECORATED_REGEX.test(displayName)) reason = lang.nickDecorated;
    if (!reason) return;
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title: lang.nickname.title, description: reason, color: 0x1ABC9C, user: message.author, channelId: message.channel.id, content: lang.nickLabel(displayName), actions }, lang);
}

// ── 9. سبام إيموجي ──────────────────────────────────────────
const EMOJI_REGEX = /(\p{Emoji_Presentation}|\p{Extended_Pictographic}|<a?:[a-zA-Z0-9_]+:\d+>)/gu;

async function checkEmojiSpam(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const maxEmojis  = cfg.maxEmojis || 10;
    const matches    = message.content.match(EMOJI_REGEX);
    if (!matches) return;
    const emojiCount = matches.length;
    if (emojiCount < maxEmojis) return;
    const reason  = lang.emojiSpam.reason(emojiCount);
    const actions = await executeActions(message, cfg, reason, lang);
    await sendLog(client, cfg.logChannel, { title: lang.emojiSpam.title, description: reason, color: 0xFF69B4, user: message.author, channelId: message.channel.id, content: message.content, actions }, lang);
}

// ── دالة مساعدة: حساب بصمة إدراكية (Perceptual Hash) للصورة ──
// بتضل نفسها تقريباً حتى لو الصورة انضغطت أو تغيّر حجمها أو حفظت
// بصيغة مختلفة (خلافاً للـ SHA256 العادي يلي بيتغير من أي بكسل)
async function getPerceptualHash(url) {
    try {
        const res = await fetch(url);
        if (!res.ok) return null;
        const buffer = Buffer.from(await res.arrayBuffer());

        const { data } = await sharp(buffer)
            .resize(8, 8, { fit: 'fill' })
            .grayscale()
            .raw()
            .toBuffer({ resolveWithObject: true });

        const avg = data.reduce((sum, v) => sum + v, 0) / data.length;
        let hash = '';
        for (let i = 0; i < data.length; i++) {
            hash += data[i] > avg ? '1' : '0';
        }
        return hash;
    } catch {
        return null;
    }
}

// ── دالة مساعدة: قياس الفرق بين بصمتين (Hamming Distance) ──
// كل ما كان الرقم أقل، كل ما الصورتين أشبه ببعض (0 = متطابقتين تماماً)
function hammingDistance(hashA, hashB) {
    if (!hashA || !hashB || hashA.length !== hashB.length) return Infinity;
    let diff = 0;
    for (let i = 0; i < hashA.length; i++) {
        if (hashA[i] !== hashB[i]) diff++;
    }
    return diff;
}

// ── دوال مساعدة لـ Content Flood (فيديو / روابط) ────────────
async function getFileHash(url) {
    try {
        const res = await fetch(url);
        if (!res.ok) return null;
        const buffer = Buffer.from(await res.arrayBuffer());
        return crypto.createHash('sha256').update(buffer).digest('hex');
    } catch {
        return null;
    }
}

function normalizeUrl(url) {
    return url.trim().toLowerCase().replace(/\/+$/, '');
}

// ── 10. سبام الصور عبر عدة رومات (Image Flood) ─────────────
const IMAGE_URL_REGEX = /https?:\/\/\S+\.(?:png|jpe?g|gif|webp)(?:\?\S*)?/gi;

async function checkImageFloodInner(message, client, cfg, lang) {
    const imageAttachments = [...message.attachments.values()]
        .filter(att => (att.contentType || '').startsWith('image/'));
    const imageUrlMatches = message.content.match(IMAGE_URL_REGEX) || [];
    if (imageAttachments.length === 0 && imageUrlMatches.length === 0) return;

    // نفضّل المرفق الحقيقي إذا موجود، وإذا مافي نستخدم أول رابط صورة بالنص
    const imageSourceUrl = imageAttachments.length > 0 ? imageAttachments[0].url : imageUrlMatches[0];

    const channelThreshold   = cfg.channelThreshold   || 3;   // كم روم مختلف للفرد
    const windowMs           = (cfg.timeWindow || 8) * 1000;  // خلال كم ثانية
    const similarityThreshold = cfg.similarityThreshold ?? 10; // فرق مسموح (من 64) — كل ما قل كل ما التطابق أدق
    const raidUserThreshold  = cfg.raidUserThreshold   || 3;  // كم حساب مختلف = هجوم منسّق
    const key                = `${message.guild.id}-${message.author.id}`;
    const now                = Date.now();

   const imageHash = await getPerceptualHash(imageSourceUrl);
    if (!imageHash) return; // ما قدرنا نحمّل الصورة، نتجاوز بأمان

    // ═══════════ 0) هل هذا المستخدم متلبس بالفعل؟ احذف فوراً بدون انتظار عتبة جديدة ═══════════
    const flaggedEntry = floodedUsersTracker.get(key);
    if (flaggedEntry && now < flaggedEntry.expiry && hammingDistance(flaggedEntry.hash, imageHash) <= similarityThreshold) {
        flaggedEntry.expiry = now + windowMs; // مد الفترة لأنه لسا عم يرسل
        if ((cfg.actions || []).includes('delete')) {
            await message.delete().catch(() => null);
        }
        return;
    }

    // ═══════════ 1) فحص السبام الفردي (نفس الشخص بعدة رومات) ═══════════
    const data   = imageFloodTracker.get(key) || { entries: [] };
    data.entries = data.entries.filter(e => now - e.time < windowMs);
    data.entries.push({ time: now, channelId: message.channel.id, messageId: message.id, hash: imageHash, userId: message.author.id });
    imageFloodTracker.set(key, data);

    // نجمع بس الرسائل يلي صورتها "شبيهة" (مش لازم متطابقة 100%) بالبصمة الحالية
    const similarEntries = data.entries.filter(e => hammingDistance(e.hash, imageHash) <= similarityThreshold);
    const distinctChannels = new Set(similarEntries.map(e => e.channelId));

    // ═══════════ 2) فحص الهجوم المنسّق (نفس الصورة من حسابات مختلفة) ═══════════
    let guildRaid = guildImageRaidTracker.get(message.guild.id);
    if (!guildRaid) { guildRaid = []; guildImageRaidTracker.set(message.guild.id, guildRaid); }

    // تنظيف القديم من سجل السيرفر
    const freshRaid = guildRaid.filter(e => now - e.time < windowMs);
    freshRaid.push({ time: now, hash: imageHash, userId: message.author.id, channelId: message.channel.id, messageId: message.id });
    guildImageRaidTracker.set(message.guild.id, freshRaid);

    const raidMatches = freshRaid.filter(e => hammingDistance(e.hash, imageHash) <= similarityThreshold);
    const distinctRaidUsers = new Set(raidMatches.map(e => e.userId));

    const isIndividualFlood = distinctChannels.size >= channelThreshold;
    const isCoordinatedRaid = distinctRaidUsers.size >= raidUserThreshold;

    if (!isIndividualFlood && !isCoordinatedRaid) return;

    // نحدد شو رح نحذف وشو السبب حسب نوع الهجوم (فردي أو منسّق)
    const targets   = isCoordinatedRaid ? raidMatches : similarEntries;
    const severity  = isCoordinatedRaid ? 'raid' : 'flood';

    // نسجل المستخدم كـ"متلبس" لمدة الـ Time Window، أي صورة مشابهة تانية منه تُحذف فوراً بدون انتظار عتبة جديدة
    floodedUsersTracker.set(key, { hash: imageHash, expiry: now + windowMs });

    // تنظيف السجلات يلي عاقبنا عليها
    data.entries = data.entries.filter(e => !similarEntries.includes(e));
    imageFloodTracker.set(key, data);
    if (isCoordinatedRaid) {
        guildImageRaidTracker.set(message.guild.id, freshRaid.filter(e => !raidMatches.includes(e)));
    }

   // حذف الرسائل من كل الرومات/الحسابات المتورطة (فقط إذا كان إجراء الحذف مفعّل)
    if ((cfg.actions || []).includes('delete')) {
        for (const entry of targets) {
            const ch = message.guild.channels.cache.get(entry.channelId);
            if (!ch) continue;
            const msg = await ch.messages.fetch(entry.messageId).catch(() => null);
            if (msg) await msg.delete().catch(() => null);
        }
    }

    const affectedUsers = new Set(targets.map(e => e.userId));
    const reason = severity === 'raid'
        ? `${lang.imageFlood.reason(distinctChannels.size)} ${lang.imageFlood.raidSuffix(affectedUsers.size)}`
        : lang.imageFlood.reason(distinctChannels.size);

    // نعاقب صاحب الرسالة الحالية + أي حساب تاني متورط بنفس الهجوم المنسّق
    const cfgNoDelete = { ...cfg, actions: (cfg.actions || []).filter(a => a !== 'delete') };
    let actionsTaken  = await executeActions(message, cfgNoDelete, reason, lang);
    if ((cfg.actions || []).includes('delete')) {
        actionsTaken = actionsTaken === lang.noActions ? lang.deleteMsg : `${lang.deleteMsg}\n${actionsTaken}`;
    }

    if (severity === 'raid') {
        for (const uid of affectedUsers) {
            if (uid === message.author.id) continue; // خذنا الشخص الحالي أصلاً
            const otherMember = await message.guild.members.fetch(uid).catch(() => null);
            if (otherMember?.kickable && (cfg.actions || []).includes('kick')) {
                await otherMember.kick(reason).catch(() => null);
            } else if (otherMember?.bannable && (cfg.actions || []).includes('ban')) {
                await message.guild.members.ban(uid, { reason }).catch(() => null);
            }
        }
    }

    await sendLog(client, cfg.logChannel, {
        title: severity === 'raid' ? `🚨 ${lang.imageFlood.title} (Raid)` : lang.imageFlood.title,
        description: reason,
        color: severity === 'raid' ? 0xED4245 : 0x00C2FF,
        user: message.author,
        channelId: message.channel.id,
        content: `${[...distinctChannels].map(id => `<#${id}>`).join(', ')}\nHash: \`${imageHash.slice(0, 16)}...\`\nحسابات متورطة: ${affectedUsers.size}`,
        actions: actionsTaken
    }, lang);
}

// ── 11. سبام فيديوهات/روابط عبر عدة رومات (Content Flood) ──
const VIDEO_CONTENT_REGEX = /\.(mp4|mov|webm|mkv|avi)(?:\?\S*)?$/i;
const GENERIC_LINK_REGEX  = /(https?:\/\/[^\s]+|www\.[^\s]+)/gi;

async function checkContentFloodInner(message, client, cfg, lang) {
    const videoAttachments = [...message.attachments.values()]
        .filter(att => (att.contentType || '').startsWith('video/') || VIDEO_CONTENT_REGEX.test(att.url));

    const discordInviteRegex = /(discord\.gg\/|discord\.com\/invite\/|discordapp\.com\/invite\/)/i;
    const allLinks       = message.content.match(GENERIC_LINK_REGEX) || [];
    const nonImageLinks  = allLinks.filter(u => !discordInviteRegex.test(u) && !IMAGE_URL_REGEX.test(u));

    if (videoAttachments.length === 0 && nonImageLinks.length === 0) return;

    let contentHash, contentType;
    if (videoAttachments.length > 0) {
        contentHash = await getFileHash(videoAttachments[0].url);
        contentType = 'video';
    } else {
        contentHash = normalizeUrl(nonImageLinks[0]);
        contentType = 'link';
    }
    if (!contentHash) return;

    const channelThreshold  = cfg.channelThreshold  || 3;
    const windowMs          = (cfg.timeWindow || 8) * 1000;
    const raidUserThreshold = cfg.raidUserThreshold  || 3;
    const key               = `${message.guild.id}-${message.author.id}`;
    const now                = Date.now();

    // مطابقة تامة (SHA256 أو رابط نصي) — مو تشابه بصري متل الصور
    const flaggedEntry = floodedContentUsersTracker.get(key);
    if (flaggedEntry && now < flaggedEntry.expiry && flaggedEntry.hash === contentHash) {
        flaggedEntry.expiry = now + windowMs;
        if ((cfg.actions || []).includes('delete')) {
            await message.delete().catch(() => null);
        }
        return;
    }

    const data   = contentFloodTracker.get(key) || { entries: [] };
    data.entries = data.entries.filter(e => now - e.time < windowMs);
    data.entries.push({ time: now, channelId: message.channel.id, messageId: message.id, hash: contentHash, userId: message.author.id });
    contentFloodTracker.set(key, data);

    const matchingEntries  = data.entries.filter(e => e.hash === contentHash);
    const distinctChannels = new Set(matchingEntries.map(e => e.channelId));

    let guildRaid = guildContentRaidTracker.get(message.guild.id);
    if (!guildRaid) { guildRaid = []; guildContentRaidTracker.set(message.guild.id, guildRaid); }
    const freshRaid = guildRaid.filter(e => now - e.time < windowMs);
    freshRaid.push({ time: now, hash: contentHash, userId: message.author.id, channelId: message.channel.id, messageId: message.id });
    guildContentRaidTracker.set(message.guild.id, freshRaid);

    const raidMatches       = freshRaid.filter(e => e.hash === contentHash);
    const distinctRaidUsers = new Set(raidMatches.map(e => e.userId));

    const isIndividualFlood = distinctChannels.size >= channelThreshold;
    const isCoordinatedRaid = distinctRaidUsers.size >= raidUserThreshold;

    if (!isIndividualFlood && !isCoordinatedRaid) return;

    const targets  = isCoordinatedRaid ? raidMatches : matchingEntries;
    const severity = isCoordinatedRaid ? 'raid' : 'flood';

    floodedContentUsersTracker.set(key, { hash: contentHash, expiry: now + windowMs });

    data.entries = data.entries.filter(e => !matchingEntries.includes(e));
    contentFloodTracker.set(key, data);
    if (isCoordinatedRaid) {
        guildContentRaidTracker.set(message.guild.id, freshRaid.filter(e => !raidMatches.includes(e)));
    }

   if ((cfg.actions || []).includes('delete')) {
        for (const entry of targets) {
            const ch = message.guild.channels.cache.get(entry.channelId);
            if (!ch) continue;
            const msg = await ch.messages.fetch(entry.messageId).catch(() => null);
            if (msg) await msg.delete().catch(() => null);
        }
    }

    const affectedUsers = new Set(targets.map(e => e.userId));
    const reason = severity === 'raid'
        ? `${lang.contentFlood.reason(distinctChannels.size, contentType)} ${lang.contentFlood.raidSuffix(affectedUsers.size)}`
        : lang.contentFlood.reason(distinctChannels.size, contentType);

    const cfgNoDelete = { ...cfg, actions: (cfg.actions || []).filter(a => a !== 'delete') };
    let actionsTaken  = await executeActions(message, cfgNoDelete, reason, lang);
    if ((cfg.actions || []).includes('delete')) {
        actionsTaken = actionsTaken === lang.noActions ? lang.deleteMsg : `${lang.deleteMsg}\n${actionsTaken}`;
    }

    if (severity === 'raid') {
        for (const uid of affectedUsers) {
            if (uid === message.author.id) continue;
            const otherMember = await message.guild.members.fetch(uid).catch(() => null);
            if (otherMember?.kickable && (cfg.actions || []).includes('kick')) {
                await otherMember.kick(reason).catch(() => null);
            } else if (otherMember?.bannable && (cfg.actions || []).includes('ban')) {
                await message.guild.members.ban(uid, { reason }).catch(() => null);
            }
        }
    }

    await sendLog(client, cfg.logChannel, {
        title: severity === 'raid' ? `🚨 ${lang.contentFlood.title} (Raid)` : lang.contentFlood.title,
        description: reason,
        color: severity === 'raid' ? 0xED4245 : 0x8E44AD,
        user: message.author,
        channelId: message.channel.id,
        content: `${[...distinctChannels].map(id => `<#${id}>`).join(', ')}\nType: \`${contentType}\`\nحسابات متورطة: ${affectedUsers.size}`,
        actions: actionsTaken
    }, lang);
}

async function checkContentFlood(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const key = `${message.guild.id}-${message.author.id}`;
    await withLock(contentFloodLocks, key, () => checkContentFloodInner(message, client, cfg, lang));
}
async function checkImageFlood(message, client, cfg, lang) {
    if (!cfg?.enabled || isExcluded(message, cfg)) return;
    const key = `${message.guild.id}-${message.author.id}`;
    await withLock(imageFloodLocks, key, () => checkImageFloodInner(message, client, cfg, lang));
}
// ── تنظيف دوري للذاكرة (كل دقيقة) — يمنع تراكم بيانات قديمة ─
setInterval(() => {
    const now = Date.now();
    const maxAge = 5 * 60 * 1000; // 5 دقائق كحد أقصى للاحتفاظ بأي سجل غير مستخدم

    for (const [key, data] of imageFloodTracker.entries()) {
        data.entries = data.entries.filter(e => now - e.time < maxAge);
        if (data.entries.length === 0) imageFloodTracker.delete(key);
    }
    for (const [guildId, entries] of guildImageRaidTracker.entries()) {
        const fresh = entries.filter(e => now - e.time < maxAge);
        if (fresh.length === 0) guildImageRaidTracker.delete(guildId);
        else guildImageRaidTracker.set(guildId, fresh);
    }
    for (const [floodKey, entry] of floodedUsersTracker.entries()) {
        if (now >= entry.expiry) floodedUsersTracker.delete(floodKey);
    }
    for (const [key, data] of contentFloodTracker.entries()) {
        data.entries = data.entries.filter(e => now - e.time < maxAge);
        if (data.entries.length === 0) contentFloodTracker.delete(key);
    }
    for (const [guildId, entries] of guildContentRaidTracker.entries()) {
        const fresh = entries.filter(e => now - e.time < maxAge);
        if (fresh.length === 0) guildContentRaidTracker.delete(guildId);
        else guildContentRaidTracker.set(guildId, fresh);
    }
    for (const [floodKey, entry] of floodedContentUsersTracker.entries()) {
        if (now >= entry.expiry) floodedContentUsersTracker.delete(floodKey);
    }
}, 60 * 1000);

// ── التصدير ──────────────────────────────────────────────────
module.exports = {
    name: 'messageCreate',

    async execute(client, settings, message) {
        if (!message.guild)     return;
        if (message.author.bot) return;
        if (!message.member)    return;

        if (
            message.member.permissions.has(PermissionFlagsBits.Administrator) ||
            message.member.permissions.has(PermissionFlagsBits.ManageMessages)
        ) return;

        const cfg  = getAutoModSettings();
        const lang = getLang(settings);

        await Promise.all([
            checkBadWords(       message, client, cfg.badWords,             lang ),
            checkSpam(           message, client, cfg.spamDetection,        lang ),
            checkLinks(          message, client, cfg.linkProtection,       lang ),
            checkMentionSpam(    message, client, cfg.raidProtection,       lang ),
            checkMassCaps(       message, client, cfg.newAccountProtection, lang ),
            checkDiscordInvites( message, client, cfg.dmSpamProtection,     lang ),
            checkRepeatedMessage(message, client, cfg.checkRepeatedMessage, lang ),
            checkNicknameFilter( message, client, cfg.checkNicknameFilter,  lang ),
            checkEmojiSpam(      message, client, cfg.checkEmojiSpam,       lang ),
           checkImageFlood(     message, client, cfg.imageFloodProtection, lang ),
            checkContentFlood(   message, client, cfg.contentFloodProtection, lang ),
        ]);
    },
};