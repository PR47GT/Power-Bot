const fs   = require('fs');
const path = require('path');

const WELCOME_FILE = path.join(__dirname, '..', '..', 'welcome.json');

function getSettings() {
    try {
        if (!fs.existsSync(WELCOME_FILE)) return null;
        return JSON.parse(fs.readFileSync(WELCOME_FILE, 'utf8'));
    } catch { return null; }
}

function parseText(template, member, ownerName) {
    return String(template || '')
        .replace(/{mention}/gi,    `<@${member.id}>`)
        .replace(/{owner}/gi,      `<@${member.guild.ownerId}>`)
        .replace(/{ownername}/gi,  ownerName || 'Unknown')
        .replace(/{user}/gi,       member.user.username)
        .replace(/{server}/gi,     member.guild.name)
        .replace(/{count}/gi,      String(member.guild.memberCount));
}

module.exports = {
    name: 'guildMemberRemove',
    once: false,
    async execute(client, settings, member) {
        const cfg = getSettings();
        if (!cfg || !cfg.leaveEnabled) return;

        let ownerName = 'Unknown';
        try {
            const owner = await member.guild.fetchOwner();
            ownerName = owner.user.username;
        } catch (e) {}

        const text = parseText(cfg.leaveMessage || '', member, ownerName);
        if (!text) return;

        if (!cfg.leaveChannelId) return;
        const channel = member.guild.channels.cache.get(cfg.leaveChannelId);
        if (!channel) return;
        await channel.send({ content: text }).catch(() => {});
    }
};