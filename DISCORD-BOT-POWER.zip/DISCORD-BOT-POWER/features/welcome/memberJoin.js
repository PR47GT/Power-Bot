const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const sharp  = require('sharp');
const https  = require('https');
const http   = require('http');
const fs     = require('fs');
const path   = require('path');

const WELCOME_FILE = path.join(__dirname, '..', '..', 'welcome.json');

function getSettings() {
    try {
        if (!fs.existsSync(WELCOME_FILE)) return null;
        return JSON.parse(fs.readFileSync(WELCOME_FILE, 'utf8'));
    } catch { return null; }
}

function fetchImageBuffer(url) {
    return new Promise((resolve, reject) => {
        if (url.startsWith('data:image/')) {
            return resolve(Buffer.from(url.split(',')[1], 'base64'));
        }
        const lib = url.startsWith('https') ? https : http;
        lib.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, (res) => {
            if (res.statusCode === 301 || res.statusCode === 302)
                return fetchImageBuffer(res.headers.location).then(resolve).catch(reject);
            if (res.statusCode !== 200)
                return reject(new Error(`HTTP ${res.statusCode}`));
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end',  () => resolve(Buffer.concat(chunks)));
            res.on('error', reject);
        }).on('error', reject);
    });
}

function parseText(template, member, ownerName) {
    return String(template || '')
        .replace(/{mention}/gi,    `<@${member.id}>`)
        .replace(/{owner}/gi,      `<@${member.guild.ownerId}>`)
        .replace(/{ownername}/gi,  ownerName || 'Unknown')
        .replace(/{user}/gi,       member.user.username)
        .replace(/{server}/gi,     member.guild.name)
        .replace(/{count}/gi,      String(member.guild.memberCount));
}

function clipShape(ctx, shape, x, y, w, h) {
    ctx.beginPath();
    if (shape === 'circle') {
        if (typeof ctx.ellipse === 'function') {
            ctx.ellipse(x + w/2, y + h/2, w/2, h/2, 0, 0, Math.PI*2);
        } else {
            ctx.arc(x + w/2, y + h/2, Math.min(w,h)/2, 0, Math.PI*2);
        }
    } else if (shape === 'rounded') {
        const r = Math.min(w,h) * 0.15;
        ctx.moveTo(x+r, y); ctx.lineTo(x+w-r, y);
        ctx.quadraticCurveTo(x+w, y, x+w, y+r);
        ctx.lineTo(x+w, y+h-r);
        ctx.quadraticCurveTo(x+w, y+h, x+w-r, y+h);
        ctx.lineTo(x+r, y+h);
        ctx.quadraticCurveTo(x, y+h, x, y+h-r);
        ctx.lineTo(x, y+r);
        ctx.quadraticCurveTo(x, y, x+r, y);
    } else {
        ctx.rect(x, y, w, h);
    }
    ctx.closePath();
    ctx.clip();
}

function drawDefaultBackground(ctx, W, H, color) {
    const g = ctx.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, color || '#1a1a2e');
    g.addColorStop(1, '#16213e');
    ctx.fillStyle = g;
    ctx.fillRect(0, 0, W, H);
}

async function buildWelcomeImage(member, cfg) {
    let bgImg    = null;
    let W = 700, H = 300;

    /*
     * imgScaleX / imgScaleY:
     * نسبة التصغير من الأبعاد الطبيعية للصورة إلى حجم الكانفاس الفعلي.
     * القيم المحفوظة في welcome.json هي بكسل نسبةً للصورة الطبيعية
     * (كما يراها الداشبورد) — لذا نضربها بهذه النسبة لتصبح صحيحة.
     */
    let imgScaleX = 1, imgScaleY = 1;

    if (cfg.bgImageUrl) {
        try {
            let buf = await fetchImageBuffer(cfg.bgImageUrl);
            // تحويل أي صيغة (WebP / AVIF / BMP...) إلى PNG لأن مكتبة canvas لا تفهمها مباشرة
            buf = await sharp(buf).png().toBuffer();
            bgImg = await loadImage(buf);
            const MAX = 800;
            const sc  = Math.min(1, MAX / bgImg.width, MAX / bgImg.height);
            W = Math.round(bgImg.width  * sc);
            H = Math.round(bgImg.height * sc);
            /* نسبة التصغير — تُطبَّق على جميع المواضع والأحجام */
            imgScaleX = W / bgImg.width;
            imgScaleY = H / bgImg.height;
        } catch(e) {
            console.error('[Welcome] فشل تحميل الخلفية:', e.message);
        }
    }

    const canvas = createCanvas(W, H);
    const ctx    = canvas.getContext('2d');

    if (bgImg) ctx.drawImage(bgImg, 0, 0, W, H);
    

    
    /* ── الأفاتار ── */
    const aW       = Number(cfg.avatarWidth  ?? 84) * imgScaleX;
    const aH       = Number(cfg.avatarHeight ?? 84) * imgScaleY;
    const aCenterX = Number(cfg.avatarLeft   ?? W / 2) * imgScaleX;
    const aCenterY = Number(cfg.avatarTop    ?? H / 2) * imgScaleY;
    const aLeft    = aCenterX - aW / 2;
    const aTop     = aCenterY - aH / 2;
    const shape    = cfg.avatarShape || 'circle';

    try {
        const avatarURL = member.user.displayAvatarURL({ extension:'png', size:256, forceStatic:true });
        const avatarImg = await loadImage(await fetchImageBuffer(avatarURL));

        ctx.save();
        clipShape(ctx, shape, aLeft, aTop, aW, aH);
        ctx.drawImage(avatarImg, aLeft, aTop, aW, aH);
        ctx.restore();

         
    } catch(e) {
        console.error('[Welcome] فشل تحميل الأفاتار:', e.message);
        ctx.save();
        ctx.beginPath();
        if (typeof ctx.ellipse === 'function') {
            ctx.ellipse(aCenterX, aCenterY, aW/2, aH/2, 0, 0, Math.PI*2);
        } else {
            ctx.arc(aCenterX, aCenterY, Math.min(aW, aH)/2, 0, Math.PI*2);
        }
        ctx.fillStyle = '#5865F2';
        ctx.fill();
        ctx.restore();
    }

    /* ── اسم المستخدم ── */
    const uCenterX = Number(cfg.usernameLeft    ?? W / 2) * imgScaleX;
    const uCenterY = Number(cfg.usernameTop     ?? H * 0.75) * imgScaleY;
    const uSize    = Number(cfg.usernameFontSize ?? 40) * imgScaleX;

    ctx.save();
    ctx.font         = `bold ${Math.round(uSize)}px Sans`;
    ctx.fillStyle    = cfg.usernameColor || '#ffffff';
    ctx.textAlign    = 'center';
    ctx.textBaseline = 'middle';
    ctx.shadowColor  = 'rgba(0,0,0,0.85)';
    ctx.shadowBlur   = 10;
    ctx.fillText(member.user.username, uCenterX, uCenterY);
    ctx.restore();

    /* ── نص الترحيب ── */
    if (cfg.welcomeTextEnabled !== false && cfg.imageWelcomeText) {
        const tCenterX = Number(cfg.welcomeTextLeft    ?? W / 2) * imgScaleX;
        const tCenterY = Number(cfg.welcomeTextTop     ?? H * 0.87) * imgScaleY;
        const tSize    = Number(cfg.welcomeTextFontSize ?? 25) * imgScaleX;

        ctx.save();
        ctx.font         = `${Math.round(tSize)}px Sans`;
        ctx.fillStyle    = cfg.welcomeTextColor || '#cccccc';
        ctx.textAlign    = 'center';
        ctx.textBaseline = 'middle';
        ctx.shadowColor  = 'rgba(0,0,0,0.8)';
        ctx.shadowBlur   = 8;
        ctx.fillText(parseText(cfg.imageWelcomeText, member, member.guild.ownerId ? (member.guild.members.cache.get(member.guild.ownerId)?.user?.username || 'Unknown') : 'Unknown'), tCenterX, tCenterY);
        ctx.restore();
    }

    return canvas.toBuffer('image/png');
}

async function sendWelcome(target, text, attachment, method) {
    method = method || 'attachment';
    if (attachment) {
        if (method === 'separate') {
            await target.send({ files: [attachment] }).catch(()=>{});
            if (text) await target.send({ content: text }).catch(()=>{});
        } else {
            await target.send({ content: text||undefined, files:[attachment] }).catch(()=>{});
        }
    } else if (text) {
        await target.send({ content: text }).catch(()=>{});
    }
}

module.exports = {
    name: 'guildMemberAdd',
    once: false,
async execute(client, settings, member) {
        const cfg = getSettings();
        if (!cfg) return;
        if (!cfg.enabled && !cfg.imageEnabled) return;

        let ownerName = 'Unknown';
        try {
            const owner = await member.guild.fetchOwner();
            ownerName = owner.user.username;
        } catch (e) {}

        const text = cfg.enabled ? parseText(cfg.message || '', member, ownerName) : '';
        let attachment = null;

        if (cfg.imageEnabled) {
            try {
                const buffer = await buildWelcomeImage(member, cfg);
                attachment = new AttachmentBuilder(buffer, { name: 'welcome.png' });
            } catch(err) {
                console.error('[Welcome] فشل بناء الصورة:', err.message);
            }
        }

        if (cfg.deliveryMethod === 'dm') {
            let dmOk = false;
            if (attachment) {
                if (cfg.imageSendMethod === 'separate') {
                    const r = await member.send({ files:[attachment] }).catch(()=>null);
                    dmOk = !!r;
                    if (dmOk && text) await member.send({ content:text }).catch(()=>{});
                } else {
                    const r = await member.send({ content:text||undefined, files:[attachment] }).catch(()=>null);
                    dmOk = !!r;
                }
            } else if (text) {
                const r = await member.send({ content:text }).catch(()=>null);
                dmOk = !!r;
            }
            if (!dmOk && cfg.welcomeChannelId) {
                const ch = member.guild.channels.cache.get(cfg.welcomeChannelId);
                if (ch) await sendWelcome(ch, text, attachment, cfg.imageSendMethod);
            }
        } else {
            if (!cfg.welcomeChannelId) return;
            const channel = member.guild.channels.cache.get(cfg.welcomeChannelId);
            if (!channel) return;
            await sendWelcome(channel, text, attachment, cfg.imageSendMethod);
        }
    }
};