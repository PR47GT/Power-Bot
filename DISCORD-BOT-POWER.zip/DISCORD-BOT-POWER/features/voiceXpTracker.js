const fs = require('fs');
const path = require('path');

const LEVEL_DATA_FILE   = path.join(__dirname, '../levelData.json');
const LEVEL_SYSTEM_FILE = path.join(__dirname, '../levelSystem.json');

const VOICE_XP_PER_MINUTE = 10;

const voiceJoinTimes = new Map();

function loadLevelData() {
    if (fs.existsSync(LEVEL_DATA_FILE)) {
        try { return JSON.parse(fs.readFileSync(LEVEL_DATA_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function saveLevelData(data) {
    fs.writeFileSync(LEVEL_DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function loadLevelSystem() {
    if (fs.existsSync(LEVEL_SYSTEM_FILE)) {
        try { return JSON.parse(fs.readFileSync(LEVEL_SYSTEM_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function calcLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp));
}

async function awardVoiceXP(client, settings, userId, guildId, minutes) {
    try {
        if (minutes < 1) return;

        const levelSystem = loadLevelSystem();
        const xpSettings  = levelSystem.xpSettings || {};

        // ── رتب معطّلة للصوت ──
        if (xpSettings.disabledRoles && xpSettings.disabledRoles.length > 0) {
            try {
                const guild  = client.guilds.cache.get(guildId);
                const member = guild ? await guild.members.fetch(userId).catch(() => null) : null;
                if (member) {
                    const hasDisabledRole = xpSettings.disabledRoles.some(roleId => member.roles.cache.has(roleId));
                    if (hasDisabledRole) return;
                }
            } catch(e) {}
        }

        const levelData = loadLevelData();
        if (!levelData[userId]) {
            levelData[userId] = { chatXP: 0, voiceXP: 0, chatLevel: 0, voiceLevel: 0 };
        }

        if (levelData[userId].xp !== undefined && levelData[userId].voiceXP === undefined) {
            levelData[userId].chatXP    = levelData[userId].xp || 0;
            levelData[userId].voiceXP   = 0;
            levelData[userId].chatLevel  = calcLevel(levelData[userId].chatXP);
            levelData[userId].voiceLevel = 0;
            delete levelData[userId].xp;
        }

        let gainedXP = Math.floor(minutes) * VOICE_XP_PER_MINUTE;

        // ── مضاعف الرتبة (صوت) ──
        const roleMultipliers = xpSettings.roleMultipliers || [];
        if (roleMultipliers.length > 0) {
            try {
                const guild  = client.guilds.cache.get(guildId);
                const member = guild ? await guild.members.fetch(userId).catch(() => null) : null;
                if (member) {
                    const hasMultiplierRole = roleMultipliers.some(roleId => member.roles.cache.has(roleId));
                    if (hasMultiplierRole) gainedXP = Math.floor(gainedXP * 2);
                }
            } catch(e) {}
        }

        const oldLevel = levelData[userId].voiceLevel || 0;
        levelData[userId].voiceXP = (levelData[userId].voiceXP || 0) + gainedXP;
        const newLevel = calcLevel(levelData[userId].voiceXP);
        levelData[userId].voiceLevel = newLevel;

        saveLevelData(levelData);

        if (newLevel > oldLevel) {
            const notifications  = levelSystem.levelUpNotifications || {};
            const notifChannelId = notifications.channelId || '';
            const msgTemplate    = notifications.message || 'Congratulations {user}! You reached voice level {level}!';
            const notifMessage   = msgTemplate
                .replace('{user}',  `<@${userId}>`)
                .replace('{level}', newLevel);

            const guild = client.guilds.cache.get(guildId);

            if (notifChannelId && guild) {
                const ch = guild.channels.cache.get(notifChannelId);
                if (ch) ch.send(notifMessage).catch(() => {});
            }

            if (guild) {
                const levelRewards = levelSystem.levelRewards || [];
                for (const reward of levelRewards) {
                    if (
                        reward.roleId &&
                        reward.voiceLevel > 0 &&
                        oldLevel < reward.voiceLevel &&
                        newLevel >= reward.voiceLevel
                    ) {
                        try {
                            const member = await guild.members.fetch(userId).catch(() => null);
                            if (!member) continue;

                            if (reward.removeHigherRoles) {
                                for (const otherReward of levelRewards) {
                                    if (otherReward.roleId && otherReward.voiceLevel < reward.voiceLevel) {
                                        await member.roles.remove(otherReward.roleId).catch(() => {});
                                    }
                                }
                            }

                            const freshMember = await guild.members.fetch(userId).catch(() => null);
                            if (!freshMember) continue;

                            await freshMember.roles.add(reward.roleId).catch((e) => {
                                console.error(`❌ فشل إضافة رتبة المكافأة الصوتية ${reward.roleId}:`, e.message);
                            });

                            if (reward.sendDM) {
                                const isAr = settings?.botLanguage === 'ar';
                                const dmMsg = isAr
                                    ? `🎉 حصلت على رتبة مكافأة لوصولك إلى مستوى الصوت ${newLevel}!`
                                    : `🎉 You've been given a role reward for reaching voice level ${newLevel}!`;
                                freshMember.user.send(dmMsg).catch(() => {});
                            }
                        } catch(e) {
                            console.error('❌ خطأ في إضافة رتبة المكافأة الصوتية:', e.message);
                        }
                    }
                }
            }
        }

    } catch(err) {
        console.error('❌ خطأ في voice XP tracker:', err.message);
    }
}

module.exports = {
    name: 'voiceStateUpdate',

    async execute(client, settings, oldState, newState) {
        try {
            const userId = newState.id || oldState.id;
            const member = newState.member || oldState.member;

            if (member && member.user && member.user.bot) return;

            const guildId = newState.guild?.id || oldState.guild?.id;

            // ── دخول قناة صوتية ──
            if (!oldState.channelId && newState.channelId) {
                voiceJoinTimes.set(userId, Date.now());
                return;
            }

            // ── خروج من قناة صوتية ──
            if (oldState.channelId && !newState.channelId) {
                const joinTime = voiceJoinTimes.get(userId);
                if (joinTime) {
                    voiceJoinTimes.delete(userId);

                    const lvlSys     = loadLevelSystem();
                    const disabledCh = (lvlSys.xpSettings || {}).disabledChannels || [];
                    if (!disabledCh.includes(oldState.channelId)) {
                        const minutesSpent = (Date.now() - joinTime) / 60000;
                        await awardVoiceXP(client, settings, userId, guildId, minutesSpent);
                    }
                }
                return;
            }

            // ── انتقال بين قنوات صوتية ──
            if (oldState.channelId && newState.channelId && oldState.channelId !== newState.channelId) {
                const joinTime = voiceJoinTimes.get(userId);
                if (joinTime) {
                    const lvlSys     = loadLevelSystem();
                    const disabledCh = (lvlSys.xpSettings || {}).disabledChannels || [];
                    if (!disabledCh.includes(oldState.channelId)) {
                        const minutesSpent = (Date.now() - joinTime) / 60000;
                        await awardVoiceXP(client, settings, userId, guildId, minutesSpent);
                    }
                }
                voiceJoinTimes.set(userId, Date.now());
                return;
            }

        } catch(err) {
            console.error('❌ خطأ في voice state update:', err.message);
        }
    }
};