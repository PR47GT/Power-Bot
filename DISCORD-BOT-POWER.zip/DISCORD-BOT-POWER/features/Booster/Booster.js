const path = require('path');
const fs = require('fs');
const { EmbedBuilder, AttachmentBuilder, MessageType } = require('discord.js');

// الملف الجذر للمشروع (root/index.js) — نطلع مستويين للخارج من features/Booster
const ROOT_DIR = path.join(__dirname, '..', '..');
const BOOST_THANKS_FILE = path.join(ROOT_DIR, 'boostThanks.json');

// ==================== تحميل/حفظ الإعدادات ====================
function loadBoostThanks() {
    if (fs.existsSync(BOOST_THANKS_FILE)) {
        try { return JSON.parse(fs.readFileSync(BOOST_THANKS_FILE, 'utf8')); } catch(e) {}
    }
  return {
        enabled: false,
        useServerIconFallback: true,
        useAuthorAvatarFallback: true,
        channelId: '',
        messageContent: '',
        embedColor: '#5865F2',
        authorName: '',
        authorUrl: '',
        embedTitle: '',
        embedDesc: '',
        embedFooter: '',
        fields: [],
        thumbnailBase64: '',
        imageBase64: '',
        authorIconBase64: '',
        footerIconBase64: ''
    };
}

function saveBoostThanks(data) {
    fs.writeFileSync(BOOST_THANKS_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// ==================== base64 → مرفق ديسكورد ====================
function base64ToAttachment(base64String, filename) {
    if (!base64String || !base64String.startsWith('data:image')) return null;
    try {
        const mimeMatch = base64String.match(/^data:image\/(\w+);base64,/);
        const ext = mimeMatch ? mimeMatch[1] : 'png';
        const nameWithExt = filename.replace(/\.\w+$/, `.${ext}`);
        const base64Data = base64String.replace(/^data:image\/\w+;base64,/, '');
        const buffer = Buffer.from(base64Data, 'base64');
        return new AttachmentBuilder(buffer, { name: nameWithExt });
    } catch(e) {
        return null;
    }
}

// ==================== دالة استبدال المتغيرات ====================
function buildReplacer({ userId, userTag, guild }) {
    return function replace(text) {
        if (!text) return '';
        const boostCount = guild.premiumSubscriptionCount || 0;
        const tier = guild.premiumTier || 0;
        return text
            .replace(/{user}/g, `<@${userId}>`)
            .replace(/{user\.tag}/g, userTag)
            .replace(/{user\.id}/g, userId)
            .replace(/{server}/g, guild.name)
            .replace(/{boost_count}/g, boostCount)
            .replace(/{boost_tier}/g, tier)
            .replace(/{date}/g, new Date().toLocaleDateString('en-GB'));
    };
}

// ==================== بناء وإرسال الإمبد (مشترك بين الحدث الحقيقي والإرسال التجريبي) ====================
async function sendBoostEmbed(channel, boostSettings, replace, { isTest = false, fallbackAvatarURL = undefined, fallbackFooterIconURL = undefined } = {}) {
    const embed = new EmbedBuilder().setColor(boostSettings.embedColor || '#5865F2');
    const embedFiles = [];

 const authorIconAtt = base64ToAttachment(boostSettings.authorIconBase64, 'author-icon.png');
    if (authorIconAtt) embedFiles.push(authorIconAtt);
    if (boostSettings.authorName || authorIconAtt || boostSettings.authorIconBase64 || fallbackAvatarURL) {
        embed.setAuthor({
            name: replace(boostSettings.authorName) || '\u200b',
            iconURL: authorIconAtt
                ? `attachment://${authorIconAtt.name}`
                : (boostSettings.authorIconBase64?.startsWith('http') ? boostSettings.authorIconBase64 : fallbackAvatarURL),
            url: boostSettings.authorUrl?.startsWith('http') ? boostSettings.authorUrl : undefined
        });
    }

    if (boostSettings.embedTitle) embed.setTitle(replace(boostSettings.embedTitle));
    if (boostSettings.embedDesc) embed.setDescription(replace(boostSettings.embedDesc));

    if (boostSettings.fields && boostSettings.fields.length > 0) {
        const validFields = boostSettings.fields.filter(f => f.name || f.value);
        if (validFields.length > 0) {
            embed.addFields(validFields.map(f => ({
                name: replace(f.name) || '\u200b',
                value: replace(f.value) || '\u200b',
                inline: f.inline || false
            })));
        }
    }

    const thumbAtt = base64ToAttachment(boostSettings.thumbnailBase64, 'thumbnail.png');
    if (thumbAtt) {
        embedFiles.push(thumbAtt);
        embed.setThumbnail(`attachment://${thumbAtt.name}`);
    } else if (boostSettings.thumbnailBase64?.startsWith('http')) {
        embed.setThumbnail(boostSettings.thumbnailBase64);
    }

const footerIconAtt = base64ToAttachment(boostSettings.footerIconBase64, 'footer-icon.png');
    if (footerIconAtt) embedFiles.push(footerIconAtt);

    const footerText = (boostSettings.embedFooter ? replace(boostSettings.embedFooter) : '')
        + (isTest ? (boostSettings.embedFooter ? ' • 🔧 Test Preview' : '🔧 Test Preview') : '');

    if (footerText || footerIconAtt || boostSettings.footerIconBase64 || fallbackFooterIconURL) {
        embed.setFooter({
            text: footerText || '\u200b',
            iconURL: footerIconAtt
                ? `attachment://${footerIconAtt.name}`
                : (boostSettings.footerIconBase64?.startsWith('http') ? boostSettings.footerIconBase64 : fallbackFooterIconURL)
        });
    }

    await channel.send({
        content: replace(boostSettings.messageContent) || undefined,
        embeds: [embed],
        files: embedFiles
    });

    const imageAtt = base64ToAttachment(boostSettings.imageBase64, 'image.png');
    if (imageAtt) {
        await channel.send({ files: [imageAtt] });
    } else if (boostSettings.imageBase64?.startsWith('http')) {
        await channel.send({ files: [boostSettings.imageBase64] });
    }
}

// ==================== دالة التسجيل الرئيسية ====================
function registerBoosterRoutes(app, client, getSettings, loadData, getGuildChannels, config) {

    // ---------- عرض صفحة الإعدادات ----------
    app.get('/boost-thanks', async (req, res) => {
        await loadData(true);
        const boostSettings = loadBoostThanks();
        res.render('boost-thanks', {
            settings: getSettings(),
            guildChannels: getGuildChannels(),
            boostSettings
        });
    });

// ---------- حفظ الإعدادات ----------
    app.post('/boost-thanks', (req, res) => {
        try {
            const data = req.body;
            saveBoostThanks(data);
            res.json({ success: true });
        } catch(e) {
            res.json({ success: false });
        }
    });

    // ---------- الإرسال التجريبي ----------
   app.post('/boost-thanks/test-send', async (req, res) => {
        try {
            const data = req.body;
            if (!data.channelId) {
                return res.json({ success: false, message: 'No channel selected' });
            }

            const guild = client.guilds.cache.get(config.guildId) || client.guilds.cache.first();
            if (!guild) return res.json({ success: false, message: 'Bot is not in any server' });

            const channel = guild.channels.cache.get(data.channelId)
                || await guild.channels.fetch(data.channelId).catch(() => null);
            if (!channel) return res.json({ success: false, message: 'Channel not found' });

            let ownerMember;
            try { ownerMember = await guild.members.fetch(guild.ownerId); } catch(e) { ownerMember = null; }
            const userId = ownerMember ? ownerMember.id : client.user.id;
            const userTag = ownerMember ? ownerMember.user.tag : client.user.tag;

const replace = buildReplacer({ userId, userTag, guild });
            const fallbackAvatarURL = (data.useAuthorAvatarFallback !== false)
                ? (ownerMember
                    ? ownerMember.user.displayAvatarURL({ dynamic: true, size: 256 })
                    : client.user.displayAvatarURL({ size: 256 }))
                : undefined;
            const fallbackFooterIconURL = (data.useServerIconFallback !== false)
                ? (guild.iconURL({ dynamic: true, size: 256 }) || undefined)
                : undefined;

            await sendBoostEmbed(channel, data, replace, { isTest: true, fallbackAvatarURL, fallbackFooterIconURL });

            res.json({ success: true });
        } catch(err) {
            console.error('❌ خطأ في الإرسال التجريبي لشكر البوست:', err.message);
            res.json({ success: false, message: err.message });
        }
    });

    // ---------- الحدث الفعلي عند حدوث بوست حقيقي (يعتمد على رسالة النظام، تعمل بكل مرة) ----------
    client.on('messageCreate', async (message) => {
        const boostTypes = [
            MessageType.UserPremiumGuildSubscription,
            MessageType.UserPremiumGuildSubscriptionTier1,
            MessageType.UserPremiumGuildSubscriptionTier2,
            MessageType.UserPremiumGuildSubscriptionTier3
        ];
        if (!message.guild || !boostTypes.includes(message.type)) return;

        const boostSettings = loadBoostThanks();
        if (!boostSettings.enabled || !boostSettings.channelId) return;

        const channel = message.guild.channels.cache.get(boostSettings.channelId);
        if (!channel) return;

        const member = message.member || await message.guild.members.fetch(message.author.id).catch(() => null);
        if (!member) return;

        const replace = buildReplacer({
            userId: member.id,
            userTag: member.user.tag,
            guild: message.guild
        });

        try {
            await sendBoostEmbed(channel, boostSettings, replace, {
                isTest: false,
                fallbackAvatarURL: (boostSettings.useAuthorAvatarFallback !== false)
                    ? member.user.displayAvatarURL({ dynamic: true, size: 256 })
                    : undefined,
                fallbackFooterIconURL: (boostSettings.useServerIconFallback !== false)
                    ? (message.guild.iconURL({ dynamic: true, size: 256 }) || undefined)
                    : undefined
            });
        } catch(err) {
            console.error('❌ خطأ في إرسال رسالة شكر البوست:', err.message);
        }
    });
}

module.exports = { registerBoosterRoutes };