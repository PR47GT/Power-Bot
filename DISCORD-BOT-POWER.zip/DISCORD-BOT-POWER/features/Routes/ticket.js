const path = require('path');
const fs = require('fs');
const {
    EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
    StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
    AttachmentBuilder
} = require('discord.js');
const {
    base64ToBuffer,
    buildEmojiOption,
    getButtonStyle,
    fetchUrlBuffer
} = require('../../slash-commands/ticket');

const TICKET_FILE = path.join(__dirname, '..', '..', 'ticketSystem.json');

function loadTicketSettings() {
    if (fs.existsSync(TICKET_FILE)) {
        try { return JSON.parse(fs.readFileSync(TICKET_FILE, 'utf8')); } catch(e) {}
    }
   return { categories: [], permissions: {}, useEmbed: false, openTickets: {}, blacklistEnabled: false, blacklist: { userIds: [], roleIds: [] } };
}

function saveTicketSettingsFile(data) {
    fs.writeFileSync(TICKET_FILE, JSON.stringify(data, null, 2), 'utf8');
}

 

function registerTicketRoutes(app, { client, loadData, getGuildChannels, getGuildRoles, getSettings }) {

    // كاش لأعضاء السيرفر (تُحدَّث كل دقيقة بدل ما تُجلب من Discord كل مرة تُفتح الصفحة)
    let _membersCacheData = [];
    let _membersCacheTime = 0;
    const MEMBERS_CACHE_DURATION = 60000; // دقيقة واحدة

    async function getCachedGuildMembers(guild) {
        const now = Date.now();
        if (now - _membersCacheTime < MEMBERS_CACHE_DURATION && _membersCacheData.length > 0) {
            return _membersCacheData;
        }
        const membersCache = await guild.members.fetch().catch(() => guild.members.cache);
        const result = [];
        membersCache.forEach(m => {
            if (m.user.bot) return;
            result.push({
                id:   m.id,
                name: m.user.username,
                avatarUrl: m.user.displayAvatarURL({ size: 32, extension: 'png' })
            });
        });
        result.sort((a, b) => a.name.localeCompare(b.name));
        _membersCacheData = result;
        _membersCacheTime = now;
        return result;
    }

    app.get('/ticket', async (req, res) => {
        await loadData(true);
        const ticketSettings = loadTicketSettings();
        const guildCategories = [];
        const guildEmojis = [];
        let guildMembers = [];
        try {
            const guild = client.guilds.cache.first();
            if (guild) {
                guild.channels.cache.filter(c => c.type === 4).forEach(c => {
                    guildCategories.push({ id: c.id, name: c.name });
                });
                guildCategories.sort((a, b) => a.name.localeCompare(b.name));
                guild.emojis.cache.forEach(e => {
                    guildEmojis.push({ id: e.id, name: e.name, animated: e.animated });
                });
                guildEmojis.sort((a, b) => a.name.localeCompare(b.name));

                guildMembers = await getCachedGuildMembers(guild);
            }
        } catch(e) { console.error('خطأ في تحميل بيانات الغيلد:', e.message); }
        const success = req.query.success === 'true';
        const error = req.query.error === 'true';
        res.render('ticket', {
            settings: getSettings(),
            guildChannels: getGuildChannels(),
            guildRoles: getGuildRoles(),
            guildCategories,
            guildEmojis,
            guildMembers,
            ticketSettings,
            success,
            error
        });
    });

    app.post('/ticket', (req, res) => {
        try {
            const ts = loadTicketSettings();

            ts.coverImageBase64 = req.body.coverImageBase64 || '';
            ts.coverImageUrl = req.body.coverImageUrl || '';
            ts.lineImageBase64 = req.body.lineImageBase64 || '';
            ts.lineImageUrl = req.body.lineImageUrl || '';

            ts.useEmbed = req.body.useEmbed === 'true' || req.body.useEmbed === 'on';
            ts.embedTitle = req.body.embedTitle || '';
            ts.embedDescription = req.body.embedDescription || '';
            ts.workingHoursEnabled = req.body.workingHoursEnabled === 'true' || req.body.workingHoursEnabled === 'on';
            ts.workingHoursStart = req.body.workingHoursStart || '09:00';
            ts.workingHoursEnd = req.body.workingHoursEnd || '17:00';
           ts.workingHoursMessage = req.body.workingHoursMessage || '';

            ts.autoCloseEnabled = req.body.autoCloseEnabled === 'true' || req.body.autoCloseEnabled === 'on';
            ts.autoCloseHours = parseFloat(req.body.autoCloseHours) || 24;
            ts.autoCloseWarningMinutes = parseFloat(req.body.autoCloseWarningMinutes) || 60;
            ts.autoCloseWarningMessage = req.body.autoCloseWarningMessage || '';

            ts.blacklistEnabled = req.body.blacklistEnabled === 'true' || req.body.blacklistEnabled === 'on';

            const blUserIds = req.body.blacklistUserIds;
            const blRoleIds = req.body.blacklistRoleIds;
            ts.blacklist = {
                userIds: Array.isArray(blUserIds) ? blUserIds.filter(v => v) : (blUserIds ? [blUserIds] : []),
                roleIds: Array.isArray(blRoleIds) ? blRoleIds.filter(v => v) : (blRoleIds ? [blRoleIds] : [])
            };

            const permsRaw = req.body.permissions || {};
            ts.permissions = {};
            const permKeys = ['adminClaim','adminClose','adminDelete','adminAddUser','adminRemoveUser','adminCopy','adminReminder','userClose','userCopy','userAddUsers','userReminder'];
            permKeys.forEach(k => {
                ts.permissions[k] = permsRaw[k] === 'true' || permsRaw[k] === 'on';
            });

            const catsRaw = req.body.categories || {};
            const cats = [];
            const indices = Object.keys(catsRaw).map(Number).sort((a, b) => a - b);
            indices.forEach(i => {
                const c = catsRaw[i];
                if (c && c.name) {
                    let adminRoleIds = [];
                    if (Array.isArray(c.adminRoleId)) {
                        adminRoleIds = c.adminRoleId.filter(v => v);
                    } else if (c.adminRoleId) {
                        adminRoleIds = [c.adminRoleId];
                    }
                    cats.push({
                        name: c.name || '',
                        emoji: c.emoji || '',
                        description: c.description || '',
                        channelId: c.channelId || '',
                        logChannelId: c.logChannelId || '',
                        adminRoleId: adminRoleIds,
                        displayType: c.displayType || 'button_primary',
                        enableEmbed: c.enableEmbed === 'true' || c.enableEmbed === 'on',
                        color: c.color || '#5865F2',
                        bgImageBase64: c.bgImageBase64 || '',
                        bgImageUrl: c.bgImageUrl || ''
                    });
                }
            });
            ts.categories = cats;
            if (!ts.openTickets) ts.openTickets = {};

            saveTicketSettingsFile(ts);
            if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
                res.json({ success: true });
            } else {
                res.redirect('/ticket?success=true');
            }
        } catch(err) {
            console.error('❌ خطأ في حفظ إعدادات التذاكر:', err);
            if (req.headers['content-type'] && req.headers['content-type'].includes('application/json')) {
                res.status(500).json({ success: false, error: err.message });
            } else {
                res.redirect('/ticket?error=true');
            }
        }
    });

    // ==================== Send Setup Message (from Dashboard) ====================
    app.post('/ticket/send-setup', async (req, res) => {
        try {
            const { channelId, categoryIndexes, coverImageBase64, lineImageBase64, customTitle, customDescription } = req.body;
            const settings = getSettings();

            if (!channelId) {
                return res.status(400).json({ success: false, error: 'CHANNEL_REQUIRED' });
            }
            const catIdxList = Array.isArray(categoryIndexes) ? categoryIndexes : (categoryIndexes ? [categoryIndexes] : []);
            if (catIdxList.length === 0) {
                return res.status(400).json({ success: false, error: 'CATEGORY_REQUIRED' });
            }

            const guild = client.guilds.cache.first();
            if (!guild) return res.status(500).json({ success: false, error: 'GUILD_NOT_FOUND' });

            const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
            if (!channel) return res.status(400).json({ success: false, error: 'CHANNEL_NOT_FOUND' });

            const ts = loadTicketSettings();
            const allCategories = ts.categories || [];
            const selectedCats = catIdxList
                .map(idx => ({ index: Number(idx), cat: allCategories[Number(idx)] }))
                .filter(entry => entry.cat);

            if (selectedCats.length === 0) {
                return res.status(400).json({ success: false, error: 'NO_VALID_CATEGORIES' });
            }

            const buttonCats = selectedCats.filter(e => e.cat.displayType && e.cat.displayType.startsWith('button_'));
            const menuCats   = selectedCats.filter(e => !e.cat.displayType || e.cat.displayType === 'select_menu');

            const rows = [];

            if (buttonCats.length > 0) {
                let currentRow = new ActionRowBuilder();
                let btnsInRow = 0;
                buttonCats.slice(0, 20).forEach(entry => {
                    const btn = new ButtonBuilder()
                        .setCustomId(`ticket_open_category_${entry.index}`)
                        .setLabel((entry.cat.name || `Category ${entry.index + 1}`).substring(0, 80))
                        .setStyle(getButtonStyle(entry.cat.displayType));
                    const emoji = buildEmojiOption(entry.cat.emoji);
                    if (emoji) { try { btn.setEmoji(emoji); } catch(e) {} }
                    currentRow.addComponents(btn);
                    btnsInRow++;
                    if (btnsInRow === 5) {
                        rows.push(currentRow);
                        currentRow = new ActionRowBuilder();
                        btnsInRow = 0;
                    }
                });
                if (btnsInRow > 0) rows.push(currentRow);
            }

            if (menuCats.length > 0 && rows.length < 5) {
                const options = menuCats.slice(0, 25).map(entry => {
                    const opt = new StringSelectMenuOptionBuilder()
                        .setValue(String(entry.index))
                        .setLabel((entry.cat.name || `Category ${entry.index + 1}`).substring(0, 100));
                    const emoji = buildEmojiOption(entry.cat.emoji);
                    if (emoji) { try { opt.setEmoji(emoji); } catch(e) {} }
                    if (entry.cat.description && entry.cat.description.trim()) {
                        opt.setDescription(entry.cat.description.substring(0, 100));
                    }
                    return opt;
                });
                const selectMenu = new StringSelectMenuBuilder()
                    .setCustomId('ticket_select_category')
                    .setPlaceholder(settings.botLanguage === 'en' ? 'Choose a ticket type...' : 'اختر نوع التذكرة...')
                    .addOptions(options);
                rows.push(new ActionRowBuilder().addComponents(selectMenu));
            }

            if (rows.length === 0) {
                return res.status(400).json({ success: false, error: 'NO_COMPONENTS_BUILT' });
            }

            const msgPayload = { components: rows };
            const files = [];

            const setupTitle = customTitle || ts.embedTitle || '';
            const setupDesc  = customDescription || ts.embedDescription || '';

            // Custom cover image (this message only) takes priority over the global one
            const effectiveCover = coverImageBase64 || ts.coverImageBase64 || '';
            const effectiveCoverUrl = coverImageBase64 ? '' : (ts.coverImageUrl || '');

            if (ts.useEmbed !== false) {
                // ── وضع EMBED (مفعل) ─────────────────────────────────────────
                const embed = new EmbedBuilder().setColor('#5865F2');
                if (setupTitle) embed.setTitle(setupTitle);
                if (setupDesc) embed.setDescription(setupDesc);

                if (effectiveCover) {
                    const result = base64ToBuffer(effectiveCover);
                    if (result) {
                        files.push(new AttachmentBuilder(result.buffer, { name: `ticket_cover.${result.ext}` }));
                        embed.setImage(`attachment://ticket_cover.${result.ext}`);
                    }
                } else if (effectiveCoverUrl) {
                    embed.setImage(effectiveCoverUrl);
                }

                msgPayload.embeds = [embed];
            } else {
                // ── وضع TEXT (معطل) ── بدون حدود Embed ────────────────────────
                msgPayload.content = setupTitle ? `**${setupTitle}**\n\n${setupDesc}` : setupDesc;

                if (effectiveCover) {
                    const result = base64ToBuffer(effectiveCover);
                    if (result) files.push(new AttachmentBuilder(result.buffer, { name: `ticket_cover.${result.ext}` }));
                } else if (effectiveCoverUrl) {
                    try {
                        const imgBuf = await fetchUrlBuffer(effectiveCoverUrl);
                        if (imgBuf) files.push(new AttachmentBuilder(imgBuf.buffer, { name: imgBuf.name }));
                    } catch(e) {}
                }
            }

            if (files.length > 0) msgPayload.files = files;

            await channel.send(msgPayload);

            // Custom line image (this message only) takes priority over the global one
            const effectiveLine = lineImageBase64 || ts.lineImageBase64 || '';
            const effectiveLineUrl = lineImageBase64 ? '' : (ts.lineImageUrl || '');
            if (effectiveLine) {
                const result = base64ToBuffer(effectiveLine);
                if (result) {
                    await channel.send({ files: [new AttachmentBuilder(result.buffer, { name: `ticket_line.${result.ext}` })] });
                }
            } else if (effectiveLineUrl) {
                try {
                    const imgBuf = await fetchUrlBuffer(effectiveLineUrl);
                    if (imgBuf) await channel.send({ files: [new AttachmentBuilder(imgBuf.buffer, { name: imgBuf.name })] });
                } catch(e) {}
            }

            res.json({ success: true });
        } catch(err) {
            console.error('❌ خطأ في إرسال رسالة الإعداد:', err);
            res.status(500).json({ success: false, error: err.message });
        }
    });
}

module.exports = {
    registerTicketRoutes,
    loadTicketSettings,
    saveTicketSettingsFile,
    TICKET_FILE
};