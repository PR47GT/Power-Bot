const fs = require('fs');
const path = require('path');

function registerModCommandsRoutes(app, deps) {
    const { loadData, getGuildChannels, getGuildRoles, getSettings } = deps;

    const MOD_COMMANDS_FILE = path.join(__dirname, '..', '..', 'modCommands.json');

    function loadModCommands() {
        let modCommands = {};
        if (fs.existsSync(MOD_COMMANDS_FILE)) {
            try {
                modCommands = JSON.parse(fs.readFileSync(MOD_COMMANDS_FILE, 'utf8'));
            } catch(e) {}
        }
        return modCommands;
    }

    // ==================== صفحة أوامر الإشراف ====================
    app.get('/mod-commands', async (req, res) => {
        await loadData(true);
        const modCommands = loadModCommands();
        res.render('mod-commands', {
            settings: getSettings(),
            guildChannels: getGuildChannels(),
            guildRoles: getGuildRoles(),
            modCommands
        });
    });

    // ==================== حفظ أوامر الإشراف ====================
    app.post('/mod-commands', (req, res) => {
        try {
            let modCommands = loadModCommands();

            const enabled = req.body.enabled || {};
            const aliases = req.body.aliases || {};
            const allowedRoles = req.body.allowedRoles || {};
            const deniedRoles = req.body.deniedRoles || {};
            const allowedChannels = req.body.allowedChannels || {};
            const deniedChannels = req.body.deniedChannels || {};
            const deleteCommand = req.body.deleteCommand || {};
            const deleteResponse = req.body.deleteResponse || {};

            // ⚠️ أي أمر جديد تضيفه بمجلد slash-commands لازم تضيف اسمه هنا
            const commandList = ['clear', 'ban', 'kick', 'timeout', 'untimeout', 'unban', 'clearbots' , 'lock', 'unlock', 'clearlinks', 'hide', 'show', 'setnick', 'role', 'move', 'vkick', 'giveroleall', 'warn', 'unwarn', 'warns', 'lockall', 'unlockall', 'vmove', 'temprole', 'rules', 'clearuser' ];

            for (var i = 0; i < commandList.length; i++) {
                var cmd = commandList[i];
                if (!modCommands[cmd]) modCommands[cmd] = {};

                if (enabled[cmd] !== undefined) {
                    modCommands[cmd].enabled = enabled[cmd] === 'true';
                }

                if (aliases[cmd] !== undefined) {
                    var aliasVal = aliases[cmd];
                    if (Array.isArray(aliasVal)) {
                        modCommands[cmd].aliases = aliasVal.filter(a => a !== '');
                    } else if (aliasVal === '') {
                        modCommands[cmd].aliases = [];
                    } else if (aliasVal) {
                        modCommands[cmd].aliases = [aliasVal];
                    } else {
                        modCommands[cmd].aliases = [];
                    }
                }

                if (allowedRoles[cmd] !== undefined) {
                    var roleVal = allowedRoles[cmd];
                    if (Array.isArray(roleVal)) {
                        modCommands[cmd].allowedRoles = roleVal.filter(r => r !== '');
                    } else if (roleVal === '') {
                        modCommands[cmd].allowedRoles = [];
                    } else if (roleVal) {
                        modCommands[cmd].allowedRoles = [roleVal];
                    } else {
                        modCommands[cmd].allowedRoles = [];
                    }
                }

                if (deniedRoles[cmd] !== undefined) {
                    var roleVal2 = deniedRoles[cmd];
                    if (Array.isArray(roleVal2)) {
                        modCommands[cmd].deniedRoles = roleVal2.filter(r => r !== '');
                    } else if (roleVal2 === '') {
                        modCommands[cmd].deniedRoles = [];
                    } else if (roleVal2) {
                        modCommands[cmd].deniedRoles = [roleVal2];
                    } else {
                        modCommands[cmd].deniedRoles = [];
                    }
                }

                if (allowedChannels[cmd] !== undefined) {
                    var chVal = allowedChannels[cmd];
                    if (Array.isArray(chVal)) {
                        modCommands[cmd].allowedChannels = chVal.filter(c => c !== '');
                    } else if (chVal === '') {
                        modCommands[cmd].allowedChannels = [];
                    } else if (chVal) {
                        modCommands[cmd].allowedChannels = [chVal];
                    } else {
                        modCommands[cmd].allowedChannels = [];
                    }
                }

                if (deniedChannels[cmd] !== undefined) {
                    var chVal2 = deniedChannels[cmd];
                    if (Array.isArray(chVal2)) {
                        modCommands[cmd].deniedChannels = chVal2.filter(c => c !== '');
                    } else if (chVal2 === '') {
                        modCommands[cmd].deniedChannels = [];
                    } else if (chVal2) {
                        modCommands[cmd].deniedChannels = [chVal2];
                    } else {
                        modCommands[cmd].deniedChannels = [];
                    }
                }

                if (deleteCommand[cmd] !== undefined) {
                    modCommands[cmd].deleteCommand = deleteCommand[cmd] === 'true';
                }

                if (deleteResponse[cmd] !== undefined) {
                    modCommands[cmd].deleteResponse = deleteResponse[cmd] === 'true';
                }
            }

            fs.writeFileSync(MOD_COMMANDS_FILE, JSON.stringify(modCommands, null, 2), 'utf8');
            res.redirect('/mod-commands?success=true');
        } catch (err) {
            console.error('❌ خطأ في حفظ أوامر الإشراف:', err);
            res.redirect('/mod-commands?error=true');
        }
    });
}

module.exports = registerModCommandsRoutes;