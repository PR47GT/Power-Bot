const path = require('path');
const fs = require('fs');

const ROOT_DIR = path.join(__dirname, '..', '..');
const GENERAL_COMMANDS_FILE = path.join(ROOT_DIR, 'generalCommands.json');

let generalCommands = {};

function loadGeneralCommands() {
    if (fs.existsSync(GENERAL_COMMANDS_FILE)) {
        try {
            generalCommands = JSON.parse(fs.readFileSync(GENERAL_COMMANDS_FILE, 'utf8'));
        } catch(e) {
            generalCommands = {};
        }
    } else {
        generalCommands = {};
        fs.writeFileSync(GENERAL_COMMANDS_FILE, JSON.stringify({}, null, 2));
    }
}

function getGeneralCommands() {
    return generalCommands;
}

function registerGeneralCommandsRoutes(app, { loadData, getGuildChannels, getGuildRoles, getSettings }) {

    app.get('/general-commands', async (req, res) => {
        await loadData(true);

        let generalCommandsData = {};
        if (fs.existsSync(GENERAL_COMMANDS_FILE)) {
            try {
                generalCommandsData = JSON.parse(fs.readFileSync(GENERAL_COMMANDS_FILE, 'utf8'));
            } catch(e) {}
        }

        res.render('general-commands', {
            settings: getSettings(),
            guildChannels: getGuildChannels(),
            guildRoles: getGuildRoles(),
            generalCommands: generalCommandsData
        });
    });

    app.post('/general-commands', (req, res) => {
        try {
            const enabled = req.body.enabled || {};
            const aliases = req.body.aliases || {};
            const allowedRoles = req.body.allowedRoles || {};
            const deniedRoles = req.body.deniedRoles || {};
            const allowedChannels = req.body.allowedChannels || {};
            const deniedChannels = req.body.deniedChannels || {};
            const deleteCommand = req.body.deleteCommand || {};
            const deleteResponse = req.body.deleteResponse || {};

            let generalCommandsData = {};
            if (fs.existsSync(GENERAL_COMMANDS_FILE)) {
                generalCommandsData = JSON.parse(fs.readFileSync(GENERAL_COMMANDS_FILE, 'utf8'));
            }

            const commandsList = ['roles', 'server', 'user', 'avatar', 'banner'];

            for (let i = 0; i < commandsList.length; i++) {
                const cmd = commandsList[i];
                if (!generalCommandsData[cmd]) generalCommandsData[cmd] = {};

                if (enabled[cmd] !== undefined) {
                    generalCommandsData[cmd].enabled = enabled[cmd] === 'true';
                }

                if (aliases[cmd] !== undefined) {
                    let aliasVal = aliases[cmd];
                    if (Array.isArray(aliasVal)) {
                        generalCommandsData[cmd].aliases = aliasVal.filter(a => a !== '');
                    } else if (aliasVal === '') {
                        generalCommandsData[cmd].aliases = [];
                    } else if (aliasVal) {
                        generalCommandsData[cmd].aliases = [aliasVal];
                    } else {
                        generalCommandsData[cmd].aliases = [];
                    }
                }

                if (allowedRoles[cmd] !== undefined) {
                    let roleVal = allowedRoles[cmd];
                    if (Array.isArray(roleVal)) {
                        generalCommandsData[cmd].allowedRoles = roleVal.filter(r => r !== '');
                    } else if (roleVal === '') {
                        generalCommandsData[cmd].allowedRoles = [];
                    } else if (roleVal) {
                        generalCommandsData[cmd].allowedRoles = [roleVal];
                    } else {
                        generalCommandsData[cmd].allowedRoles = [];
                    }
                }

                if (deniedRoles[cmd] !== undefined) {
                    let roleVal = deniedRoles[cmd];
                    if (Array.isArray(roleVal)) {
                        generalCommandsData[cmd].deniedRoles = roleVal.filter(r => r !== '');
                    } else if (roleVal === '') {
                        generalCommandsData[cmd].deniedRoles = [];
                    } else if (roleVal) {
                        generalCommandsData[cmd].deniedRoles = [roleVal];
                    } else {
                        generalCommandsData[cmd].deniedRoles = [];
                    }
                }

                if (allowedChannels[cmd] !== undefined) {
                    let chVal = allowedChannels[cmd];
                    if (Array.isArray(chVal)) {
                        generalCommandsData[cmd].allowedChannels = chVal.filter(c => c !== '');
                    } else if (chVal === '') {
                        generalCommandsData[cmd].allowedChannels = [];
                    } else if (chVal) {
                        generalCommandsData[cmd].allowedChannels = [chVal];
                    } else {
                        generalCommandsData[cmd].allowedChannels = [];
                    }
                }

                if (deniedChannels[cmd] !== undefined) {
                    let chVal = deniedChannels[cmd];
                    if (Array.isArray(chVal)) {
                        generalCommandsData[cmd].deniedChannels = chVal.filter(c => c !== '');
                    } else if (chVal === '') {
                        generalCommandsData[cmd].deniedChannels = [];
                    } else if (chVal) {
                        generalCommandsData[cmd].deniedChannels = [chVal];
                    } else {
                        generalCommandsData[cmd].deniedChannels = [];
                    }
                }

                if (deleteCommand[cmd] !== undefined) {
                    generalCommandsData[cmd].deleteCommand = deleteCommand[cmd] === 'true';
                }
                if (deleteResponse[cmd] !== undefined) {
                    generalCommandsData[cmd].deleteResponse = deleteResponse[cmd] === 'true';
                }
            }

            fs.writeFileSync(GENERAL_COMMANDS_FILE, JSON.stringify(generalCommandsData, null, 2), 'utf8');
            res.redirect('/general-commands?success=true');
        } catch (err) {
            console.error('❌ خطأ في حفظ الأوامر العامة:', err);
            res.redirect('/general-commands?error=true');
        }
    });
}

module.exports = {
    registerGeneralCommandsRoutes,
    loadGeneralCommands,
    getGeneralCommands,
    GENERAL_COMMANDS_FILE
};