// ==================== features/economy/economyRoutes.js ====================
const path = require('path');
const fs   = require('fs');

// [FIX-STATS] نجلب getAllUsers لحساب الإحصائيات الحقيقية من بيانات المستخدمين
const { getAllUsers } = require('../../slash-commands/economyData');
// نجلب config لمعرفة guildId الخادم الرئيسي
const config = require('../../config');

const ECONOMY_FILE = path.join(__dirname, '..', '..', 'economySystem.json');
const ITEMS_FILE   = path.join(__dirname, '..', '..', 'items.json');

// ─── [PATCH-05] Settings cache — avoids disk read on every command ─────────────
let _settingsCache    = null;
let _settingsCacheTs  = 0;
const SETTINGS_CACHE_TTL = 30000; // 30 seconds

function loadEconomySettings() {
    const now = Date.now();
    if (_settingsCache && (now - _settingsCacheTs) < SETTINGS_CACHE_TTL) {
        return _settingsCache;
    }
    if (fs.existsSync(ECONOMY_FILE)) {
        try {
            _settingsCache   = JSON.parse(fs.readFileSync(ECONOMY_FILE, 'utf8'));
            _settingsCacheTs = now;
            return _settingsCache;
        } catch (e) {
            _settingsCache   = getDefaultEconomySettings();
            _settingsCacheTs = now;
            return _settingsCache;
        }
    }
    _settingsCache   = getDefaultEconomySettings();
    _settingsCacheTs = now;
    return _settingsCache;
}

function getDefaultEconomySettings() {
    return {
        enabled: false,
        currency: '🪙',
        currencyName: 'Coins',
        startingBalance: 0,
        walletLimit: 0,
        resetOnLeave: false,
        globalMultiplier: 1,
        stackMultipliers: false,

        messageMoney:  { enabled: false, min: 1,  max: 5,   cooldown: 60, ignoreMuted: true, ignoreBots: true },
        voiceMoney:    { enabled: false, min: 2,  max: 10,  interval: 5,  ignoreSelfMuted: true, ignoreAlone: false, ignoreDeafened: false },
        commandMoney:  { enabled: false, min: 1,  max: 10,  cooldown: 30 },
        reactionMoney: { enabled: false, min: 1,  max: 5,   cooldown: 20 },

        work:   { min: 50,  max: 300,  cooldown: 8,   replies: [] },
        daily:  { min: 100, max: 500,  cooldown: 24,  streakBonus: 1.05, streakCap: 30 },
        weekly: { min: 500, max: 2000, cooldown: 168 },

        shop:   [],
        chests: [],

        pay: { enabled: true, min: 1, max: 0, tax: 0, cooldown: 0 },

        // [PATCH-09] Both keys preserved — finePrecent is the legacy name kept for backward compat
        rob: { enabled: false, successRate: 40, maxPercent: 30, cooldown: 60, finePrecent: 20 },

        bank: {
            enabled:      true,
            interestRate: 0,
            limit:        0,
            withdrawFee:  0,
            transferFee:  0,
        },

        gambling: {
            slots:     { enabled: false, minBet: 10, maxBet: 5000,  winChance: 35, cooldown: 0 },
            coinflip:  { enabled: false, minBet: 10, maxBet: 10000, cooldown: 0 },
            blackjack: { enabled: false, minBet: 10, maxBet: 10000, cooldown: 0 },
            dice:      { enabled: false, minBet: 10, maxBet: 10000, cooldown: 0 },
            rps:       { enabled: false, minBet: 0,  maxBet: 10000, cooldown: 0 },
        },

        profileCard: { accentColor: '#5865F2', showWallet: true, showRank: true },
        leaderboard: { perPage: 10, sortBy: 'total', hideLeft: false },

        roleBoosters:    [],
        channelBoosters: [],

        stats: { totalCoins: 0, totalUsers: 0, richest: 0 },

        // [PATCH-06] Preserved keys — must not be lost on save
        payCommand: { enabled: true, minAmount: 1, maxAmount: 0, taxRate: 0, cooldown: 0 },
        giveSystem: { chestGive: true, itemGive: true, chestCooldown: 0, itemCooldown: 0 },

        // NEW: Economy Level, Quests, Reminders, Auction
        levelRewards:       [],
        questsEnabled:      true,
        reminderChannelId:  '',
        auctionEnabled:     false,
        auctionMaxDuration: 48,
        loan: { enabled: false, maxAmount: 5000, interestRate: 10, dueHours: 24, cooldownHours: 48 },
        treasuryEnabled: false,
    };
}

function _atomicWrite(file, data) {
    const tmp = file + '.tmp';
    try {
        fs.writeFileSync(tmp, JSON.stringify(data, null, 2), 'utf8');
        fs.renameSync(tmp, file);
    } catch(e) {
        try { fs.unlinkSync(tmp); } catch(_) {}
        fs.writeFileSync(file, JSON.stringify(data, null, 2), 'utf8');
    }
}

function saveEconomySettings(data) {
    _settingsCache   = data;
    _settingsCacheTs = Date.now();
    _atomicWrite(ECONOMY_FILE, data);
}

/* ---- tiny helpers ---- */
function bool(val)   { return val === 'on' || val === true; }
function num(val, d) {
    if (val === undefined || val === null || val === '') return d;
    const parsed = parseFloat(val);
    return Number.isFinite(parsed) ? parsed : d;
}
function int(val, d) {
    if (val === undefined || val === null || val === '') return d;
    const parsed = parseInt(val, 10);
    return Number.isFinite(parsed) ? parsed : d;
}

function safeJson(raw, fallback) {
    try { const p = JSON.parse(raw); return Array.isArray(p) ? p : fallback; }
    catch (e) { return fallback; }
}

function safeJsonObj(raw, fallback) {
    try {
        const p = JSON.parse(raw);
        return (p && typeof p === 'object' && !Array.isArray(p)) ? p : fallback;
    } catch (e) { return fallback; }
}

function registerEconomyRoutes(app, deps = {}) {
    const {
        loadData         = async () => {},
        getSettings      = () => ({}),
        getGuildRoles    = () => [],
        getGuildChannels = () => [],
        getGuildEmojis   = () => [],
    } = deps;

    /* ==================== GET /economy ==================== */
    app.get('/economy', async (req, res) => {
        await loadData(true);
        const settings        = getSettings();
        const guildRoles      = getGuildRoles();
        const guildChannels   = getGuildChannels();
        const guildEmojis     = getGuildEmojis();
        const economySettings = loadEconomySettings();

        // [FIX-STATS] احسب الإحصائيات الحقيقية من بيانات المستخدمين
        // المشكلة القديمة: stats كانت أصفاراً ثابتة محفوظة في economySystem.json
        // لأن الكود لم يحسبها أبداً من economyUserData.json
        try {
            const guildId    = config.guildId;
            const allUsers   = getAllUsers(guildId); // مصفوفة بيانات كل مستخدم
            let totalCoins   = 0;
            let richest      = 0;
            for (const u of allUsers) {
                const total   = (u.wallet || 0) + (u.bank || 0);
                totalCoins   += total;
                if (total > richest) richest = total;
            }
            if (!economySettings.stats) economySettings.stats = {};
            economySettings.stats.totalCoins  = totalCoins;
            economySettings.stats.totalUsers  = allUsers.length;
            economySettings.stats.richest     = richest;
        } catch (_) {
            // في حال فشل القراءة، تبقى الأصفار كما هي
        }

        let consumableItems = {};
        try { consumableItems = JSON.parse(fs.readFileSync(ITEMS_FILE, 'utf8')); } catch (_) {}

        let recipes = {};
        try { recipes = JSON.parse(fs.readFileSync(path.join(__dirname, '..', '..', 'recipes.json'), 'utf8')); } catch (_) {}

        res.render('economy', { settings, guildRoles, guildChannels, guildEmojis, economySettings, consumableItems, recipes });
    });

    /* ==================== POST /economy ==================== */
    app.post('/economy', (req, res) => {
        try {
            const b  = req.body;
            const es = loadEconomySettings();

            /* ---- الإعدادات العامة ---- */
            es.enabled          = bool(b.economyEnabled);
            es.currency         = b.currencyEmoji    || '🪙';
            es.currencyName     = b.currencyName     || 'Coins';
            es.startingBalance  = int(b.startingBalance, 0);
            es.walletLimit      = int(b.walletLimit, 0);
            es.resetOnLeave     = bool(b.resetOnLeave);
            es.globalMultiplier = num(b.globalMultiplier, 1);
            es.stackMultipliers = bool(b.stackMultipliers);

            /* ---- عملات الرسائل ---- */
            es.messageMoney = {
                enabled:     bool(b['messageMoney.enabled']),
                min:         int(b['messageMoney.min'], 1),
                max:         int(b['messageMoney.max'], 5),
                cooldown:    int(b['messageMoney.cooldown'], 60),
                ignoreMuted: bool(b['messageMoney.ignoreMuted']),
                ignoreBots:  bool(b['messageMoney.ignoreBots']),
            };

            /* ---- عملات الصوت ---- */
            es.voiceMoney = {
                enabled:         bool(b['voiceMoney.enabled']),
                min:             int(b['voiceMoney.min'], 2),
                max:             int(b['voiceMoney.max'], 10),
                interval:        int(b['voiceMoney.interval'], 5),
                ignoreSelfMuted: bool(b['voiceMoney.ignoreSelfMuted']),
                ignoreAlone:     bool(b['voiceMoney.ignoreAlone']),
                ignoreDeafened:  bool(b['voiceMoney.ignoreDeafened']),
            };

            /* ---- عملات الأوامر ---- */
            es.commandMoney = {
                enabled:  bool(b['commandMoney.enabled']),
                min:      int(b['commandMoney.min'], 1),
                max:      int(b['commandMoney.max'], 10),
                cooldown: int(b['commandMoney.cooldown'], 30),
            };

            /* ---- عملات الإعجاب ---- */
            es.reactionMoney = {
                enabled:  bool(b['reactionMoney.enabled']),
                min:      int(b['reactionMoney.min'], 1),
                max:      int(b['reactionMoney.max'], 5),
                cooldown: int(b['reactionMoney.cooldown'], 20),
            };

            /* ---- المتجر ---- */
            es.shop = safeJson(b.shopItems, es.shop || []);

            /* ---- الصناديق ---- */
            es.chests = safeJson(b.chests, es.chests || []);

            /* ---- أمر العمل ---- */
            es.work = {
                min:      int(b['work.min'], 50),
                max:      int(b['work.max'], 300),
                cooldown: int(b['work.cooldown'], 8),
                replies:  safeJson(b.workReplies, es.work?.replies || []),
            };

            /* ---- المكافأة اليومية ---- */
            es.daily = {
                min:         int(b['daily.min'], 100),
                max:         int(b['daily.max'], 500),
                cooldown:    int(b['daily.cooldown'], 24),
                streakBonus: num(b['daily.streakBonus'], 1.05),
                streakCap:   int(b['daily.streakCap'], 30),
            };

            /* ---- المكافأة الأسبوعية ---- */
            es.weekly = {
                min:      int(b['weekly.min'], 500),
                max:      int(b['weekly.max'], 2000),
                cooldown: int(b['weekly.cooldown'], 168),
            };

            /* ---- البنك ---- */
            es.bank = {
                enabled:      bool(b['bank.enabled']),
                interestRate: num(b['bank.interestRate'], 0),
                limit:        int(b['bank.limit'], 0),
                withdrawFee:  num(b['bank.withdrawFee'], 0),
                transferFee:  num(b['bank.transferFee'], 0),
            };

/* ---- السرقة ---- */
es.rob = {
    enabled:     bool(b['rob.enabled']),
    successRate: int(b['rob.successRate'], 40),
    maxPercent:  int(b['rob.maxPercent'], 30),
    cooldown:    int(b['rob.cooldown'], 60),
    finePrecent: int(b['rob.finePrecent'] || b['rob.finePercent'], 20),
};

            /* ---- الألعاب ---- */
            es.gambling = {
                slots: {
                    enabled:   bool(b['gambling.slots.enabled']),
                    minBet:    int(b['gambling.slots.minBet'], 10),
                    maxBet:    int(b['gambling.slots.maxBet'], 5000),
                    winChance: int(b['gambling.slots.winChance'], 35),
                    cooldown:  int(b['gambling.slots.cooldown'], es.gambling?.slots?.cooldown || 0),
                },
                coinflip: {
                    enabled:  bool(b['gambling.coinflip.enabled']),
                    minBet:   int(b['gambling.coinflip.minBet'], 10),
                    maxBet:   int(b['gambling.coinflip.maxBet'], 10000),
                    cooldown: int(b['gambling.coinflip.cooldown'], es.gambling?.coinflip?.cooldown || 0),
                },
                blackjack: {
                    enabled:  bool(b['gambling.blackjack.enabled']),
                    minBet:   int(b['gambling.blackjack.minBet'], 10),
                    maxBet:   int(b['gambling.blackjack.maxBet'], 10000),
                    cooldown: int(b['gambling.blackjack.cooldown'], es.gambling?.blackjack?.cooldown || 0),
                },
                // [PATCH-DICE] Preserve dice settings — was missing from dashboard save
                dice: {
                    enabled:  bool(b['gambling.dice.enabled']),
                    minBet:   int(b['gambling.dice.minBet'], 10),
                    maxBet:   int(b['gambling.dice.maxBet'], 5000),
                    cooldown: int(b['gambling.dice.cooldown'], es.gambling?.dice?.cooldown || 0),
                },
                // [PATCH-RPS] Preserve rps settings — was missing from dashboard save
                rps: {
                    enabled:  bool(b['gambling.rps.enabled']),
                    minBet:   int(b['gambling.rps.minBet'], 0),
                    maxBet:   int(b['gambling.rps.maxBet'], 10000),
                    cooldown: int(b['gambling.rps.cooldown'], es.gambling?.rps?.cooldown || 0),
                },
            };

            /* ---- التحويل بين الأعضاء ---- */
            es.pay = {
                enabled:  bool(b['pay.enabled']),
                min:      int(b['pay.min'], 1),
                max:      int(b['pay.max'], 0),
                tax:      num(b['pay.tax'], 0),
                cooldown: int(b['pay.cooldown'], 0),
            };

            /* ---- بطاقة الملف الشخصي ---- */
            es.profileCard = {
                accentColor:     b['profileCard.accentColor']     || '#5865F2',
                showWallet:      bool(b['profileCard.showWallet']),
                showRank:        bool(b['profileCard.showRank']),
                backgroundImage: b['profileCard.backgroundImage'] || '',
                font:            b['profileCard.font']            || 'Default',
                bgOpacity:       int(b['profileCard.bgOpacity'],   80),
                textColor:       b['profileCard.textColor']       || '#ffffff',
                primaryColor:    b['profileCard.primaryColor']    || '#5865F2',
                foregroundColor: b['profileCard.foregroundColor'] || '#1a1a2e',
                backgroundColor: b['profileCard.backgroundColor'] || '#0a0a0f',
            };

            /* ---- ترتيب الأثرياء ---- */
            es.leaderboard = {
                perPage:  int(b['leaderboard.perPage'], 10),
                sortBy:   b['leaderboard.sortBy'] || 'total',
                hideLeft: bool(b['leaderboard.hideLeft']),
            };

            /* ---- مضاعفات الرتب والقنوات ---- */
            es.roleBoosters    = safeJson(b.roleBoosters,    es.roleBoosters    || []);
            es.channelBoosters = safeJson(b.channelBoosters, es.channelBoosters || []);

            /* ---- الإحصائيات (نحتفظ بالقيم الحالية) ---- */
            if (!es.stats) es.stats = { totalCoins: 0, totalUsers: 0, richest: 0 };

            // [PATCH-06] Preserve payCommand and giveSystem — never overwrite with undefined
            es.payCommand = safeJsonObj(b.payCommand, es.payCommand || {
                enabled: true, minAmount: 1, maxAmount: 0, taxRate: 0, cooldown: 0
            });
            es.giveSystem = safeJsonObj(b.giveSystem, es.giveSystem || {
                chestGive: true, itemGive: true, chestCooldown: 0, itemCooldown: 0
            });

            /* ---- نظام المستويات الاقتصادية ---- */
            const rawLvlRewards = safeJson(b.levelRewards, null);
            if (rawLvlRewards !== null) {
                es.levelRewards = rawLvlRewards
                    .filter(r => r && r.level > 0)
                    .map(r => ({ level: Math.max(1, parseInt(r.level) || 1), reward: Math.max(0, parseInt(r.reward) || 0) }))
                    .sort((a, b) => a.level - b.level);
            }

            /* ---- المهام اليومية ---- */
            es.questsEnabled = bool(b.questsEnabled);

            /* ---- التذكيرات ---- */
            es.reminderChannelId = b.reminderChannelId || '';

            /* ---- المزاد ---- */
            es.auctionEnabled     = bool(b.auctionEnabled);
            es.auctionMaxDuration = int(b.auctionMaxDuration, 48);

            /* ---- نظام القروض ---- */
            es.loan = {
                enabled:       bool(b['loan.enabled']),
                maxAmount:     int(b['loan.maxAmount'], 5000),
                interestRate:  num(b['loan.interestRate'], 10),
                dueHours:      int(b['loan.dueHours'], 24),
                cooldownHours: (es.loan && es.loan.cooldownHours) || 48,
            };

            /* ---- خزينة السيرفر ---- */
            es.treasuryEnabled = bool(b.treasuryEnabled);

            saveEconomySettings(es);

            /* ---- العناصر القابلة للاستخدام (items.json) ---- */
            const newItems = safeJsonObj(b.consumableItems, null);
            if (newItems !== null) {
                const cleaned = {};
                Object.entries(newItems).forEach(([id, item]) => {
                    if (id && !String(id).startsWith('_') && item && item.name) {
                        cleaned[id] = {
                            name:        String(item.name).trim(),
                            price:       Math.max(0, parseInt(item.price)  || 0),
                            emoji:       String(item.emoji  || '✨'),
                            effect:      item.effect ? String(item.effect) : null,
                            multiplier:  parseFloat(item.multiplier) || 1,
                            duration:    Math.max(60000, parseInt(item.duration) || 3600000),
                            description: String(item.description || ''),
                        };
                    }
                });
                _atomicWrite(ITEMS_FILE, cleaned);
            }

            /* ---- الوصفات ---- */
            const newRecipes = safeJsonObj(b.recipes, null);
            if (newRecipes !== null) {
                const RECIPES_FILE = path.join(__dirname, '..', '..', 'recipes.json');
                const cleanedRecipes = {};
                Object.entries(newRecipes).forEach(([id, r]) => {
                    if (id && !String(id).startsWith('_') && r && r.resultId) {
                        cleanedRecipes[id] = {
                            name:        String(r.name || id).trim(),
                            description: String(r.description || ''),
                            resultId:    String(r.resultId).trim(),
                            resultQty:   Math.max(1, parseInt(r.resultQty) || 1),
                            ingredients: (r.ingredients && typeof r.ingredients === 'object' && !Array.isArray(r.ingredients))
                                ? Object.fromEntries(Object.entries(r.ingredients).map(([k,v]) => [k, Math.max(1, parseInt(v)||1)]))
                                : {},
                        };
                    }
                });
                _atomicWrite(RECIPES_FILE, cleanedRecipes);
            }

            res.redirect('/economy?success=true');
        } catch (err) {
            console.error('❌ خطأ في حفظ إعدادات الاقتصاد:', err);
            res.redirect('/economy?error=true');
        }
    });
}

module.exports = { registerEconomyRoutes, loadEconomySettings, saveEconomySettings, getDefaultEconomySettings };
