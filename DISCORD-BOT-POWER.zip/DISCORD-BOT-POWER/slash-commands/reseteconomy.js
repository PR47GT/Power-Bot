const { EmbedBuilder, MessageFlags, ButtonBuilder, ButtonStyle, ActionRowBuilder } = require('discord.js');
const { resetEconomy } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:     '⚠️ نظام الاقتصاد معطل حالياً.',
        confirmTitle: '⚠️ تأكيد إعادة تصفير الاقتصاد',
        confirmDesc:  'هذا الإجراء سيحذف **جميع أرصدة ومخازن وصناديق الأعضاء** بشكل نهائي.\nهل أنت متأكد؟',
        confirmed:    '✅ تم تصفير الاقتصاد بالكامل.',
        cancelled:    '❌ تم إلغاء العملية.',
        btnConfirm:   'تأكيد',
        btnCancel:    'إلغاء',
        notYou:       '❌ هذا الزر ليس لك.',
        footer:       'إعادة تعيين الاقتصاد'
    },
    en: {
        disabled:     '⚠️ Economy system is currently disabled.',
        confirmTitle: '⚠️ Confirm Economy Reset',
        confirmDesc:  'This will permanently delete **all member balances, inventories, and chests**.\nAre you sure?',
        confirmed:    '✅ The entire economy has been reset.',
        cancelled:    '❌ Operation cancelled.',
        btnConfirm:   'Confirm',
        btnCancel:    'Cancel',
        notYou:       '❌ This button is not for you.',
        footer:       'Economy Reset'
    }
};

module.exports = {
    data: {
        name: 'reseteconomy',
        description: 'Reset the entire economy | إعادة تصفير الاقتصاد بالكامل',
        default_member_permissions: '8'
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const confirmBtn = new ButtonBuilder()
            .setCustomId('reseteconomy_confirm')
            .setLabel(t.btnConfirm)
            .setStyle(ButtonStyle.Danger);
        const cancelBtn = new ButtonBuilder()
            .setCustomId('reseteconomy_cancel')
            .setLabel(t.btnCancel)
            .setStyle(ButtonStyle.Secondary);
        const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

        const embed = new EmbedBuilder()
            .setTitle(t.confirmTitle)
            .setDescription(t.confirmDesc)
            .setColor('#ED4245')
            .setFooter({ text: t.footer });

        // [FIX] Use resource.message for ephemeral confirmation with buttons
        const _cbr = await interaction.reply({
            embeds: [embed],
            components: [row],
            flags: MessageFlags.Ephemeral,
            withResponse: true
        });
        const msg = _cbr.resource.message;

        const collector = msg.createMessageComponentCollector({ time: 30000 });

        collector.on('collect', async btn => {
            if (btn.user.id !== interaction.user.id) {
                return btn.reply({ content: t.notYou, flags: MessageFlags.Ephemeral });
            }
            collector.stop();
            if (btn.customId === 'reseteconomy_confirm') {
                resetEconomy(interaction.guildId);
                await btn.update({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.confirmed)
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })],
                    components: []
                });
            } else {
                await btn.update({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.cancelled)
                        .setColor('#71717a')
                        .setFooter({ text: t.footer })],
                    components: []
                });
            }
        });

        collector.on('end', (_, reason) => {
            if (reason === 'time') {
                interaction.editReply({ components: [] }).catch(() => {});
            }
        });
    
      } catch (err) {
          console.error('[reseteconomy] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
