const fs = require('fs');
const path = require('path');
const { ChannelType, MessageFlags, PermissionFlagsBits } = require('discord.js');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'حذف عدد من الرسائل',
        option_amount: 'عدد الرسائل (1-100)',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        notText: '❌ هذا الأمر يعمل فقط في رومات النصية',
        botNoPerm: '❌ البوت لا يملك صلاحية حذف الرسائل',
        deleteFailed: '❌ فشل حذف الرسائل:',
        success: (count) => `🗑️ تم حذف **${count}** رسالة بنجاح`,
        noMessages: '⚠️ لا توجد رسائل لحذفها',
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Delete a number of messages',
        option_amount: 'Number of messages (1-100)',
        disabled: '⚠️ This command is currently disabled.',
        notText: '❌ This command only works in text channels',
        botNoPerm: '❌ Bot does not have permission to manage messages',
        deleteFailed: '❌ Failed to delete messages:',
        success: (count) => `🗑️ Successfully deleted **${count}** messages`,
        noMessages: '⚠️ No messages to delete',
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'clear',
        description: 'Delete messages | حذف الرسائل',
        options: [
            {
                name: 'amount',
                description: 'Number of messages (1-100)',
                type: 4,
                required: true,
                min_value: 1,
                max_value: 100
            }
        ]
    },
    
    async execute(interaction, client, settings) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const commandConfig = modCommands.clear || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!commandConfig.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                commandConfig
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            if (interaction.channel.type !== ChannelType.GuildText) {
                return await interaction.editReply({ content: t.notText });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageMessages)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            const amount = interaction.options.getInteger('amount');
            
            let deletedCount = 0;
            try {
                const messages = await interaction.channel.messages.fetch({ limit: amount });
                const deleted = await interaction.channel.bulkDelete(messages, true);
                deletedCount = deleted.size;
            } catch (error) {
                console.error('Clear error:', error.message);
                return await interaction.editReply({ 
                    content: `${t.deleteFailed} ${error.message}`
                });
            }
            
            const successMessage = deletedCount > 0 
                ? t.success(deletedCount)
                : t.noMessages;
            
            if (commandConfig.deleteResponse) {
                await interaction.editReply({ content: successMessage });

                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }
            
        } catch (error) {
            console.error('❌ Clear command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};