const { MessageFlags, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌐 ترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        botNoPerm: '❌ البوت لا يملك صلاحية نقل الأعضاء في الرومات الصوتية',
        sourceNotVoice: '⚠️ الروم المصدر ليس روم صوتي.',
        targetNotVoice: '⚠️ الروم الهدف ليس روم صوتي.',
        sameChannel: '⚠️ الروم المصدر والهدف نفس الروم.',
        noMembersInSource: '⚠️ لا يوجد أعضاء في الروم الصوتي المصدر.',
        moving: (count, source, target) => `🔄 جاري نقل \`\`${count} \`\`عضو من \`\`${source}\`\` إلى \`\`${target}\`\`...`,
        success: (count, source, target) => `✅ تم نقل \`\`${count}\`\` عضو من \`\`${source}\`\` إلى \`\`${target}\`\` بنجاح`,
        partialSuccess: (successCount, failCount, source, target) => `⚠️ تم نقل \`${successCount}\` عضو من \`${source}\` إلى \`${target}\` (فشل نقل ${failCount})`,
        failed: (err) => `❌ فشل نقل الأعضاء: ${err}`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        botNoPerm: '❌ Bot does not have permission to move members',
        sourceNotVoice: '⚠️ Source channel is not a voice channel.',
        targetNotVoice: '⚠️ Target channel is not a voice channel.',
        sameChannel: '⚠️ Source and target are the same channel.',
        noMembersInSource: '⚠️ No members found in the source voice channel.',
        moving: (count, source, target) => `🔄 Moving \`\`${count}\`\` members from \`\`${source}\`\` to \`\`${target}\`\`...`,
        success: (count, source, target) => `✅ Successfully moved \`\`${count}\`\` members from \`\`${source}\`\` to \`\`${target}\`\``,
        partialSuccess: (successCount, failCount, source, target) => `⚠️ Moved \`${successCount}\` members from \`${source}\` to \`${target}\` (${failCount} failed)`,
        failed: (err) => `❌ Failed to move members: ${err}`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'vmove',
        description: 'Move all members from one voice channel to another | نقل جميع الأعضاء من روم صوتي لآخر',
        description_localizations: {
            ar: 'نقل جميع الأعضاء من روم صوتي إلى آخر',
            'en-US': 'Move all members from one voice channel to another'
        },
        default_member_permissions: PermissionFlagsBits.MoveMembers.toString(),
        options: [
            {
                name: 'source',
                description: 'Source voice channel | الروم الصوتي المصدر',
                description_localizations: {
                    ar: 'الروم الصوتي المصدر',
                    'en-US': 'Source voice channel'
                },
                type: 7, // CHANNEL
                required: true,
                channel_types: [2] // Voice channels only
            },
            {
                name: 'target',
                description: 'Target voice channel | الروم الصوتي الهدف',
                description_localizations: {
                    ar: 'الروم الصوتي الهدف',
                    'en-US': 'Target voice channel'
                },
                type: 7, // CHANNEL
                required: true,
                channel_types: [2] // Voice channels only
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.vmove || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            // Check bot permissions
            if (!interaction.guild.members.me.permissions.has('MoveMembers')) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            const sourceChannel = interaction.options.getChannel('source');
            const targetChannel = interaction.options.getChannel('target');
            
            // Validate source channel
            if (!sourceChannel || sourceChannel.type !== 2) {
                return await interaction.editReply({ content: t.sourceNotVoice });
            }
            
            // Validate target channel
            if (!targetChannel || targetChannel.type !== 2) {
                return await interaction.editReply({ content: t.targetNotVoice });
            }
            
            // Check if same channel
            if (sourceChannel.id === targetChannel.id) {
                return await interaction.editReply({ content: t.sameChannel });
            }
            
            // Get all members in source channel
            const membersToMove = Array.from(sourceChannel.members.values());
            
            if (membersToMove.length === 0) {
                return await interaction.editReply({ content: t.noMembersInSource });
            }
            
            // Send moving status
            await interaction.editReply({ 
                content: t.moving(membersToMove.length, sourceChannel.name, targetChannel.name) 
            });
            
            // Move all members
            let successCount = 0;
            let failCount = 0;
            
            const movePromises = membersToMove.map(async (member) => {
                try {
                    await member.voice.setChannel(targetChannel);
                    successCount++;
                } catch (error) {
                    failCount++;
                    console.error(`Failed to move ${member.user.tag}: ${error.message}`);
                }
            });
            
            await Promise.all(movePromises);
            
            // Build result message
            let resultMessage;
            
            if (failCount === 0) {
                resultMessage = t.success(successCount, sourceChannel.name, targetChannel.name);
            } else if (successCount > 0) {
                resultMessage = t.partialSuccess(successCount, failCount, sourceChannel.name, targetChannel.name);
            } else {
                resultMessage = t.failed(lang === 'ar' ? 'فشل نقل جميع الأعضاء' : 'Failed to move all members');
            }
            
            // Send final result
            if (config.deleteResponse) {
                await interaction.editReply({ content: resultMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: resultMessage });
            }
            
        } catch (error) {
            console.error('❌ Error in vmove:', error.message);
            
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};