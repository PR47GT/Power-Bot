const {
    EmbedBuilder, MessageFlags,
    ButtonBuilder, ButtonStyle, ActionRowBuilder
} = require('discord.js');
const { getUser, saveUser, getChest, restockChest, getAllUsers, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        noChest:    '❌ الصندوق غير موجود في الإعدادات.',
        notOwned:   (id) => `❌ لا يملك العضو صندوق **${id}**.`,
        empty:      'لا يملك أي صناديق.',
        restocked:  (name, qty) => `✅ تم إعادة تعبئة الصندوق **${name}** بـ **${qty}** وحدة.`,
        added:      (qty, name, user) => `✅ تمت إضافة **${qty}x ${name}** إلى **${user}**.`,
        removed:    (name, user) => `✅ تمت إزالة جميع نسخ **${name}** من **${user}**.`,
        inventory:  (name) => `📦 صناديق **${name}**`,
        viewAll:    '📋 كل الأعضاء الذين يملكون صناديق',
        noOwners:   'لا يوجد أعضاء يملكون صناديق حالياً.',
        confirmRem: (name, user) => `⚠️ هل تريد إزالة **${name}** من **${user}**؟`,
        confirmed:  '✅ تمت الإزالة.',
        cancelled:  '❌ تم الإلغاء.',
        notYou:     '❌ هذا الزر ليس لك.',
        btnConfirm: 'تأكيد',
        btnCancel:  'إلغاء',
        footer:     'إدارة الصناديق'
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        noChest:    '❌ Chest not found in settings.',
        notOwned:   (id) => `❌ Member does not own chest **${id}**.`,
        empty:      'No chests.',
        restocked:  (name, qty) => `✅ Restocked chest **${name}** with **${qty}** units.`,
        added:      (qty, name, user) => `✅ Gave **${qty}x ${name}** to **${user}**.`,
        removed:    (name, user) => `✅ Removed all copies of **${name}** from **${user}**.`,
        inventory:  (name) => `📦 ${name}'s Chests`,
        viewAll:    '📋 All Members with Chests',
        noOwners:   'No members currently own any chests.',
        confirmRem: (name, user) => `⚠️ Remove **${name}** from **${user}**?`,
        confirmed:  '✅ Removed.',
        cancelled:  '❌ Cancelled.',
        notYou:     '❌ This button is not for you.',
        btnConfirm: 'Confirm',
        btnCancel:  'Cancel',
        footer:     'Chest Management'
    }
};

module.exports = {
    data: {
        name: 'achest',
        description: 'Admin: Manage chests | إدارة: التحكم بالصناديق',
        default_member_permissions: '8',
        options: [
            {
                name: 'restock',
                description: 'Restock a chest in the shop | أعد تعبئة صندوق في المتجر',
                type: 1,
                options: [
                    { name: 'name',   description: 'Chest name | اسم الصندوق', type: 3, required: true },
                    { name: 'amount', description: 'Stock amount | الكمية',     type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'user',
                description: 'User chest operations | عمليات صناديق الأعضاء',
                type: 2,
                options: [
                    {
                        name: 'add',
                        description: 'Give a chest to a member | أعط صندوقاً لعضو',
                        type: 1,
                        options: [
                            { name: 'user',   description: 'Target member | العضو',         type: 6, required: true },
                            { name: 'name',   description: 'Chest name | اسم الصندوق',      type: 3, required: true },
                            { name: 'amount', description: 'Amount | الكمية',                type: 4, required: false, min_value: 1 }
                        ]
                    },
                    {
                        name: 'remove',
                        description: 'Remove a chest from a member | أزل صندوقاً من عضو',
                        type: 1,
                        options: [
                            { name: 'user', description: 'Target member | العضو',       type: 6, required: true },
                            { name: 'name', description: 'Chest name | اسم الصندوق',    type: 3, required: true }
                        ]
                    },
                    {
                        name: 'inventory',
                        description: "View a member's chests | شوف صناديق عضو",
                        type: 1,
                        options: [
                            { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                        ]
                    },
                    {
                        name: 'view-all',
                        description: 'View all members who own chests | عرض كل الأعضاء الذين يملكون صناديق',
                        type: 1,
                        options: []
                    }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const sub = interaction.options.getSubcommand();

        // ── RESTOCK ──────────────────────────────────────────────────────────
        if (sub === 'restock') {
            const name   = interaction.options.getString('name');
            const amount = interaction.options.getInteger('amount');
            const chest  = getChest(name);
            if (!chest) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noChest).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            restockChest(name, amount);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.restocked(chest.name || name, amount))
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        // ── VIEW-ALL ─────────────────────────────────────────────────────────
        if (sub === 'view-all') {
            const allUsers = getAllUsers(interaction.guildId);
            const lines = [];
            for (const u of allUsers) {
                const chests = u.chests || {};
                if (typeof chests !== 'object' || Array.isArray(chests)) continue;
                const entries = Object.entries(chests).filter(([, qty]) => qty > 0);
                if (!entries.length) continue;
                const member = await interaction.guild.members.fetch(u.userId).catch(() => null);
                const name   = member ? member.displayName : u.userId;
                const list   = entries.map(([id, qty]) => {
                    const c = getChest(id);
                    const emoji = c?.emoji ? `${c.emoji} ` : '📦 ';
                    return `  • ${emoji}${c ? c.name : id} x${qty}`;
                }).join('\n');
                lines.push(`**${name}**\n${list}`);
            }
            const desc = lines.length ? lines.join('\n\n') : t.noOwners;
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(t.viewAll)
                    .setDescription(desc)
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }

        // ── USER subcommands ──────────────────────────────────────────────────
        const target   = interaction.options.getUser('user');
        const userData = getUser(interaction.guildId, target.id);
        if (!userData.chests || Array.isArray(userData.chests)) userData.chests = {};

        // ADD
        if (sub === 'add') {
            const name   = interaction.options.getString('name');
            const amount = interaction.options.getInteger('amount') || 1;
            const chest  = getChest(name);
            if (!chest) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noChest).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            userData.chests[name] = (userData.chests[name] || 0) + amount;
            saveUser(interaction.guildId, target.id, userData);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.added(amount, chest.name || name, target.username))
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        // REMOVE — with confirmation buttons (fixed: withResponse instead of fetchReply)
        if (sub === 'remove') {
            const name  = interaction.options.getString('name');
            const chest = getChest(name);
            if (!(userData.chests[name] > 0)) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.notOwned(name)).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            const confirmBtn = new ButtonBuilder()
                .setCustomId('achest_remove_confirm')
                .setLabel(t.btnConfirm)
                .setStyle(ButtonStyle.Danger);
            const cancelBtn = new ButtonBuilder()
                .setCustomId('achest_remove_cancel')
                .setLabel(t.btnCancel)
                .setStyle(ButtonStyle.Secondary);
            const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

            // [FIX] Use resource.message for ephemeral confirmation with buttons
            const _cbr = await interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.confirmRem(chest?.name || name, target.username))
                    .setColor('#FEE75C').setFooter({ text: t.footer })],
                components: [row],
                flags: MessageFlags.Ephemeral,
                withResponse: true
            });
            const msg = _cbr.resource.message;

            const collector = msg.createMessageComponentCollector({ time: 30000 });
            collector.on('collect', async btn => {
                if (btn.user.id !== interaction.user.id) {
                    return btn.reply({ content: t.notYou, flags: MessageFlags.Ephemeral });
                }
                collector.stop();
                if (btn.customId === 'achest_remove_confirm') {
                    const fresh = getUser(interaction.guildId, target.id);
                    if (!fresh.chests || Array.isArray(fresh.chests)) fresh.chests = {};
                    delete fresh.chests[name];
                    saveUser(interaction.guildId, target.id, fresh);
                    await btn.update({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.removed(chest?.name || name, target.username))
                            .setColor('#57F287').setFooter({ text: t.footer })],
                        components: []
                    });
                } else {
                    await btn.update({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.cancelled)
                            .setColor('#71717a').setFooter({ text: t.footer })],
                        components: []
                    });
                }
            });
            collector.on('end', (_, reason) => {
                if (reason === 'time') interaction.editReply({ components: [] }).catch(() => {});
            });
            return;
        }

        // INVENTORY
        if (sub === 'inventory') {
            const entries = Object.entries(userData.chests)
                .filter(([, qty]) => qty > 0);
            const list = entries.length
                ? entries.map(([id, qty]) => {
                    const c = getChest(id);
                    const emoji = c?.emoji ? `${c.emoji} ` : '📦 ';
                    return `• ${emoji}${c ? c.name : id}: **${qty}**`;
                }).join('\n')
                : t.empty;
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(t.inventory(target.username))
                    .setDescription(list)
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }
    
      } catch (err) {
          console.error('[achest] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
