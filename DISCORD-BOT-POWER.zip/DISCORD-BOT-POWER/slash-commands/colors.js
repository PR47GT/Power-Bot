const { MessageFlags, EmbedBuilder, AttachmentBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const { COLOR_PALETTES } = require('./color');

let createCanvas, loadImage;
try {
    ({ createCanvas, loadImage } = require('@napi-rs/canvas'));
} catch(e) {
    console.warn('⚠️ @napi-rs/canvas not available:', e.message);
}

function loadColorSettings() {
    const p = path.join(__dirname, '../colorRolesSettings.json');
    if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch(e) {}
    }
    return { enabled: true, selectedPalette: 'rainbow', colorRoleIds: {}, commands: { color: { enabled: true }, colors: { enabled: true } } };
}

const T = {
    ar: {
        cmdDisabled:  '⚠️ هذا الأمر معطل حالياً.',
        noPalette:    '⚠️ لم يتم اختيار لوحة ألوان بعد.',
        defaultTitle: 'منتقي الألوان',
        desc:         () => `اختر **لونك المفضل** من الدوائر أدناه!\nاستخدم الأمر \`/color\` لاختيار اللون الذي تريده.`,
        footer:       'استخدم /color لاختيار لونك',
    },
    en: {
        cmdDisabled:  '⚠️ This command is currently disabled.',
        noPalette:    '⚠️ No color palette has been selected yet.',
        defaultTitle: 'Colors Picker',
        desc:         () => `Choose your **favorite color** from the roles below!\nUse the command \`/color\` to select the color you like.`,
        footer:       'Use /color to pick your color',
    }
};

// ── Shape drawers ──────────────────────────────────────────────────────────────
function drawShape(ctx, shape, cx, cy, r) {
    ctx.beginPath();
    switch (shape) {
        case 'square': {
            const rr = r * 0.28; // corner radius
            const x  = cx - r, y = cy - r, s = r * 2;
            ctx.moveTo(x + rr, y);
            ctx.lineTo(x + s - rr, y); ctx.arcTo(x + s, y, x + s, y + rr, rr);
            ctx.lineTo(x + s, y + s - rr); ctx.arcTo(x + s, y + s, x + s - rr, y + s, rr);
            ctx.lineTo(x + rr, y + s); ctx.arcTo(x, y + s, x, y + s - rr, rr);
            ctx.lineTo(x, y + rr); ctx.arcTo(x, y, x + rr, y, rr);
            ctx.closePath();
            break;
        }
        case 'pentagon': {
            const sides = 5;
            const startAngle = -Math.PI / 2;
            for (let i = 0; i < sides; i++) {
                const a = startAngle + (i / sides) * Math.PI * 2;
                const px = cx + r * Math.cos(a), py = cy + r * Math.sin(a);
                i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
            }
            ctx.closePath();
            break;
        }
        case 'star': {
            const spikes = 5, outerR = r, innerR = r * 0.45;
            const startA = -Math.PI / 2;
            for (let i = 0; i < spikes * 2; i++) {
                const ang  = startA + (i / (spikes * 2)) * Math.PI * 2;
                const rad  = i % 2 === 0 ? outerR : innerR;
                const px = cx + rad * Math.cos(ang), py = cy + rad * Math.sin(ang);
                i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
            }
            ctx.closePath();
            break;
        }
       case 'heart': {
            const s = r * 1.0;
            ctx.save();
            ctx.translate(cx, cy - s * 0.1);
            ctx.scale(s / 48, s / 48);
            ctx.moveTo(0, 30);
            ctx.bezierCurveTo(-5, 15, -35, 10, -35, -10);
            ctx.bezierCurveTo(-35, -35, 0, -20, 0, -5);
            ctx.bezierCurveTo(0, -20, 35, -35, 35, -10);
            ctx.bezierCurveTo(35, 10, 5, 15, 0, 30);
            ctx.closePath();
            ctx.restore();
            return; // path already set
        }
        case 'hexagon': {
            const sides = 6;
            const startAngle = -Math.PI / 2;
            for (let i = 0; i < sides; i++) {
                const a = startAngle + (i / sides) * Math.PI * 2;
                const px = cx + r * Math.cos(a), py = cy + r * Math.sin(a);
                i === 0 ? ctx.moveTo(px, py) : ctx.lineTo(px, py);
            }
            ctx.closePath();
            break;
        }
        case 'diamond': {
            ctx.moveTo(cx, cy - r);
            ctx.lineTo(cx + r, cy);
            ctx.lineTo(cx, cy + r);
            ctx.lineTo(cx - r, cy);
            ctx.closePath();
            break;
        }
        case 'circle':
        default:
            ctx.arc(cx, cy, r, 0, Math.PI * 2);
            break;
    }
}

// ── Image generator ────────────────────────────────────────────────────────────
async function generateColorImage(colors, bgBase64, shape = 'circle') {
    const COLS       = 8;
    const RADIUS     = 55;
    const GAP        = 22;
    const PAD_X      = 40;
    const PAD_Y      = 36;
    const rows       = Math.ceil(colors.length / COLS);
    const canvasW    = COLS * (RADIUS * 2 + GAP) - GAP + PAD_X * 2;
    const canvasH    = rows  * (RADIUS * 2 + GAP) - GAP + PAD_Y * 2;

    const canvas = createCanvas(canvasW, canvasH);
    const ctx    = canvas.getContext('2d');

    // ── Background ─────────────────────────────────────────────────────────
    // Canvas starts transparent by default — only fill if a background image is provided
    // (no fillRect here so PNG stays transparent when no image is set)

    // Draw user's background image on top (if provided)
    if (bgBase64 && bgBase64.startsWith('data:image/')) {
        try {
            const buf = Buffer.from(bgBase64.split(',')[1], 'base64');
            const img = await loadImage(buf);
            ctx.drawImage(img, 0, 0, canvasW, canvasH);
        } catch(e) {
            console.error('⚠️ Failed to load bg image:', e.message);
        }
    }

    // ── Shapes ─────────────────────────────────────────────────────────────
    colors.forEach((color, i) => {
        const col = i % COLS;
        const row = Math.floor(i / COLS);
        const cx  = PAD_X + col * (RADIUS * 2 + GAP) + RADIUS;
        const cy  = PAD_Y + row * (RADIUS * 2 + GAP) + RADIUS;

        // Drop shadow
        ctx.save();
        ctx.shadowColor   = 'rgba(0,0,0,0.55)';
        ctx.shadowBlur    = 14;
        ctx.shadowOffsetX = 3;
        ctx.shadowOffsetY = 4;
        drawShape(ctx, shape, cx, cy, RADIUS);
        ctx.fillStyle = color.hex;
        ctx.fill();
        ctx.restore();

        // Number label — clip text inside the shape area
        const label    = String(i + 1);
        const fontSize = label.length >= 2 ? 30 : 34;
        ctx.font        = `bold ${fontSize}px sans-serif`;
        ctx.textAlign   = 'center';
        ctx.textBaseline = 'middle';

        // Slight offset for heart (centroid is a bit higher)
        const textY = shape === 'heart' ? cy - RADIUS * 0.08 : cy;

        ctx.strokeStyle = 'rgba(0,0,0,0.45)';
        ctx.lineWidth   = 4;
        ctx.strokeText(label, cx, textY);
        ctx.fillStyle   = '#ffffff';
        ctx.fillText(label, cx, textY);
    });

    return canvas.toBuffer('image/png');
}

// ──────────────────────────────────────────────────────────────────────────────

module.exports.data = {
    name: 'colors',
    description: '🌈 Show all available color roles | عرض ألوان الرتب المتاحة'
};

module.exports.execute = async function(interaction, client, settings, commandConfig) {
    try {
        await interaction.deferReply();

        const isAr = settings.botLanguage === 'ar';
        const t    = isAr ? T.ar : T.en;
        const cs   = loadColorSettings();

        if (commandConfig && commandConfig.enabled === false) {
            return interaction.editReply({ content: t.cmdDisabled });
        }

        const palette = COLOR_PALETTES[cs.selectedPalette];
        if (!palette) return interaction.editReply({ content: t.noPalette });

        // Only show colors that have a valid assigned role; fall back to full palette if none configured
        const hasAnyRole = cs.colorRoleIds && Object.keys(cs.colorRoleIds).length > 0;
        const activeColors = hasAnyRole
            ? palette.colors.filter(c => {
                const rid = cs.colorRoleIds[c.id];
                if (!rid) return false;
                // Also verify the role still exists in Discord
                return !!interaction.guild.roles.cache.get(rid);
            })
            : palette.colors;

        if (activeColors.length === 0) return interaction.editReply({ content: t.noPalette });

        const title     = cs.pickerTitle || t.defaultTitle;
        const accentHex = activeColors[0]?.hex || '#5865F2';

        const embed = new EmbedBuilder()
            .setTitle(title)
            .setDescription(t.desc())
            .setColor(accentHex)
            .setFooter({ text: t.footer })
            .setTimestamp();

        // Generate color circles image
        if (createCanvas) {
            try {
                const shape  = cs.selectedShape || 'circle';
                const imgBuf = await generateColorImage(activeColors, cs.bgImage || null, shape);
                const attach = new AttachmentBuilder(imgBuf, { name: 'colors.png' });
                embed.setImage('attachment://colors.png');
                return interaction.editReply({ embeds: [embed], files: [attach] });
            } catch(e) {
                console.error('❌ generateColorImage error:', e);
            }
        }

        // Fallback: plain text list if canvas unavailable
        const lines = activeColors.map((c, i) => {
            const rid  = cs.colorRoleIds?.[c.id];
            const role = rid ? interaction.guild.roles.cache.get(rid) : null;
            return role ? `${i + 1}. <@&${role.id}>` : `${i + 1}. ${c.nameEn} — \`${c.hex}\``;
        });
        embed.addFields({ name: '\u200b', value: lines.join('\n') });
        await interaction.editReply({ embeds: [embed] });

    } catch (err) {
        console.error('❌ خطأ في /colors:', err);
        try {
            if (interaction.deferred || interaction.replied) await interaction.editReply({ content: `❌ ${err.message}` });
            else await interaction.reply({ content: `❌ ${err.message}`, flags: MessageFlags.Ephemeral });
        } catch(e) {}
    }
};
