const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نفس نظام roles بالضبط
const T = {
    ar: {
        description: 'قفل الروم',
        option_channel: 'الروم (اختياري)',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرومات',
        alreadyLocked: '🔒 الروم مقفل بالفعل.',
        lockFailed: '❌ فشل قفل الروم:',
        success: (channel) => `🔒 تم قفل ${channel}`,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Lock a channel',
        option_channel: 'Channel (optional)',
        disabled: '⚠️ This command is currently disabled.',
        botNoPerm: '❌ Bot does not have permission to manage channels',
        alreadyLocked: '🔒 Channel is already locked.',
        lockFailed: '❌ Failed to lock channel:',
        success: (channel) => `🔒 ${channel} has been locked`,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    name: 'lock',
    description: 'Lock a channel | قفل الروم',

    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس طريقتك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.lock || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ 
                    content: t.disabled
                });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ 
                    content: permission.reason
                });
            }
            
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return await interaction.editReply({ 
                    content: t.botNoPerm
                });
            }
            
            if (!channel.permissionsFor(interaction.guild.id).has('SendMessages')) {
                return await interaction.editReply({ 
                    content: t.alreadyLocked
                });
            }
            
            try {
                await channel.permissionOverwrites.edit(interaction.guild.id, {
                    SendMessages: false
                });
            } catch (error) {
                return await interaction.editReply({ 
                    content: `${t.lockFailed} ${error.message}`
                });
            }
            
            const successMessage = t.success(channel);
            
            if (config.deleteResponse) {
                await interaction.editReply({ content: successMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }
            
        } catch (error) {
            console.error('❌ Lock command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    },
};