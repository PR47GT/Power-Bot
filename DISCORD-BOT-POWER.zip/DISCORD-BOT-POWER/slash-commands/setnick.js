const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌐 ترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        noPermission: (reason) => reason,
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        botNoPerm: '❌ البوت لا يملك صلاحية تغيير الألقاب',
        nicknameTooLong: '❌ اللقب لا يمكن أن يتجاوز 32 حرفاً.',
        success: (user, nick) => `✏️ تم تغيير لقب \`${user}\`/إلى: ${nick || 'بدون لقب'}`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        noPermission: (reason) => reason,
        memberNotFound: '❌ Member not found in the server.',
        botNoPerm: '❌ Bot does not have permission to manage nicknames',
        nicknameTooLong: '❌ Nickname cannot be longer than 32 characters.',
        success: (user, nick) => `✏️ Nickname changed for \`${user}\` → ${nick || 'No nickname'}`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'setnick',
        description: 'Change a member nickname | تغيير لقب العضو',
        description_localizations: {
            ar: 'تغيير لقب العضو',
            enUS: 'Change a member nickname'
        },
        default_member_permissions: PermissionFlagsBits.ManageNicknames.toString(),
        options: [
            { 
                name: 'user', 
                description: 'Member', 
                description_localizations: {
                    ar: 'العضو',
                    enUS: 'Member'
                },
                type: 6, 
                required: true 
            },
            { 
                name: 'nickname', 
                description: 'New nickname', 
                description_localizations: {
                    ar: 'اللقب الجديد',
                    enUS: 'New nickname'
                },
                type: 3, 
                required: false 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.setnick || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: t.noPermission(permission.reason) });
            }
            
            const targetUser = interaction.options.getUser('user');
            const nickname = interaction.options.getString('nickname');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageNicknames)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (nickname && nickname.length > 32) {
                return await interaction.editReply({ content: t.nicknameTooLong });
            }
            
            try {
                await targetMember.setNickname(nickname);
                
                const successMessage = t.success(targetUser.tag, nickname);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ 
                    content: t.error(error.message)
                });
            }
            
        } catch (error) {
            console.error('❌ Error in setnick:', error.message);
            
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};