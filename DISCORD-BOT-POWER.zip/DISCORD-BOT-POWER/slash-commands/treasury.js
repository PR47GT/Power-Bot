const { EmbedBuilder, MessageFlags, PermissionFlagsBits } = require('discord.js');
const { getUser, saveUser, getTreasury, addToTreasury, withdrawFromTreasury } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:     '⚠️ نظام الاقتصاد معطل حالياً.',
        treasuryOff:  '⚠️ خزينة السيرفر معطلة حالياً.',
        title:        '🏛️ خزينة السيرفر',
        balance:      'رصيد الخزينة',
        lastActivity: 'آخر النشاطات',
        empty:        '📭 لا توجد معاملات بعد.',
        noMoney:      (amt, cur) => `❌ لا تملك **${amt.toLocaleString()} ${cur}** في محفظتك.`,
        donated:      (amt, cur) => `✅ تبرعت بـ **${amt.toLocaleString()} ${cur}** للخزينة. شكراً!`,
        withdrawn:    (amt, cur) => `✅ سُحب **${amt.toLocaleString()} ${cur}** من الخزينة.`,
        insufficientT:'❌ الخزينة لا تملك هذا المبلغ.',
        footer:       'خزينة السيرفر',
        sourceNames: {
            rob_fine:     '🚓 غرامة سرقة',
            bank_fee:     '🏦 رسوم بنكية',
            pay_tax:      '💸 ضريبة دفع',
            donate:       '❤️ تبرع',
            admin_withdraw:'🔧 سحب إداري',
        }
    },
    en: {
        disabled:     '⚠️ Economy system is currently disabled.',
        treasuryOff:  '⚠️ Server treasury is currently disabled.',
        title:        '🏛️ Server Treasury',
        balance:      'Treasury Balance',
        lastActivity: 'Recent Activity',
        empty:        '📭 No activity yet.',
        noMoney:      (amt, cur) => `❌ You don't have **${amt.toLocaleString()} ${cur}** in your wallet.`,
        donated:      (amt, cur) => `✅ You donated **${amt.toLocaleString()} ${cur}** to the treasury. Thank you!`,
        withdrawn:    (amt, cur) => `✅ Withdrew **${amt.toLocaleString()} ${cur}** from the treasury.`,
        insufficientT:'❌ The treasury does not have enough funds.',
        footer:       'Server Treasury',
        sourceNames: {
            rob_fine:     '🚓 Rob Fine',
            bank_fee:     '🏦 Bank Fee',
            pay_tax:      '💸 Pay Tax',
            donate:       '❤️ Donation',
            admin_withdraw:'🔧 Admin Withdrawal',
        }
    }
};

function timeAgo(ts, lang) {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (lang === 'ar') {
        if (diff < 60)    return `${diff} ثانية`;
        if (diff < 3600)  return `${Math.floor(diff/60)} دقيقة`;
        if (diff < 86400) return `${Math.floor(diff/3600)} ساعة`;
        return `${Math.floor(diff/86400)} يوم`;
    }
    if (diff < 60)    return `${diff}s ago`;
    if (diff < 3600)  return `${Math.floor(diff/60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
    return `${Math.floor(diff/86400)}d ago`;
}

module.exports = {
    data: {
        name: 'treasury',
        description: 'Server treasury — taxes, fines, and donations | خزينة السيرفر',
        default_member_permissions: '8',
        options: [
            {
                name: 'view',
                description: 'View treasury balance and recent activity | عرض الخزينة',
                type: 1
            },
            {
                name: 'donate',
                description: 'Donate coins to the treasury | التبرع للخزينة',
                type: 1,
                options: [
                    { name: 'amount', description: 'Amount to donate | المبلغ', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'withdraw',
                description: '[Admin] Withdraw from treasury | سحب من الخزينة',
                type: 1,
                default_member_permissions: String(PermissionFlagsBits.ManageGuild),
                options: [
                    { name: 'amount', description: 'Amount to withdraw | المبلغ', type: 4, required: true, min_value: 1 },
                    { name: 'user',   description: 'Recipient member | المستلم', type: 6, required: false }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            if (!es.treasuryEnabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.treasuryOff).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const sub  = interaction.options.getSubcommand();
            const cur  = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            // ── view ─────────────────────────────────────────────────────────────
            if (sub === 'view') {
                const treasury = getTreasury(interaction.guildId);
                const log      = (treasury.log || []).slice(0, 7);

                const embed = new EmbedBuilder()
                    .setTitle(t.title)
                    .setColor('#FFD700')
                    .addFields({ name: t.balance, value: `**${(treasury.balance || 0).toLocaleString()} ${cur}**` })
                    .setFooter({ text: t.footer })
                    .setTimestamp();

                if (log.length === 0) {
                    embed.addFields({ name: t.lastActivity, value: t.empty });
                } else {
                    const lines = log.map(entry => {
                        const srcName = t.sourceNames[entry.source] || entry.source || '💱';
                        const sign    = entry.amount >= 0 ? '+' : '';
                        return `${srcName} **${sign}${entry.amount.toLocaleString()} ${es.currency || '🪙'}** · \`${timeAgo(entry.ts, lang)}\``;
                    });
                    embed.addFields({ name: t.lastActivity, value: lines.join('\n') });
                }

                return interaction.reply({ embeds: [embed] });
            }

            // ── donate ───────────────────────────────────────────────────────────
            if (sub === 'donate') {
                const amount = interaction.options.getInteger('amount');
                const user   = getUser(interaction.guildId, interaction.user.id);

                if ((user.wallet || 0) < amount) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                user.wallet = (user.wallet || 0) - amount;
                saveUser(interaction.guildId, interaction.user.id, user);
                addToTreasury(interaction.guildId, amount, 'donate');

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.donated(amount, cur))
                        .addFields({ name: lang === 'ar' ? 'رصيد المحفظة' : 'Wallet', value: `${user.wallet.toLocaleString()} ${cur}` })
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })
                    ]
                });
            }

            // ── withdraw (admin) ─────────────────────────────────────────────────
            if (sub === 'withdraw') {
                if (!interaction.member?.permissions?.has(PermissionFlagsBits.ManageGuild)) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription('❌ ' + (lang === 'ar' ? 'هذا الأمر للمسؤولين فقط.' : 'This command is for admins only.')).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                const amount    = interaction.options.getInteger('amount');
                const recipient = interaction.options.getUser('user') || interaction.user;
                const success   = withdrawFromTreasury(interaction.guildId, amount);

                if (!success) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.insufficientT).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                const recipUser   = getUser(interaction.guildId, recipient.id);
                recipUser.wallet  = (recipUser.wallet || 0) + amount;
                recipUser.totalEarned = (recipUser.totalEarned || 0) + amount;
                saveUser(interaction.guildId, recipient.id, recipUser);

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.withdrawn(amount, cur))
                        .addFields({ name: lang === 'ar' ? 'المستلم' : 'Recipient', value: `<@${recipient.id}>`, inline: true })
                        .setColor('#5865F2')
                        .setFooter({ text: t.footer })
                    ]
                });
            }

        } catch (err) {
            console.error('[treasury] unexpected error:', err);
            const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
