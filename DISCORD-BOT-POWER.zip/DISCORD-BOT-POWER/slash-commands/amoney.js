const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:  '⚠️ نظام الاقتصاد معطل حالياً.',
        add:       (amount, cur, name, field) => `✅ تم إضافة **${amount.toLocaleString()} ${cur}** إلى **${name}** (${field}).`,
        remove:    (amount, cur, name, field) => `✅ تم حذف **${amount.toLocaleString()} ${cur}** من **${name}** (${field}).`,
        set:       (amount, cur, name, field) => `✅ تم تحديد رصيد **${name}** (${field}) إلى **${amount.toLocaleString()} ${cur}**.`,
        transfer:  (from, to, amount, cur) => `✅ تم تحويل **${amount.toLocaleString()} ${cur}** من **${from}** إلى **${to}**.`,
        wallet:    '💰 المحفظة',
        bank:      '🏦 البنك',
        fieldWallet: 'المحفظة',
        fieldBank:   'البنك',
        footer:    'إدارة الاقتصاد'
    },
    en: {
        disabled:  '⚠️ Economy system is currently disabled.',
        add:       (amount, cur, name, field) => `✅ Added **${amount.toLocaleString()} ${cur}** to **${name}**'s ${field}.`,
        remove:    (amount, cur, name, field) => `✅ Removed **${amount.toLocaleString()} ${cur}** from **${name}**'s ${field}.`,
        set:       (amount, cur, name, field) => `✅ Set **${name}**'s ${field} to **${amount.toLocaleString()} ${cur}**.`,
        transfer:  (from, to, amount, cur) => `✅ Transferred **${amount.toLocaleString()} ${cur}** from **${from}** to **${to}**.`,
        wallet:    '💰 Wallet',
        bank:      '🏦 Bank',
        fieldWallet: 'Wallet',
        fieldBank:   'Bank',
        footer:    'Economy Management'
    }
};

module.exports = {
    data: {
        name: 'amoney',
        description: 'Admin: Manage member balances | إدارة: التحكم بأرصدة الأعضاء',
        default_member_permissions: '8',
        options: [
            {
                name: 'add',
                description: 'Add coins to a member | أضف عملات لعضو',
                type: 1,
                options: [
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true },
                    { name: 'amount', description: 'Amount | المبلغ', type: 4, required: true, min_value: 1 },
                    { name: 'wallet', description: 'Wallet or bank | محفظة أو بنك', type: 3, required: false,
                      choices: [{ name: 'Wallet', value: 'wallet' }, { name: 'Bank', value: 'bank' }] }
                ]
            },
            {
                name: 'remove',
                description: 'Remove coins from a member | احذف عملات من عضو',
                type: 1,
                options: [
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true },
                    { name: 'amount', description: 'Amount | المبلغ', type: 4, required: true, min_value: 1 },
                    { name: 'wallet', description: 'Wallet or bank | محفظة أو بنك', type: 3, required: false,
                      choices: [{ name: 'Wallet', value: 'wallet' }, { name: 'Bank', value: 'bank' }] }
                ]
            },
            {
                name: 'set',
                description: 'Set a member\'s balance | حدد رصيد عضو',
                type: 1,
                options: [
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true },
                    { name: 'amount', description: 'New balance | الرصيد الجديد', type: 4, required: true, min_value: 0 },
                    { name: 'wallet', description: 'Wallet or bank | محفظة أو بنك', type: 3, required: false,
                      choices: [{ name: 'Wallet', value: 'wallet' }, { name: 'Bank', value: 'bank' }] }
                ]
            },
            {
                name: 'balance',
                description: 'Check a member\'s balance | فحص رصيد عضو',
                type: 1,
                options: [
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                ]
            },
            {
                name: 'transfer',
                description: 'Transfer coins between members | حول عملات بين أعضاء',
                type: 1,
                options: [
                    { name: 'from', description: 'From member | من العضو', type: 6, required: true },
                    { name: 'to', description: 'To member | إلى العضو', type: 6, required: true },
                    { name: 'amount', description: 'Amount | المبلغ', type: 4, required: true, min_value: 1 }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const sub = interaction.options.getSubcommand();
        const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        if (sub === 'add') {
            const target    = interaction.options.getUser('user');
            const amount    = interaction.options.getInteger('amount');
            const field     = interaction.options.getString('wallet') || 'wallet';
            const fieldLabel = field === 'bank' ? t.fieldBank : t.fieldWallet;
            const data = getUser(interaction.guildId, target.id);
            data[field] = (data[field] || 0) + amount;
            if (field === 'wallet') data.totalEarned = (data.totalEarned || 0) + amount;
            saveUser(interaction.guildId, target.id, data);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.add(amount, cur, target.username, fieldLabel))
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        if (sub === 'remove') {
            const target    = interaction.options.getUser('user');
            const amount    = interaction.options.getInteger('amount');
            const field     = interaction.options.getString('wallet') || 'wallet';
            const fieldLabel = field === 'bank' ? t.fieldBank : t.fieldWallet;
            const data = getUser(interaction.guildId, target.id);
            data[field] = Math.max((data[field] || 0) - amount, 0);
            saveUser(interaction.guildId, target.id, data);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.remove(amount, cur, target.username, fieldLabel))
                    .setColor('#ED4245').setFooter({ text: t.footer })]
            });
        }

        if (sub === 'set') {
            const target    = interaction.options.getUser('user');
            const amount    = interaction.options.getInteger('amount');
            const field     = interaction.options.getString('wallet') || 'wallet';
            const fieldLabel = field === 'bank' ? t.fieldBank : t.fieldWallet;
            const data = getUser(interaction.guildId, target.id);
            data[field] = amount;
            saveUser(interaction.guildId, target.id, data);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.set(amount, cur, target.username, fieldLabel))
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        if (sub === 'balance') {
            const target = interaction.options.getUser('user');
            const data   = getUser(interaction.guildId, target.id);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(`💰 ${target.username}`)
                    .setColor('#5865F2')
                    .addFields(
                        { name: t.wallet, value: `${(data.wallet || 0).toLocaleString()} ${cur}`, inline: true },
                        { name: t.bank,   value: `${(data.bank   || 0).toLocaleString()} ${cur}`, inline: true }
                    )
                    .setFooter({ text: t.footer })]
            });
        }

        if (sub === 'transfer') {
            const from   = interaction.options.getUser('from');
            const to     = interaction.options.getUser('to');
            const amount = interaction.options.getInteger('amount');
            const fromData = getUser(interaction.guildId, from.id);
            const toData   = getUser(interaction.guildId, to.id);
            fromData.wallet = Math.max((fromData.wallet || 0) - amount, 0);
            toData.wallet   = (toData.wallet || 0) + amount;
            toData.totalEarned = (toData.totalEarned || 0) + amount;
            saveUser(interaction.guildId, from.id, fromData);
            saveUser(interaction.guildId, to.id,   toData);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.transfer(from.username, to.username, amount, cur))
                    .setColor('#FEE75C').setFooter({ text: t.footer })]
            });
        }
    
      } catch (err) {
          console.error('[amoney] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
