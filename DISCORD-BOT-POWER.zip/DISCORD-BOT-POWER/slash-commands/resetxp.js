const { PermissionFlagsBits, MessageFlags, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

function loadLevelData() {
    const p = path.join(__dirname, '../levelData.json');
    if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch(e) { return {}; }
    }
    return {};
}

function saveLevelData(data) {
    const p = path.join(__dirname, '../levelData.json');
    fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
}

// ── Translations ─────────────────────────────────────────────────────────────
const T = {
    ar: {
        disabled:        '⚠️ هذا الأمر معطل حالياً.',
        notFound:        '❌ العضو غير موجود في السيرفر.',
        title:           '✅ تمت إعادة الضبط بنجاح',
        description:     (name) => `تمت إعادة ضبط XP والمستويات لـ **${name}** بنجاح.`,
        fieldAffected:   'البيانات المتأثرة',
        affectedValue:   '• XP الشات والمستويات\n• XP الصوت والمستويات',
        fieldTarget:     'العضو المستهدف',
        error:           (msg) => `❌ حدث خطأ: ${msg || 'خطأ غير معروف'}`
    },
    en: {
        disabled:        '⚠️ This command is currently disabled.',
        notFound:        '❌ Member not found in the server.',
        title:           '✅ Reset Successful',
        description:     (name) => `Successfully reset XP and levels for **${name}**.`,
        fieldAffected:   'Affected Data',
        affectedValue:   '• Chat XP and Levels\n• Voice XP and Levels',
        fieldTarget:     'Target User',
        error:           (msg) => `❌ Error: ${msg || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'reset',
        description: '🔄 Reset XP and levels for a member | إعادة ضبط XP ومستوى عضو',
        default_member_permissions: PermissionFlagsBits.Administrator.toString(),
        options: [
            {
                name: 'user',
                description: 'The member to reset | العضو المراد إعادة ضبطه',
                type: 6,
                required: true
            }
        ]
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const isAr = settings.botLanguage === 'ar';
            const t    = isAr ? T.ar : T.en;

            if (commandConfig && !commandConfig.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }

            const targetUser   = interaction.options.getUser('user');

            if (!targetUser) {
                return await interaction.editReply({ content: t.notFound });
            }

            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

            if (!targetMember) {
                return await interaction.editReply({ content: t.notFound });
            }

            // ── Reset data ────────────────────────────────────────────────
            const levelData = loadLevelData();
            levelData[targetUser.id] = {
                chatXP:    0,
                voiceXP:   0,
                chatLevel:  0,
                voiceLevel: 0
            };
            saveLevelData(levelData);

            // ── Build embed ───────────────────────────────────────────────
            const memberName = targetMember.displayName || targetUser.username;

            const now     = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
            const todayStr = isAr ? `اليوم الساعة ${timeStr}` : `Today at ${timeStr}`;

            const embed = new EmbedBuilder()
                .setColor('#57F287')
                .setTitle(t.title)
                .setDescription(t.description(memberName))
                .addFields(
                    {
                        name:  t.fieldAffected,
                        value: t.affectedValue
                    },
                    {
                        name:  t.fieldTarget,
                        value: memberName
                    },
                    {
                        name:  '\u200b',
                        value: `**${todayStr}**`
                    }
                );

            await interaction.editReply({ embeds: [embed] });

            if (commandConfig && commandConfig.deleteResponse) {
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 10000);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر /reset:', error.message);
            const isAr = settings?.botLanguage === 'ar';
            const errMsg = isAr
                ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                : `❌ Error: ${error.message || 'Unknown error'}`;
            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ content: errMsg });
                } else {
                    await interaction.reply({ content: errMsg, flags: MessageFlags.Ephemeral });
                }
            } catch(e) {}
        }
    }
};
