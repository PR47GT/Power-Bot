const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'إخفاء الروم عن الأعضاء',
        option_channel: 'الروم (اختياري)',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرومات',
        failed: '❌ فشل إخفاء الروم:',
        success: (channel) => `👁️ تم إخفاء ${channel}`,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Hide a channel from members',
        option_channel: 'Channel (optional)',
        disabled: '⚠️ This command is currently disabled.',
        botNoPerm: '❌ Bot does not have permission to manage channels',
        failed: '❌ Failed to hide channel:',
        success: (channel) => `👁️ ${channel} has been hidden`,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'hide',
        description: 'Hide channel | إخفاء روم',
        default_member_permissions: PermissionFlagsBits.ManageChannels.toString(),
        options: [
            { 
                name: 'channel', 
                description: 'Channel', 
                type: 7, 
                required: false 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.hide || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const channel = interaction.options.getChannel('channel') || interaction.channel;
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageChannels)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            try {
                await channel.permissionOverwrites.edit(interaction.guild.id, {
                    ViewChannel: false
                });
            } catch (error) {
                return await interaction.editReply({ 
                    content: `${t.failed} ${error.message}`
                });
            }
            
            const successMessage = t.success(channel);
            
            if (config.deleteResponse) {
                await interaction.editReply({ content: successMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }
            
        } catch (error) {
            console.error('❌ Hide command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};