const { ChannelType } = require('discord.js');

const VERIFICATION = {
    ar: ['بدون', 'منخفض', 'متوسط', 'عالي', 'عالي جداً'],
    en: ['None', 'Low', 'Medium', 'High', 'Very High'],
};

const T = {
    ar: {
        id:          'معرف السيرفر',
        ownedBy:     'المالك',
        members:     (n) => `الأعضاء (${n})`,
        membersVal:  (online) => `**${online}** متصل`,
        channels:    (n) => `الرومات (${n})`,
        channelsVal: (text, voice, categories) => `**${text}** نصي | **${voice}** صوتي | **${categories}** تصنيف`,
        others:      'مستوى التحقق',
        othersVal:   (lvl) => `**${lvl}**`,
        roles:       (n) => `الرتب (${n})`,
        rolesVal:    (name) => `أعلى رتبة: ${name}`,
        emojis:      'الإيموجي / الستيكرز',
        emojisVal:   (e, s) => `**${e}** إيموجي | **${s}** ستيكر`,
        boost:       'مستوى البوست',
        boostVal:    (tier, bar, count) => `المستوى **${tier}**  ${bar}\n**${count}** بوست`,
        locale:      'اللغة',
    },
    en: {
        id:          'Server ID',
        ownedBy:     'Owned by',
        members:     (n) => `Members (${n})`,
        membersVal:  (online) => `**${online}** Online`,
        channels:    (n) => `Channels (${n})`,
        channelsVal: (text, voice, categories) => `**${text}** Text | **${voice}** Voice | **${categories}** Categories`,
        others:      'Verification Level',
        othersVal:   (lvl) => `**${lvl}**`,
        roles:       (n) => `Roles (${n})`,
        rolesVal:    (name) => `Top Role: ${name}`,
        emojis:      'Emojis / Stickers',
        emojisVal:   (e, s) => `**${e}** Emojis | **${s}** Stickers`,
        boost:       'Boost Level',
        boostVal:    (tier, bar, count) => `Level **${tier}**  ${bar}\n**${count}** Boosts`,
        locale:      'Language',
    },
};

module.exports = {
    name: 'server',
    description: 'معلومات عن السيرفر | Server information',

    async execute(interaction, client, settings, commandConfig) {
        await interaction.deferReply();

        const { guild } = interaction;
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];

        const owner = await guild.fetchOwner().catch(() => null);

        // ── Member counts ───────────────────────────────────────────────────
        const memberCount = guild.memberCount;
        const boostCount  = guild.premiumSubscriptionCount || 0;
        const boostTier   = guild.premiumTier ?? 0; // 0-3
        const onlineCount = guild.members.cache.filter(m =>
            m.presence && ['online', 'idle', 'dnd'].includes(m.presence.status)
        ).size;

        // ── Channel counts ──────────────────────────────────────────────────
        const channels      = guild.channels.cache;
        const textCount     = channels.filter(c => [
            ChannelType.GuildText,
            ChannelType.GuildAnnouncement,
            ChannelType.GuildForum,
            ChannelType.GuildMedia,
        ].includes(c.type)).size;
        const voiceCount    = channels.filter(c => [
            ChannelType.GuildVoice,
            ChannelType.GuildStageVoice,
        ].includes(c.type)).size;
        const categoryCount = channels.filter(c => c.type === ChannelType.GuildCategory).size;
        const totalChannels = textCount + voiceCount;

        // ── Extra info ─────────────────────────────────────────────────────
        const roleCount    = guild.roles.cache.size - 1; // exclude @everyone
        const emojiCount   = guild.emojis.cache.size;
        const stickerCount = guild.stickers.cache.size;
        const verifyLevel  = VERIFICATION[lang][guild.verificationLevel] ?? guild.verificationLevel;

        // Highest role in the server (excluding @everyone)
        const topRole = guild.roles.cache
            .filter(r => r.id !== guild.id)
            .sort((a, b) => b.position - a.position)
            .first();
        const topRoleValue = topRole ? `<@&${topRole.id}>` : '—';

        const boostBar = '■'.repeat(boostTier) + '□'.repeat(3 - boostTier);

        // ── Embed ──────────────────────────────────────────────────────────
        const embed = {
            color: 0x5865F2,
            author: {
                name:     guild.name,
                icon_url: guild.iconURL({ dynamic: true, size: 128 }) ?? undefined,
            },
            description: guild.description
                ? `*${guild.description}*`
                : undefined,
            thumbnail: { url: guild.iconURL({ dynamic: true, size: 1024 }) ?? undefined },
            image: guild.bannerURL({ size: 1024 }) ? { url: guild.bannerURL({ size: 1024 }) } : undefined,
            fields: [
                { name: t.id,      value: `\`${guild.id}\``,              inline: true },
                { name: t.ownedBy, value: owner ? `<@${owner.id}>` : '—', inline: true },
                { name: t.roles(roleCount), value: t.rolesVal(topRoleValue), inline: true },

                { name: t.members(memberCount),    value: t.membersVal(onlineCount),                           inline: true },
                { name: t.channels(totalChannels), value: t.channelsVal(textCount, voiceCount, categoryCount), inline: true },
                { name: t.others,                  value: t.othersVal(verifyLevel),                            inline: true },

                { name: t.boost,   value: t.boostVal(boostTier, boostBar, boostCount),      inline: true },
                { name: t.emojis,  value: t.emojisVal(emojiCount, stickerCount),            inline: true },
                { name: t.locale,  value: `**${guild.preferredLocale ?? '—'}**`,            inline: true },
            ],
            footer: {
                text:     owner ? owner.user.tag : guild.name,
                icon_url: owner ? owner.user.displayAvatarURL({ dynamic: true, size: 128 }) : undefined,
            },
        };

        await interaction.editReply({ embeds: [embed] });

        if (commandConfig?.deleteResponse) {
            setTimeout(async () => {
                try { await interaction.deleteReply(); } catch (e) {}
            }, 5000);
        }
    },
};