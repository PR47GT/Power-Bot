const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, addEconXP, XP_SOURCES, addUserStat, updateQuestProgress, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:  '⚠️ نظام الاقتصاد معطل حالياً.',
        cooldown:  (time) => `⏰ يمكنك استلام الجائزة اليومية مرة أخرى بعد **${time}**.`,
        received:  (amount, cur) => `💎 استلمت جائزتك اليومية: **${amount.toLocaleString()} ${cur}**.`,
        streak:    (n) => `🔥 سلسلة ${n} أيام متتالية!`,
        bonus:     (pct) => `✨ مكافأة السلسلة: +${pct}%`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **مبروك! ارتقيت للمستوى ${lvl}!**${reward > 0 ? `\n🎁 مكافأة: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:   'رصيدك الحالي',
        xpGained:  (n) => `+${n} XP`,
        footer:    'الجائزة اليومية'
    },
    en: {
        disabled:  '⚠️ Economy system is currently disabled.',
        cooldown:  (time) => `⏰ You can claim your daily reward again in **${time}**.`,
        received:  (amount, cur) => `💎 You've received your daily reward: **${amount.toLocaleString()} ${cur}**.`,
        streak:    (n) => `🔥 ${n}-day streak!`,
        bonus:     (pct) => `✨ Streak bonus: +${pct}%`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **Level up! You reached Level ${lvl}!**${reward > 0 ? `\n🎁 Reward: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:   'Your Balance',
        xpGained:  (n) => `+${n} XP`,
        footer:    'Daily Reward'
    }
};

function formatRemaining(ms, lang) {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    if (lang === 'ar') return `${h} ساعة و ${m} دقيقة`;
    return `${h}h ${m}m`;
}

function isSameDay(ts1, ts2) {
    const d1 = new Date(ts1);
    const d2 = new Date(ts2);
    return d1.getFullYear() === d2.getFullYear() &&
           d1.getMonth()    === d2.getMonth()    &&
           d1.getDate()     === d2.getDate();
}

function isYesterday(ts, now) {
    const yesterday = now - 86400000;
    return isSameDay(ts, yesterday);
}

module.exports = {
    data: {
        name: 'daily',
        description: 'Claim your daily reward | استلم جائزتك اليومية',
        default_member_permissions: null,
        options: []
    },

    async execute(interaction, client, settings) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const user       = getUser(interaction.guildId, interaction.user.id);
        const cur        = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        const dailyCfg   = es.daily || {};
        const cooldownMs = (dailyCfg.cooldown || 24) * 3600000;
        const now        = Date.now();

        if (user.lastDaily && now - user.lastDaily < cooldownMs) {
            const remaining = cooldownMs - (now - user.lastDaily);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.cooldown(formatRemaining(remaining, lang)))
                    .setColor('#FEE75C')],
                flags: MessageFlags.Ephemeral
            });
        }

        // 1. حساب المبلغ الأساسي
        const min = dailyCfg.min || 100;
        const max = dailyCfg.max || 500;
        let amount = Math.floor(Math.random() * (max - min + 1)) + min;

        // 2. حساب الـ streak ومضاعفه
        let streak = user.dailyStreak || 0;
        if (user.lastDaily && isYesterday(user.lastDaily, now)) {
            streak = Math.min(streak + 1, dailyCfg.streakCap || 30);
        } else if (!user.lastDaily || !isYesterday(user.lastDaily, now)) {
            streak = 1;
        }

        const streakBonus = dailyCfg.streakBonus || 1.05;
        const streakPct   = Math.round(((Math.pow(streakBonus, streak - 1)) - 1) * 100);
        const bonusMulti  = Math.pow(streakBonus, streak - 1);
        amount            = Math.floor(amount * bonusMulti);

        // 3. تطبيق تأثير Daily Boost (بعد حساب المبلغ والـ streak)
        const dailyBoost = (user.activeEffects || []).find(
            e => e.effect === 'daily_boost' && e.expires > now
        );
        if (dailyBoost) amount = Math.floor(amount * (parseFloat(dailyBoost.multiplier) || 1));

        user.wallet      = (user.wallet      || 0) + amount;
        user.totalEarned = (user.totalEarned || 0) + amount;
        user.lastDaily   = now;
        user.dailyStreak = streak;
        saveUser(interaction.guildId, interaction.user.id, user);
        addTransaction(interaction.guildId, interaction.user.id, 'daily', amount, `streak:${streak}`);

        // ── XP & Stats ────────────────────────────────────────────────────────
        const xpAmount = XP_SOURCES.daily;
        const xpResult = addEconXP(interaction.guildId, interaction.user.id, xpAmount);

        // ── Quest progress ────────────────────────────────────────────────────
        updateQuestProgress(interaction.guildId, interaction.user.id, 'daily_claim', 1);
        updateQuestProgress(interaction.guildId, interaction.user.id, 'earn_coins', amount);

        // ── Level-up suffix ───────────────────────────────────────────────────
        let levelSuffix = '';
        if (xpResult.leveled) {
            // ── [FIX] Read level reward from config, not wallet diff ──
            const _lvlSettings = loadEconomySettings();
            const _lvlRewards  = _lvlSettings?.levelRewards || [];
            let   _lvlReward   = 0;
            for (let _l = xpResult.oldLevel + 1; _l <= xpResult.newLevel; _l++) {
                const _r = _lvlRewards.find(x => x.level === _l);
                if (_r && _r.reward > 0) _lvlReward += _r.reward;
            }
            levelSuffix = t.levelUp(xpResult.newLevel, _lvlReward, cur);
        }

        const refreshedUser = getUser(interaction.guildId, interaction.user.id);
        const fields = [
            { name: t.balance,  value: `${refreshedUser.wallet.toLocaleString()} ${cur}` },
            { name: '⭐ XP',    value: t.xpGained(xpAmount), inline: true }
        ];
        if (streak > 1) {
            fields.push({ name: t.streak(streak), value: t.bonus(streakPct), inline: true });
        }

        const embed = new EmbedBuilder()
            
            .setDescription(t.received(amount, cur) + levelSuffix)
            .setColor('#57F287')
            .addFields(fields)
            .setFooter({ text: t.footer })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // ── Channel Reminder ──────────────────────────────────────────────────
        const MAX_REMINDER_MS = 7_200_000;
        if (cooldownMs > 0 && cooldownMs <= MAX_REMINDER_MS && es.reminderChannelId) { // [FIX-DAILY-01]
            setTimeout(async () => {
                try {
                    const ch = await client.channels.fetch(es.reminderChannelId).catch(() => null);
                    if (ch) {
                        const text = lang === 'ar'
                            ? `💎 <@${interaction.user.id}> جائزتك اليومية جاهزة! استخدم </daily:0> الآن!\n🔥 سلسلتك: **${user.dailyStreak} يوم**`
                            : `💎 <@${interaction.user.id}> Your daily reward is ready! Use </daily:0> now!\n🔥 Streak: **${user.dailyStreak} days**`;
                        await ch.send(text).catch(() => {});
                    }
                } catch (_) {}
            }, cooldownMs);
        } else if (cooldownMs > 0 && cooldownMs <= MAX_REMINDER_MS && user.notifications?.daily !== false) {
            setTimeout(async () => {
                try {
                    const dmUser = await client.users.fetch(interaction.user.id).catch(() => null);
                    if (dmUser) {
                        const text = lang === 'ar'
                            ? `💎 **تنبيه المكافأة اليومية!**\nيمكنك المطالبة بمكافأتك الآن عبر </daily:0>!\n🔥 سلسلتك: **${user.dailyStreak} يوم**`
                            : `💎 **Daily Reminder!**\nYour daily reward is ready! Use </daily:0> now!\n🔥 Streak: **${user.dailyStreak} days**`;
                        await dmUser.send(text).catch(() => {});
                    }
                } catch (_) {}
            }, cooldownMs);
        }
    }
};