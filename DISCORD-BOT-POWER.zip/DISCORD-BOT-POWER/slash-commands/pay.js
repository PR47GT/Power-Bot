const { EmbedBuilder, MessageFlags } = require('discord.js');
const {
    getUser, saveUser, cooldownLeft, formatTime,
    addToTreasury, addTransaction, withTwoUserLocks
} = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        payOff:     '⚠️ التحويل بين الأعضاء معطل حالياً.',
        selfPay:    '❌ لا يمكنك التحويل لنفسك.',
        noMoney:    (amount, cur) => `❌ لا تملك **${amount.toLocaleString()} ${cur}** في محفظتك.`,
        belowMin:   (min, cur)  => `❌ الحد الأدنى للتحويل هو **${min.toLocaleString()} ${cur}**.`,
        aboveMax:   (max, cur)  => `❌ الحد الأقصى للتحويل هو **${max.toLocaleString()} ${cur}**.`,
        cooldown:   (time) => `⏰ يمكنك التحويل مرة أخرى بعد **${time}**.`,
        balance:    'رصيدك',
        footer:     (user) => `💸 تحويل بواسطة ${user}`,
        // Success fields
        sentLabel:     '📤 المبلغ المُرسَل',
        taxLabel:      '🏦 الضريبة',
        receivedLabel: '📥 وصل للمُستقبِل',
        toLabel:       '👤 المُستقبِل',
        balanceLabel:  '💰 رصيدك الحالي',
        successTitle:  '✅ تم التحويل بنجاح',
        noTaxLabel:    'بدون ضريبة',
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        payOff:     '⚠️ Pay transfer is currently disabled.',
        selfPay:    '❌ You cannot pay yourself.',
        noMoney:    (amount, cur) => `❌ You don't have **${amount.toLocaleString()} ${cur}** in your wallet.`,
        belowMin:   (min, cur)  => `❌ Minimum transfer is **${min.toLocaleString()} ${cur}**.`,
        aboveMax:   (max, cur)  => `❌ Maximum transfer is **${max.toLocaleString()} ${cur}**.`,
        cooldown:   (time) => `⏰ You can transfer again in **${time}**.`,
        balance:    'Your Balance',
        footer:     (user) => `💸 Transfer by ${user}`,
        // Success fields
        sentLabel:     '📤 Amount Sent',
        taxLabel:      '🏦 Tax',
        receivedLabel: '📥 Received',
        toLabel:       '👤 Recipient',
        balanceLabel:  '💰 Your Balance',
        successTitle:  '✅ Transfer Successful',
        noTaxLabel:    'No Tax',
    }
};

module.exports = {
    data: {
        name: 'pay',
        description: 'Transfer coins to another member | تحويل عملات لعضو آخر',
        default_member_permissions: null,
        options: [
            { name: 'user',   description: 'Member to pay | العضو', type: 6, required: true },
            { name: 'amount', description: 'Amount | المبلغ',        type: 4, required: true, min_value: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const payCfg = es.pay || {};
            if (payCfg.enabled === false) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.payOff).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const target = interaction.options.getUser('user');
            const amount = interaction.options.getInteger('amount');
            const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            if (target.id === interaction.user.id) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.selfPay).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const minPay = payCfg.min || 1;
            const maxPay = payCfg.max || 0;
            if (amount < minPay) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.belowMin(minPay, cur)).setColor('#FEE75C')],
                    flags: MessageFlags.Ephemeral
                });
            }
            if (maxPay > 0 && amount > maxPay) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.aboveMax(maxPay, cur)).setColor('#FEE75C')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const cooldownMs = (payCfg.cooldown || 0) * 60000;

            let replyPayload;
            await withTwoUserLocks(interaction.guildId, interaction.user.id, target.id, async () => {
                const user = getUser(interaction.guildId, interaction.user.id);

                if (cooldownMs > 0) {
                    const left = cooldownLeft(user.lastPay, cooldownMs);
                    if (left > 0) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.cooldown(formatTime(left))).setColor('#FEE75C')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                }

                if ((user.wallet || 0) < amount) {
                    replyPayload = {
                        embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    };
                    return;
                }

                const taxRate  = payCfg.tax || 0;
                const tax      = Math.floor(amount * (taxRate / 100));
                const net      = amount - tax;

                user.wallet = (user.wallet || 0) - amount;
                if (cooldownMs > 0) user.lastPay = Date.now();
                saveUser(interaction.guildId, interaction.user.id, user);

                const targetData = getUser(interaction.guildId, target.id);
                targetData.wallet      = (targetData.wallet      || 0) + net;
                targetData.totalEarned = (targetData.totalEarned || 0) + net;
                saveUser(interaction.guildId, target.id, targetData);

                if (es.treasuryEnabled && tax > 0) addToTreasury(interaction.guildId, tax, 'pay_tax');
                addTransaction(interaction.guildId, interaction.user.id, 'pay_sent',     -amount, `To ${target.username}`);
                addTransaction(interaction.guildId, target.id,           'pay_received',  net,    `From ${interaction.user.username}`);

                // ✅ Embed احترافي ومنظم
                const embed = new EmbedBuilder()
                    .setTitle(t.successTitle)
                    .setColor('#57F287')
                    .setThumbnail(target.displayAvatarURL({ dynamic: true, size: 128 }))
                    .addFields(
                        {
                            name: t.toLabel,
                            value: `<@${target.id}>`,
                            inline: true
                        },
                        {
                            name: t.sentLabel,
                            value: `**${amount.toLocaleString()}** ${cur}`,
                            inline: true
                        },
                        {
                            name: '\u200b',
                            value: '\u200b',
                            inline: true
                        },
                        {
                            name: t.taxLabel,
                            value: tax > 0
                                ? `**${tax.toLocaleString()}** ${cur} (${taxRate}%)`
                                : `*${t.noTaxLabel}*`,
                            inline: true
                        },
                        {
                            name: t.receivedLabel,
                            value: `**${net.toLocaleString()}** ${cur}`,
                            inline: true
                        },
                        {
                            name: '\u200b',
                            value: '\u200b',
                            inline: true
                        },
                        {
                            name: t.balanceLabel,
                            value: `**${user.wallet.toLocaleString()}** ${cur}`,
                            inline: false
                        }
                    )
                    .setFooter({
                        text: t.footer(interaction.user.username),
                        iconURL: interaction.user.displayAvatarURL({ dynamic: true })
                    })
                    .setTimestamp();

                replyPayload = { embeds: [embed] };
            });

            return interaction.reply(replyPayload);

        } catch (err) {
            console.error('[pay] unexpected error', {
                guildId: interaction.guildId,
                userId:  interaction.user.id,
                amount:  interaction.options.getInteger?.('amount'),
                error:   err.message
            });
            const _errEmbed  = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};