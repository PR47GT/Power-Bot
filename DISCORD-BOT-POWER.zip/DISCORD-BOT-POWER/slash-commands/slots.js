const {
    AttachmentBuilder,
    EmbedBuilder,
    MessageFlags,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder
} = require('discord.js');
const { getUser, saveUser, cooldownLeft, formatTime, addTransaction , withUserLock } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

let canvasApi = null;
try {
    canvasApi = require('@napi-rs/canvas');
} catch (_) {
    canvasApi = null;
}

const SPIN_AGAIN_TIMEOUT = 60_000;

const SYMBOLS = [
    { emoji: '🍒', label: 'Cherry',  color: '#ef4444', weight: 30, multiplier: 2 },
    { emoji: '🍋', label: 'Lemon',   color: '#facc15', weight: 25, multiplier: 3 },
    { emoji: '🍊', label: 'Orange',  color: '#fb923c', weight: 20, multiplier: 4 },
    { emoji: '🍇', label: 'Grapes',  color: '#a855f7', weight: 15, multiplier: 6 },
    { emoji: '🔔', label: 'Bell',    color: '#f59e0b', weight: 6,  multiplier: 10 },
    { emoji: '⭐', label: 'Star',    color: '#fde047', weight: 3,  multiplier: 25 },
    { emoji: '💎', label: 'Diamond', color: '#38bdf8', weight: 1,  multiplier: 100 }
];

const TOTAL_WEIGHT = SYMBOLS.reduce((sum, symbol) => sum + symbol.weight, 0);

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        slotOff: '⚠️ الآلة القمارية معطلة حالياً.',
        noMoney: (n, c) => `❌ رصيدك غير كافٍ. تحتاج **${n.toLocaleString()} ${c}**.`,
        minBet: (n, c) => `❌ الحد الأدنى للرهان **${n.toLocaleString()} ${c}**.`,
        maxBet: (n, c) => `❌ الحد الأقصى للرهان **${n.toLocaleString()} ${c}**.`,
        jackpot: (n, c) => `💥 **JACKPOT!** ربحت **${n.toLocaleString()} ${c}**!`,
        win: (n, c) => `🎰 فزت وربحت **${n.toLocaleString()} ${c}**!`,
        smallWin: (n, c) => `🎰 ربح صغير! +**${n.toLocaleString()} ${c}**`,
        lose: (n, c) => `🎰 حظاً أوفر! خسرت **${n.toLocaleString()} ${c}**.`,
        capped: (n, c) => `تم تحديد الجائزة عند **${n.toLocaleString()} ${c}** لحماية الاقتصاد.`,
        balance: 'الرصيد',
        bet: 'الرهان',
        payout: 'الجائزة',
        net: 'الصافي',
        result: 'النتيجة',
        spinning: 'تدور البكرات...',
        spinAgain: 'Spin Again',
        paytable: 'Paytable',
        help: 'How to Play?',
        helpTitle: 'طريقة لعب Slots',
        helpDescription:
            '**الهدف:** احصل على رموز متطابقة لربح مضاعفات من رهانك.\n\n' +
            '**3 رموز متطابقة:** تربح المضاعف الكامل.\n' +
            '**رمزان متطابقان:** تربح نصف مضاعف الرمز تقريباً.\n' +
            '**Spin Again:** يعيد اللعب بنفس الرهان إذا كان رصيدك كافياً.\n\n' +
            'كلما كان الرمز أندر، كانت جائزته أعلى.',
        paytableTitle: 'جدول الجوائز',
        notYou: '❌ هذه الأزرار ليست لك.',
        footer: 'Slot Machine'
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        slotOff: '⚠️ Slots are currently disabled.',
        noMoney: (n, c) => `❌ Insufficient balance. Need **${n.toLocaleString()} ${c}**.`,
        minBet: (n, c) => `❌ Minimum bet is **${n.toLocaleString()} ${c}**.`,
        maxBet: (n, c) => `❌ Maximum bet is **${n.toLocaleString()} ${c}**.`,
        jackpot: (n, c) => `💥 **JACKPOT!** You won **${n.toLocaleString()} ${c}**!`,
        win: (n, c) => `🎰 Winner! You won **${n.toLocaleString()} ${c}**!`,
        smallWin: (n, c) => `🎰 Small win! +**${n.toLocaleString()} ${c}**`,
        lose: (n, c) => `🎰 Better luck next time! Lost **${n.toLocaleString()} ${c}**.`,
        capped: (n, c) => `Payout was capped at **${n.toLocaleString()} ${c}** to protect the economy.`,
        balance: 'Balance',
        bet: 'Bet',
        payout: 'Payout',
        net: 'Net',
        result: 'Result',
        spinning: 'The reels are spinning...',
        spinAgain: 'Spin Again',
        paytable: 'Paytable',
        help: 'How to Play?',
        helpTitle: 'How to Play Slots',
        helpDescription:
            '**Goal:** Match symbols to win multipliers from your bet.\n\n' +
            '**3 matching symbols:** pays the full multiplier.\n' +
            '**2 matching symbols:** pays roughly half of the symbol multiplier.\n' +
            '**Spin Again:** repeats the same bet if you have enough balance.\n\n' +
            'Rarer symbols pay bigger rewards.',
        paytableTitle: 'Paytable',
        notYou: '❌ These buttons are not for you.',
        footer: 'Slot Machine'
    }
};

function clamp(value, min, max) {
    return Math.min(Math.max(value, min), max);
}

function cleanCurrency(cur) {
    return String(cur)
        .replace(/<a?:[a-zA-Z0-9_]+:\d+>/g, '')
        .replace(/\s+/g, ' ')
        .trim() || 'Coins';
}

function spinReel() {
    let roll = Math.random() * TOTAL_WEIGHT;
    for (const symbol of SYMBOLS) {
        roll -= symbol.weight;
        if (roll <= 0) return { ...symbol };
    }
    return { ...SYMBOLS[0] };
}

function spin() {
    return [spinReel(), spinReel(), spinReel()];
}

// [FIX-SLOTS-WINCHANCE]
// المشكلة القديمة: winChance كانت تعمل كـ "فلتر" فقط على الفوز الطبيعي —
// لم تكن تُقرر إذا الدورة تفوز أو تخسر، بل كانت تمنع الفوز الطبيعي النادر (~4%).
// النتيجة: winChance=100% لا يُعني أن كل دورة تفوز!
//
// الإصلاح: winChance هو القرار الأول (Primary Controller):
//   shouldWin = Math.random() * 100 < winChance
//   • إذا يجب الفوز   → اقبل الفوز الطبيعي أو أجبر 3 رموز متطابقة
//   • إذا يجب الخسارة → اكسر أي توافق طبيعي
//
// الآن: winChance=100 → كل دورة تفوز، winChance=0 → كل دورة تخسر
function evaluate(reels, bet, winChance, maxPayout = 0) {
    const chance    = clamp(Number(winChance) || 35, 0, 100);
    const shouldWin = Math.random() * 100 < chance;
    const miss      = { win: false, amount: 0, label: 'miss', capped: false };

    const [a, b, c] = reels;
    const has3Match  = a.emoji === b.emoji && b.emoji === c.emoji;
    const has2Match  = !has3Match && (a.emoji === b.emoji || b.emoji === c.emoji || a.emoji === c.emoji);

    if (!shouldWin) {
        // ── يجب الخسارة: اكسر أي توافق ──────────────────────────────────
        if (has3Match) {
            // غيّر البكرة الثالثة لتكسير التطابق
            reels[2] = spinReel();
            let safety = 0;
            while (reels[2].emoji === reels[0].emoji && safety++ < 20) reels[2] = spinReel();
        } else if (has2Match) {
            // أيّ رمزان متطابقان؟ غيّر أحدهما
            if (a.emoji === b.emoji) {
                reels[1] = spinReel();
                let safety = 0;
                while ((reels[1].emoji === reels[0].emoji || reels[1].emoji === reels[2].emoji) && safety++ < 20)
                    reels[1] = spinReel();
            } else if (b.emoji === c.emoji) {
                reels[2] = spinReel();
                let safety = 0;
                while ((reels[2].emoji === reels[1].emoji || reels[2].emoji === reels[0].emoji) && safety++ < 20)
                    reels[2] = spinReel();
            } else {
                reels[2] = spinReel();
                let safety = 0;
                while ((reels[2].emoji === reels[0].emoji || reels[2].emoji === reels[1].emoji) && safety++ < 20)
                    reels[2] = spinReel();
            }
        }
        return miss;
    }

    // ── يجب الفوز ─────────────────────────────────────────────────────────
    if (has3Match) {
        // فوز طبيعي بثلاثة رموز — استخدمه
        const result = {
            win:    true,
            amount: Math.floor(bet * a.multiplier),
            label:  a.multiplier >= 25 ? 'jackpot' : 'win',
            capped: false
        };
        if (maxPayout > 0 && result.amount > maxPayout) { result.amount = maxPayout; result.capped = true; }
        return result;
    }

    if (has2Match) {
        // فوز طبيعي برمزين — فوز صغير
        const matched = a.emoji === b.emoji ? a : (b.emoji === c.emoji ? b : a);
        const result  = {
            win:    true,
            amount: Math.floor(bet * Math.max(1, matched.multiplier * 0.5)),
            label:  'small',
            capped: false
        };
        if (maxPayout > 0 && result.amount > maxPayout) { result.amount = maxPayout; result.capped = true; }
        return result;
    }

    // لا يوجد توافق طبيعي لكن يجب الفوز → أجبر 3 رموز متطابقة
    const forced    = spinReel();
    reels[0] = reels[1] = reels[2] = { ...forced };
    const result = {
        win:    true,
        amount: Math.floor(bet * forced.multiplier),
        label:  forced.multiplier >= 25 ? 'jackpot' : 'win',
        capped: false
    };
    if (maxPayout > 0 && result.amount > maxPayout) { result.amount = maxPayout; result.capped = true; }
    return result;
}

function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
}

async function drawAvatar(ctx, user, x, y, size) {
    if (!canvasApi) return;
    try {
        const avatar = await canvasApi.loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatar, x, y, size, size);
        ctx.restore();
    } catch (_) {
        ctx.fillStyle = '#5865f2';
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawCherryIcon(ctx, cx, cy, scale) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.strokeStyle = '#166534';
    ctx.lineWidth = 7;
    ctx.lineCap = 'round';
    ctx.beginPath();
    ctx.moveTo(-22, -12);
    ctx.quadraticCurveTo(-8, -60, 22, -70);
    ctx.moveTo(20, -12);
    ctx.quadraticCurveTo(8, -58, 22, -70);
    ctx.stroke();
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.ellipse(38, -72, 24, 11, -0.35, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(-28, 18, 32, 0, Math.PI * 2);
    ctx.arc(22, 20, 32, 0, Math.PI * 2);
    ctx.fill();
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.beginPath();
    ctx.arc(-42, 4, 8, 0, Math.PI * 2);
    ctx.arc(8, 6, 8, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function drawCitrusIcon(ctx, cx, cy, scale, color, leaf = false) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.fillStyle = color;
    ctx.beginPath();
    ctx.ellipse(0, 8, 58, 46, -0.15, 0, Math.PI * 2);
    ctx.fill();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.arc(-16, -7, 18, Math.PI * 0.95, Math.PI * 1.55);
    ctx.stroke();
    if (leaf) {
        ctx.fillStyle = '#22c55e';
        ctx.beginPath();
        ctx.ellipse(24, -42, 25, 12, -0.45, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

function drawGrapesIcon(ctx, cx, cy, scale) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.fillStyle = '#22c55e';
    ctx.beginPath();
    ctx.ellipse(18, -64, 25, 12, -0.45, 0, Math.PI * 2);
    ctx.fill();
    const grapes = [
        [0, -32], [-28, -8], [28, -8],
        [-14, 22], [18, 22], [0, 52]
    ];
    grapes.forEach(([x, y]) => {
        ctx.fillStyle = '#a855f7';
        ctx.beginPath();
        ctx.arc(x, y, 24, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = 'rgba(255,255,255,0.38)';
        ctx.beginPath();
        ctx.arc(x - 8, y - 8, 6, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.restore();
}

function drawBellIcon(ctx, cx, cy, scale) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    const grad = ctx.createLinearGradient(0, -70, 0, 70);
    grad.addColorStop(0, '#fde68a');
    grad.addColorStop(1, '#f59e0b');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(-54, 38);
    ctx.quadraticCurveTo(-38, 18, -36, -22);
    ctx.quadraticCurveTo(-28, -70, 0, -70);
    ctx.quadraticCurveTo(28, -70, 36, -22);
    ctx.quadraticCurveTo(38, 18, 54, 38);
    ctx.closePath();
    ctx.fill();
    ctx.fillStyle = '#b45309';
    roundRect(ctx, -62, 34, 124, 20, 10);
    ctx.fill();
    ctx.fillStyle = '#fef3c7';
    ctx.beginPath();
    ctx.arc(0, 58, 14, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

function drawStarIcon(ctx, cx, cy, scale) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.fillStyle = '#facc15';
    ctx.beginPath();
    for (let i = 0; i < 10; i += 1) {
        const radius = i % 2 === 0 ? 68 : 30;
        const angle = -Math.PI / 2 + i * Math.PI / 5;
        const x = Math.cos(angle) * radius;
        const y = Math.sin(angle) * radius;
        if (i === 0) ctx.moveTo(x, y);
        else ctx.lineTo(x, y);
    }
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#f59e0b';
    ctx.lineWidth = 6;
    ctx.stroke();
    ctx.restore();
}

function drawDiamondIcon(ctx, cx, cy, scale) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    const grad = ctx.createLinearGradient(0, -70, 0, 72);
    grad.addColorStop(0, '#e0f2fe');
    grad.addColorStop(1, '#38bdf8');
    ctx.fillStyle = grad;
    ctx.beginPath();
    ctx.moveTo(0, -74);
    ctx.lineTo(62, -20);
    ctx.lineTo(0, 76);
    ctx.lineTo(-62, -20);
    ctx.closePath();
    ctx.fill();
    ctx.strokeStyle = '#0284c7';
    ctx.lineWidth = 5;
    ctx.stroke();
    ctx.strokeStyle = 'rgba(255,255,255,0.65)';
    ctx.lineWidth = 4;
    ctx.beginPath();
    ctx.moveTo(-62, -20);
    ctx.lineTo(62, -20);
    ctx.moveTo(0, -74);
    ctx.lineTo(-18, -20);
    ctx.lineTo(0, 76);
    ctx.lineTo(18, -20);
    ctx.closePath();
    ctx.stroke();
    ctx.restore();
}

function drawSlotIcon(ctx, symbol, cx, cy) {
    const scale = 0.92;
    if (symbol.label === 'Cherry') return drawCherryIcon(ctx, cx, cy + 4, scale);
    if (symbol.label === 'Lemon') return drawCitrusIcon(ctx, cx, cy + 5, scale, '#facc15', true);
    if (symbol.label === 'Orange') return drawCitrusIcon(ctx, cx, cy + 5, scale, '#fb923c', true);
    if (symbol.label === 'Grapes') return drawGrapesIcon(ctx, cx, cy + 3, scale);
    if (symbol.label === 'Bell') return drawBellIcon(ctx, cx, cy + 4, scale);
    if (symbol.label === 'Star') return drawStarIcon(ctx, cx, cy + 4, scale);
    if (symbol.label === 'Diamond') return drawDiamondIcon(ctx, cx, cy + 4, scale);
}

function drawSymbol(ctx, symbol, x, y, w, h, spinning = false) {
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.42)';
    ctx.shadowBlur = 14;
    ctx.shadowOffsetY = 6;
    roundRect(ctx, x, y, w, h, 18);
    ctx.fillStyle = spinning ? '#1f2937' : '#f8fafc';
    ctx.fill();
    ctx.restore();

    roundRect(ctx, x, y, w, h, 18);
    ctx.strokeStyle = spinning ? '#64748b' : symbol.color;
    ctx.lineWidth = 4;
    ctx.stroke();

    if (spinning) {
        ctx.strokeStyle = 'rgba(255,255,255,0.20)';
        ctx.lineWidth = 8;
        for (let i = 0; i < 5; i += 1) {
            ctx.beginPath();
            ctx.moveTo(x + 28, y + 30 + i * 32);
            ctx.lineTo(x + w - 28, y + 30 + i * 32);
            ctx.stroke();
        }
        return;
    }

    drawSlotIcon(ctx, symbol, x + w / 2, y + h / 2 - 4);

    ctx.fillStyle = symbol.color;
    ctx.font = 'bold 18px Arial';
    ctx.fillText(`${symbol.multiplier}x`, x + w / 2, y + h - 24);
}

async function buildBoardImage({ interaction, reels, bet, cur, balance, result, spinning = false }) {
    if (!canvasApi) return null;

    const { createCanvas } = canvasApi;
    const canvas = createCanvas(900, 430);
    const ctx = canvas.getContext('2d');

    const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
    bg.addColorStop(0, '#22132d');
    bg.addColorStop(0.45, '#111827');
    bg.addColorStop(1, '#0b1020');
    ctx.fillStyle = bg;
    roundRect(ctx, 0, 0, canvas.width, canvas.height, 18);
    ctx.fill();

    ctx.strokeStyle = result?.label === 'jackpot' ? '#facc15' : result?.win ? '#22c55e' : '#ef4444';
    ctx.lineWidth = 5;
    roundRect(ctx, 8, 8, canvas.width - 16, canvas.height - 16, 18);
    ctx.stroke();

    ctx.fillStyle = 'rgba(15, 23, 42, 0.86)';
    roundRect(ctx, 28, 24, 844, 78, 16);
    ctx.fill();

    await drawAvatar(ctx, interaction.user, 46, 37, 52);
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 30px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(interaction.user.username, 112, 57);
    ctx.fillStyle = '#cbd5e1';
    ctx.font = 'bold 18px Arial';
    ctx.fillText(`${bet.toLocaleString()} ${cleanCurrency(cur)} bet • ${Number(balance || 0).toLocaleString()} balance`, 112, 84);

    ctx.textAlign = 'right';
    ctx.fillStyle = spinning ? '#93c5fd' : result?.label === 'jackpot' ? '#facc15' : result?.win ? '#22c55e' : '#ef4444';
    ctx.font = 'bold 34px Arial';
    ctx.fillText(spinning ? 'SPINNING' : result?.label?.toUpperCase() || 'SLOTS', 842, 70);

    ctx.fillStyle = '#070b14';
    roundRect(ctx, 48, 132, 804, 220, 24);
    ctx.fill();
    ctx.strokeStyle = '#334155';
    ctx.lineWidth = 3;
    roundRect(ctx, 48, 132, 804, 220, 24);
    ctx.stroke();

    const reelW = 190;
    const reelH = 168;
    const startX = 116;
    const gap = 53;
    reels.forEach((symbol, index) => {
        drawSymbol(ctx, symbol, startX + index * (reelW + gap), 158, reelW, reelH, spinning);
    });

    ctx.fillStyle = 'rgba(250,204,21,0.12)';
    roundRect(ctx, 250, 368, 400, 36, 18);
    ctx.fill();
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 18px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('Cherry • Lemon • Orange • Grapes • Bell • Star • Diamond', 450, 391);

    return new AttachmentBuilder(await canvas.encode('png'), { name: 'slots-board.png' });
}

function quickEmbed(description, color = '#5865f2') {
    return new EmbedBuilder().setDescription(description).setColor(color);
}

function resultDescription(t, result, bet, cur) {
    if (result.label === 'jackpot') return t.jackpot(result.amount, cur);
    if (result.label === 'small') return t.smallWin(result.amount, cur);
    if (result.win) return t.win(result.amount, cur);
    return t.lose(bet, cur);
}

function resultColor(result) {
    if (result.label === 'jackpot') return '#facc15';
    if (result.win) return '#22c55e';
    return '#ef4444';
}

function buildActionRow(t, gameId, canSpinAgain = true) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`${gameId}:again`)
            .setEmoji('🎰')
            .setLabel(t.spinAgain)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(!canSpinAgain),
        new ButtonBuilder()
            .setCustomId(`${gameId}:paytable`)
            .setEmoji('📋')
            .setLabel(t.paytable)
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId(`${gameId}:help`)
            .setEmoji('ℹ️')
            .setLabel(t.help)
            .setStyle(ButtonStyle.Secondary)
    );
}

function paytableEmbed(t) {
    return new EmbedBuilder()
        .setTitle(t.paytableTitle)
        .setDescription(SYMBOLS.map(s => `${s.emoji} **${s.label}** • ${s.multiplier}x`).join('\n'))
        .setColor('#facc15')
        .setFooter({ text: t.footer });
}

async function buildSpinPayload(interaction, t, cur, bet, reels, result, user, spinning = false) {
    const attachment = await buildBoardImage({
        interaction,
        reels,
        bet,
        cur,
        balance: user.wallet || 0,
        result,
        spinning
    });

    const desc = spinning
        ? t.spinning
        : `${reels.map(symbol => symbol.emoji).join('  ')}\n\n${resultDescription(t, result, bet, cur)}${result.capped ? `\n${t.capped(result.amount, cur)}` : ''}`;

    const embed = new EmbedBuilder()
        .setTitle('Slot Machine')
        .setDescription(desc)
        .setColor(spinning ? '#5865f2' : resultColor(result))
        .addFields(
            { name: t.bet, value: `${bet.toLocaleString()} ${cur}`, inline: true },
            { name: t.payout, value: `${(result?.amount || 0).toLocaleString()} ${cur}`, inline: true },
            { name: t.balance, value: `${(user.wallet || 0).toLocaleString()} ${cur}`, inline: true }
        )
        .setFooter({ text: t.footer })
        .setTimestamp();

    if (attachment) embed.setImage('attachment://slots-board.png');

    const payload = { embeds: [embed] };
    if (attachment) payload.files = [attachment];
    return payload;
}

function playSpin(interaction, bet, cur, t, slotCfg) {
    const user = getUser(interaction.guildId, interaction.user.id);
    if ((user.wallet || 0) < bet) {
        return { error: t.noMoney(bet, cur), user };
    }

    const reels = spin();
    const result = evaluate(reels, bet, slotCfg.winChance, slotCfg.maxPayout || 0);

    user.wallet = Math.max(0, (user.wallet || 0) - bet);
    if (result.win) {
        user.wallet = (user.wallet || 0) + result.amount;
        user.totalEarned = (user.totalEarned || 0) + Math.max(0, result.amount - bet);
    }
    user.totalGambled = (user.totalGambled || 0) + bet;
    user.slotsPlayed = (user.slotsPlayed || 0) + 1;
    if (result.label === 'jackpot') user.jackpotsWon = (user.jackpotsWon || 0) + 1;
    saveUser(interaction.guildId, interaction.user.id, user);

    // ── [FIX] Transaction log ─────────────────────────────────────────────
    const _netSlots = result.win ? (result.amount - bet) : -bet;
    addTransaction(interaction.guildId, interaction.user.id, result.win ? 'slots_win' : 'slots_loss', _netSlots, `Slots bet:${bet}`);

    return { reels, result, user };
}

module.exports = {
    data: {
        name: 'slots',
        description: 'Spin the slot machine | العب الآلة القمارية',
        default_member_permissions: null,
        options: [
            { name: 'amount', description: 'Bet amount | مبلغ الرهان', type: 4, required: true, min_value: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        await interaction.deferReply();

        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];
        const es = loadEconomySettings();

        if (!es.enabled) {
            return interaction.editReply({ embeds: [quickEmbed(t.disabled, '#ef4444')] });
        }

        const slotCfg = es.gambling?.slots || {};
        if (!slotCfg.enabled) {
            return interaction.editReply({ embeds: [quickEmbed(t.slotOff, '#ef4444')] });
        }

        const bet = interaction.options.getInteger('amount');
        const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        slotCfg.winChance = clamp(Number(slotCfg.winChance) || 35, 0, 100);

        if (slotCfg.minBet > 0 && bet < slotCfg.minBet) {
            return interaction.editReply({ embeds: [quickEmbed(t.minBet(slotCfg.minBet, cur), '#facc15')] });
        }
        if (slotCfg.maxBet > 0 && bet > slotCfg.maxBet) {
            return interaction.editReply({ embeds: [quickEmbed(t.maxBet(slotCfg.maxBet, cur), '#facc15')] });
        }

        const gameId = `slots:${interaction.id}`;
        // [FIX-SLOTS-01] withUserLock protects against interleaving with /pay or /bank
        let spinState = playSpin(interaction, bet, cur, t, slotCfg);
          const _slotsUser = getUser(interaction.guildId, interaction.user.id);
          const _slotsCdMs = (slotCfg.cooldown || 0) * 60000;
          if (_slotsCdMs > 0) {
              const _slotsLeft = cooldownLeft(_slotsUser.lastSlots || 0, _slotsCdMs);
              if (_slotsLeft > 0) {
                  return interaction.editReply({ embeds: [quickEmbed(`⏰ يمكنك اللعب مرة أخرى بعد **${formatTime(_slotsLeft)}**.`, '#facc15')] });
              }
              _slotsUser.lastSlots = Date.now();
              saveUser(interaction.guildId, interaction.user.id, _slotsUser);
          }
          
        if (spinState.error) {
            return interaction.editReply({ embeds: [quickEmbed(spinState.error, '#ef4444')] });
        }

        const fakeReels = [spinReel(), spinReel(), spinReel()];
        await interaction.editReply(await buildSpinPayload(interaction, t, cur, bet, fakeReels, { amount: 0, label: 'spinning' }, spinState.user, true));
        await new Promise(resolve => setTimeout(resolve, 1200));

        const canSpinAgain = (spinState.user.wallet || 0) >= bet;
        const message = await interaction.editReply({
            ...(await buildSpinPayload(interaction, t, cur, bet, spinState.reels, spinState.result, spinState.user, false)),
            components: [buildActionRow(t, gameId, canSpinAgain)]
        });

        const collector = message.createMessageComponentCollector({
            filter: async i => {
                if (i.user.id === interaction.user.id) return true;
                await i.reply({ embeds: [quickEmbed(t.notYou, '#ef4444')], flags: MessageFlags.Ephemeral }).catch(() => {});
                return false;
            },
            time: SPIN_AGAIN_TIMEOUT
        });

        collector.on('collect', async btn => {
            const action = btn.customId.split(':').pop();

            if (action === 'help') {
                return btn.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(t.helpTitle)
                            .setDescription(t.helpDescription)
                            .setColor('#5865f2')
                            .setFooter({ text: t.footer })
                    ],
                    flags: MessageFlags.Ephemeral
                });
            }

            if (action === 'paytable') {
                return btn.reply({ embeds: [paytableEmbed(t)], flags: MessageFlags.Ephemeral });
            }

            if (action !== 'again') return;

            spinState = playSpin(interaction, bet, cur, t, slotCfg);
            if (spinState.error) {
                return btn.reply({ embeds: [quickEmbed(spinState.error, '#ef4444')], flags: MessageFlags.Ephemeral });
            }

            await btn.update({
                ...(await buildSpinPayload(interaction, t, cur, bet, [spinReel(), spinReel(), spinReel()], { amount: 0, label: 'spinning' }, spinState.user, true)),
                components: [buildActionRow(t, gameId, false)]
            });
            await new Promise(resolve => setTimeout(resolve, 1200));

            const nextCanSpinAgain = (spinState.user.wallet || 0) >= bet;
            await interaction.editReply({
                ...(await buildSpinPayload(interaction, t, cur, bet, spinState.reels, spinState.result, spinState.user, false)),
                components: [buildActionRow(t, gameId, nextCanSpinAgain)]
            });
            collector.resetTimer();
        });

        collector.on('end', () => {
            interaction.editReply({ components: [] }).catch(() => {});
        });
    }
};
