const fs = require('fs');
const path = require('path');
const { MessageFlags } = require('discord.js');
const { checkPermissions } = require('../utils/permissionChecker');

// 🌐 الترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        noPermBot: '❌ البوت لا يملك صلاحية إدارة الرومات',
        success: (count) => `🔓 تم فتح **${count}** قناة/روم`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        noPermBot: '❌ The bot does not have permission to manage channels',
        success: (count) => `🔓 Unlocked **${count}** channels`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) {
            return {};
        }
    }
    return {};
}

module.exports = {
    data: {
        name: 'unlockall',
        description: 'فتح جميع الرومات | Unlock all channels',
        description_localizations: {
            enUS: 'Unlock all channels',
            ar: 'فتح جميع الرومات (الصوتية والكتابية)'
        }
    },

    async execute(interaction, client, settings) {

        // 🌐 تحديد اللغة
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const modCommands = loadModCommands();
            const commandConfig = modCommands.unlockall || {
                enabled: true,
                deniedRoles: [],
                allowedRoles: [],
                deniedChannels: [],
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };

            if (!commandConfig.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }

            const permission = checkPermissions(
                interaction.member,
                interaction.channelId,
                commandConfig
            );

            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }

            if (!interaction.guild.members.me.permissions.has('ManageChannels')) {
                return await interaction.editReply({ content: t.noPermBot });
            }

            let count = 0;
            const channels = [...interaction.guild.channels.cache.values()];

            for (const channel of channels) {
                try {
                    await channel.permissionOverwrites.edit(interaction.guild.roles.everyone, {
                        SendMessages: true,
                        Connect: true,
                    });
                    count++;
                } catch (err) {
                    console.warn(`⚠️ Failed to unlock channel ${channel.name}:`, err.message);
                }
            }

            const successMessage = t.success(count);

            if (commandConfig.deleteResponse) {
                await interaction.editReply({ content: successMessage, components: [] });

                setTimeout(() => {
                    interaction.deleteReply().catch(err => {
                        if (err.code !== 10008) console.warn('⚠️ Failed to delete message:', err.message);
                    });
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }

        } catch (error) {
            console.error('❌ Error in unlockall:', error.message);

            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {
                if (e.code !== 10008) console.warn('❌ Failed to send error message:', e.message);
            }
        }
    }
};