const fs   = require('fs');
const path = require('path');

const BOT_DATA_FILE = path.join(__dirname, '../botData.json');

function loadData() {
    try {
        if (fs.existsSync(BOT_DATA_FILE)) {
            const raw = fs.readFileSync(BOT_DATA_FILE, 'utf8').trim();
            if (raw) return JSON.parse(raw);
        }
    } catch(e) {}
    return { warns: {}, tempRoles: {} };
}

function saveData(data) {
    try {
        fs.writeFileSync(BOT_DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch(e) {}
}

function cleanExpiredWarnings() {
    const data  = loadData();
    const warns = data.warns || {};
    const now   = Date.now();
    let changed = false;

    for (const guildId of Object.keys(warns)) {
        for (const userId of Object.keys(warns[guildId])) {
            const before = warns[guildId][userId].length;

            warns[guildId][userId] = warns[guildId][userId].filter(w => {
                if (!w.expiresAt) return true; // دائم، لا تحذفه
                return new Date(w.expiresAt).getTime() > now;
            });

            if (warns[guildId][userId].length === 0)
                delete warns[guildId][userId];

            if ((warns[guildId][userId]?.length ?? 0) !== before) changed = true;
        }

        if (Object.keys(warns[guildId]).length === 0)
            delete warns[guildId];
    }

    if (changed) {
        data.warns = warns;
        saveData(data);
    }
}

function startWarnScheduler() {
    cleanExpiredWarnings();
    setInterval(cleanExpiredWarnings, 60 * 1000);
}

module.exports = { startWarnScheduler, cleanExpiredWarnings };