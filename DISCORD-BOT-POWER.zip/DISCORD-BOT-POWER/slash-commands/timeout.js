const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'إسكات عضو مؤقتاً',
        option_user: 'العضو',
        option_duration: 'المدة بالدقائق (1-40320)',
        option_reason: 'السبب',
        noReason: '\`لا يوجد سبب⚠️\`',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        notModeratable: '❌ لا يمكنني إسكات هذا العضو. تأكد أن رتبتي أعلى.',
        botNoPerm: '❌ البوت لا يملك صلاحية إسكات الأعضاء',
        adminBlock: '❌ لا يمكنني إسكات أدمن.',
        timeoutFailed: '❌ فشل إسكات العضو:',
        success: (user, duration, reason) => `🔇 تم إسكات \`${user.tag}\` لمدة ${duration} دقيقة\nالسبب: ${reason}`,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Timeout a member',
        option_user: 'User',
        option_duration: 'Duration in minutes (1-40320)',
        option_reason: 'Reason',
        noReason: '\`⚠️ No reason provided\`',
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '❌ Member not found in the server.',
        notModeratable: '❌ Cannot timeout this member. Ensure my role is higher.',
        botNoPerm: '❌ Bot does not have permission to timeout members',
        adminBlock: '❌ Cannot timeout an administrator.',
        timeoutFailed: '❌ Failed to timeout member:',
        success: (user, duration, reason) => `🔇 \`${user.tag}\` has been timed out for ${duration} minutes\nReason: ${reason}`,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'timeout',
        description: 'Timeout a member | إسكات عضو',
        default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
        options: [
            { name: 'user', description: 'User', type: 6, required: true },
            { name: 'duration', description: 'Duration in minutes (1-40320)', type: 4, required: true, min_value: 1, max_value: 40320 },
            { name: 'reason', description: 'Reason', type: 3, required: false }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.timeout || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const duration = interaction.options.getInteger('duration');
            const reason = interaction.options.getString('reason') || t.noReason;

            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!targetMember.moderatable) {
                return await interaction.editReply({ content: t.notModeratable });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (targetMember.permissions.has(PermissionFlagsBits.Administrator)) {
                return await interaction.editReply({ content: t.adminBlock });
            }
            
            try {
                await targetMember.timeout(duration * 60 * 1000, reason);
                
                const successMessage = t.success(targetUser, duration, reason);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });

                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ 
                    content: `${t.timeoutFailed} ${error.message}`
                });
            }
            
        } catch (error) {
            console.error('❌ Timeout command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};