const {
    AttachmentBuilder,
    EmbedBuilder,
    MessageFlags,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder
} = require('discord.js');
const { getUser, saveUser, cooldownLeft, formatTime, addTransaction, startActiveGame, endActiveGame } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

let canvasApi = null;
try {
    canvasApi = require('@napi-rs/canvas');
} catch (_) {
    canvasApi = null;
}

const GAME_TIMEOUT = 120_000;
const SUITS = ['spades', 'hearts', 'diamonds', 'clubs'];
const SUIT_SYMBOL = {
    spades: '♠',
    hearts: '♥',
    diamonds: '♦',
    clubs: '♣'
};
const RED_SUITS = new Set(['hearts', 'diamonds']);
const RANKS = ['A', '2', '3', '4', '5', '6', '7', '8', '9', '10', 'J', 'Q', 'K'];

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        bjDisabled: '⚠️ لعبة البلاك جاك معطلة حالياً.',
        noMoney: (n, c) => `❌ رصيدك غير كافٍ. تحتاج **${n.toLocaleString()} ${c}**.`,
        minBet: (n, c) => `❌ الحد الأدنى للرهان **${n.toLocaleString()} ${c}**.`,
        maxBet: (n, c) => `❌ الحد الأقصى للرهان **${n.toLocaleString()} ${c}**.`,
        blackjack: '🃏 بلاك جاك! فزت بـ 1.5x الرهان!',
        bust: n => `💥 تجاوزت 21 بنقاط **${n}**. خسرت.`,
        dealerBust: n => `🎉 الموزع تجاوز 21 بنقاط **${n}**. فزت!`,
        win: (n, c) => `🎉 فزت وربحت **${n.toLocaleString()} ${c}**!`,
        lose: (n, c) => `😢 خسرت **${n.toLocaleString()} ${c}**.`,
        push: '🟰 تعادل! تم إرجاع الرهان.',
        balance: 'الرصيد الحالي',
        bet: 'الرهان',
        player: 'اللاعب',
        dealer: 'الموزع',
        score: 'النقاط',
        playing: 'اختر حركة للمتابعة.',
        footer: 'Blackjack',
        btnHit: 'سحب',
        btnStand: 'وقوف',
        btnDouble: 'مضاعفة',
        btnSplit: 'تقسيم',
        btnHelp: 'How to Play?',
        helpTitle: 'طريقة لعب Blackjack',
        helpDescription:
            '**الهدف:** اقترب من 21 أكثر من الموزع بدون أن تتجاوزها.\n\n' +
            '**Hit:** اسحب بطاقة جديدة.\n' +
            '**Stand:** توقف وانهي دورك.\n' +
            '**Double:** ضاعف الرهان واسحب بطاقة واحدة ثم تقف تلقائياً.\n' +
            '**Split:** يظهر إذا أول ورقتين نفس الرتبة. يقسمهما إلى يدين برهان إضافي.\n\n' +
            '**القيم:** A تساوي 11 أو 1، و J/Q/K تساوي 10.\n' +
            '**Blackjack:** إذا حصلت على 21 من أول ورقتين تربح 1.5x.',
        noDouble: '❌ لا تملك رصيداً كافياً للمضاعفة.',
        noSplit: '❌ لا يمكن التقسيم الآن.',
        nextHand: n => `تم الانتقال إلى اليد ${n}.`,
        hand: n => `اليد ${n}`,
        timer: 'الوقت',
        notYou: '❌ هذه اللعبة ليست لك.',
        timeout: '⏰ انتهى وقت اللعبة وتم إنهاؤها تلقائياً.'
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        bjDisabled: '⚠️ Blackjack is currently disabled.',
        noMoney: (n, c) => `❌ Insufficient balance. Need **${n.toLocaleString()} ${c}**.`,
        minBet: (n, c) => `❌ Minimum bet is **${n.toLocaleString()} ${c}**.`,
        maxBet: (n, c) => `❌ Maximum bet is **${n.toLocaleString()} ${c}**.`,
        blackjack: '🃏 Blackjack! You win 1.5x your bet!',
        bust: n => `💥 Bust! You went over 21 with **${n}**. You lose.`,
        dealerBust: n => `🎉 Dealer busted with **${n}**. You win!`,
        win: (n, c) => `🎉 You win **${n.toLocaleString()} ${c}**!`,
        lose: (n, c) => `😢 You lost **${n.toLocaleString()} ${c}**.`,
        push: '🟰 Push! Your bet has been returned.',
        balance: 'Balance',
        bet: 'Bet',
        player: 'Player',
        dealer: 'Dealer',
        score: 'Score',
        playing: 'Choose your next move.',
        footer: 'Blackjack',
        btnHit: 'Hit',
        btnStand: 'Stand',
        btnDouble: 'Double',
        btnSplit: 'Split',
        btnHelp: 'How to Play?',
        helpTitle: 'How to Play Blackjack',
        helpDescription:
            '**Goal:** Get closer to 21 than the dealer without going over.\n\n' +
            '**Hit:** Draw one more card.\n' +
            '**Stand:** Keep your hand and let the dealer play.\n' +
            '**Double:** Double your bet, draw one card, then stand automatically.\n' +
            '**Split:** Available when your first two cards have the same rank. It creates two hands for an extra bet.\n\n' +
            '**Values:** A is 11 or 1, and J/Q/K are worth 10.\n' +
            '**Blackjack:** 21 with your first two cards pays 1.5x.',
        noDouble: '❌ Not enough balance to double down.',
        noSplit: '❌ You cannot split right now.',
        nextHand: n => `Moving to hand ${n}.`,
        hand: n => `Hand ${n}`,
        timer: 'Timer',
        notYou: '❌ This game is not yours.',
        timeout: '⏰ Game timed out and was resolved automatically.'
    }
};

function newDeck() {
    const deck = [];
    for (const suit of SUITS) {
        for (const rank of RANKS) deck.push({ rank, suit });
    }
    for (let i = deck.length - 1; i > 0; i -= 1) {
        const j = Math.floor(Math.random() * (i + 1));
        [deck[i], deck[j]] = [deck[j], deck[i]];
    }
    return deck;
}

function cardValue(rank) {
    if (['J', 'Q', 'K'].includes(rank)) return 10;
    if (rank === 'A') return 11;
    return Number(rank);
}

function handValue(hand) {
    let total = 0;
    let aces = 0;
    for (const card of hand) {
        total += cardValue(card.rank);
        if (card.rank === 'A') aces += 1;
    }
    while (total > 21 && aces > 0) {
        total -= 10;
        aces -= 1;
    }
    return total;
}

function handText(hand, hideSecond = false) {
    if (hideSecond && hand.length > 1) {
        return `${hand[0].rank}${SUIT_SYMBOL[hand[0].suit]}  ??`;
    }
    return hand.map(card => `${card.rank}${SUIT_SYMBOL[card.suit]}`).join('  ');
}

function activeHand(state) {
    return state.playerHands ? state.playerHands[state.activeHand].cards : state.playerHand;
}

function activeBet(state) {
    return state.playerHands ? state.playerHands[state.activeHand].bet : state.currentBet;
}

function canSplitHand(state, wallet = 0) {
    const hand = activeHand(state);
    return !state.playerHands &&
        !state.doubled &&
        hand.length === 2 &&
        hand[0].rank === hand[1].rank &&
        wallet >= activeBet(state);
}

function cleanCurrency(cur) {
    return String(cur)
        .replace(/<a?:[a-zA-Z0-9_]+:\d+>/g, '')
        .replace(/\s+/g, ' ')
        .trim() || 'Coins';
}

function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
}

function drawChip(ctx, x, y, text, color = '#facc15') {
    ctx.save();
    ctx.shadowColor = 'rgba(0,0,0,0.35)';
    ctx.shadowBlur = 8;
    ctx.shadowOffsetY = 3;
    roundRect(ctx, x, y, 118, 36, 18);
    ctx.fillStyle = '#151b27';
    ctx.fill();
    ctx.restore();
    ctx.strokeStyle = color;
    ctx.lineWidth = 2;
    roundRect(ctx, x, y, 118, 36, 18);
    ctx.stroke();
    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 17px Arial';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, x + 59, y + 19);
}

function drawCard(ctx, card, x, y, w, h, hidden = false, highlight = false) {
    ctx.save();
    ctx.shadowColor = highlight ? 'rgba(250, 204, 21, 0.7)' : 'rgba(0, 0, 0, 0.42)';
    ctx.shadowBlur = highlight ? 18 : 12;
    ctx.shadowOffsetY = 6;
    roundRect(ctx, x, y, w, h, 10);
    ctx.fillStyle = hidden ? '#25304b' : '#f7f8fb';
    ctx.fill();
    ctx.restore();

    roundRect(ctx, x, y, w, h, 10);
    ctx.strokeStyle = hidden ? '#5865f2' : '#d6dbe3';
    ctx.lineWidth = 2;
    ctx.stroke();

    if (hidden) {
        const grad = ctx.createLinearGradient(x, y, x + w, y + h);
        grad.addColorStop(0, '#111827');
        grad.addColorStop(0.52, '#1f3b5f');
        grad.addColorStop(1, '#0f766e');
        ctx.fillStyle = grad;
        roundRect(ctx, x + 8, y + 8, w - 16, h - 16, 8);
        ctx.fill();

        ctx.strokeStyle = 'rgba(250,204,21,0.34)';
        ctx.lineWidth = 3;
        for (let i = -h; i < w; i += 22) {
            ctx.beginPath();
            ctx.moveTo(x + i, y + h - 8);
            ctx.lineTo(x + i + h, y + 8);
            ctx.stroke();
        }

        ctx.strokeStyle = 'rgba(255,255,255,0.18)';
        ctx.lineWidth = 2;
        roundRect(ctx, x + 17, y + 17, w - 34, h - 34, 8);
        ctx.stroke();

        ctx.fillStyle = '#facc15';
        ctx.font = 'bold 50px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('BJ', x + w / 2, y + h / 2 + 2);
        return;
    }

    const red = RED_SUITS.has(card.suit);
    ctx.fillStyle = red ? '#ef4444' : '#111827';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';

    ctx.font = 'bold 28px Arial';
    ctx.fillText(card.rank, x + 28, y + 28);
    ctx.font = 'bold 28px Arial';
    ctx.fillText(SUIT_SYMBOL[card.suit], x + 28, y + 62);

    ctx.font = 'bold 72px Arial';
    ctx.fillText(SUIT_SYMBOL[card.suit], x + w / 2, y + h / 2 + 10);

    ctx.save();
    ctx.translate(x + w - 28, y + h - 28);
    ctx.rotate(Math.PI);
    ctx.font = 'bold 28px Arial';
    ctx.fillText(card.rank, 0, 0);
    ctx.font = 'bold 28px Arial';
    ctx.fillText(SUIT_SYMBOL[card.suit], 0, 32);
    ctx.restore();
}

function drawHand(ctx, hand, x, y, hideSecond = false, highlightLast = false) {
    const cardW = 104;
    const cardH = 150;
    const gap = hand.length > 5 ? 52 : 72;
    hand.forEach((card, index) => {
        drawCard(ctx, card, x + index * gap, y, cardW, cardH, hideSecond && index === 1, highlightLast && index === hand.length - 1);
    });
}

async function drawAvatar(ctx, user, x, y, size) {
    if (!canvasApi) return;
    try {
        const avatar = await canvasApi.loadImage(user.displayAvatarURL({ extension: 'png', size: 128 }));
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatar, x, y, size, size);
        ctx.restore();
    } catch (_) {
        ctx.fillStyle = '#5865f2';
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
    }
}

async function buildBoardImage({
    interaction,
    playerHand,
    dealerHand,
    bet,
    cur,
    t,
    hideDealer,
    resultColor = '#5865f2',
    balance = 0,
    timeLeft = GAME_TIMEOUT / 1000,
    highlightLast = false,
    splitInfo = null,
    blackjackGlow = false
}) {
    if (!canvasApi) return null;

    const { createCanvas } = canvasApi;
    const canvas = createCanvas(900, 560);
    const ctx = canvas.getContext('2d');

    const felt = ctx.createRadialGradient(450, 300, 80, 450, 290, 650);
    felt.addColorStop(0, '#17845f');
    felt.addColorStop(0.55, '#0f6b4d');
    felt.addColorStop(1, '#073b2e');
    ctx.fillStyle = felt;
    roundRect(ctx, 0, 0, canvas.width, canvas.height, 18);
    ctx.fill();

    ctx.strokeStyle = '#b8860b';
    ctx.lineWidth = 5;
    roundRect(ctx, 7, 7, canvas.width - 14, canvas.height - 14, 18);
    ctx.stroke();

    ctx.strokeStyle = 'rgba(250, 204, 21, 0.30)';
    ctx.lineWidth = 3;
    ctx.beginPath();
    ctx.ellipse(450, 315, 350, 210, 0, Math.PI, Math.PI * 2);
    ctx.stroke();

    ctx.fillStyle = 'rgba(12, 18, 28, 0.88)';
    roundRect(ctx, 24, 22, 852, 82, 16);
    ctx.fill();
    ctx.strokeStyle = resultColor;
    ctx.lineWidth = 3;
    roundRect(ctx, 24, 22, 852, 82, 16);
    ctx.stroke();

    await drawAvatar(ctx, interaction.user, 44, 36, 54);

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 29px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(interaction.user.username, 116, 54);
    ctx.font = 'bold 18px Arial';
    ctx.fillStyle = '#d8dee9';
    ctx.fillText(`${t.balance}: ${Number(balance || 0).toLocaleString()} ${cleanCurrency(cur)}`, 116, 83);

    ctx.textAlign = 'center';
    ctx.font = 'bold 31px Arial';
    ctx.fillStyle = blackjackGlow ? '#facc15' : '#ffffff';
    ctx.fillText('BLACKJACK', 450, 55);
    ctx.font = 'bold 17px Arial';
    ctx.fillStyle = '#d8dee9';
    ctx.fillText(`${t.bet}: ${bet.toLocaleString()} ${cleanCurrency(cur)}`, 450, 83);

    ctx.textAlign = 'right';
    drawChip(ctx, 738, 35, `${t.timer}: ${Math.max(0, timeLeft)}s`, timeLeft <= 20 ? '#ef4444' : '#22c55e');

    const dealerY = 158;
    const playerY = 360;

    ctx.fillStyle = 'rgba(12, 18, 28, 0.66)';
    roundRect(ctx, 34, dealerY - 48, 832, 42, 12);
    ctx.fill();
    roundRect(ctx, 34, playerY - 48, 832, 42, 12);
    ctx.fill();

    ctx.fillStyle = '#f8fafc';
    ctx.font = 'bold 22px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(t.dealer, 54, dealerY - 20);
    ctx.fillText(splitInfo ? `${t.hand(splitInfo.active + 1)} / ${splitInfo.total}` : t.player, 54, playerY - 20);

    drawChip(ctx, 728, dealerY - 46, `${t.score}: ${hideDealer ? '?' : handValue(dealerHand)}`, hideDealer ? '#5865f2' : '#facc15');
    drawChip(ctx, 728, playerY - 46, `${t.score}: ${handValue(playerHand)}`, handValue(playerHand) === 21 ? '#facc15' : '#22c55e');

    if (splitInfo) {
        for (let i = 0; i < splitInfo.total; i += 1) {
            drawChip(ctx, 54 + i * 128, 512, `${t.hand(i + 1)}: ${splitInfo.values[i]}`, i === splitInfo.active ? '#facc15' : '#64748b');
        }
    }

    drawHand(ctx, dealerHand, 44, dealerY, hideDealer);
    drawHand(ctx, playerHand, 44, playerY, false, highlightLast || blackjackGlow);

    return new AttachmentBuilder(await canvas.encode('png'), { name: 'blackjack-board.png' });
}

function quickEmbed(description, color = '#5865f2') {
    return new EmbedBuilder().setDescription(description).setColor(color);
}

function buildGameEmbed({ t, playerHand, dealerHand, bet, cur, hideDealer, attachment, description, color = '#5865f2', balance }) {
    const embed = new EmbedBuilder()
        .setTitle('Blackjack')
        .setColor(color)
        .setDescription(
            description ||
            `**${t.bet}:** ${bet.toLocaleString()} ${cur}\n` +
            `**${t.player}:** ${handValue(playerHand)} • ${handText(playerHand)}\n` +
            `**${t.dealer}:** ${hideDealer ? '?' : handValue(dealerHand)} • ${handText(dealerHand, hideDealer)}\n\n` +
            t.playing
        )
        .setFooter({ text: t.footer });

    if (balance !== undefined) {
        embed.addFields({ name: t.balance, value: `${balance.toLocaleString()} ${cur}`, inline: true });
    }
    if (attachment) embed.setImage('attachment://blackjack-board.png');
    return embed;
}

function buildActionRow(t, gameId, canDouble, canSplit = false, disabled = false) {
    const buttons = [
        new ButtonBuilder()
            .setCustomId(`${gameId}:hit`)
            .setEmoji('🃏')
            .setLabel(t.btnHit)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(disabled),
        new ButtonBuilder()
            .setCustomId(`${gameId}:stand`)
            .setEmoji('✋')
            .setLabel(t.btnStand)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(disabled)
    ];

    if (canDouble) {
        buttons.push(
            new ButtonBuilder()
                .setCustomId(`${gameId}:double`)
                .setEmoji('💰')
                .setLabel(t.btnDouble)
                .setStyle(ButtonStyle.Success)
                .setDisabled(disabled)
        );
    }

    if (canSplit) {
        buttons.push(
            new ButtonBuilder()
                .setCustomId(`${gameId}:split`)
                .setEmoji('✂️')
                .setLabel(t.btnSplit)
                .setStyle(ButtonStyle.Success)
                .setDisabled(disabled)
        );
    }

    buttons.push(
        new ButtonBuilder()
            .setCustomId(`${gameId}:help`)
            .setEmoji('ℹ️')
            .setLabel(t.btnHelp)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(disabled)
    );

    return new ActionRowBuilder().addComponents(buttons);
}

async function renderGame(target, state, options = {}) {
    const fresh = getUser(state.interaction.guildId, state.interaction.user.id);
    const hand = activeHand(state);
    const timeLeft = state.expiresAt ? Math.ceil((state.expiresAt - Date.now()) / 1000) : GAME_TIMEOUT / 1000;
    const splitInfo = state.playerHands ? {
        active: state.activeHand,
        total: state.playerHands.length,
        values: state.playerHands.map(h => handValue(h.cards))
    } : null;
    const attachment = await buildBoardImage({
        interaction: state.interaction,
        playerHand: hand,
        dealerHand: state.dealerHand,
        bet: activeBet(state),
        cur: state.cur,
        t: state.t,
        hideDealer: options.hideDealer,
        resultColor: options.color || '#5865f2',
        balance: options.balance ?? fresh.wallet ?? 0,
        timeLeft: Math.max(0, timeLeft),
        highlightLast: options.highlightLast,
        splitInfo,
        blackjackGlow: options.blackjackGlow
    });

    const embed = buildGameEmbed({
        t: state.t,
        playerHand: hand,
        dealerHand: state.dealerHand,
        bet: activeBet(state),
        cur: state.cur,
        hideDealer: options.hideDealer,
        attachment,
        description: options.description,
        color: options.color,
        balance: options.balance
    });

    const payload = {
        embeds: [embed],
        components: options.done ? [] : [buildActionRow(state.t, state.gameId, options.canDouble, options.canSplit)]
    };
    if (attachment) payload.files = [attachment];

    if (target?.update) return target.update(payload);
    if (target?.editReply) return target.editReply(payload);
    return target.edit(payload);
}

function resolveHand(state, handState) {
    const pVal = handValue(handState.cards);
    const dVal = handValue(state.dealerHand);
    const fresh = getUser(state.interaction.guildId, state.interaction.user.id);

    if (pVal > 21) {
        return { status: 'lose', text: state.t.bust(pVal), color: '#ef4444', balance: fresh.wallet || 0 };
    }

    if (dVal > 21) {
        fresh.wallet = (fresh.wallet || 0) + handState.bet * 2;
        fresh.totalEarned = (fresh.totalEarned || 0) + handState.bet;
        saveUser(state.interaction.guildId, state.interaction.user.id, fresh);
    endActiveGame(state.interaction.guildId, state.interaction.user.id); // [FIX-BJ-01]
        addTransaction(state.interaction.guildId, state.interaction.user.id, 'bj_win', handState.bet, `BJ dealer bust bet:${handState.bet}`);
        return { status: 'win', text: state.t.dealerBust(dVal), color: '#facc15', balance: fresh.wallet };
    }

    if (pVal > dVal) {
        fresh.wallet = (fresh.wallet || 0) + handState.bet * 2;
        fresh.totalEarned = (fresh.totalEarned || 0) + handState.bet;
        saveUser(state.interaction.guildId, state.interaction.user.id, fresh);
    endActiveGame(state.interaction.guildId, state.interaction.user.id); // [FIX-BJ-01]
        addTransaction(state.interaction.guildId, state.interaction.user.id, 'bj_win', handState.bet, `BJ win bet:${handState.bet}`);
        return { status: 'win', text: state.t.win(handState.bet, state.cur), color: '#facc15', balance: fresh.wallet };
    }

    if (pVal === dVal) {
        fresh.wallet = (fresh.wallet || 0) + handState.bet;
        saveUser(state.interaction.guildId, state.interaction.user.id, fresh);
    endActiveGame(state.interaction.guildId, state.interaction.user.id); // [FIX-BJ-01]
        addTransaction(state.interaction.guildId, state.interaction.user.id, 'bj_push', 0, `BJ push bet:${handState.bet}`);
        return { status: 'push', text: state.t.push, color: '#facc15', balance: fresh.wallet };
    }

    return { status: 'lose', text: state.t.lose(handState.bet, state.cur), color: '#ef4444', balance: fresh.wallet || 0 };
}

function resolveGame(state) {
    while (handValue(state.dealerHand) < 17) state.dealerHand.push(state.deck.pop());

    if (state.playerHands) {
        const results = state.playerHands.map(handState => resolveHand(state, handState));
        const wins = results.filter(r => r.status === 'win').length;
        const losses = results.filter(r => r.status === 'lose').length;
        const pushes = results.filter(r => r.status === 'push').length;
        const color = wins > 0 ? '#facc15' : losses > 0 ? '#ef4444' : '#facc15';
        const balance = results.length ? results[results.length - 1].balance : 0;
        return {
            description: results.map((r, index) => `**${state.t.hand(index + 1)}:** ${r.text}`).join('\n'),
            color,
            balance,
            summary: { wins, losses, pushes }
        };
    }

    const result = resolveHand(state, { cards: state.playerHand, bet: state.currentBet });
    return { description: result.text, color: result.color, balance: result.balance };
}

function advanceSplitHand(state) {
    if (!state.playerHands) return false;
    state.playerHands[state.activeHand].done = true;
    const next = state.playerHands.findIndex(handState => !handState.done);
    if (next === -1) return false;
    state.activeHand = next;
    state.doubled = false;
    return true;
}

module.exports = {
    data: {
        name: 'blackjack',
        description: 'Play Blackjack | العب البلاك جاك',
        default_member_permissions: null,
        options: [
            { name: 'amount', description: 'Bet amount | مبلغ الرهان', type: 4, required: true, min_value: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        await interaction.deferReply();

        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];
        const es = loadEconomySettings();

        if (!es.enabled) {
            return interaction.editReply({ embeds: [quickEmbed(t.disabled, '#ef4444')] });
        }

        const bjCfg = es.gambling?.blackjack || {};
        if (!bjCfg.enabled) {
            return interaction.editReply({ embeds: [quickEmbed(t.bjDisabled, '#ef4444')] });
        }

        let bet = interaction.options.getInteger('amount');
        const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        if (bjCfg.minBet > 0 && bet < bjCfg.minBet) {
            return interaction.editReply({ embeds: [quickEmbed(t.minBet(bjCfg.minBet, cur), '#facc15')] });
        }
        if (bjCfg.maxBet > 0 && bet > bjCfg.maxBet) {
            return interaction.editReply({ embeds: [quickEmbed(t.maxBet(bjCfg.maxBet, cur), '#facc15')] });
        }

        const user = getUser(interaction.guildId, interaction.user.id);
          const _bjCdMs = (bjCfg.cooldown || 0) * 60000;
          if (_bjCdMs > 0) {
              const _bjLeft = cooldownLeft(user.lastBlackjack || 0, _bjCdMs);
              if (_bjLeft > 0) {
                  return interaction.editReply({ embeds: [quickEmbed(`⏰ يمكنك اللعب مرة أخرى بعد **${formatTime(_bjLeft)}**.`, '#facc15')] });
              }
          }
          if (_bjCdMs > 0) user.lastBlackjack = Date.now();
        if ((user.wallet || 0) < bet) {
            return interaction.editReply({ embeds: [quickEmbed(t.noMoney(bet, cur), '#ef4444')] });
        }

        user.wallet = (user.wallet || 0) - bet;
        saveUser(interaction.guildId, interaction.user.id, user);

        // [FIX-BJ-01] تسجيل اللعبة النشطة قبل بدء الجلسة.
        // إذا أُعيد تشغيل البوت أثناء اللعبة، سيُسترجع الرهان تلقائياً
        // عند بدء البوت التالي عبر recoverActiveGames().
        startActiveGame(interaction.guildId, interaction.user.id, bet);

        const state = {
            interaction,
            t,
            cur,
            deck: newDeck(),
            playerHand: [],
            dealerHand: [],
            gameId: `bj:${interaction.id}`,
            currentBet: bet,
            doubled: false,
            expiresAt: Date.now() + GAME_TIMEOUT
        };
        state.playerHand.push(state.deck.pop(), state.deck.pop());
        state.dealerHand.push(state.deck.pop(), state.deck.pop());

        if (handValue(state.playerHand) === 21) {
            const winAmt = Math.floor(bet * 1.5);
            const fresh = getUser(interaction.guildId, interaction.user.id);
            fresh.wallet = (fresh.wallet || 0) + bet + winAmt;
            fresh.totalEarned = (fresh.totalEarned || 0) + winAmt;
            saveUser(interaction.guildId, interaction.user.id, fresh);
            addTransaction(interaction.guildId, interaction.user.id, 'bj_blackjack', winAmt, `BJ Blackjack bet:${bet}`);
            endActiveGame(interaction.guildId, interaction.user.id); // [FIX-BJ-01]

            await renderGame(interaction, state, {
                hideDealer: false,
                done: true,
                color: '#facc15',
                description: t.blackjack,
                balance: fresh.wallet,
                blackjackGlow: true
            });
            return;
        }

        const message = await renderGame(interaction, state, {
            hideDealer: true,
            canDouble: (user.wallet || 0) >= bet,
            canSplit: canSplitHand(state, user.wallet || 0)
        });

        const collector = message.createMessageComponentCollector({
            filter: async i => {
                if (i.user.id === interaction.user.id) return true;
                await i.reply({ embeds: [quickEmbed(t.notYou, '#ef4444')], flags: MessageFlags.Ephemeral }).catch(() => {});
                return false;
            },
            time: GAME_TIMEOUT
        });

        collector.on('collect', async btn => {
            const action = btn.customId.split(':').pop();
            const hand = activeHand(state);

            if (action === 'help') {
                return btn.reply({
                    embeds: [
                        new EmbedBuilder()
                            .setTitle(t.helpTitle)
                            .setDescription(t.helpDescription)
                            .setColor('#5865f2')
                            .setFooter({ text: t.footer })
                    ],
                    flags: MessageFlags.Ephemeral
                });
            }

            if (action === 'split') {
                const freshUser = getUser(interaction.guildId, interaction.user.id);
                if (!canSplitHand(state, freshUser.wallet || 0)) {
                    return btn.reply({ embeds: [quickEmbed(t.noSplit, '#ef4444')], flags: MessageFlags.Ephemeral });
                }

                freshUser.wallet = (freshUser.wallet || 0) - state.currentBet;
                saveUser(interaction.guildId, interaction.user.id, freshUser);

                const [first, second] = state.playerHand;
                state.playerHands = [
                    { cards: [first, state.deck.pop()], bet: state.currentBet, done: false },
                    { cards: [second, state.deck.pop()], bet: state.currentBet, done: false }
                ];
                state.activeHand = 0;
                state.doubled = false;

                await renderGame(btn, state, {
                    hideDealer: true,
                    highlightLast: true,
                    canDouble: (freshUser.wallet || 0) >= activeBet(state),
                    canSplit: false,
                    description: `${t.nextHand(1)}\n\n${t.playing}`
                });
                return;
            }

            if (action === 'double') {
                const freshUser = getUser(interaction.guildId, interaction.user.id);
                if ((freshUser.wallet || 0) < activeBet(state)) {
                    return btn.reply({ embeds: [quickEmbed(t.noDouble, '#ef4444')], flags: MessageFlags.Ephemeral });
                }
                freshUser.wallet = (freshUser.wallet || 0) - activeBet(state);
                saveUser(interaction.guildId, interaction.user.id, freshUser);
                if (state.playerHands) state.playerHands[state.activeHand].bet *= 2;
                else state.currentBet *= 2;
                state.doubled = true;
                hand.push(state.deck.pop());
            }

            if (action === 'hit') {
                hand.push(state.deck.pop());
            }

            const pVal = handValue(hand);
            if (pVal > 21) {
                if (advanceSplitHand(state)) {
                    const fresh = getUser(interaction.guildId, interaction.user.id);
                    await renderGame(btn, state, {
                        hideDealer: true,
                        highlightLast: true,
                        canDouble: (fresh.wallet || 0) >= activeBet(state) && activeHand(state).length === 2,
                        canSplit: false,
                        description: `${t.bust(pVal)}\n\n${t.nextHand(state.activeHand + 1)}`
                    });
                    return;
                }

                collector.stop('done');
                if (state.playerHands) {
                    const result = resolveGame(state);
                    await renderGame(btn, state, {
                        hideDealer: false,
                        done: true,
                        color: result.color,
                        description: result.description,
                        balance: result.balance
                    });
                    return;
                }

                const fresh = getUser(interaction.guildId, interaction.user.id);
                await renderGame(btn, state, {
                    hideDealer: false,
                    done: true,
                    color: '#ef4444',
                    description: t.bust(pVal),
                    balance: fresh.wallet || 0
                });
                return;
            }

            if (action === 'stand' || action === 'double' || pVal === 21) {
                if (advanceSplitHand(state)) {
                    const fresh = getUser(interaction.guildId, interaction.user.id);
                    await renderGame(btn, state, {
                        hideDealer: true,
                        highlightLast: action === 'double',
                        canDouble: (fresh.wallet || 0) >= activeBet(state) && activeHand(state).length === 2,
                        canSplit: false,
                        description: `${t.nextHand(state.activeHand + 1)}\n\n${t.playing}`
                    });
                    return;
                }

                collector.stop('done');
                const result = resolveGame(state);
                await renderGame(btn, state, {
                    hideDealer: false,
                    done: true,
                    color: result.color,
                    description: result.description,
                    balance: result.balance,
                    blackjackGlow: pVal === 21
                });
                return;
            }

            const fresh = getUser(interaction.guildId, interaction.user.id);
            await renderGame(btn, state, {
                hideDealer: true,
                highlightLast: action === 'hit',
                canDouble: !state.doubled && hand.length === 2 && (fresh.wallet || 0) >= activeBet(state),
                canSplit: canSplitHand(state, fresh.wallet || 0)
            });
        });

        collector.on('end', async (_, reason) => {
            if (reason !== 'time') return;
            const result = resolveGame(state);
            await renderGame(message, state, {
                hideDealer: false,
                done: true,
                color: result.color,
                description: `${t.timeout}\n\n${result.description}`,
                balance: result.balance
            }).catch(() => {});
        });
    }
};
