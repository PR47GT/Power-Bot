const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, cooldownLeft, formatTime, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

// ─── Dice Faces ───────────────────────────────────────────────────────────────
const DICE_FACES = ['⚀', '⚁', '⚂', '⚃', '⚄', '⚅'];

function rollDie() { return Math.floor(Math.random() * 6) + 1; }

function diceEmoji(n) { return DICE_FACES[n - 1] || n; }

// ─── Payout table ─────────────────────────────────────────────────────────────
// Bet types:
//   high   = sum 8-12   → 2x payout
//   low    = sum 2-6    → 2x payout
//   seven  = sum exactly 7 → 5x (hardest)
//   exact  = exact number 2-12 → scales by probability
//   double = both dice same → 4x

const EXACT_MULTIPLIERS = { 2:32, 3:16, 4:11, 5:8, 6:6, 7:5, 8:6, 9:8, 10:11, 11:16, 12:32 };

function parseGuess(input) {
    const s = String(input).toLowerCase().trim();
    if (s === 'high')   return { type: 'high',   value: null };
    if (s === 'low')    return { type: 'low',    value: null };
    if (s === 'seven' || s === '7') return { type: 'seven', value: 7 };
    if (s === 'double') return { type: 'double', value: null };
    const n = parseInt(s);
    if (!isNaN(n) && n >= 2 && n <= 12) return { type: 'exact', value: n };
    return null;
}

function resolveBet(guess, d1, d2) {
    const sum = d1 + d2;
    switch (guess.type) {
        case 'high':   return sum >= 8  && sum <= 12 ? { win: true, multiplier: 2   } : { win: false };
        case 'low':    return sum >= 2  && sum <= 6  ? { win: true, multiplier: 2   } : { win: false };
        case 'seven':  return sum === 7              ? { win: true, multiplier: 5   } : { win: false };
        case 'double': return d1 === d2              ? { win: true, multiplier: 4   } : { win: false };
        case 'exact':  return sum === guess.value    ? { win: true, multiplier: EXACT_MULTIPLIERS[guess.value] || 5 } : { win: false };
        default:       return { win: false };
    }
}

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        badGuess:   '❌ خيار غير صالح. الخيارات: `high` `low` `seven` `double` أو رقم من 2 إلى 12.',
        noMoney:    (n, c) => `❌ رصيدك غير كافٍ. تحتاج **${n.toLocaleString()} ${c}**.`,
        minBet:     (n, c) => `❌ الحد الأدنى للرهان **${n.toLocaleString()} ${c}**.`,
        maxBet:     (n, c) => `❌ الحد الأقصى للرهان **${n.toLocaleString()} ${c}**.`,
        rolled:     'النتيجة',
        sum:        'المجموع',
        yourBet:    'رهانك',
        win:        (n, c, mult) => `🎲 فزت بـ **${n.toLocaleString()} ${c}**! (${mult}x)`,
        lose:       (n, c) => `🎲 خسرت **${n.toLocaleString()} ${c}**!`,
        balance:    'رصيدك الحالي',
        footer:     'النرد',
        betTypes:   '**الخيارات:** `high` (8-12) → 2x | `low` (2-6) → 2x | `seven` (7) → 5x | `double` → 4x | رقم محدد (2-12) → جائزة متغيرة'
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        badGuess:   '❌ Invalid bet type. Options: `high` `low` `seven` `double` or a number 2-12.',
        noMoney:    (n, c) => `❌ Insufficient balance. Need **${n.toLocaleString()} ${c}**.`,
        minBet:     (n, c) => `❌ Minimum bet is **${n.toLocaleString()} ${c}**.`,
        maxBet:     (n, c) => `❌ Maximum bet is **${n.toLocaleString()} ${c}**.`,
        rolled:     'Rolled',
        sum:        'Sum',
        yourBet:    'Your Bet',
        win:        (n, c, mult) => `🎲 You won **${n.toLocaleString()} ${c}**! (${mult}x)`,
        lose:       (n, c) => `🎲 You lost **${n.toLocaleString()} ${c}**!`,
        balance:    'Your Balance',
        footer:     'Dice',
        betTypes:   '**Bet Types:** `high` (8-12) → 2x | `low` (2-6) → 2x | `seven` (7) → 5x | `double` → 4x | exact number (2-12) → variable payout'
    }
};

module.exports = {
    data: {
        name: 'dice',
        description: 'Roll dice and bet on the outcome | العب النرد وراهن على النتيجة',
        default_member_permissions: null,
        options: [
            {
                name: 'bet',
                description: 'Bet type: high/low/seven/double/2-12 | نوع الرهان',
                type: 3,
                required: true,
                choices: [
                    { name: '📈 High (8-12) → 2x',        value: 'high'   },
                    { name: '📉 Low (2-6) → 2x',           value: 'low'    },
                    { name: '7️⃣  Seven (7) → 5x',           value: 'seven'  },
                    { name: '🎯 Double (same) → 4x',        value: 'double' },
                    { name: '2 → 32x',  value: '2'  },
                    { name: '3 → 16x',  value: '3'  },
                    { name: '4 → 11x',  value: '4'  },
                    { name: '5 → 8x',   value: '5'  },
                    { name: '6 → 6x',   value: '6'  },
                    { name: '8 → 6x',   value: '8'  },
                    { name: '9 → 8x',   value: '9'  },
                    { name: '10 → 11x', value: '10' },
                    { name: '11 → 16x', value: '11' },
                    { name: '12 → 32x', value: '12' }
                ]
            },
            { name: 'amount', description: 'Bet amount | مبلغ الرهان', type: 4, required: true, min_value: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled || es.gambling?.dice?.enabled === false) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')], flags: MessageFlags.Ephemeral });
        }

        const betType = interaction.options.getString('bet');
        const bet     = interaction.options.getInteger('amount');
        const cur     = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        const guess = parseGuess(betType);
        if (!guess) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(t.badGuess).setColor('#ED4245')], flags: MessageFlags.Ephemeral });
        }

        // Use slots config for min/max if available, otherwise use global defaults
        const gamblingCfg = es.gambling?.dice || {};
        const minBet = gamblingCfg.minBet || 10;
        const maxBet = gamblingCfg.maxBet || 0;

        if (minBet > 0 && bet < minBet) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(t.minBet(minBet, cur)).setColor('#FEE75C')], flags: MessageFlags.Ephemeral });
        }
        if (maxBet > 0 && bet > maxBet) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(t.maxBet(maxBet, cur)).setColor('#FEE75C')], flags: MessageFlags.Ephemeral });
        }

        const user = getUser(interaction.guildId, interaction.user.id);
          const _diceCdMs = (gamblingCfg.cooldown || 0) * 60000;
          if (_diceCdMs > 0) {
              const _diceLeft = cooldownLeft(user.lastDice || 0, _diceCdMs);
              if (_diceLeft > 0) {
                  return interaction.reply({ embeds: [new EmbedBuilder().setDescription(`⏰ يمكنك اللعب مرة أخرى بعد **${formatTime(_diceLeft)}**.`).setColor('#FEE75C')], flags: MessageFlags.Ephemeral });
              }
          }
          if (_diceCdMs > 0) user.lastDice = Date.now();
        if ((user.wallet || 0) < bet) {
            return interaction.reply({ embeds: [new EmbedBuilder().setDescription(t.noMoney(bet, cur)).setColor('#ED4245')], flags: MessageFlags.Ephemeral });
        }

        const d1     = rollDie();
        const d2     = rollDie();
        const sum    = d1 + d2;
        const result = resolveBet(guess, d1, d2);

        user.wallet = Math.max(0, (user.wallet || 0) - bet);
        let desc, color;

        if (result.win) {
            const winAmt = Math.floor(bet * result.multiplier);
            user.wallet = (user.wallet || 0) + winAmt;
            user.totalEarned = (user.totalEarned || 0) + Math.max(0, winAmt - bet);
            desc  = t.win(winAmt, cur, result.multiplier);
            color = '#57F287';
        } else {
            desc  = t.lose(bet, cur);
            color = '#ED4245';
        }

        saveUser(interaction.guildId, interaction.user.id, user);

        // ── [FIX] Transaction log ─────────────────────────────────────────
        if (result.win) {
            const winAmt = Math.floor(bet * result.multiplier);
            addTransaction(interaction.guildId, interaction.user.id, 'dice_win', winAmt - bet, `Dice: ${betType} | ${d1}+${d2}=${sum}`);
        } else {
            addTransaction(interaction.guildId, interaction.user.id, 'dice_loss', -bet, `Dice: ${betType} | ${d1}+${d2}=${sum}`);
        }

        const betLabel = betType === 'high' ? '📈 High' :
                         betType === 'low'  ? '📉 Low'  :
                         betType === 'seven'? '7️⃣ Seven' :
                         betType === 'double'?'🎯 Double': `#${guess.value}`;

        const embed = new EmbedBuilder()
            .setTitle('🎲 Dice Roll')
            .setDescription(`${diceEmoji(d1)} ${diceEmoji(d2)}\n\n${desc}`)
            .setColor(color)
            .addFields(
                { name: t.rolled,  value: `${diceEmoji(d1)} + ${diceEmoji(d2)} = **${sum}**`, inline: true },
                { name: t.yourBet, value: betLabel, inline: true },
                { name: '💰 Bet',  value: `${bet.toLocaleString()} ${cur}`, inline: true },
                { name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}`, inline: false }
            )
            .setFooter({ text: t.footer })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    
      } catch (err) {
          console.error('[dice] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
