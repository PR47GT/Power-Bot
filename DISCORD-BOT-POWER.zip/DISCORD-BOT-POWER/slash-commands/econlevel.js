const { AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const { getUser, getEconLevelInfo } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

// ── Rank tiers ─────────────────────────────────────────────────────────────────
const TIERS = [
    { min:  0, ar: 'مبتدئ',   en: 'Rookie',   icon: '○', color: '#a1a1aa' },
    { min:  5, ar: 'برونزي',  en: 'Bronze',   icon: '◈', color: '#cd7f32' },
    { min: 10, ar: 'فضي',     en: 'Silver',   icon: '◈', color: '#b0b7c3' },
    { min: 20, ar: 'ذهبي',    en: 'Gold',     icon: '◈', color: '#FFD700' },
    { min: 35, ar: 'بلاتيني', en: 'Platinum', icon: '◈', color: '#5865F2' },
    { min: 50, ar: 'ألماسي',  en: 'Diamond',  icon: '◈', color: '#00d4ff' },
    { min: 75, ar: 'أسطوري',  en: 'Legend',   icon: '◈', color: '#FF6B35' },
];

function getTier(level) {
    let t = TIERS[0];
    for (const tier of TIERS) { if (level >= tier.min) t = tier; }
    return t;
}

// ── Parse Discord custom emoji from string ─────────────────────────────────────
// Returns { emojiImg, cleanText } where emojiImg is a loaded Image or null
async function parseDiscordEmoji(str) {
    if (!str) return { emojiImg: null, cleanText: '' };
    const match = String(str).match(/<a?:(\w+):(\d+)>/);
    if (!match) {
        return { emojiImg: null, cleanText: String(str).trim() };
    }
    const emojiId  = match[2];
    const isAnimated = str.startsWith('<a:');
    // Use .png even for animated — canvas can't play GIF, but the first frame PNG works
    const url = `https://cdn.discordapp.com/emojis/${emojiId}.png?size=32`;
    let emojiImg = null;
    try { emojiImg = await loadImage(url); } catch { /* fallback to no image */ }
    // Remove the emoji token from the text
    const cleanText = String(str).replace(/<a?:\w+:\d+>/g, '').replace(/\s+/g, ' ').trim();
    return { emojiImg, cleanText };
}

function hexToRgba(hex, alpha) {
    const r = parseInt(hex.slice(1, 3), 16);
    const g = parseInt(hex.slice(3, 5), 16);
    const b = parseInt(hex.slice(5, 7), 16);
    return `rgba(${r},${g},${b},${alpha})`;
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function clipCircle(ctx, cx, cy, r) {
    ctx.beginPath();
    ctx.arc(cx, cy, r, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
}

// ── Helper: draw text with optional emoji image before it ──────────────────────
function drawTextWithEmoji(ctx, emojiImg, text, x, y, emojiSize = 18) {
    if (emojiImg) {
        ctx.drawImage(emojiImg, x, y - emojiSize + 3, emojiSize, emojiSize);
        ctx.fillText(text, x + emojiSize + 4, y);
    } else {
        ctx.fillText(text, x, y);
    }
}

// ── Main card renderer ─────────────────────────────────────────────────────────
async function generateLevelCard({
    username, avatarURL, level,
    currentXP, xpNeeded, totalXP, progressPct,
    tier, nextReward, lang, currencyRaw,
}) {
    const W = 860, H = 220;
    const canvas = createCanvas(W, H);
    const ctx    = canvas.getContext('2d');
    const tc     = tier.color;
    const pct    = Math.max(0, Math.min(100, progressPct));
    const tierName = lang === 'ar' ? tier.ar : tier.en;
    const xpLeft   = xpNeeded - currentXP;

    // Parse currency emoji (custom Discord emoji → load PNG from CDN)
    const { emojiImg: curEmojiImg, cleanText: curText } = await parseDiscordEmoji(currencyRaw || '');
    const cur = curText || 'Coins';

    // ── Background ────────────────────────────────────────────────────────────
    const bg = ctx.createLinearGradient(0, 0, W, H);
    bg.addColorStop(0, '#1a1c24');
    bg.addColorStop(1, '#111318');
    roundRect(ctx, 0, 0, W, H, 22);
    ctx.fillStyle = bg;
    ctx.fill();

    // glow corner
    const gl = ctx.createRadialGradient(W * 0.85, 0, 0, W * 0.85, 0, W * 0.55);
    gl.addColorStop(0, hexToRgba(tc, 0.1));
    gl.addColorStop(1, 'transparent');
    roundRect(ctx, 0, 0, W, H, 22);
    ctx.fillStyle = gl;
    ctx.fill();

    // border
    roundRect(ctx, 0.75, 0.75, W - 1.5, H - 1.5, 22);
    ctx.strokeStyle = hexToRgba(tc, 0.35);
    ctx.lineWidth   = 1.5;
    ctx.stroke();

    // top accent line
    const al = ctx.createLinearGradient(0, 0, W, 0);
    al.addColorStop(0,   'transparent');
    al.addColorStop(0.3, hexToRgba(tc, 0.85));
    al.addColorStop(0.7, hexToRgba(tc, 0.85));
    al.addColorStop(1,   'transparent');
    ctx.beginPath(); ctx.moveTo(22, 1); ctx.lineTo(W - 22, 1);
    ctx.strokeStyle = al; ctx.lineWidth = 2; ctx.stroke();

    // ── Avatar ────────────────────────────────────────────────────────────────
    const avCX = 62, avCY = 108, avR = 50;
    try {
        const safeURL = avatarURL
            .replace(/\.webp(\?|$)/, '.png$1')
            .replace(/\.gif(\?|$)/,  '.png$1');
        const img = await loadImage(safeURL);

        // glow ring
        ctx.save();
        ctx.shadowColor = hexToRgba(tc, 0.7);
        ctx.shadowBlur  = 18;
        ctx.beginPath(); ctx.arc(avCX, avCY, avR + 3, 0, Math.PI * 2);
        ctx.strokeStyle = tc; ctx.lineWidth = 2.5; ctx.stroke();
        ctx.restore();

        // clip + draw
        ctx.save();
        clipCircle(ctx, avCX, avCY, avR);
        ctx.drawImage(img, avCX - avR, avCY - avR, avR * 2, avR * 2);
        ctx.restore();
    } catch {
        ctx.save();
        ctx.beginPath(); ctx.arc(avCX, avCY, avR, 0, Math.PI * 2);
        ctx.fillStyle = '#23272A'; ctx.fill();
        ctx.font = 'bold 30px sans-serif';
        ctx.fillStyle = tc; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
        ctx.fillText((username[0] || '?').toUpperCase(), avCX, avCY);
        ctx.restore();
    }

    // level badge
    const bx = avCX + 34, by = avCY + 34;
    ctx.save();
    ctx.shadowColor = hexToRgba(tc, 0.9); ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.arc(bx, by, 16, 0, Math.PI * 2);
    ctx.fillStyle = tc; ctx.fill();
    ctx.restore();
    ctx.font = 'bold 13px sans-serif';
    ctx.fillStyle = '#111'; ctx.textAlign = 'center'; ctx.textBaseline = 'middle';
    ctx.fillText(String(level), bx, by);

    // ── Right content ─────────────────────────────────────────────────────────
    const CX = 134; // content start X

    // Username
    ctx.textAlign = 'left'; ctx.textBaseline = 'alphabetic';
    ctx.font = 'bold 26px sans-serif';
    ctx.fillStyle = '#ffffff';
    ctx.fillText(username, CX, 52);

    // Tier badge (top right)
    const tbW = 120, tbH = 28, tbX = W - tbW - 22, tbY = 22;
    roundRect(ctx, tbX, tbY, tbW, tbH, 14);
    ctx.fillStyle = hexToRgba(tc, 0.15); ctx.fill();
    roundRect(ctx, tbX, tbY, tbW, tbH, 14);
    ctx.strokeStyle = hexToRgba(tc, 0.55); ctx.lineWidth = 1; ctx.stroke();
    ctx.font = 'bold 12px sans-serif';
    ctx.fillStyle = tc; ctx.textAlign = 'center';
    ctx.fillText(tierName.toUpperCase(), tbX + tbW / 2, tbY + 18);

    // ── Stats grid ────────────────────────────────────────────────────────────
    // Row 1: LEVEL | XP PROGRESS | TOTAL XP | REWARD (if any)
    const stats = [
        {
            label: lang === 'ar' ? 'المستوى'  : 'LEVEL',
            value: String(level),
            color: '#ffffff',
        },
        {
            label: lang === 'ar' ? 'التقدم'   : 'XP PROGRESS',
            value: `${currentXP.toLocaleString()} / ${xpNeeded.toLocaleString()}`,
            color: '#ffffff',
        },
        {
            label: lang === 'ar' ? 'إجمالي XP' : 'TOTAL XP',
            value: `${totalXP.toLocaleString()} XP`,
            color: '#ffffff',
        },
    ];

    // rewardEmoji used when drawing the reward stat value inline
    let rewardLabel = '';
    if (nextReward) {
        rewardLabel = lang === 'ar'
            ? `مكافأة Lv ${nextReward.level}`
            : `Lv ${nextReward.level} REWARD`;
        stats.push({
            label:        rewardLabel,
            value:        `${nextReward.coins.toLocaleString()} ${cur}`,
            color:        '#FFD700',
            useEmojiImg:  true,   // draw curEmojiImg before value
        });
    }

    let sx = CX;
    const statY  = 72;
    const colW   = stats.length === 4 ? (W - CX - 28) / 4 : 140;

    for (let i = 0; i < stats.length; i++) {
        const s = stats[i];

        ctx.font = '10px sans-serif';
        ctx.fillStyle = 'rgba(255,255,255,0.38)';
        ctx.textAlign = 'left';
        ctx.fillText(s.label, sx, statY);

        ctx.font = 'bold 20px sans-serif';
        ctx.fillStyle = s.color;

        if (s.useEmojiImg && curEmojiImg) {
            // Draw emoji image + text side by side
            drawTextWithEmoji(ctx, curEmojiImg,
                `${nextReward.coins.toLocaleString()} ${cur}`,
                sx, statY + 22, 20
            );
        } else {
            ctx.fillText(s.value, sx, statY + 22);
        }

        sx += colW;

        if (i < stats.length - 1) {
            ctx.beginPath();
            ctx.moveTo(sx - 12, statY - 4);
            ctx.lineTo(sx - 12, statY + 26);
            ctx.strokeStyle = 'rgba(255,255,255,0.1)';
            ctx.lineWidth = 1;
            ctx.stroke();
        }
    }

    // ── Progress bar ──────────────────────────────────────────────────────────
    const barX = CX, barY = 128, barW = W - CX - 24, barH = 14, barR = 7;

    // label + pct
    ctx.font = '10px sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.35)';
    ctx.textAlign = 'left';
    ctx.fillText(
        lang === 'ar'
            ? `التقدم للمستوى ${level + 1}`
            : `PROGRESS TO LEVEL ${level + 1}`,
        barX, barY - 7
    );
    ctx.textAlign = 'right';
    ctx.fillStyle = tc;
    ctx.fillText(`${pct}%`, barX + barW, barY - 7);

    // track
    roundRect(ctx, barX, barY, barW, barH, barR);
    ctx.fillStyle = 'rgba(255,255,255,0.07)'; ctx.fill();

    // fill
    const fillW = Math.max(barR * 2, (pct / 100) * barW);
    const barGr = ctx.createLinearGradient(barX, 0, barX + fillW, 0);
    barGr.addColorStop(0, hexToRgba(tc, 0.65));
    barGr.addColorStop(1, tc);
    roundRect(ctx, barX, barY, fillW, barH, barR);
    ctx.save();
    ctx.shadowColor = hexToRgba(tc, 0.65); ctx.shadowBlur = 8;
    ctx.fillStyle = barGr; ctx.fill();
    ctx.restore();

    // shine
    const shine = ctx.createLinearGradient(barX, barY, barX, barY + barH / 2);
    shine.addColorStop(0, 'rgba(255,255,255,0.18)');
    shine.addColorStop(1, 'transparent');
    roundRect(ctx, barX, barY, fillW, barH / 2, barR);
    ctx.fillStyle = shine; ctx.fill();

    // end dot
    ctx.save();
    ctx.shadowColor = tc; ctx.shadowBlur = 10;
    ctx.beginPath(); ctx.arc(barX + fillW, barY + barH / 2, 7, 0, Math.PI * 2);
    ctx.fillStyle = tc; ctx.fill();
    ctx.restore();

    // remaining XP — bigger and clearer
    ctx.font = 'bold 12px sans-serif';
    ctx.fillStyle = 'rgba(255,255,255,0.55)';
    ctx.textAlign = 'left';
    ctx.fillText(
        lang === 'ar'
            ? `${xpLeft.toLocaleString()} XP متبقية للمستوى ${level + 1}`
            : `${xpLeft.toLocaleString()} XP remaining to Level ${level + 1}`,
        barX, barY + barH + 17
    );

    return canvas.toBuffer('image/png');
}

// ── Discord command ────────────────────────────────────────────────────────────
module.exports = {
    data: {
        name: 'econlevel',
        description: 'View economy level & XP progress | عرض المستوى الاقتصادي',
        default_member_permissions: null,
        options: [
            {
                name: 'user',
                description: 'Target member | عضو معين',
                type: 6,
                required: false
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            await interaction.deferReply();

            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const es   = loadEconomySettings();

            if (!es.enabled) {
                const msg = lang === 'ar'
                    ? '⚠️ نظام الاقتصاد معطل حالياً.'
                    : '⚠️ Economy system is currently disabled.';
                return interaction.editReply(msg);
            }

            const target  = interaction.options.getUser('user') || interaction.user;
            const user    = getUser(interaction.guildId, target.id);
            const totalXP = user.econXP || 0;
            const { level, currentXP, xpNeeded, progressPct } = getEconLevelInfo(totalXP);
            const tier    = getTier(level);

            // next reward — find first reward above current level
            const levelRewards = es.levelRewards || [];
            const nrEntry = levelRewards.find(r => r.level > level);
            const nextReward = nrEntry
                ? { level: nrEntry.level, coins: nrEntry.reward || nrEntry.coins || 0 }
                : null;

            const avatarURL = target.displayAvatarURL({
                size:        256,
                forceStatic: true,
                extension:   'png',
            });

            const buffer = await generateLevelCard({
                username:     target.username,
                avatarURL,
                level,
                currentXP,
                xpNeeded,
                totalXP,
                progressPct,
                tier,
                nextReward,
                lang,
                // Pass the full currency string including custom emoji e.g. "<:coin:123456> Coins"
                currencyRaw: `${es.currency || ''} ${es.currencyName || 'Coins'}`.trim(),
            });

            const attachment = new AttachmentBuilder(buffer, { name: 'level-card.png' });
            return interaction.editReply({ files: [attachment] });

        } catch (err) {
            console.error('[econlevel] error:', err);
            const msg = '❌ ' + (settings?.botLanguage === 'ar'
                ? 'حدث خطأ، يرجى المحاولة لاحقاً.'
                : 'An error occurred, please try again.');
            if (interaction.deferred || interaction.replied) {
                await interaction.editReply(msg).catch(() => {});
            } else {
                await interaction.reply({ content: msg, flags: 64 }).catch(() => {});
            }
        }
    }
};
