const { PermissionFlagsBits, MessageFlags, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

function loadLevelData() {
    const p = path.join(__dirname, '../levelData.json');
    if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch(e) { return {}; }
    }
    return {};
}

function saveLevelData(data) {
    const p = path.join(__dirname, '../levelData.json');
    fs.writeFileSync(p, JSON.stringify(data, null, 2), 'utf8');
}

function calcLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp));
}

// ── Translations ────────────────────────────────────────────────────────────
const T = {
    ar: {
        disabled:       '⚠️ هذا الأمر معطل حالياً.',
        notFound:       '❌ العضو غير موجود في السيرفر.',
        title:          '✅ تم تحديث XP بنجاح',
        description:    (name) => `تم تحديث XP لـ **${name}**`,
        fieldType:      'النوع',
        fieldNewXP:     'XP الجديد',
        fieldNewLevel:  'المستوى الجديد',
        fieldChanges:   'التغييرات',
        typeChat:       'XP الشات',
        typeVoice:      'XP الصوت',
        typeBoth:       'XP الشات والصوت',
        chatLine:       (o, n, s) => `شات XP:  ${o} ← ${n} (${s})`,
        voiceLine:      (o, n, s) => `صوت XP: ${o} ← ${n} (${s})`,
        footer:         (user, time) => `تم التحديث بواسطة ${user} • اليوم الساعة ${time}`,
        error:          (msg) => `❌ حدث خطأ: ${msg || 'خطأ غير معروف'}`
    },
    en: {
        disabled:       '⚠️ This command is currently disabled.',
        notFound:       '❌ Member not found in the server.',
        title:          '✅ XP Updated Successfully',
        description:    (name) => `Updated XP for **${name}**`,
        fieldType:      'Type',
        fieldNewXP:     'New XP',
        fieldNewLevel:  'New Level',
        fieldChanges:   'Changes',
        typeChat:       'Chat XP',
        typeVoice:      'Voice XP',
        typeBoth:       'Chat and Voice XP',
        chatLine:       (o, n, s) => `Chat XP:  ${o} → ${n} (${s})`,
        voiceLine:      (o, n, s) => `Voice XP: ${o} → ${n} (${s})`,
        footer:         (user, time) => `Updated by ${user} • Today at ${time}`,
        error:          (msg) => `❌ Error: ${msg || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'setxp',
        description: '✏️ Set XP for a member | تعيين XP لعضو',
        default_member_permissions: PermissionFlagsBits.Administrator.toString(),
        options: [
            {
                name: 'user',
                description: 'The member | العضو',
                type: 6,
                required: true
            },
            {
                name: 'type',
                description: 'Type of XP | نوع XP',
                type: 3,
                required: true,
                choices: [
                    { name: 'Chat XP  |  XP الشات',        value: 'chat'  },
                    { name: 'Voice XP  |  XP الصوت',       value: 'voice' },
                    { name: 'Both  |  كلاهما',              value: 'both'  }
                ]
            },
            {
                name: 'amount',
                description: 'Amount of XP | كمية XP',
                type: 4,
                required: true,
                min_value: 0
            }
        ]
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const isAr = settings.botLanguage === 'ar';
            const t    = isAr ? T.ar : T.en;

            if (commandConfig && !commandConfig.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }

            const targetUser = interaction.options.getUser('user');
            const xpType     = interaction.options.getString('type');
            const amount     = interaction.options.getInteger('amount');

            if (!targetUser) {
                return await interaction.editReply({ content: t.notFound });
            }

            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            if (!targetMember) {
                return await interaction.editReply({ content: t.notFound });
            }

            // ── Load & migrate data ───────────────────────────────────────
            const levelData = loadLevelData();
            if (!levelData[targetUser.id]) {
                levelData[targetUser.id] = { chatXP: 0, voiceXP: 0, chatLevel: 0, voiceLevel: 0 };
            }
            const userData = levelData[targetUser.id];

            if (userData.xp !== undefined && userData.chatXP === undefined) {
                userData.chatXP    = userData.xp || 0;
                userData.voiceXP   = 0;
                userData.chatLevel  = calcLevel(userData.chatXP);
                userData.voiceLevel = 0;
                delete userData.xp;
            }
            if (userData.chatXP  === undefined) userData.chatXP  = 0;
            if (userData.voiceXP === undefined) userData.voiceXP = 0;

            // ── Record old values ─────────────────────────────────────────
            const oldChatXP  = userData.chatXP;
            const oldVoiceXP = userData.voiceXP;

            // ── Apply ─────────────────────────────────────────────────────
            if (xpType === 'chat'  || xpType === 'both') {
                userData.chatXP    = amount;
                userData.chatLevel = calcLevel(amount);
            }
            if (xpType === 'voice' || xpType === 'both') {
                userData.voiceXP    = amount;
                userData.voiceLevel = calcLevel(amount);
            }
            levelData[targetUser.id] = userData;
            saveLevelData(levelData);

            // ── Build embed ───────────────────────────────────────────────
            const typeLabelMap = {
                chat:  t.typeChat,
                voice: t.typeVoice,
                both:  t.typeBoth
            };
            const typeLabel = typeLabelMap[xpType];

            const newXP  = xpType === 'voice' ? userData.voiceXP : userData.chatXP;
            const newLvl = xpType === 'voice' ? userData.voiceLevel : userData.chatLevel;

            const chatDiff  = userData.chatXP  - oldChatXP;
            const voiceDiff = userData.voiceXP - oldVoiceXP;

            let changesText = '';
            if (xpType === 'chat' || xpType === 'both') {
                const sign = chatDiff >= 0 ? `+${chatDiff}` : `${chatDiff}`;
                changesText += t.chatLine(oldChatXP, userData.chatXP, sign) + '\n';
            }
            if (xpType === 'voice' || xpType === 'both') {
                const sign = voiceDiff >= 0 ? `+${voiceDiff}` : `${voiceDiff}`;
                changesText += t.voiceLine(oldVoiceXP, userData.voiceXP, sign) + '\n';
            }

            const now     = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
            const memberName = targetMember.displayName || targetUser.username;

            const embed = new EmbedBuilder()
                .setColor('#57F287')
                .setTitle(t.title)
                .setDescription(t.description(memberName))
                .addFields(
                    { name: t.fieldType,     value: typeLabel,                 inline: true },
                    { name: t.fieldNewXP,    value: newXP.toLocaleString(),    inline: true },
                    { name: t.fieldNewLevel, value: `${newLvl}`,              inline: true },
                    { name: t.fieldChanges,  value: `\`\`\`\n${changesText}\`\`\`` }
                )
                .setFooter({
                    text:    t.footer(interaction.user.username, timeStr),
                    iconURL: interaction.user.displayAvatarURL()
                });

            await interaction.editReply({ embeds: [embed] });

            if (commandConfig && commandConfig.deleteResponse) {
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 10000);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر /setxp:', error.message);
            const isAr = settings?.botLanguage === 'ar';
            const errMsg = isAr
                ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                : `❌ Error: ${error.message || 'Unknown error'}`;
            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ content: errMsg });
                } else {
                    await interaction.reply({ content: errMsg, flags: MessageFlags.Ephemeral });
                }
            } catch(e) {}
        }
    }
};
