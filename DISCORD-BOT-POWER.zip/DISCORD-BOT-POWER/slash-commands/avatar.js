const { EmbedBuilder } = require('discord.js');

const T = {
    ar: {
        title: (username) => ` الصورة الرمزية لـ ${username}`,
        footer: (requester) => `بناءً على طلب ${requester}`,
        userOption: 'المستخدم',
        userOptionDesc: 'المستخدم (اختياري)',
    },
    en: {
        title: (username) => ` Avatar of ${username}`,
        footer: (requester) => `Requested by ${requester}`,
        userOption: 'user',
        userOptionDesc: 'User (optional)',
    },
};

module.exports = {
    name: 'avatar',
    description: 'عرض الصورة الرمزية للمستخدم | Display user avatar',
    description_localizations: {
        enUS: 'Display user avatar',
        ar: 'عرض الصورة الرمزية للمستخدم',
    },
    options: [
        { 
            name: 'user', 
            name_localizations: {
                ar: 'مستخدم',
                enUS: 'user',
            },
            type: 6, 
            description: 'المستخدم (اختياري) | User (optional)',
            description_localizations: {
                ar: 'المستخدم الذي تريد عرض صورته الرمزية (اختياري)',
                enUS: 'The user whose avatar you want to display (optional)',
            },
            required: false 
        }
    ],

    async execute(interaction, client, settings, commandConfig) {
        // تحديد اللغة من الإعدادات
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        // الحصول على المستخدم المستهدف
        const targetUser = interaction.options.getUser('user') || interaction.user;
        
        // الحصول على رابط الصورة الرمزية
        const avatarUrl = targetUser.displayAvatarURL({ 
            dynamic: true,  // يدعم الصور المتحركة GIF
            size: 4096      // حجم كبير للصورة في المنتصف
        });
        
        // إنشاء Embed - صورة واحدة كبيرة في المنتصف فقط
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle(t.title(targetUser.username))
            .setImage(avatarUrl)  // صورة كبيرة في المنتصف
            .setFooter({ 
                text: t.footer(interaction.user.username),
                iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 })
            })
            .setTimestamp();
        
        // إرسال الرد
        await interaction.reply({ embeds: [embed] });
        
        // حذف الرد بعد 5 ثواني إذا كان الإعداد مفعلاً
        if (commandConfig?.deleteResponse) {
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch(e) {
                    // تجاهل الأخطاء
                }
            }, 5000);
        }
    },
};