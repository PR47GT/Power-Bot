const { MessageFlags, EmbedBuilder } = require('discord.js');

module.exports = {
    data: {
        name: 'ping',
        description: '🏓 عرض سرعة الاتصال'
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            const start = Date.now();
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            const roundtrip = Date.now() - start;

            const wsPing = client.ws.ping;

            // تحديد اللون حسب سرعة الاتصال
            let color;
            if (wsPing < 100) color = 0x57F287;       // أخضر — ممتاز
            else if (wsPing < 200) color = 0xFEE75C;  // أصفر — جيد
            else color = 0xED4245;                     // أحمر — بطيء

            const embed = new EmbedBuilder()
                .setColor(color)
                .setTitle('🏓 Pong!')
                .addFields(
                    { name: '📡 Roundtrip', value: `\`${roundtrip}ms\``, inline: true },
                    { name: '💓 WebSocket', value: `\`${wsPing}ms\``,    inline: true },
                )
                .setTimestamp();

            if (commandConfig?.deleteResponse) {
                await interaction.editReply({ embeds: [embed] });
                setTimeout(() => {
                    interaction.deleteReply().catch(() => null);
                }, 5000);
            } else {
                await interaction.editReply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('❌ خطأ في أمر ping:', error.message);
            try {
                const errMsg = { content: `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}` };
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply(errMsg);
                } else if (!interaction.replied) {
                    await interaction.reply({ ...errMsg, flags: MessageFlags.Ephemeral });
                }
            } catch(e) {
                console.warn('❌ لم يتمكن من إرسال رسالة الخطأ:', e.message);
            }
        }
    }
};
