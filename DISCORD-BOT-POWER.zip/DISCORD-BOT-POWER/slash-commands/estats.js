const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, getEconLevelInfo } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:    '⚠️ نظام الاقتصاد معطل حالياً.',
        noAccount:   '❌ هذا العضو لا يملك حساباً.',
        title:       (name) => ` إحصائيات ${name}`,
        wallet:      'المحفظة',
        bank:        'البنك',
        total:       'الإجمالي',
        totalEarned: 'إجمالي المكسوب',
        level:       'المستوى الاقتصادي',
        xp:          'نقاط الخبرة',
        streak:      'سلسلة الحضور',
        workCount:   'مرات العمل',
        buyCount:    'مرات الشراء',
        totalSpent:  'إجمالي الإنفاق',
        chestsOpened:'صناديق مفتوحة',
        itemsCrafted:'عناصر مصنوعة',
        questsDone:  'مهام مكتملة',
        auctionsWon: 'مزادات فائزة',
        footer:      'الإحصائيات الاقتصادية'
    },
    en: {
        disabled:    '⚠️ Economy system is currently disabled.',
        noAccount:   '❌ This member has no account.',
        title:       (name) => ` ${name}'s Economy Stats`,
        wallet:      'Wallet',
        bank:        'Bank',
        total:       'Total',
        totalEarned: 'Total Earned',
        level:       'Economy Level',
        xp:          'XP Points',
        streak:      'Daily Streak',
        workCount:   'Times Worked',
        buyCount:    'Items Bought',
        totalSpent:  'Total Spent',
        chestsOpened:'Chests Opened',
        itemsCrafted:'Items Crafted',
        questsDone:  'Quests Done',
        auctionsWon: 'Auctions Won',
        footer:      'Economy Statistics'
    }
};

module.exports = {
    data: {
        name: 'estats',
        description: 'View detailed economy statistics | عرض الإحصائيات الاقتصادية',
        default_member_permissions: null,
        options: [
            {
                name: 'user',
                description: 'Target member | عضو معين',
                type: 6,
                required: false
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang   = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t      = T[lang];
        const es     = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const target  = interaction.options.getUser('user') || interaction.user;
        const user    = getUser(interaction.guildId, target.id);
        const cur     = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        const stats   = user.stats || {};
        const totalXP = user.econXP || 0;
        const { level, currentXP, xpNeeded } = getEconLevelInfo(totalXP);

        const wallet = (user.wallet || 0).toLocaleString();
        const bank   = (user.bank   || 0).toLocaleString();
        const total  = ((user.wallet || 0) + (user.bank || 0)).toLocaleString();

        const embed = new EmbedBuilder()
           .setAuthor({
    name:    t.title(target.username),
    iconURL: target.displayAvatarURL({ size: 128 })
})
            .setColor('#5865F2')
            .addFields(
                { name: `💰 ${t.wallet}`,      value: `${wallet} ${cur}`,  inline: true },
                { name: `🏦 ${t.bank}`,         value: `${bank} ${cur}`,   inline: true },
                { name: `💎 ${t.total}`,        value: `${total} ${cur}`,  inline: true },
                { name: `📈 ${t.totalEarned}`,  value: `${(user.totalEarned || 0).toLocaleString()} ${cur}`, inline: true },
                { name: `⭐ ${t.level}`,        value: `**${level}** (${currentXP}/${xpNeeded} XP)`, inline: true },
                { name: `🔥 ${t.streak}`,       value: `**${user.dailyStreak || 0}** ${lang === 'ar' ? 'يوم' : 'days'}`, inline: true },
                { name: `💼 ${t.workCount}`,    value: `${(stats.workCount    || 0).toLocaleString()}`, inline: true },
                { name: `🛒 ${t.buyCount}`,     value: `${(stats.buyCount     || 0).toLocaleString()}`, inline: true },
                { name: `💸 ${t.totalSpent}`,   value: `${(stats.totalSpent   || 0).toLocaleString()} ${cur}`, inline: true },
                { name: `📦 ${t.chestsOpened}`, value: `${(stats.chestsOpened || 0).toLocaleString()}`, inline: true },
                { name: `🔨 ${t.itemsCrafted}`, value: `${(stats.itemsCrafted || 0).toLocaleString()}`, inline: true },
                { name: `📋 ${t.questsDone}`,   value: `${(stats.questsDone   || 0).toLocaleString()}`, inline: true }
            )
            .setFooter({ text: t.footer })
            .setTimestamp();

        return interaction.reply({ embeds: [embed] });
    
      } catch (err) {
          console.error('[estats] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
