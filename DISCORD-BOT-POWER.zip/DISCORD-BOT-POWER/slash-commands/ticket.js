const {
    EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle,
    StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
    ModalBuilder, TextInputBuilder, TextInputStyle,
    UserSelectMenuBuilder,
    ChannelType, PermissionFlagsBits, AttachmentBuilder, MessageFlags
} = require('discord.js');
const fs = require('fs');
const path = require('path');

const TICKET_FILE = path.join(__dirname, '..', 'ticketSystem.json');
const SETTINGS_FILE = path.join(__dirname, '..', 'data.json');

function loadBotLanguage() {
    try {
        const data = JSON.parse(fs.readFileSync(SETTINGS_FILE, 'utf8'));
        return data.botLanguage === 'en' ? 'en' : 'ar';
    } catch(e) {
        return 'ar';
    }
}

// In-memory lock to prevent race conditions (multiple simultaneous ticket opens)
const pendingTicketUsers = new Set();

// Cooldown tracking for Admin PM Reminder (key: channelId → timestamp)
const adminReminderCooldowns = new Map();

// ==================== Helpers ====================

function loadTicketSettings() {
    if (fs.existsSync(TICKET_FILE)) {
        try { return JSON.parse(fs.readFileSync(TICKET_FILE, 'utf8')); } catch(e) {}
    }
    return { categories: [], permissions: {}, openTickets: {} };
}

function saveTicketSettings(data) {
    fs.writeFileSync(TICKET_FILE, JSON.stringify(data, null, 2), 'utf8');
}

function setOpenTicket(channelId, data) {
    const ts = loadTicketSettings();
    if (!ts.openTickets) ts.openTickets = {};
    ts.openTickets[channelId] = data;
    saveTicketSettings(ts);
}

function removeOpenTicket(channelId) {
    const ts = loadTicketSettings();
    if (ts.openTickets && ts.openTickets[channelId]) {
        delete ts.openTickets[channelId];
        saveTicketSettings(ts);
    }
}

// ==================== Auto-Close Idle Tickets ====================
let autoCloseIntervalHandle = null;

function startAutoCloseChecker(client) {
    if (autoCloseIntervalHandle) return; // يعمل بالفعل، لا تكرر
    autoCloseIntervalHandle = setInterval(() => checkIdleTickets(client), 5 * 60 * 1000); // فحص كل 5 دقائق
    checkIdleTickets(client); // فحص فوري عند تشغيل البوت
}

async function checkIdleTickets(client) {
    const ts = loadTicketSettings();
    if (!ts.autoCloseEnabled) return;

    const guild = client.guilds.cache.first();
    if (!guild) return;

    const idleMs = (Number(ts.autoCloseHours) || 24) * 60 * 60 * 1000;
    const warnMs = (Number(ts.autoCloseWarningMinutes) || 60) * 60 * 1000;
    const openTickets = ts.openTickets || {};

    for (const channelId of Object.keys(openTickets)) {
        const ticket = openTickets[channelId];
        if (!ticket || !ticket.open || ticket.pending) continue;

        try {
            const channel = guild.channels.cache.get(channelId) || await guild.channels.fetch(channelId).catch(() => null);
            if (!channel) continue;

            const lastMsgCollection = await channel.messages.fetch({ limit: 1 }).catch(() => null);
            const lastMsg = lastMsgCollection ? lastMsgCollection.first() : null;
            const lastActivityTime = lastMsg ? lastMsg.createdTimestamp : new Date(ticket.createdAt || Date.now()).getTime();
            const idleFor = Date.now() - lastActivityTime;

            if (idleFor >= idleMs) {
                await autoCloseIdleTicket(client, guild, channel, ticket, ts);
            } else if (idleFor >= (idleMs - warnMs)) {
                if (!ticket.idleWarned) {
                    const isArWarn = loadBotLanguage() !== 'en';
                    const warnMsg = ts.autoCloseWarningMessage
                        ? ts.autoCloseWarningMessage
                        : (isArWarn
                            ? '⚠️ هذه التذكرة ستُغلق تلقائيًا قريبًا بسبب عدم النشاط. يرجى الرد للإبقاء عليها مفتوحة.'
                            : '⚠️ This ticket will be automatically closed soon due to inactivity. Please reply to keep it open.');
                    try {
                        await channel.send({ content: `<@${ticket.userId}> ${warnMsg}` });
                    } catch(e) {}
                    ticket.idleWarned = true;
                    setOpenTicket(channelId, ticket);
                }
            } else if (ticket.idleWarned) {
                ticket.idleWarned = false;
                setOpenTicket(channelId, ticket);
            }
        } catch(e) {
            console.error('❌ خطأ في فحص خمول التذكرة:', channelId, e.message);
        }
    }
}

async function autoCloseIdleTicket(client, guild, channel, ticket, ts) {
    const isAr = loadBotLanguage() !== 'en';

    try {
        await channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: false });
    } catch(e) {}

    try {
        const currentName = channel.name;
        const newName = currentName.replace(/🎫/g, '🔒');
        if (newName !== currentName) channel.setName(newName).catch(() => {});
    } catch(e) {}

    ticket.open = false;
    ticket.idleWarned = false;
    setOpenTicket(channel.id, ticket);

    const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`ticket_reopen_${channel.id}`).setLabel(isAr ? 'فتح' : 'Open').setEmoji('🔓').setStyle(ButtonStyle.Secondary),
        new ButtonBuilder().setCustomId(`ticket_delete_${channel.id}`).setLabel(isAr ? 'حذف' : 'Delete').setEmoji('🗑️').setStyle(ButtonStyle.Danger)
    );

    const closedEmbed = new EmbedBuilder()
        .setTitle(isAr ? '🔒 تم إغلاق التذكرة تلقائيًا' : '🔒 Ticket Auto-Closed')
        .setDescription(isAr
            ? 'تم إغلاق هذه التذكرة تلقائيًا بسبب عدم النشاط لفترة طويلة.'
            : 'This ticket was automatically closed due to prolonged inactivity.')
        .setColor('#ED4245')
        .setTimestamp();

    try { await channel.send({ embeds: [closedEmbed], components: [actionRow] }); } catch(e) {}

    await autoSaveTranscript(guild, channel, ticket, ts);
}

// ==================== Auto-Save Transcript on Close ====================
async function autoSaveTranscript(guild, channel, ticket, ts) {
    try {
        const categories = ts.categories || [];
        const cat = categories[ticket.categoryIndex];
        if (!cat || !cat.logChannelId) return; // لازم يكون فيه روم لوج محدد بالفئة

        const logCh = guild.channels.cache.get(cat.logChannelId) || await guild.channels.fetch(cat.logChannelId).catch(() => null);
        if (!logCh) return;

        const openedBy = await guild.members.fetch(ticket.userId).catch(() => null);
        const ticketInfoText = `فُتحت بواسطة: ${openedBy ? openedBy.user.tag : 'غير معروف'} | الفئة: ${cat.name || 'غير محددة'}`;

        const htmlBuffer = await generateTranscriptHTML(channel, ticketInfoText);
        const transcriptFile = new AttachmentBuilder(htmlBuffer, { name: `transcript-${channel.name}.html` });

        // ── رفع الملف بروم مخفي بدل إرفاقه مباشرة (حتى لا يظهر الكود الخام بالروم) ─
        let fileUrl = null;
        try {
            const storageChannel = await getOrCreateStorageChannel(guild);
            if (storageChannel) {
                const storageMsg = await storageChannel.send({ files: [transcriptFile] });
                fileUrl = storageMsg.attachments.first()?.url || null;
            }
        } catch(e) {}

       // lang يفترض إنه موجود عندك مسبقاً، مثلاً: guildConfig.lang أو ticket.lang ("ar" أو "en")
const lang = ticket.lang || 'en'; // خليه ياخذ القيمة الفعلية عندك

const texts = {
    en: {
        title: '📋 Auto Ticket Transcript',
        openedBy: 'Opened By',
        category: 'Category',
        channel: 'Channel',
        unknownUser: 'Unknown',
        unknownCat: 'Unknown',
        download: '⬇️ Download Transcript'
    },
    ar: {
        title: '📋 نسخة تلقائية عند إغلاق التذكرة',
        openedBy: 'فُتحت بواسطة',
        category: 'الفئة',
        channel: 'القناة',
        unknownUser: 'غير معروف',
        unknownCat: 'غير محددة',
        download: '⬇️ تحميل النسخة'
    }
};

const t = texts[lang];

const logEmbed = new EmbedBuilder()
    .setTitle(t.title)
    .setColor('#5865F2')
    .addFields(
        { name: t.openedBy, value: ticket.userId ? `<@${ticket.userId}>` : t.unknownUser, inline: true },
        { name: t.category, value: cat.name || t.unknownCat, inline: true },
        { name: t.channel, value: channel.name, inline: true }
    )
    .setTimestamp();

const logPayload = { embeds: [logEmbed] };
if (fileUrl) {
    logPayload.components = [
        new ActionRowBuilder().addComponents(
            new ButtonBuilder()
                .setLabel(t.download)
                .setStyle(ButtonStyle.Link)
                .setURL(fileUrl)
        )
    ];
}

        await logCh.send(logPayload);
    } catch(e) {
        console.error('❌ فشل الحفظ التلقائي لنسخة التذكرة:', e.message);
    }
}

// روم مخفي خاص بالبوت فقط لتخزين ملفات النسخ (Transcripts) — لا يراه أي عضو أو أدمن
async function getOrCreateStorageChannel(guild) {
    const ts = loadTicketSettings();

    if (ts.storageChannelId) {
        const existing = guild.channels.cache.get(ts.storageChannelId);
        if (existing) return existing;
    }

    try {
        const newChannel = await guild.channels.create({
            name: '🔒-ticket-storage',
            type: ChannelType.GuildText,
            permissionOverwrites: [
                { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] }
            ]
        });
        const freshTs = loadTicketSettings();
        freshTs.storageChannelId = newChannel.id;
        saveTicketSettings(freshTs);
        return newChannel;
    } catch(e) {
        console.error('❌ فشل إنشاء روم التخزين المخفي:', e);
        return null;
    }
}

// Convert base64 image string to buffer + extension
function base64ToBuffer(b64) {
    const m = b64.match(/^data:image\/(\w+);base64,(.+)$/);
    if (!m) return null;
    return { buffer: Buffer.from(m[2], 'base64'), ext: m[1] };
}

// Download an image URL and return { buffer, name }
function fetchUrlBuffer(url) {
    return new Promise((resolve) => {
        const mod = url.startsWith('https') ? require('https') : require('http');
        mod.get(url, (res) => {
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end', () => {
                const buffer = Buffer.concat(chunks);
                const ext    = (url.split('.').pop() || 'png').split('?')[0].substring(0, 4);
                resolve({ buffer, name: `line_image.${ext}` });
            });
            res.on('error', () => resolve(null));
        }).on('error', () => resolve(null));
    });
}

// Build emoji object for Discord.js select menu options
function buildEmojiOption(emojiValue) {
    if (!emojiValue || !emojiValue.trim()) return null;
    const val = emojiValue.trim();
    if (/^\d+$/.test(val)) return { id: val };
    return val;
}

// Format emoji for use inside embed text/title
function formatEmoji(emojiValue) {
    if (!emojiValue || !emojiValue.trim()) return '🎫';
    const val = emojiValue.trim();
    if (/^\d+$/.test(val)) return `<:e:${val}>`;
    return val;
}
// ==================== Generate Discord-style HTML Transcript ====================
function escapeHtml(str) {
    return String(str || '')
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;');
}

async function formatMessageContent(content, guild) {
    let text = escapeHtml(content);

    // ── تحويل وقت ديسكورد <t:UNIX:FORMAT> إلى تاريخ حقيقي مقروء ──
    text = text.replace(/&lt;t:(\d+):?([a-zA-Z]?)&gt;/g, (match, ts, fmt) => {
        const date = new Date(parseInt(ts) * 1000);
        switch (fmt) {
            case 't': return date.toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' });
            case 'T': return date.toLocaleTimeString('en-US');
            case 'd': return date.toLocaleDateString('en-US');
            case 'D': return date.toLocaleDateString('en-US', { day: 'numeric', month: 'long', year: 'numeric' });
            case 'f': return date.toLocaleString('en-US');
            case 'F': return date.toLocaleString('en-US', { weekday: 'long', day: 'numeric', month: 'long', year: 'numeric', hour: '2-digit', minute: '2-digit' });
            default:  return date.toLocaleString('en-US', { day: 'numeric', month: 'short', year: 'numeric', hour: '2-digit', minute: '2-digit' });
        }
    });

    // ── تنسيق Markdown (كود، عريض، مائل) ─────────────────────────
    text = text.replace(/```([\s\S]+?)```/g, '<pre class="code-block">$1</pre>');
    text = text.replace(/`([^`]+?)`/g, '<code class="inline-code">$1</code>');
    text = text.replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>');
    text = text.replace(/\*(.+?)\*/g, '<em>$1</em>');

    // ── منشن المستخدمين → استبدال بالاسم الحقيقي + عزل اتجاه النص ─
    const userIds = [...text.matchAll(/&lt;@!?(\d+)&gt;/g)].map(m => m[1]);
    for (const id of [...new Set(userIds)]) {
        let name = id;
        try {
            const member = await guild.members.fetch(id);
            name = member.displayName || member.user.username;
        } catch(e) {}
        const re = new RegExp(`&lt;@!?${id}&gt;`, 'g');
        text = text.replace(re, `<bdi class="mention">@${escapeHtml(name)}</bdi>`);
    }

    // ── منشن الرولات ───────────────────────────────────────────────
    const roleIds = [...text.matchAll(/&lt;@&amp;(\d+)&gt;/g)].map(m => m[1]);
    for (const id of [...new Set(roleIds)]) {
        let name = id;
        try {
            const role = await guild.roles.fetch(id);
            if (role) name = role.name;
        } catch(e) {}
        const re = new RegExp(`&lt;@&amp;${id}&gt;`, 'g');
        text = text.replace(re, `<bdi class="mention mention-role">@${escapeHtml(name)}</bdi>`);
    }

    // ── منشن القنوات ───────────────────────────────────────────────
    const channelIds = [...text.matchAll(/&lt;#(\d+)&gt;/g)].map(m => m[1]);
    for (const id of [...new Set(channelIds)]) {
        let name = id;
        const ch = guild.channels.cache.get(id);
        if (ch) name = ch.name;
        const re = new RegExp(`&lt;#${id}&gt;`, 'g');
        text = text.replace(re, `<bdi class="mention">#${escapeHtml(name)}</bdi>`);
    }

   text = text.replace(/\n/g, '<br>');
    return text;
}

// ── بناء بادج الرد (Reply) فوق الرسالة، بشكل يطابق ديسكورد ─────
// ── حل المنشنات لنص عادي (بدون HTML) للاستخدام بمعاينة الردود ──
async function resolveMentionsPlain(content, guild) {
    let text = content || '';

    const userIds = [...text.matchAll(/<@!?(\d+)>/g)].map(m => m[1]);
    for (const id of [...new Set(userIds)]) {
        let name = id;
        try {
            const member = await guild.members.fetch(id);
            name = member.displayName || member.user.username;
        } catch(e) {}
        text = text.replace(new RegExp(`<@!?${id}>`, 'g'), `@${name}`);
    }

    const roleIds = [...text.matchAll(/<@&(\d+)>/g)].map(m => m[1]);
    for (const id of [...new Set(roleIds)]) {
        let name = id;
        try {
            const role = await guild.roles.fetch(id);
            if (role) name = role.name;
        } catch(e) {}
        text = text.replace(new RegExp(`<@&${id}>`, 'g'), `@${name}`);
    }

    const channelIds = [...text.matchAll(/<#(\d+)>/g)].map(m => m[1]);
    for (const id of [...new Set(channelIds)]) {
        const ch = guild.channels.cache.get(id);
        if (ch) text = text.replace(new RegExp(`<#${id}>`, 'g'), `#${ch.name}`);
    }

    return text;
}

async function buildReplyHTML(msg, guild) {
    if (!msg.reference || !msg.reference.messageId) return '';
    let repliedMsg = null;
    try {
        repliedMsg = await msg.fetchReference();
    } catch(e) {
        // الرسالة الأصلية محذوفة أو غير متاحة
        return `<div class="reply-line"><span class="reply-icon">↪</span><span class="reply-deleted">رسالة أصلية محذوفة</span></div>`;
    }
    const authorName = escapeHtml(repliedMsg.member?.displayName || repliedMsg.author.username);
    const avatarUrl = repliedMsg.author.displayAvatarURL({ size: 16, extension: 'png' });

    const rawPreview = repliedMsg.content ? await resolveMentionsPlain(repliedMsg.content, guild) : '';
    let previewText = rawPreview
        ? escapeHtml(rawPreview).substring(0, 90)
        : (repliedMsg.embeds.length ? '📋 Embed' : (repliedMsg.attachments.size ? '📎 مرفق' : ''));
    if (rawPreview && rawPreview.length > 90) previewText += '…';

    return `<div class="reply-line">
        <span class="reply-icon">↪</span>
        <img class="reply-avatar" src="${avatarUrl}">
        <span class="reply-author">${authorName}</span>
        <span class="reply-content">${previewText || ''}</span>
    </div>`;
}

// ── بناء الريأكشنز (Reactions) أسفل الرسالة ─────────────────────
function buildReactionsHTML(msg) {
    if (!msg.reactions || msg.reactions.cache.size === 0) return '';
    let html = '<div class="reactions-row">';
    msg.reactions.cache.forEach(r => {
        const emojiDisplay = r.emoji.id
            ? `<img class="reaction-emoji-img" src="https://cdn.discordapp.com/emojis/${r.emoji.id}.png" alt="${escapeHtml(r.emoji.name)}">`
            : escapeHtml(r.emoji.name);
        html += `<span class="reaction-pill">${emojiDisplay} <span class="reaction-count">${r.count}</span></span>`;
    });
    html += '</div>';
    return html;
}

// ── بناء الستيكرز (Stickers) ─────────────────────────────────────
function buildStickersHTML(msg) {
    if (!msg.stickers || msg.stickers.size === 0) return '';
    let html = '';
    msg.stickers.forEach(s => {
        const url = s.url || `https://cdn.discordapp.com/stickers/${s.id}.png`;
        html += `<div class="sticker-box"><img src="${url}" alt="${escapeHtml(s.name)}"><div class="sticker-name">${escapeHtml(s.name)}</div></div>`;
    });
    return html;
}

async function generateTranscriptHTML(channel, ticketInfo) {
    let allMessages = [];
    let lastId = null;
    let wasTruncated = false;

    // جلب كل الرسائل بالقناة (بحد أقصى 1000 رسالة لتفادي الإفراط)
    for (let i = 0; i < 10; i++) {
        const options = { limit: 100 };
        if (lastId) options.before = lastId;
        const batch = await channel.messages.fetch(options);
        if (batch.size === 0) break;
        allMessages.push(...batch.values());
        lastId = batch.last().id;
        if (batch.size < 100) {
            break;
        } else if (i === 9) {
            // وصلنا للحد الأقصى (1000 رسالة) وما زال فيه رسائل أقدم
            wasTruncated = true;
        }
    }
    allMessages.reverse(); // من الأقدم للأحدث

    const guild = channel.guild;
    const messageBlocks = [];

    for (const msg of allMessages) {
        const avatarUrl = msg.author.displayAvatarURL({ size: 64, extension: 'png' });
        const username   = escapeHtml(msg.member?.displayName || msg.author.username);
        const timestamp  = new Date(msg.createdTimestamp).toLocaleString('en-US', {
            month: 'short', day: 'numeric', year: 'numeric', hour: '2-digit', minute: '2-digit'
        });
        const editedTag  = msg.editedTimestamp ? '<span class="edited-tag">(معدّلة)</span>' : '';
        const content    = await formatMessageContent(msg.content, guild);
        const replyHTML     = await buildReplyHTML(msg, guild);
        const reactionsHTML = buildReactionsHTML(msg);
        const stickersHTML  = buildStickersHTML(msg);

        let attachmentsHTML = '';
        msg.attachments.forEach(att => {
            const isImage = /\.(png|jpe?g|gif|webp)$/i.test(att.name || '');
            if (isImage) {
                attachmentsHTML += `<div class="attachment-img"><img src="${att.url}" alt="${escapeHtml(att.name)}"></div>`;
            } else {
                attachmentsHTML += `<div class="attachment-file"><a href="${att.url}" target="_blank">📎 ${escapeHtml(att.name)}</a></div>`;
            }
        });

        let embedsHTML = '';
        for (const em of msg.embeds) {
            const color = em.color ? `#${em.color.toString(16).padStart(6, '0')}` : '#5865F2';
            embedsHTML += `<div class="embed" style="border-color:${color}">`;
            if (em.title) embedsHTML += `<div class="embed-title">${escapeHtml(em.title)}</div>`;
            if (em.description) embedsHTML += `<div class="embed-desc">${await formatMessageContent(em.description, guild)}</div>`;
            if (em.fields && em.fields.length) {
                embedsHTML += `<div class="embed-fields">`;
                for (const f of em.fields) {
                    const fieldValue = await formatMessageContent(f.value, guild);
                    embedsHTML += `<div class="embed-field${f.inline ? ' inline' : ''}"><div class="embed-field-name">${escapeHtml(f.name)}</div><div class="embed-field-value">${fieldValue}</div></div>`;
                }
                embedsHTML += `</div>`;
            }
            if (em.image && em.image.url) embedsHTML += `<img class="embed-image" src="${em.image.url}">`;
            if (em.footer && em.footer.text) embedsHTML += `<div class="embed-footer">${escapeHtml(em.footer.text)}</div>`;
            embedsHTML += `</div>`;
        }

       messageBlocks.push(`
        <div class="message">
            <img class="avatar" src="${avatarUrl}" alt="">
            <div class="message-body">
                ${replyHTML}
                <div class="message-header">
                    <span class="username">${username}</span>
                    <span class="timestamp">${timestamp}</span>
                    ${editedTag}
                </div>
                <div class="message-content">${content}</div>
                ${attachmentsHTML}
                ${embedsHTML}
                ${stickersHTML}
                ${reactionsHTML}
            </div>
        </div>`);
    }

    const messagesHTML = messageBlocks.join('\n');

    const guildIconUrl = guild.iconURL({ size: 128, extension: 'png' }) || '';

    const html = `<!DOCTYPE html>
<html lang="ar">
<head>
<meta charset="UTF-8">
<title>  ${escapeHtml(channel.name)}</title>
${guildIconUrl ? `<link rel="icon" type="image/png" href="${guildIconUrl}">` : ''}
<style>
    * { margin:0; padding:0; box-sizing:border-box; }
    body { background:#313338; color:#dbdee1; font-family:'gg sans','Whitney',Helvetica,Arial,sans-serif; }
    .header {
        background:#2b2d31; padding:16px 24px; border-bottom:1px solid #26282c;
        position:sticky; top:0; display:flex; align-items:center; gap:10px;
    }
    .header h1 { font-size:16px; color:#fff; }
    .header p { font-size:12px; color:#949ba4; margin-top:2px; }
    .messages-wrap { max-width:900px; margin:0 auto; padding:16px 24px 60px; }
    .message { display:flex; gap:16px; padding:10px 0; }
    .message:hover { background:#2e3035; margin:0 -16px; padding:10px 16px; border-radius:4px; }
    .avatar { width:40px; height:40px; border-radius:50%; flex-shrink:0; }
    .message-body { flex:1; min-width:0; }
    .message-header { display:flex; align-items:baseline; gap:8px; direction:ltr; }
    .username { font-weight:600; color:#f2f3f5; font-size:15px; unicode-bidi:isolate; }
    .timestamp { font-size:11px; color:#949ba4; unicode-bidi:isolate; }
    .edited-tag { unicode-bidi:isolate; }
    .message-content { font-size:14.5px; line-height:1.5; color:#dbdee1; margin-top:2px; word-wrap:break-word; }
    .message-content strong { color:#fff; font-weight:700; }
    .message-content em { font-style:italic; }
    .message-content code.inline-code {
        background:#2b2d31; border:1px solid #1e1f22; border-radius:4px;
        padding:1px 5px; font-family:Consolas,Menlo,monospace; font-size:13px; color:#f2f3f5;
    }
    .message-content pre.code-block {
        background:#2b2d31; border:1px solid #1e1f22; border-radius:6px;
        padding:10px 12px; margin:6px 0; font-family:Consolas,Menlo,monospace;
        font-size:13px; color:#f2f3f5; white-space:pre-wrap; direction:ltr; text-align:left;
    }
    .mention {
        background:rgba(88,101,242,0.3); color:#c9cdfb; padding:0 2px; border-radius:3px;
        font-weight:500; unicode-bidi:isolate;
    }
    .mention-role { background:rgba(235,69,158,0.25); color:#f4b8d8; }
    .attachment-img { margin-top:6px; max-width:400px; }
    .attachment-img img { max-width:100%; border-radius:6px; }
    .attachment-file { margin-top:6px; }
    .attachment-file a { color:#00a8fc; text-decoration:none; font-size:13.5px; }
    .edited-tag { font-size:10px; color:#949ba4; }
    .reply-line {
        display:flex; align-items:center; gap:6px; margin-bottom:2px;
        font-size:13px; color:#949ba4; padding-left:4px;
    }
    .reply-icon { font-size:14px; color:#4e5058; }
    .reply-avatar { width:16px; height:16px; border-radius:50%; }
    .reply-author { font-weight:600; color:#dbdee1; }
    .reply-content { color:#949ba4; overflow:hidden; text-overflow:ellipsis; white-space:nowrap; max-width:400px; }
    .reply-deleted { font-style:italic; color:#4e5058; }
    .reactions-row { display:flex; flex-wrap:wrap; gap:4px; margin-top:6px; }
    .reaction-pill {
        display:inline-flex; align-items:center; gap:4px; background:#2b2d31;
        border:1px solid #3a3c41; border-radius:8px; padding:2px 6px; font-size:12.5px; color:#dbdee1;
    }
    .reaction-emoji-img { width:16px; height:16px; vertical-align:middle; }
    .reaction-count { color:#949ba4; font-size:12px; }
    .sticker-box { margin-top:6px; display:inline-block; text-align:center; }
    .sticker-box img { width:100px; height:100px; }
    .sticker-name { font-size:11px; color:#949ba4; }
    .truncation-notice {
        background:#3a2e1a; border:1px solid #5c4a1e; color:#f5c869; border-radius:6px;
        padding:10px 16px; margin-bottom:12px; font-size:13px; text-align:center;
    }
    .embed { margin-top:6px; background:#2b2d31; border-left:4px solid #5865F2; border-radius:4px; padding:12px 16px; max-width:520px; }
    .embed-title { font-weight:600; color:#fff; margin-bottom:6px; font-size:14px; }
    .embed-desc { font-size:13.5px; color:#dbdee1; line-height:1.4; }
    .embed-fields { display:flex; flex-wrap:wrap; gap:8px; margin-top:8px; }
    .embed-field { flex:1 1 100%; }
    .embed-field.inline { flex:1 1 30%; min-width:120px; }
    .embed-field-name { font-weight:600; font-size:12.5px; color:#fff; }
    .embed-field-value { font-size:12.5px; color:#dbdee1; }
    .embed-image { margin-top:8px; max-width:100%; border-radius:4px; }
    .embed-footer { margin-top:8px; font-size:11.5px; color:#949ba4; }
    footer { text-align:center; padding:20px; color:#4e5058; font-size:11px; }
</style>
</head>
<body>
    <div class="header">
        <div>
            <h1>🎫 ${escapeHtml(channel.name)}</h1>
            <p>${ticketInfo || ''}</p>
        </div>
    </div>
    <div class="messages-wrap">
        ${wasTruncated ? `<div class="truncation-notice">⚠️ هذه النسخة تحتوي على أحدث 1000 رسالة فقط — الرسائل الأقدم لم تُحفظ.</div>` : ''}
        ${messagesHTML || '<p style="color:#949ba4;text-align:center;padding:40px;">لا توجد رسائل بهذه التذكرة</p>'}
    </div>
    <footer>POWER — Ticket Transcript</footer>
</body>
</html>`;

    return Buffer.from(html, 'utf8');
}
// Map displayType string → Discord ButtonStyle
function getButtonStyle(displayType) {
    switch (displayType) {
        case 'button_primary':   return ButtonStyle.Primary;
        case 'button_secondary': return ButtonStyle.Secondary;
        case 'button_success':   return ButtonStyle.Success;
        case 'button_danger':    return ButtonStyle.Danger;
        default:                 return ButtonStyle.Primary;
    }
}

// ==================== /ticket command (Admin Setup - Public Message) ====================

module.exports = {
    async execute(interaction, client, settings) {
        // Only admins/managers can send the setup message
        const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
                     || interaction.member.permissions.has(PermissionFlagsBits.Administrator);

        if (!isAdmin) {
            return interaction.reply({
                content: settings.botLanguage === 'en'
                    ? '❌ You do not have permission to use this command.'
                    : '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
                flags: MessageFlags.Ephemeral
            });
        }

        const ts = loadTicketSettings();
        const categories = ts.categories || [];

        if (categories.length === 0) {
            return interaction.reply({
                content: settings.botLanguage === 'en'
                    ? '❌ No ticket categories configured. Please set them up in the dashboard.'
                    : '❌ لا توجد فئات تذاكر مُعدّة. يرجى إعدادها من الداشبورد.',
                flags: MessageFlags.Ephemeral
            });
        }

        // ── Separate button categories from select-menu categories ──────────
        const buttonCats = categories.filter(c => c.displayType && c.displayType.startsWith('button_'));
        const menuCats   = categories.filter(c => !c.displayType || c.displayType === 'select_menu');

        const rows = [];

        // Build button rows (max 4 rows × 5 buttons = 20 buttons)
        if (buttonCats.length > 0) {
            let currentRow = new ActionRowBuilder();
            let btnsInRow  = 0;
            buttonCats.slice(0, 20).forEach(cat => {
                const realIndex = categories.indexOf(cat);
                const btn = new ButtonBuilder()
                    .setCustomId(`ticket_open_category_${realIndex}`)
                    .setLabel((cat.name || `Category ${realIndex + 1}`).substring(0, 80))
                    .setStyle(getButtonStyle(cat.displayType));
                const emoji = buildEmojiOption(cat.emoji);
                if (emoji) { try { btn.setEmoji(emoji); } catch(e) {} }
                currentRow.addComponents(btn);
                btnsInRow++;
                if (btnsInRow === 5) {
                    rows.push(currentRow);
                    currentRow = new ActionRowBuilder();
                    btnsInRow  = 0;
                }
            });
            if (btnsInRow > 0) rows.push(currentRow);
        }

        // Build select menu row (for select_menu categories) — Discord allows max 5 rows total
        if (menuCats.length > 0 && rows.length < 5) {
            const options = menuCats.slice(0, 25).map(cat => {
                const realIndex = categories.indexOf(cat);
                const opt = new StringSelectMenuOptionBuilder()
                    .setValue(String(realIndex))
                    .setLabel((cat.name || `Category ${realIndex + 1}`).substring(0, 100));
                const emoji = buildEmojiOption(cat.emoji);
                if (emoji) { try { opt.setEmoji(emoji); } catch(e) {} }
                if (cat.description && cat.description.trim()) {
                    opt.setDescription(cat.description.substring(0, 100));
                }
                return opt;
            });
            const selectMenu = new StringSelectMenuBuilder()
                .setCustomId('ticket_select_category')
                .setPlaceholder(settings.botLanguage === 'en'
                    ? 'Choose a ticket type...'
                    : 'اختر نوع التذكرة...')
                .addOptions(options);
            rows.push(new ActionRowBuilder().addComponents(selectMenu));
        }

        if (rows.length === 0) {
            return interaction.reply({
                content: settings.botLanguage === 'en'
                    ? '❌ No categories configured.'
                    : '❌ لا توجد فئات مُعدّة.',
                flags: MessageFlags.Ephemeral
            });
        }

       // PUBLIC payload (no ephemeral) — all images in ONE message
        const msgPayload = { components: rows };
        const files      = [];

        const setupTitle = ts.embedTitle || '';
        const setupDesc  = ts.embedDescription || '';

        if (ts.useEmbed !== false) {
            // ── وضع EMBED (مفعل) ─────────────────────────────────────────
            const embed = new EmbedBuilder().setColor('#5865F2');
            if (setupTitle) embed.setTitle(setupTitle);
            if (setupDesc) embed.setDescription(setupDesc);

            if (ts.coverImageBase64) {
                try {
                    const result = base64ToBuffer(ts.coverImageBase64);
                    if (result) {
                        files.push(new AttachmentBuilder(result.buffer, { name: `ticket_cover.${result.ext}` }));
                        embed.setImage(`attachment://ticket_cover.${result.ext}`);
                    }
                } catch(e) {}
            } else if (ts.coverImageUrl) {
                embed.setImage(ts.coverImageUrl);
            }

            msgPayload.embeds = [embed];
        } else {
            // ── وضع TEXT (معطل) ── بدون حدود Embed ────────────────────────
            let textMessage = setupTitle ? `**${setupTitle}**\n\n${setupDesc}` : setupDesc;
            msgPayload.content = textMessage;

            if (ts.coverImageBase64) {
                try {
                    const result = base64ToBuffer(ts.coverImageBase64);
                    if (result) {
                        files.push(new AttachmentBuilder(result.buffer, { name: `ticket_cover.${result.ext}` }));
                    }
                } catch(e) {}
            } else if (ts.coverImageUrl) {
                try {
                    const imgBuf = await fetchUrlBuffer(ts.coverImageUrl);
                    if (imgBuf) files.push(new AttachmentBuilder(imgBuf.buffer, { name: imgBuf.name }));
                } catch(e) {}
            }
        }

        if (files.length > 0) msgPayload.files = files;

        // Acknowledge interaction silently (ephemeral) so we can send both messages
        // as regular channel.send() calls → Discord groups consecutive bot messages
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        // Send main embed as regular channel message (not interaction reply)
        await interaction.channel.send(msgPayload);

        // Send line image immediately after → Discord groups them as one visual block
        if (ts.lineImageBase64) {
            try {
                const result = base64ToBuffer(ts.lineImageBase64);
                if (result) {
                    await interaction.channel.send({
                        files: [new AttachmentBuilder(result.buffer, { name: `ticket_line.${result.ext}` })]
                    });
                }
            } catch(e) {}
        } else if (ts.lineImageUrl) {
            try {
                const imgBuf = await fetchUrlBuffer(ts.lineImageUrl);
                if (imgBuf) {
                    await interaction.channel.send({
                        files: [new AttachmentBuilder(imgBuf.buffer, { name: imgBuf.name })]
                    });
                }
            } catch(e) {}
        }

        // Confirm to admin (ephemeral)
        await interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(settings.botLanguage === 'en' ? '✅ Setup message sent.' : '✅ تم إرسال رسالة الإعداد.')
                .setColor('#57F287')]
        });
    },

    // ==================== Button / Select / Modal Handler ====================
    async handleButton(interaction, client, settings) {
        const customId = interaction.customId;

        // Category button clicked → open ticket channel
        if (customId.startsWith('ticket_open_category_')) {
            const categoryIndex = parseInt(customId.replace('ticket_open_category_', ''));
            return openTicketChannel(interaction, client, settings, categoryIndex);
        }

        // Category selected from select menu → open ticket channel
        if (interaction.isStringSelectMenu?.() && customId === 'ticket_select_category') {
            const categoryIndex = parseInt(interaction.values[0]);
            return openTicketChannel(interaction, client, settings, categoryIndex);
        }

        // Ticket options button → show management dropdown
        if (customId.startsWith('ticket_options_')) {
            return showTicketOptions(interaction, client, settings);
        }

        // Ticket option selected from dropdown → execute action
        if (interaction.isStringSelectMenu?.() && customId === 'ticket_option_select') {
            return handleTicketAction(interaction, client, settings);
        }

        // Close modal submitted → process close with reason
        if (interaction.isModalSubmit?.() && customId.startsWith('ticket_close_modal_')) {
            return processCloseModal(interaction, client, settings);
        }

        // Claim / Reopen / Delete buttons
        if (customId.startsWith('ticket_claim_'))   return claimTicket(interaction, client, settings);
        if (customId.startsWith('ticket_reopen_'))  return reopenTicket(interaction, client, settings);
        if (customId.startsWith('ticket_delete_'))  return deleteTicket(interaction, client, settings);

        // Add user select menu submit
        if (interaction.isUserSelectMenu?.() && customId.startsWith('ticket_adduser_select_')) {
            return addUserFromSelect(interaction, client, settings);
        }
        // Remove user select menu submit
        if (interaction.isUserSelectMenu?.() && customId.startsWith('ticket_removeuser_select_')) {
            return removeUserFromSelect(interaction, client, settings);
        }
       // Add user modal submit (legacy fallback)
        if (interaction.isModalSubmit?.() && customId.startsWith('ticket_adduser_modal_')) {
            return addUserToTicket(interaction, client, settings);
        }
    }
};

module.exports.startAutoCloseChecker = startAutoCloseChecker;
module.exports.base64ToBuffer = base64ToBuffer;
module.exports.buildEmojiOption = buildEmojiOption;
module.exports.formatEmoji = formatEmoji;
module.exports.getButtonStyle = getButtonStyle;
module.exports.fetchUrlBuffer = fetchUrlBuffer;

// ==================== Open Ticket Channel ====================
async function openTicketChannel(interaction, client, settings, categoryIndex) {
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    const userId = interaction.user.id;

    // Lock: prevent same user from opening multiple tickets simultaneously
    if (pendingTicketUsers.has(userId)) {
        return interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(settings.botLanguage === 'en'
                    ? '⏳ Your ticket is being created, please wait...'
                    : '⏳ جارٍ إنشاء تذكرتك، يرجى الانتظار...')
                .setColor('#FEE75C')]
        });
    }
    pendingTicketUsers.add(userId);

    try {
    const ts         = loadTicketSettings();
    const categories = ts.categories || [];
    const cat        = categories[categoryIndex];

    if (!cat) {
        return interaction.editReply({
            content: settings.botLanguage === 'en' ? '❌ Category not found.' : '❌ الفئة غير موجودة.'
        });
    }

    // ── Working Hours Check ──
    if (ts.workingHoursEnabled) {
        const now   = new Date();
        const hhmm  = now.getHours() * 60 + now.getMinutes();
        const toMin = (str) => {
            const [h, m] = (str || '00:00').split(':').map(Number);
            return h * 60 + m;
        };
        const start = toMin(ts.workingHoursStart);
        const end   = toMin(ts.workingHoursEnd);
        const inHours = start <= end ? (hhmm >= start && hhmm < end)
                                     : (hhmm >= start || hhmm < end); // overnight range
        if (!inHours) {
            const msg = ts.workingHoursMessage
                ? ts.workingHoursMessage
                : (settings.botLanguage === 'en'
                    ? ` Tickets are only available from ${ts.workingHoursStart} to ${ts.workingHoursEnd}.`
                    : ` التذاكر متاحة فقط من ${ts.workingHoursStart} إلى ${ts.workingHoursEnd}.`);
            return interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(msg)
                    .setColor('#FEE75C')]
            });
        }
    }

const guild  = interaction.guild;
    const member = interaction.member;

   // ── Blacklist Check ──
    const blacklist = ts.blacklist || { userIds: [], roleIds: [] };
    const isUserBlocked = ts.blacklistEnabled !== false && (blacklist.userIds || []).includes(member.user.id);
    const isRoleBlocked = ts.blacklistEnabled !== false && (blacklist.roleIds || []).some(roleId => member.roles.cache.has(roleId));
    if (isUserBlocked || isRoleBlocked) {
        return interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(settings.botLanguage === 'en'
                    ? '❌ You are not allowed to open tickets.'
                    : '❌ غير مسموح لك بفتح تذاكر.')
                .setColor('#ED4245')]
        });
    }

    // Check if user already has an open ticket (includes pending records)
    const openTickets = ts.openTickets || {};
    const existing = Object.values(openTickets).find(t => t.userId === member.user.id && t.open);
    if (existing && !existing.pending) {
        // User already has an open ticket — block immediately, no channel fetch needed
        return interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(settings.botLanguage === 'en'
                    ? `❌ You already have an open ticket: <#${existing.channelId}>`
                    : `❌ لديك تذكرة مفتوحة بالفعل: <#${existing.channelId}>`)
                .setColor('#ED4245')]
        });
    }
    if (existing && existing.pending) {
        return interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(settings.botLanguage === 'en'
                    ? '⏳ Your ticket is being created, please wait...'
                    : '⏳ جارٍ إنشاء تذكرتك، يرجى الانتظار...')
                .setColor('#FEE75C')]
        });
    }

    // ── Reserve slot + increment counter in ONE atomic write ──
    // Must reload fresh from disk to avoid overwriting other concurrent writes
    const freshTs = loadTicketSettings();
    if (!freshTs.openTickets) freshTs.openTickets = {};
    const pendingKey = `pending_${userId}`;
    freshTs.openTickets[pendingKey] = { userId, open: true, pending: true };
    const ticketCounter = (freshTs.ticketCounter || 0) + 1;
    freshTs.ticketCounter = ticketCounter;
    saveTicketSettings(freshTs);

    const ticketName = `🎫・${ticketCounter}`;

    const supportRoleIds = Array.isArray(cat.adminRoleId)
        ? cat.adminRoleId.filter(v => v)
        : (cat.adminRoleId ? [cat.adminRoleId] : []);

    const permOverwrites = [
        { id: guild.roles.everyone.id, deny: [PermissionFlagsBits.ViewChannel] },
        {
            id: member.user.id,
            allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory
            ]
        }
    ];
    supportRoleIds.forEach(roleId => {
        permOverwrites.push({
            id: roleId,
            allow: [
                PermissionFlagsBits.ViewChannel,
                PermissionFlagsBits.SendMessages,
                PermissionFlagsBits.ReadMessageHistory,
                PermissionFlagsBits.ManageMessages
            ]
        });
    });

    const channelOptions = {
        name: ticketName,
        type: ChannelType.GuildText,
        permissionOverwrites: permOverwrites,
        topic: `${settings.botLanguage === 'en' ? 'Ticket for' : 'تذكرة لـ'} ${member.user.tag} | ${cat.name}`
    };

    // Place channel inside the Discord category folder
    if (cat.channelId) {
        const parentCh = guild.channels.cache.get(cat.channelId);
        if (parentCh && parentCh.type === ChannelType.GuildCategory) {
            channelOptions.parent = cat.channelId;
        }
    }

    let ticketChannel;
    try {
        ticketChannel = await guild.channels.create(channelOptions);
    } catch(e) {
        console.error('❌ خطأ في إنشاء قناة التذكرة:', e);
        removeOpenTicket(pendingKey); // Clean up pending reservation on failure
        return interaction.editReply({
            content: settings.botLanguage === 'en'
                ? '❌ Failed to create ticket channel. Check bot permissions.'
                : '❌ فشل إنشاء قناة التذكرة. تأكد من صلاحيات البوت.'
        });
    }

    // Remove the pending reservation and save the real ticket record
    removeOpenTicket(pendingKey);
    setOpenTicket(ticketChannel.id, {
        channelId:    ticketChannel.id,
        userId:       member.user.id,
        categoryIndex,
        categoryName: cat.name,
        open:         true,
        createdAt:    new Date().toISOString()
    });

// ===== الكود المعدل: يدعم Enable Embed لكل فئة =====
const color       = cat.color || '#5865F2';
const emojiStr    = formatEmoji(cat.emoji);
const welcomeMsg  = settings.botLanguage === 'en'
    ? `Hello <@${member.user.id}>! Please describe your issue and our team will assist you shortly.`
    : `مرحباً <@${member.user.id}>! يرجى وصف مشكلتك وسيساعدك فريقنا قريباً.`;

let msgPayload = {};
const ticketFiles = [];

// ✅ التحقق من إعداد Enable Embed لهذه الفئة
if (cat.enableEmbed !== false) {
    // ── وضع EMBED (مفعل) ─────────────────────────────────────────
    const ticketEmbed = new EmbedBuilder()
        .setTitle(`${emojiStr} ${cat.name}`)
        .setDescription(welcomeMsg)
        .setColor(color)
        .addFields(
            {
                name:   settings.botLanguage === 'en' ? 'Category'   : 'الفئة',
                value:  `${emojiStr} ${cat.name}`,
                inline: true
            },
            {
                name:   settings.botLanguage === 'en' ? 'Opened by'  : 'فُتحت بواسطة',
                value:  `<@${member.user.id}>`,
                inline: true
            },
            {
                name:   settings.botLanguage === 'en' ? 'Date'       : 'التاريخ',
                value:  `<t:${Math.floor(Date.now() / 1000)}:R>`,
                inline: true
            }
        )
        .setTimestamp();

    // صورة الخلفية (لحالة EMBED فقط)
    if (cat.bgImageBase64) {
        try {
            const result = base64ToBuffer(cat.bgImageBase64);
            if (result) {
                ticketFiles.push(new AttachmentBuilder(result.buffer, { name: `ticket_bg.${result.ext}` }));
                ticketEmbed.setImage(`attachment://ticket_bg.${result.ext}`);
            }
        } catch(e) {}
    } else if (cat.bgImageUrl) {
        ticketEmbed.setImage(cat.bgImageUrl);
    }

const mentionPrefix = supportRoleIds.length > 0
    ? supportRoleIds.map(id => `<@&${id}>`).join(' ') + ' | '
    : '';

msgPayload = {
        content:    `${mentionPrefix}<@${member.user.id}>`,
        embeds:     [ticketEmbed],
        components: []
    };
    if (ticketFiles.length > 0) msgPayload.files = ticketFiles;

} else {
    // ── وضع TEXT (معطل) ── رسالة عادية بدون Embed ────────────────
    let textMessage = `**${emojiStr} ${cat.name}**\n\n${welcomeMsg}\n\n`;
    textMessage += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n`;
    textMessage += `📁 **${settings.botLanguage === 'en' ? 'Category' : 'الفئة'}:** ${emojiStr} ${cat.name}\n`;
    textMessage += `👤 **${settings.botLanguage === 'en' ? 'Opened by' : 'فُتحت بواسطة'}:** <@${member.user.id}>\n`;
    textMessage += `📅 **${settings.botLanguage === 'en' ? 'Date' : 'التاريخ'}:** <t:${Math.floor(Date.now() / 1000)}:R>\n`;
    textMessage += `━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━`;

    msgPayload = {
        content:    textMessage,
        components: [],
        files:      []
    };

    // صورة الخلفية للرسالة النصية (ترفق كملف منفصل)
    if (cat.bgImageBase64) {
        try {
            const result = base64ToBuffer(cat.bgImageBase64);
            if (result) {
                msgPayload.files.push(new AttachmentBuilder(result.buffer, { name: `ticket_bg.${result.ext}` }));
            }
        } catch(e) {}
    } else if (cat.bgImageUrl) {
        // في حالة TEXT، نضيف رابط الصورة في نهاية الرسالة
        textMessage += `\n\n📸 **${settings.botLanguage === 'en' ? 'Background Image' : 'صورة الخلفية'}:** ${cat.bgImageUrl}`;
        msgPayload.content = textMessage;
    }
}

// الأزرار (تعمل في كلتا الحالتين)
const perms   = ts.permissions || {};
const buttons = [];

const hasAnyOption = perms.adminClose      !== false || perms.userClose      !== false
                  || perms.adminAddUser    !== false || perms.userAddUsers   !== false
                  || perms.adminRemoveUser !== false
                  || perms.adminReminder   !== false || perms.userReminder   !== false
                  || perms.adminCopy       !== false || perms.userCopy       !== false;

if (hasAnyOption) {
    buttons.push(new ButtonBuilder()
        .setCustomId(`ticket_options_${ticketChannel.id}`)
        .setLabel(settings.botLanguage === 'en' ? '🗃️ Ticket Options' : '🗃️ خيارات التذكرة')
        .setStyle(ButtonStyle.Secondary));
}

if (perms.adminClaim !== false) {
    buttons.push(new ButtonBuilder()
        .setCustomId(`ticket_claim_${ticketChannel.id}`)
        .setLabel(settings.botLanguage === 'en' ? '💼 Claim' : '💼 استلام')
        .setStyle(ButtonStyle.Secondary));
}

if (buttons.length > 0) {
    msgPayload.components = [new ActionRowBuilder().addComponents(buttons)];
}

// إرسال الرسالة
const sentMsg = await ticketChannel.send(msgPayload);

// تثبيت الرسالة تلقائياً (Pin)
try {
    await sentMsg.pin();
} catch (e) {
    console.error('❌ فشل تثبيت رسالة التذكرة:', e);
}

    // Log to category log channel
    if (cat.logChannelId) {
        try {
            const logCh = guild.channels.cache.get(cat.logChannelId);
            if (logCh) {
                const logEmbed = new EmbedBuilder()
                    .setTitle(settings.botLanguage === 'en' ? '🎫 New Ticket Opened' : '🎫 تذكرة جديدة مفتوحة')
                    .setColor('#57F287')
                    .addFields(
                        {
                            name:   settings.botLanguage === 'en' ? 'Ticket #' : 'رقم التذكرة',
                            value:  `#${ticketCounter}`,
                            inline: true
                        },
                        {
                            name:   settings.botLanguage === 'en' ? 'User'     : 'المستخدم',
                            value:  `<@${member.user.id}>`,
                            inline: true
                        },
                        {
                            name:   settings.botLanguage === 'en' ? 'Category' : 'الفئة',
                            value:  cat.name,
                            inline: true
                        },
                        {
                            name:   settings.botLanguage === 'en' ? 'Channel'  : 'القناة',
                            value:  `<#${ticketChannel.id}> (${ticketChannel.name})`,
                            inline: true
                        }
                    )
                    .setTimestamp();
                await logCh.send({ embeds: [logEmbed] });
            }
        } catch(e) {}
    }

    await interaction.editReply({
        content: (settings.botLanguage === 'en'
            ? '  Ticket created: '
            : '  تم فتح تذكرتك: ') + `<#${ticketChannel.id}>`
    });

    } catch(e) {
        console.error('Error opening ticket:', e);
        try { await interaction.editReply({ content: '❌ ' + e.message }); } catch(_) {}
    } finally {
        pendingTicketUsers.delete(userId);
        // Safety net: remove pending JSON reservation if still there
        removeOpenTicket(`pending_${userId}`);
    }
}

// ==================== Show Ticket Options Dropdown ====================
async function showTicketOptions(interaction, client, settings) {
    const ts     = loadTicketSettings();
    const perms  = ts.permissions || {};
    const ticket = (ts.openTickets || {})[interaction.channelId];
    const isAr   = settings.botLanguage !== 'en';

    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
                 || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    const isOwner = ticket && ticket.userId === interaction.user.id;

    // Only ticket owner or admins can use the menu
    if (!isAdmin && !isOwner) {
        return interaction.reply({
            content: isAr ? '❌ ليس لديك صلاحية لاستخدام هذه القائمة.' : '❌ You cannot use this menu.',
            flags: MessageFlags.Ephemeral
        });
    }

    const options = [];

    if (isAdmin) {
        // ── ADMIN MENU ────────────────────────────────────────────────

        // Cancel Claim (only if ticket is currently claimed)
        if (perms.adminClaim !== false && ticket && ticket.claimedBy) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('cancelclaim')
                .setLabel(isAr ? 'إلغاء الاستلام' : 'Cancel Claim')
                .setDescription(isAr ? 'إلغاء استلام التذكرة' : 'Cancel the ticket claim')
                .setEmoji('❌'));
        }

        // Close with Reason (ADMIN ONLY - shows modal)
        if (perms.adminClose !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('close')
                .setLabel(isAr ? 'إغلاق مع سبب' : 'Close with Reason')
                .setDescription(isAr ? 'إغلاق التذكرة مع ذكر السبب' : 'Close the ticket with reason')
                .setEmoji('🔒'));
        }

// Add User to Ticket
        if (perms.adminAddUser !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('adduser')
                .setLabel(isAr ? 'إضافة مستخدم للتذكرة' : 'Add User to Ticket')
                .setDescription(isAr ? 'إضافة مستخدم إلى التذكرة' : 'Add a user to the ticket')
                .setEmoji('👤'));
        }

       // Remove User from Ticket — فقط إذا يوجد أعضاء مُضافين فعلياً
        if (perms.adminRemoveUser !== false && ticket && Array.isArray(ticket.addedUsers) && ticket.addedUsers.length > 0) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('removeuser')
                .setLabel(isAr ? 'إزالة مستخدم من التذكرة' : 'Remove User from Ticket')
                .setDescription(isAr ? 'إزالة مستخدم من التذكرة' : 'Remove a user from the ticket')
                .setEmoji('🚫'));
        }

        // Member PM Reminder → sends DM to ticket creator
        if (perms.adminReminder !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('memberreminder')
                .setLabel(isAr ? 'تذكير خاص للعضو' : 'Member PM Reminder')
                .setDescription(isAr ? 'إرسال تذكير للعضو فاتح التذكرة' : 'Send a PM reminder to the ticket creator')
                .setEmoji('✉️'));
        }

        // Request Ticket Copy
        if (perms.adminCopy !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('copy')
                .setLabel(isAr ? 'طلب نسخة من التذكرة' : 'Request Ticket Copy')
                .setDescription(isAr ? 'طلب نسخة من محادثة التذكرة' : 'Request a copy of the ticket')
                .setEmoji('📋'));
        }

    } else {
        // ── MEMBER MENU ───────────────────────────────────────────────

        // Admin PM Reminder → sends DM/ping to support role (with cooldown)
        if (perms.userReminder !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('adminreminder')
                .setLabel(isAr ? 'تذكير خاص للأدمن' : 'Admin PM Reminder')
                .setDescription(isAr ? 'إرسال تذكير للأدمن عبر رسالة خاصة' : 'Send a PM reminder to the ticket admin')
                .setEmoji('✉️'));
        }

        // Add User to Ticket
        if (perms.userAddUsers !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('adduser')
                .setLabel(isAr ? 'إضافة مستخدم للتذكرة' : 'Add User to Ticket')
                .setDescription(isAr ? 'إضافة مستخدم إلى التذكرة' : 'Add a user to the ticket')
                .setEmoji('👤'));
        }

        // Close Ticket (MEMBER - closes directly without reason)
        if (perms.userClose !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('close')
                .setLabel(isAr ? 'إغلاق التذكرة' : 'Close Ticket')
                .setDescription(isAr ? 'إغلاق التذكرة' : 'Close the ticket')
                .setEmoji('🔒'));
        }

        // Request Ticket Copy
        if (perms.userCopy !== false) {
            options.push(new StringSelectMenuOptionBuilder()
                .setValue('copy')
                .setLabel(isAr ? 'طلب نسخة من التذكرة' : 'Request Ticket Copy')
                .setDescription(isAr ? 'طلب نسخة من محادثة التذكرة' : 'Request a copy of the ticket')
                .setEmoji('📋'));
        }
    }

    if (options.length === 0) {
        return interaction.reply({
            content: isAr ? '❌ لا توجد خيارات متاحة لك في هذه التذكرة.' : '❌ No options available for you.',
            flags: MessageFlags.Ephemeral
        });
    }

    const selectMenu = new StringSelectMenuBuilder()
        .setCustomId('ticket_option_select')
        .setPlaceholder(isAr ? 'اختر إجراءً...' : 'Choose a Ticket Action')
        .addOptions(options);

    const embed = new EmbedBuilder()
        .setTitle(isAr ? '🎫 إدارة التذكرة' : '🎫 Ticket Management')
        .setDescription(isAr
            ? '• اختر إجراءً من القائمة أدناه'
            : '• Select an option from the dropdown menu below')
        .setColor('#5865F2');

    await interaction.reply({
        embeds:     [embed],
        components: [new ActionRowBuilder().addComponents(selectMenu)],
        flags: MessageFlags.Ephemeral
    });
}

// ==================== Handle Ticket Action from Dropdown ====================
async function handleTicketAction(interaction, client, settings) {
    const action = interaction.values[0];
    const isAr   = settings.botLanguage !== 'en';

    if (action === 'close')          return closeTicket(interaction, client, settings);
    if (action === 'memberreminder') return sendMemberReminder(interaction, client, settings);
    if (action === 'adminreminder')  return sendAdminReminder(interaction, client, settings);
    if (action === 'copy')           return sendTicketCopy(interaction, client, settings);
    if (action === 'cancelclaim')    return cancelClaim(interaction, client, settings);

if (action === 'adduser') {
        const userSelect = new UserSelectMenuBuilder()
            .setCustomId(`ticket_adduser_select_${interaction.channelId}`)
            .setPlaceholder(isAr ? 'حدد شخصاً لإضافته إلى التذكرة' : 'Select a user to add to the ticket')
            .setMinValues(1)
            .setMaxValues(1);
        return interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? 'يرجى تحديد شخص لإضافته إلى التذكرة.' : 'Please select a user to add to the ticket.')
                .setColor('#5865F2')],
            components: [new ActionRowBuilder().addComponents(userSelect)],
            flags: MessageFlags.Ephemeral
        });
    }

    if (action === 'removeuser') {
        const userSelect = new UserSelectMenuBuilder()
            .setCustomId(`ticket_removeuser_select_${interaction.channelId}`)
            .setPlaceholder(isAr ? 'حدد شخصاً لإزالته من التذكرة' : 'Select a user to remove from the ticket')
            .setMinValues(1)
            .setMaxValues(1);
        return interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? 'يرجى تحديد شخص لإزالته من التذكرة.' : 'Please select a user to remove from the ticket.')
                .setColor('#5865F2')],
            components: [new ActionRowBuilder().addComponents(userSelect)],
            flags: MessageFlags.Ephemeral
        });
    }
}

// ==================== Add User from Select ====================
async function addUserFromSelect(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const userId = interaction.values[0];
    try {
        const member = await interaction.guild.members.fetch(userId);
        await interaction.channel.permissionOverwrites.edit(member, {
            ViewChannel:        true,
            SendMessages:       true,
            ReadMessageHistory: true
        });

        // تسجيل العضو بقائمة المُضافين بهذه التذكرة
        const ts     = loadTicketSettings();
        const ticket = (ts.openTickets || {})[interaction.channelId];
        if (ticket) {
            if (!ticket.addedUsers) ticket.addedUsers = [];
            if (!ticket.addedUsers.includes(userId)) ticket.addedUsers.push(userId);
            setOpenTicket(interaction.channelId, ticket);
        }

        await interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(`👤 ${isAr ? `تمت إضافة <@${userId}> للتذكرة` : `<@${userId}> has been added to the ticket`}`)
                .setColor('#57F287')],
            components: []
        });
    } catch(e) {
        await interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ تعذّر إضافة المستخدم.' : '❌ Could not add the user.')
                .setColor('#ED4245')],
            components: []
        });
    }
}

// ==================== Remove User from Ticket ====================
async function removeUserFromSelect(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const userId = interaction.values[0];

    const ts     = loadTicketSettings();
    const ticket = (ts.openTickets || {})[interaction.channelId];

    // منع إزالة صاحب التذكرة نفسه
    if (ticket && ticket.userId === userId) {
        return interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ لا يمكن إزالة صاحب التذكرة.' : '❌ You cannot remove the ticket owner.')
                .setColor('#ED4245')],
            components: []
        });
    }

    // السماح فقط بإزالة من تمت إضافته فعلياً للتذكرة
    if (!ticket || !Array.isArray(ticket.addedUsers) || !ticket.addedUsers.includes(userId)) {
        return interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ هذا المستخدم لم يُضَف لهذه التذكرة.' : '❌ This user was not added to this ticket.')
                .setColor('#ED4245')],
            components: []
        });
    }

    try {
        await interaction.channel.permissionOverwrites.delete(userId);

        // حذف العضو من قائمة المُضافين
        ticket.addedUsers = ticket.addedUsers.filter(id => id !== userId);
        setOpenTicket(interaction.channelId, ticket);

        await interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(`🚫 ${isAr ? `تمت إزالة <@${userId}> من التذكرة` : `<@${userId}> has been removed from the ticket`}`)
                .setColor('#ED4245')],
            components: []
        });
    } catch(e) {
        await interaction.update({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ تعذّر إزالة المستخدم.' : '❌ Could not remove the user.')
                .setColor('#ED4245')],
            components: []
        });
    }
}

// ==================== Add User to Ticket ====================
async function addUserToTicket(interaction, client, settings) {
    const isAr  = settings.botLanguage !== 'en';
    const raw   = interaction.fields.getTextInputValue('user_id_input') || '';
    const userId = raw.replace(/[<@!>]/g, '').trim();

    if (!userId || !/^\d+$/.test(userId)) {
        return interaction.reply({
            content: isAr ? '❌ معرّف المستخدم غير صالح.' : '❌ Invalid user ID.',
            flags: MessageFlags.Ephemeral
        });
    }

    try {
        const member = await interaction.guild.members.fetch(userId);
        await interaction.channel.permissionOverwrites.edit(member, {
            ViewChannel:        true,
            SendMessages:       true,
            ReadMessageHistory: true
        });
        await interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(`👤 ${isAr ? `تمت إضافة <@${userId}> للتذكرة` : `<@${userId}> has been added to the ticket`}`)
                .setColor('#57F287')],
        });
    } catch(e) {
        await interaction.reply({
            content: isAr ? '❌ لم يتم العثور على المستخدم.' : '❌ User not found.',
            flags: MessageFlags.Ephemeral
        });
    }
}

// ==================== Cancel Claim (Admin Only) ====================
async function cancelClaim(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const ts     = loadTicketSettings();
    const ticket = (ts.openTickets || {})[interaction.channelId];

    if (!ticket || !ticket.claimedBy) {
        return interaction.reply({
            content: isAr ? '❌ التذكرة غير مُستلمة.' : '❌ Ticket is not claimed.',
            flags: MessageFlags.Ephemeral
        });
    }

    const prevClaimer = ticket.claimedBy;
    delete ticket.claimedBy;
    setOpenTicket(interaction.channelId, ticket);

    await interaction.reply({
        embeds: [new EmbedBuilder()
            .setDescription(`❌ ${isAr
                ? `تم إلغاء استلام التذكرة من <@${prevClaimer}>`
                : `Claim cancelled from <@${prevClaimer}>`}`)
            .setColor('#ED4245')]
    });
}

// ==================== Member PM Reminder (Admin → sends DM to ticket creator) ====================
async function sendMemberReminder(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const ts     = loadTicketSettings();
    const ticket = (ts.openTickets || {})[interaction.channelId];

    if (!ticket) {
        return interaction.reply({ content: isAr ? '❌ لا توجد تذكرة هنا.' : '❌ No ticket found.', flags: MessageFlags.Ephemeral });
    }

    try {
        const member = await interaction.guild.members.fetch(ticket.userId);
        await member.send({
            embeds: [new EmbedBuilder()
                .setTitle(isAr ? ' تذكير بتذكرتك' : ' Ticket Reminder')
                .setDescription(isAr
                    ? `مرحباً! فريق الدعم بانتظار ردك في تذكرتك <#${interaction.channelId}>`
                    : `Hello! The support team is waiting for your reply in <#${interaction.channelId}>`)
                .setColor('#FEE75C')
                .setTimestamp()]
        });
        await interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(`✉️ ${isAr ? `تم إرسال تذكير لـ <@${ticket.userId}>` : `Reminder sent to <@${ticket.userId}>`}`)
                .setColor('#57F287')],
            flags: MessageFlags.Ephemeral
        });
    } catch(e) {
        await interaction.reply({
            content: isAr ? '❌ تعذّر إرسال الرسالة الخاصة للعضو.' : '❌ Could not send DM to user.',
            flags: MessageFlags.Ephemeral
        });
    }
}

// ==================== Admin PM Reminder (Member → DM to claimed admin) WITH COOLDOWN ====================
const ADMIN_REMINDER_COOLDOWN_MS = 5 * 60 * 1000; // 5 minutes

async function sendAdminReminder(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const ts     = loadTicketSettings();
    const ticket = (ts.openTickets || {})[interaction.channelId];
    const channelId = interaction.channelId;

    // No claimed admin on this ticket
    if (!ticket || !ticket.claimedBy) {
        return interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ لا يوجد مشرف مُعين حاليًا لهذه التذكرة.' : '❌ No admin is currently assigned to this ticket.')
                .setColor('#ED4245')],
            flags: MessageFlags.Ephemeral
        });
    }

    // COOLDOWN CHECK
    const now = Date.now();
    const lastUsed = adminReminderCooldowns.get(channelId);

    if (lastUsed && (now - lastUsed) < ADMIN_REMINDER_COOLDOWN_MS) {
        const remainingMs = ADMIN_REMINDER_COOLDOWN_MS - (now - lastUsed);
        const remainingMinutes = Math.ceil(remainingMs / 60000);
        return interaction.reply({
            embeds: [new EmbedBuilder()
                .setTitle(isAr ? '⏳ انتظر من فضلك' : '⏳ Please Wait')
                .setDescription(isAr
                    ? `يمكنك إرسال تذكير مرة أخرى بعد **${remainingMinutes}** دقيقة.`
                    : `You can send another reminder in **${remainingMinutes}** minute(s).`)
                .setColor('#FEE75C')],
            flags: MessageFlags.Ephemeral
        });
    }

    // Set/update the cooldown timestamp
    adminReminderCooldowns.set(channelId, now);

    try {
        const adminMember = await interaction.guild.members.fetch(ticket.claimedBy);
        await adminMember.send({
            embeds: [new EmbedBuilder()
                .setTitle(isAr ? '🔔 تذكير بتذكرة' : '🔔 Ticket Reminder')
                .setDescription(isAr
                    ? `العضو <@${interaction.user.id}> يطلب منك الرد في التذكرة <#${interaction.channelId}>`
                    : `Member <@${interaction.user.id}> is requesting your attention in <#${interaction.channelId}>`)
                .setColor('#FEE75C')
                .setTimestamp()]
        });
        await interaction.reply({
            embeds: [new EmbedBuilder()
                .setTitle(isAr ? '✅ تم إرسال تذكير للمشرف' : '✅ Reminder Sent')
                .setDescription(isAr
                    ? `تم إرسال تذكير إلى <@${ticket.claimedBy}> بخصوص هذه التذكرة.`
                    : `A reminder was sent to <@${ticket.claimedBy}> regarding this ticket.`)
                .setColor('#57F287')],
            flags: MessageFlags.Ephemeral
        });
    } catch(e) {
        // Remove cooldown if the send failed, so user can try again
        adminReminderCooldowns.delete(channelId);
        await interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '❌ تعذّر إرسال الرسالة الخاصة للمشرف.' : '❌ Could not send DM to the admin.')
                .setColor('#ED4245')],
            flags: MessageFlags.Ephemeral
        });
    }
}

// ==================== Send Ticket Copy (Transcript) ====================
async function sendTicketCopy(interaction, client, settings) {
    const isAr = settings.botLanguage !== 'en';
    await interaction.deferReply({ flags: MessageFlags.Ephemeral });

    try {
        // ── جلب بيانات التذكرة ───────────────────────────────────
        const ts         = loadTicketSettings();
        const ticket     = (ts.openTickets || {})[interaction.channelId];
        const categories = ts.categories || [];
        const cat        = ticket ? categories[ticket.categoryIndex] : null;

        const openedBy  = ticket
            ? (await interaction.guild.members.fetch(ticket.userId).catch(() => null))
            : null;
        const claimedBy = ticket?.claimedBy
            ? (await interaction.guild.members.fetch(ticket.claimedBy).catch(() => null))
            : null;

        // ── بناء الـ Embed الاحترافي ─────────────────────────────
        const ticketEmbed = new EmbedBuilder()
            .setTitle(isAr ? '🎫 نسخة من التذكرة' : '🎫 Ticket Copy')
            .setColor('#5865F2')
            .addFields(
                {
                    name:   isAr ? '**[ 👤 ] : فُتحت بواسطة**' : '**[ 👤 ] : Opened By**',
                    value:  openedBy
                        ? `<@${openedBy.user.id}>`
                        : (ticket?.userId ? `<@${ticket.userId}>` : (isAr ? 'غير معروف' : 'Unknown')),
                    inline: true
                },
                {
                    name:   isAr ? '**[ 💼 ] : استُلمت بواسطة**' : '**[ 💼 ] : Claimed By**',
                    value:  claimedBy ? `<@${claimedBy.user.id}>` : (isAr ? 'لا أحد' : 'No one'),
                    inline: true
                },
                {
                    name:   isAr ? '**[ 📋 ] : اسم القناة**' : '**[ 📋 ] : Channel**',
                    value:  `<#${interaction.channelId}>`,
                    inline: true
                },
                {
                    name:   isAr ? '**[ 📅 ] : وقت الفتح**' : '**[ 📅 ] : Opened At**',
                    value:  ticket?.createdAt
                        ? `<t:${Math.floor(new Date(ticket.createdAt).getTime() / 1000)}:F>`
                        : (isAr ? 'غير معروف' : 'Unknown'),
                    inline: true
                },
                {
                    name:   isAr ? '**[ ⏰ ] : وقت الطلب**' : '**[ ⏰ ] : Requested At**',
                    value:  `<t:${Math.floor(Date.now() / 1000)}:F>`,
                    inline: true
                },
                {
                    name:   isAr ? '**[ 🗂️ ] : الفئة**' : '**[ 🗂️ ] : Category**',
                    value:  cat?.name || (isAr ? 'غير محددة' : 'Unknown'),
                    inline: true
                }
            )
            .setFooter({
                text: isAr
                    ? `طُلبت بواسطة ${interaction.user.tag}`
                    : `Requested by ${interaction.user.tag}`,
                iconURL: interaction.user.displayAvatarURL()
            })
            .setTimestamp();

// ── بناء ملف الـ HTML Transcript ─────────────────────────
       let transcriptFile = null;
        try {
            const ticketInfoText = isAr
                ? `فُتحت بواسطة: ${openedBy ? openedBy.user.tag : 'غير معروف'} | الفئة: ${cat?.name || 'غير محددة'}`
                : `Opened by: ${openedBy ? openedBy.user.tag : 'Unknown'} | Category: ${cat?.name || 'Unknown'}`;
            const htmlBuffer = await generateTranscriptHTML(interaction.channel, ticketInfoText);
            transcriptFile = new AttachmentBuilder(htmlBuffer, { name: `transcript-${interaction.channel.name}.html` });
        } catch(e) {
            console.error('❌ خطأ في بناء ملف النسخة:', e);
        }

// ── رفع الملف بروم مخفي خاص بالبوت فقط (ما يشوفه أي عضو أو أدمن) ─
        let fileUrl = null;
        if (transcriptFile) {
            try {
                const storageChannel = await getOrCreateStorageChannel(interaction.guild);
                if (storageChannel) {
                    const storageMsg = await storageChannel.send({ files: [transcriptFile] });
                    fileUrl = storageMsg.attachments.first()?.url || null;
                }
            } catch(e) {}
        }

        // ── إرسال للـ DM (Embed + زر تحميل فقط، بدون مرفق) ────────
        try {
            const dmPayload = { embeds: [ticketEmbed] };

            if (fileUrl) {
                const downloadRow = new ActionRowBuilder().addComponents(
                    new ButtonBuilder()
                        .setLabel(isAr ? '⬇️ تحميل النسخة' : '⬇️ Download Transcript')
                        .setStyle(ButtonStyle.Link)
                        .setURL(fileUrl)
                );
                dmPayload.components = [downloadRow];
            }

            await interaction.user.send(dmPayload);

            await interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(isAr
                        ? '✅ تم إرسال نسخة التذكرة في رسالتك الخاصة.'
                        : '✅ Ticket copy sent to your DMs.')
                    .setColor('#57F287')]
            });
        } catch(e) {
            await interaction.editReply({
                embeds: [new EmbedBuilder()
                    .setDescription(isAr
                        ? '❌ تعذّر الإرسال. تأكد من أن رسائلك الخاصة مفتوحة.'
                        : '❌ Could not send copy. Please enable your DMs.')
                    .setColor('#ED4245')]
            });
        }

    } catch(e) {
        await interaction.editReply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr
                    ? '❌ حدث خطأ أثناء إنشاء النسخة.'
                    : '❌ An error occurred while creating the copy.')
                .setColor('#ED4245')]
        });
    }
}

// ==================== Claim Ticket ====================
async function claimTicket(interaction, client, settings) {
    const ts    = loadTicketSettings();
    const perms = ts.permissions || {};
    const isAr  = settings.botLanguage !== 'en';

    if (perms.adminClaim === false) {
        return interaction.reply({ content: isAr ? '❌ هذه الصلاحية معطلة.' : '❌ This action is disabled.', flags: MessageFlags.Ephemeral });
    }

    const ticket = (ts.openTickets || {})[interaction.channelId];
    if (!ticket) {
        return interaction.reply({ content: isAr ? '❌ لا توجد تذكرة في هذا الروم.' : '❌ No ticket found here.', flags: MessageFlags.Ephemeral });
    }
    // Ticket owner cannot claim their own ticket
    if (ticket.userId === interaction.user.id) {
        return interaction.reply({
            embeds: [new EmbedBuilder()
                .setDescription(isAr ? '  لا يمكنك استلام تذكرتك الخاصة.' : '  You cannot claim your own ticket.')
                .setColor('#ED4245')],
            flags: MessageFlags.Ephemeral
        });
    }

    if (ticket.claimedBy) {
        return interaction.reply({
            content: `❌ ${isAr ? `هذه التذكرة مُستلمة بالفعل من <@${ticket.claimedBy}>` : `Ticket already claimed by <@${ticket.claimedBy}>`}.`,
            flags: MessageFlags.Ephemeral
        });
    }

ticket.claimedBy = interaction.user.id;
    setOpenTicket(interaction.channelId, ticket);

    await interaction.reply({
        embeds: [new EmbedBuilder()
            .setTitle(isAr ? '  تم استلام التذكرة' : '  Ticket Claimed')
            .setDescription(isAr
                ? `تم استلام هذه التذكرة بواسطة <@${interaction.user.id}>.`
                : `This ticket has been claimed by <@${interaction.user.id}>.`)
            .setColor('#2ed015')]
    });
}

// ══════════════════════════════════════════════════════════════════════════
// Close Ticket - ADMIN sees modal, MEMBER closes directly
// ══════════════════════════════════════════════════════════════════════════
async function closeTicket(interaction, client, settings) {
    const ts     = loadTicketSettings();
    const perms  = ts.permissions || {};
    const isAr   = settings.botLanguage !== 'en';
    const ticket = (ts.openTickets || {})[interaction.channelId];

    if (!ticket) {
        return interaction.reply({
            content: isAr ? '❌ لا توجد تذكرة هنا.' : '❌ No ticket found here.',
            flags: MessageFlags.Ephemeral
        });
    }

    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
                 || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    const isOwner = ticket.userId === interaction.user.id;

    if (!isAdmin && (!isOwner || perms.userClose === false)) {
        return interaction.reply({
            content: isAr ? '❌ ليس لديك صلاحية لإغلاق هذه التذكرة.' : '❌ You cannot close this ticket.',
            flags: MessageFlags.Ephemeral
        });
    }

    
    if (isAdmin) {
        const modal = new ModalBuilder()
            .setCustomId(`ticket_close_modal_${interaction.channelId}`)
            .setTitle(isAr ? 'إغلاق التذكرة' : 'Close Ticket');

        const reasonInput = new TextInputBuilder()
            .setCustomId('close_reason_input')
            .setLabel(isAr ? 'سبب )' : 'Reason')
            .setStyle(TextInputStyle.Paragraph)
            .setRequired(false)
            .setPlaceholder(isAr ? 'اكتب سبب إغلاق التذكرة...' : 'Enter the reason for closing this ticket...')
            .setMaxLength(1000);

        const firstActionRow = new ActionRowBuilder().addComponents(reasonInput);
        modal.addComponents(firstActionRow);

        await interaction.showModal(modal);
        return;
    }

// ✅ إذا كان عضو عادي → أغلق التذكرة مباشرة
    await interaction.deferReply();
    await executeCloseTicket(interaction, client, settings, null, false);
}

// ══════════════════════════════════════════════════════════════════════════
// Process Close Modal - handles the submitted reason (ADMIN ONLY)
// ══════════════════════════════════════════════════════════════════════════
async function processCloseModal(interaction, client, settings) {
    const isAr   = settings.botLanguage !== 'en';
    const rawReason = interaction.fields.getTextInputValue('close_reason_input') || '';
    const reason = rawReason.trim() || null;

    try {
        await interaction.deferReply();
    } catch (e) {
        console.error('⚠️ التفاعل انتهت صلاحيته قبل الرد عليه (Unknown interaction):', e.message);
        return; // ما فيه شي نقدر نسويه بعدها، نوقف بهدوء بدل ما يطلع كراش
    }

    await executeCloseTicket(interaction, client, settings, reason, true);
}

// ══════════════════════════════════════════════════════════════════════════
// Execute Close Ticket - shared logic for both admin and member
// ══════════════════════════════════════════════════════════════════════════
async function executeCloseTicket(interaction, client, settings, reason, closedByAdmin) {
    const isAr   = settings.botLanguage !== 'en';
    const ts     = loadTicketSettings();
    const ticket = (ts.openTickets || {})[interaction.channelId];

    if (!ticket) {
        try {
            if (interaction.replied || interaction.deferred) {
                await interaction.editReply({
                    content: isAr ? '❌ لا توجد تذكرة هنا.' : '❌ No ticket found here.'
                });
            } else {
                await interaction.reply({
                    content: isAr ? '❌ لا توجد تذكرة هنا.' : '❌ No ticket found here.',
                    flags: MessageFlags.Ephemeral
                });
            }
        } catch(e) {}
        return;
    }

// إزالة صلاحية المشاهدة لصاحب التذكرة
    try {
        await interaction.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: false });
    } catch(e) {
        console.error('❌ فشل إخفاء الروم عن العضو عند الإغلاق:', e.message);
        try {
            await new Promise(r => setTimeout(r, 500));
            await interaction.channel.permissionOverwrites.edit(ticket.userId, { ViewChannel: false });
        } catch(e2) {
             
        }
    }

    try {
        const currentName = interaction.channel.name;
        const newName = currentName.replace(/🎫/g, '🔒');
        if (newName !== currentName) {
            interaction.channel.setName(newName).catch(() => {});
        }
    } catch(e) {
       
    }

    // السبب النهائي
    const finalReason = reason
        ? reason
        : (isAr ? 'لم يتم تقديم سبب' : 'No reason provided');

   
    if (closedByAdmin) {
        interaction.guild.members.fetch(ticket.userId)
            .then(owner => owner.send({
                embeds: [new EmbedBuilder()
                    .setTitle(isAr ? '🔒 تم إغلاق تذكرتك' : '🔒 Your Ticket Has Been Closed')
                    .setDescription(isAr
                        ? `**التذكرة:** \`${interaction.channel.name}\`\n\n**سبب الإغلاق:**\n\`\`\`${finalReason}\`\`\``
                        : `**Ticket:** \`${interaction.channel.name}\`\n\n**Close Reason:**\n\`\`\`${finalReason}\`\`\``)
                    .setColor('#ED4245')
                    .setTimestamp()]
            }))
            .catch(() => {});
    }

   // تحديث حالة التذكرة إلى مغلقة
    ticket.open = false;
    setOpenTicket(interaction.channelId, ticket);

    // 📋 حفظ نسخة تلقائية من التذكرة في روم اللوج عند الإغلاق
    autoSaveTranscript(interaction.guild, interaction.channel, ticket, ts).catch(() => {});

    const actionRow = new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`ticket_reopen_${interaction.channelId}`)
            .setLabel(isAr ? 'فتح' : 'Open')
            .setEmoji('🔓')
            .setStyle(ButtonStyle.Secondary),
        new ButtonBuilder()
            .setCustomId(`ticket_delete_${interaction.channelId}`)
            .setLabel(isAr ? 'حذف' : 'Delete')
            .setEmoji('🗑️')
            .setStyle(ButtonStyle.Danger)
    );

    // بناء رسالة الإغلاق
    const closeDescription = reason
        ? (isAr
            ? `**تم إغلاق التذكرة بواسطة <@${interaction.user.id}>**\n\n📝 **السبب:** ${finalReason}`
            : `**Ticket closed by <@${interaction.user.id}>**\n\n📝 **Reason:** ${finalReason}`)
        : (isAr
            ? `**تم إغلاق التذكرة بواسطة <@${interaction.user.id}>**`
            : `**Ticket closed by <@${interaction.user.id}>**`);

    const closedEmbed = new EmbedBuilder()
        .setTitle(isAr ? '🔒 تم إغلاق التذكرة' : '🔒 Ticket Closed')
        .setDescription(closeDescription)
        .setColor('#ED4245')
        .setTimestamp();

// إرسال رسالة الإغلاق
    try {
        if (interaction.replied || interaction.deferred) {
            await interaction.editReply({ embeds: [closedEmbed], components: [actionRow] });
        } else {
            await interaction.reply({ embeds: [closedEmbed], components: [actionRow] });
        }
    } catch(e) {
        await interaction.channel.send({ embeds: [closedEmbed], components: [actionRow] });
    }
}

// ==================== Reopen Ticket ====================
async function reopenTicket(interaction, client, settings) {
    const ts    = loadTicketSettings();
    const isAr  = settings.botLanguage !== 'en';
    const ticket = (ts.openTickets || {})[interaction.channelId];

    if (!ticket) {
        return interaction.reply({ content: isAr ? '❌ لا توجد تذكرة هنا.' : '❌ No ticket found here.', flags: MessageFlags.Ephemeral });
    }

    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
                 || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    if (!isAdmin) {
        return interaction.reply({
            content: isAr ? '❌ فقط الأدمن يمكنه إعادة فتح التذكرة.' : '❌ Only admins can reopen tickets.',
            flags: MessageFlags.Ephemeral
        });
    }

// نحجز وقت أطول فوراً قبل أي عملية شبكية
 await interaction.deferUpdate();

    ticket.open = true;
    ticket.idleWarned = false;
    setOpenTicket(interaction.channelId, ticket);

    // Restore owner's view permission — مع مهلة قصوى 5 ثواني عشان ما يعلق للأبد
    const withTimeout = (promise, ms) => Promise.race([
        promise,
        new Promise((_, reject) => setTimeout(() => reject(new Error('TIMEOUT')), ms))
    ]);

    let permSuccess = false;
    try {
        const targetMember = await withTimeout(
            interaction.guild.members.fetch(ticket.userId),
            5000
        );
        await withTimeout(
            interaction.channel.permissionOverwrites.edit(targetMember, { ViewChannel: true, SendMessages: true }),
            5000
        );
        permSuccess = true;
 } catch(e) {
        // تم تعطيل الطباعة بالترمينال
    }

    // ══════════════════════════════════════════════════════════════
    // 🎫 إعادة اسم الروم من 🔒・إلى 🎫・ (تجميلي - بدون انتظار)
    // ══════════════════════════════════════════════════════════════
    try {
        const currentName = interaction.channel.name;
        const newName = currentName.replace(/🔒/g, '🎫');
        if (newName !== currentName) {
            interaction.channel.setName(newName).catch(() => {});
        }
    } catch(e) {
        // إذا فشل تغيير الاسم، نكمل عادي
    }

   await interaction.editReply({
        embeds: [new EmbedBuilder()
            .setTitle(permSuccess
                ? (isAr ? '🔓 تم إعادة فتح التذكرة' : '🔓 Ticket Reopened')
                : (isAr ? '⚠️ تم إعادة الفتح جزئياً' : '⚠️ Partially Reopened'))
            .setDescription(permSuccess
                ? (isAr ? `أُعيد فتح التذكرة بواسطة <@${interaction.user.id}>` : `Ticket reopened by <@${interaction.user.id}>`)
                : (isAr
                    ? `أُعيد فتح التذكرة، لكن تعذّر إظهار الروم لصاحبها فوراً بسبب ضغط على ديسكورد. اضغط Open مرة ثانية بعد قليل.`
                    : `Ticket reopened, but the room couldn't be shown to the owner immediately due to Discord rate limits. Press Open again shortly.`))
            .setColor(permSuccess ? '#57F287' : '#FEE75C')],
        components: permSuccess ? [] : undefined
    });
}

// ==================== Delete Ticket ====================
async function deleteTicket(interaction, client, settings) {
    const ts    = loadTicketSettings();
    const perms = ts.permissions || {};
    const isAr  = settings.botLanguage !== 'en';

    if (perms.adminDelete === false) {
        return interaction.reply({ content: isAr ? '❌ هذه الصلاحية معطلة.' : '❌ This action is disabled.', flags: MessageFlags.Ephemeral });
    }

    const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageChannels)
                 || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
    if (!isAdmin) {
        return interaction.reply({
            content: isAr ? '❌ ليس لديك صلاحية لحذف التذكرة.' : '❌ No permission to delete this ticket.',
            flags: MessageFlags.Ephemeral
        });
    }

    removeOpenTicket(interaction.channelId);

    await interaction.reply({
        content: isAr ? '🗑️ سيتم حذف التذكرة خلال 3 ثواني...' : '🗑️ Deleting ticket in 3 seconds...'
    });

    setTimeout(async () => {
        try { await interaction.channel.delete(); } catch(e) {}
    }, 3000);
}