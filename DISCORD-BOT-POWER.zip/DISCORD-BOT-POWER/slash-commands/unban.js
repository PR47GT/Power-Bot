const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'إلغاء حظر عضو',
        option_user_id: 'معرف المستخدم',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        invalidId: '❌ معرف المستخدم غير صحيح.',
        botNoPerm: '❌ البوت لا يملك صلاحية إلغاء الحظر',
        notBanned: '❌ هذا المستخدم غير محظور في السيرفر.',
        success: (user) => `✅ تم إلغاء حظر \`${user.tag}\``,
        failed: '❌ فشل إلغاء الحظر:',
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Unban a user',
        option_user_id: 'User ID',
        disabled: '⚠️ This command is currently disabled.',
        invalidId: '❌ Invalid user ID.',
        botNoPerm: '❌ Bot does not have permission to unban members',
        notBanned: '❌ This user is not banned in the server.',
        success: (user) => `✅ \`${user.tag}\` has been unbanned`,
        failed: '❌ Failed to unban:',
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'unban',
        description: 'Unban a user | إلغاء حظر',
        default_member_permissions: PermissionFlagsBits.BanMembers.toString(),
        options: [
            { 
                name: 'user_id', 
                description: 'User ID', 
                type: 3, 
                required: true 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.unban || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const userId = interaction.options.getString('user_id');
            
            if (!/^\d+$/.test(userId)) {
                return await interaction.editReply({ content: t.invalidId });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            try {
                const banList = await interaction.guild.bans.fetch();
                const bannedUser = banList.get(userId);
                
                if (!bannedUser) {
                    return await interaction.editReply({ content: t.notBanned });
                }
                
                const user = bannedUser.user;
                await interaction.guild.members.unban(userId);
                
                const successMessage = t.success(user);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ 
                    content: `${t.failed} ${error.message}`
                });
            }
            
        } catch (error) {
            console.error('❌ Unban command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};