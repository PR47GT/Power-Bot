const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'طرد عضو من السيرفر',
        option_user: 'العضو',
        option_reason: 'السبب',
        noReason: '\`لا يوجد سبب\`',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        notKickable: '❌ لا يمكنني طرد هذا العضو. تأكد أن رتبتي أعلى.',
        botNoPerm: '❌ البوت لا يملك صلاحية طرد الأعضاء',
        success: (user, reason) => `✅ تم طرد \`${user.tag}\`\nالسبب: ${reason}`,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Kick a member from the server',
        option_user: 'User',
        option_reason: 'Reason',
        noReason: '\`No reason provided\`',
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '❌ Member not found in the server.',
        notKickable: '❌ Cannot kick this member. Ensure my role is higher.',
        botNoPerm: '❌ Bot does not have permission to kick members',
        success: (user, reason) => `✅ \`${user.tag}\` has been kicked\nReason: ${reason}`,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'kick',
        description: 'Kick a member | طرد عضو',
        default_member_permissions: PermissionFlagsBits.KickMembers.toString(),
        options: [
            { name: 'user', description: 'User', type: 6, required: true },
            { name: 'reason', description: 'Reason', type: 3, required: false }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.kick || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || t.noReason;
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!targetMember.kickable) {
                return await interaction.editReply({ content: t.notKickable });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.KickMembers)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            await targetMember.kick(reason);
            
            const successMessage = t.success(targetUser, reason);
            
            if (config.deleteResponse) {
                await interaction.editReply({ content: successMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }
            
        } catch (error) {
            console.error('❌ Kick command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};