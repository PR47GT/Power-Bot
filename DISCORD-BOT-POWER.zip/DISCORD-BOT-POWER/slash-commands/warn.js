const { MessageFlags, EmbedBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');
const { addTempRole } = require('./tempRoles');

const { loadData, saveData } = require('./tempRoles');

function parseDuration(input) {
    if (!input) return null;
    const match = input.trim().match(/^(\d+)(m|h|d)$/i);
    if (!match) return null;
    const value = parseInt(match[1]);
    const unit  = match[2].toLowerCase();
    if (unit === 'm') return value * 60 * 1000;
    if (unit === 'h') return value * 60 * 60 * 1000;
    if (unit === 'd') return value * 24 * 60 * 60 * 1000;
    return null;
}

function formatDuration(raw, lang) {
    const m = String(raw).match(/^(\d+)(m|h|d)$/i);
    if (!m) return raw;
    const v = m[1], u = m[2].toLowerCase();
    if (lang === 'ar') {
        if (u === 'm') return `${v} دقيقة`;
        if (u === 'h') return `${v} ساعة`;
        return `${v} يوم`;
    }
    if (u === 'm') return `${v} Minute(s)`;
    if (u === 'h') return `${v} Hour(s)`;
    return `${v} Day(s)`;
}

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try { return JSON.parse(fs.readFileSync(modPath, 'utf8')); }
        catch (e) { return {}; }
    }
    return {};
}

function getWarns() {
    return loadData().warns;
}

function saveWarns(warns) {
    const data = loadData();
    data.warns = warns;
    saveData(data);
}

async function checkWarnThresholds(guild, userId, warnCount, lang, settings, moderatorId, warnReason, client, durationMs) {
    const warnActions = settings.warnActions;
    if (!warnActions || !warnActions.enabled) return;

    const thresholds = warnActions.thresholds || [];
    const matched = thresholds
        .filter(th => warnCount === th.count)
        .sort((a, b) => b.count - a.count)[0];

    if (!matched) return;

    try {
        const member = await guild.members.fetch(userId).catch(() => null);
        if (!member) return;

        const botMember = guild.members.me || await guild.members.fetch(client.user.id).catch(() => null);

        const reason = lang === 'ar'
            ? `إجراء تلقائي: بلغ ${warnCount} تحذيرات`
            : `Auto action: reached ${warnCount} warnings`;

        if (matched.action === 'mute') {
            const ms = (matched.duration || 60) * 60 * 1000;
            await member.timeout(ms, reason).catch(err => console.error('❌ فشل الكتم التلقائي:', err.message));

        } else if (matched.action === 'kick') {
            await member.kick(reason).catch(err => console.error('❌ فشل الطرد التلقائي:', err.message));

        } else if (matched.action === 'ban') {
            await guild.members.ban(userId, { reason }).catch(err => console.error('❌ فشل الحظر التلقائي:', err.message));

        } else if (matched.action === 'role') {
            if (!matched.roleId) {
                console.error('⚠️ إجراء "إضافة رتبة" مفعّل لكن لا توجد رتبة محددة (roleId فارغ).');
            } else {
                const role = guild.roles.cache.get(matched.roleId);
                if (!role) {
                    console.error(`⚠️ الرتبة بالآيدي ${matched.roleId} غير موجودة (ربما انحذفت من السيرفر).`);
                } else if (!botMember || role.position >= botMember.roles.highest.position) {
                    console.error(`⚠️ لا يمكن إضافة الرتبة "${role.name}" — رتبة البوت أدنى منها أو تساويها بالترتيب.`);
                } else {
                    await member.roles.add(role, reason).catch(err => console.error('❌ فشل إضافة الرتبة التلقائية:', err.message));

                    if (durationMs) {
                        const expiresAt = new Date(Date.now() + durationMs).toISOString();
                        addTempRole(guild.id, userId, matched.roleId, expiresAt);
                    }
                }
            }
        }

        if (warnActions.logChannel) {
            const logCh = guild.channels.cache.get(warnActions.logChannel);
            if (logCh) {
                const actionColors = { mute: '#01f737', kick: '#f3eb06', ban: '#ED4245', role: '#5865F2' };
                const actionDisplay = lang === 'ar'
                    ? { mute: 'كتم', kick: 'طرد', ban: 'حظر', role: 'إضافة رتبة' }[matched.action] || matched.action.toUpperCase()
                    : { mute: 'MUTE', kick: 'KICK', ban: 'BAN', role: 'ADD ROLE' }[matched.action] || matched.action.toUpperCase();

                let muteDurationDisplay = null;
                if (matched.action === 'mute') {
                    const muteMinutes = matched.duration || 60;
                    if (muteMinutes < 60) {
                        muteDurationDisplay = lang === 'ar' ? `${muteMinutes} دقيقة` : `${muteMinutes} Minute(s)`;
                    } else if (muteMinutes % 1440 === 0) {
                        const d = muteMinutes / 1440;
                        muteDurationDisplay = lang === 'ar' ? `${d} يوم` : `${d} Day(s)`;
                    } else {
                        const h = Math.round(muteMinutes / 60);
                        muteDurationDisplay = lang === 'ar' ? `${h} ساعة` : `${h} Hour(s)`;
                    }
                }

                const moderatorMember = await guild.members.fetch(moderatorId).catch(() => null);
                const moderatorTag    = moderatorMember ? moderatorMember.user.tag : moderatorId;

                let actionDescription = lang === 'ar'
                    ? `**العضو:** <@${userId}>\n**الاسم:** \`${member.user.username}\`\n**الآيدي:** \`${userId}\`\n\n`
                    : `**Member:** <@${userId}>\n**Name:** \`${member.user.username}\`\n**ID:** \`${userId}\`\n\n`;

                actionDescription += lang === 'ar'
                    ? `**التحذيرات:** \`${warnCount}\`\n**الإجراء:** ${actionDisplay}\n`
                    : `**Warnings:** \`${warnCount}\`\n**Action:** ${actionDisplay}\n`;

                if (muteDurationDisplay) {
                    actionDescription += lang === 'ar'
                        ? `**مدة الكتم:** ${muteDurationDisplay}\n`
                        : `**Mute Duration:** ${muteDurationDisplay}\n`;
                }

                if (matched.action === 'role' && matched.roleId) {
                    actionDescription += lang === 'ar'
                        ? `**الرتبة المضافة:** <@&${matched.roleId}>\n`
                        : `**Role Added:** <@&${matched.roleId}>\n`;

                    if (durationMs) {
                        actionDescription += lang === 'ar'
                            ? `**مدة الرتبة:** ${formatDuration(
                                  durationMs % 86400000 === 0 ? `${durationMs / 86400000}d` :
                                  durationMs % 3600000 === 0 ? `${durationMs / 3600000}h` :
                                  `${Math.round(durationMs / 60000)}m`, lang)}\n`
                            : `**Role Duration:** ${formatDuration(
                                  durationMs % 86400000 === 0 ? `${durationMs / 86400000}d` :
                                  durationMs % 3600000 === 0 ? `${durationMs / 3600000}h` :
                                  `${Math.round(durationMs / 60000)}m`, lang)}\n`;
                    }
                }

                actionDescription += lang === 'ar'
                    ? `**السبب:** \`${warnReason}\`\n\n`
                    : `**Reason:** \`${warnReason}\`\n\n`;

                actionDescription += lang === 'ar'
                    ? `**بواسطة:** <@${moderatorId}>\n**الاسم:** \`${moderatorTag}\`\n**الآيدي:** \`${moderatorId}\`\n\n`
                    : `**By:** <@${moderatorId}>\n**Name:**\` ${moderatorTag}\`\n**ID:** \`${moderatorId}\`\n\n`;

                actionDescription += `**${new Date().toLocaleString('en-US')}**`;

                const embed = new EmbedBuilder()
                    .setColor(actionColors[matched.action] || '#5865F2')
                    .setTitle(lang === 'ar' ? '⚠️ إجراء تحذير تلقائي' : '⚠️ Auto Warn Action')
                    .setDescription(actionDescription);

                logCh.send({ embeds: [embed] }).catch(err => console.error('❌ فشل إرسال سجل الإجراء التلقائي:', err.message));
            }
        }
    } catch (e) {
        console.error('❌ خطأ داخل checkWarnThresholds:', e);
    }
}

module.exports = {
    data: {
        name: 'warn',
        description: 'تحذير عضو | Warn a member',
        description_localizations: { 'en-US': 'Warn a member', ar: 'تحذير عضو في السيرفر' },
        options: [
            { name: 'user',     description: 'العضو',                       type: 6, required: true  },
            { name: 'reason',   description: 'سبب التحذير',                 type: 3, required: false },
            { name: 'duration', description: 'مدة التحذير مثال: 30m أو 1h أو 2d', type: 3, required: false }
        ]
    },

    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.warn || {
                enabled: true, deniedRoles: [], allowedRoles: [],
                deniedChannels: [], allowedChannels: [],
                deleteCommand: false, deleteResponse: false
            };

            if (!config.enabled) {
                return await interaction.editReply({
                    content: lang === 'ar' ? '⚠️ هذا الأمر معطل حالياً.' : '⚠️ This command is currently disabled.'
                });
            }

            const permission = checkPermissions(interaction.member, interaction.channelId, config);
            if (!permission.allowed)
                return await interaction.editReply({ content: permission.reason });

            const targetUser  = interaction.options.getUser('user');
            const reason      = interaction.options.getString('reason') || (lang === 'ar' ? 'بدون سبب' : 'No reason provided');
            const durationRaw = interaction.options.getString('duration') || null;
            const durationMs  = parseDuration(durationRaw);

            if (durationRaw && !durationMs) {
                return await interaction.editReply({
                    content: lang === 'ar'
                        ? '❌ صيغة المدة غير صحيحة. استخدم مثلاً: `30m` لنصف ساعة، `1h` لساعة، أو `2d` ليومين.'
                        : '❌ Invalid duration format. Use e.g. `30m` for 30 minutes, `1h` for 1 hour, or `2d` for 2 days.'
                });
            }

            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

            if (!targetMember)
                return await interaction.editReply({ content: lang === 'ar' ? '⚠️ هذا العضو غير موجود في السيرفر.' : '⚠️ This user is not in the server.' });
            if (targetUser.id === client.user.id)
                return await interaction.editReply({ content: lang === 'ar' ? '❌ لا يمكنني تحذير نفسي.' : '❌ I cannot warn myself.' });
            if (targetMember.permissions.has('Administrator'))
                return await interaction.editReply({ content: lang === 'ar' ? '❌ لا يمكنك تحذير أدمن.' : '❌ You cannot warn an admin.' });

            const warns   = getWarns();
            const guildId = interaction.guildId;

            if (!warns[guildId]) warns[guildId] = {};
            if (!warns[guildId][targetUser.id]) warns[guildId][targetUser.id] = [];

            const expiresAt = durationMs ? new Date(Date.now() + durationMs).toISOString() : null;

            warns[guildId][targetUser.id].push({
                reason,
                moderator: interaction.user.id,
                timestamp: new Date().toISOString(),
                expiresAt
            });

            saveWarns(warns);

            const newCount = warns[guildId][targetUser.id].length;
            await checkWarnThresholds(interaction.guild, targetUser.id, newCount, lang, settings, interaction.user.id, reason, client, durationMs);

            // ===== Embed =====
            const durationDisplay = durationRaw
                ? formatDuration(durationRaw, lang)
                : (lang === 'ar' ? '♾️ دائم' : '♾️ Permanent');

            const expiresDisplay = expiresAt
                ? new Date(expiresAt).toLocaleDateString(
                      lang === 'ar' ? 'ar-SA' : 'en-US',
                      { year: 'numeric', month: 'short', day: 'numeric' }
                  )
                : null;

            let description = lang === 'ar'
                ? `**معلومات العضو**\n**العضو:** ${targetUser}\n**الاسم:** \`${targetUser.tag}\`\n**الآيدي:** \`${targetUser.id}\`\n\n`
                : `**Member Info**\n**Member:** ${targetUser}\n**Name:** \`${targetUser.tag}\`\n**ID:** \`${targetUser.id}\`\n\n`;

            if (lang === 'ar') {
                description +=
                    `**رقم التحذير:** \`${newCount}\`\n` +
                    `**المدة:** ${durationDisplay}\n` +
                    `**السبب:** \`${reason}\``;
            } else {
                description +=
                    `**Warning #:** \`${newCount}\`\n\n` +
                    `**Duration:** ${durationDisplay}\n\n` +
                    `**Reason:** \`${reason}\``;
            }

            if (expiresDisplay) {
                description += lang === 'ar'
                    ? `\n\n**ينتهي في:** ${expiresDisplay}`
                    : `\n\n**Expires At:** ${expiresDisplay}`;
            }

            const embed = new EmbedBuilder()
                .setColor('#fd0000')
                .setTitle(lang === 'ar' ? '⚠️ تم إصدار تحذير' : '⚠️ Warning Issued')
                .setThumbnail(targetUser.displayAvatarURL({ extension: 'png', size: 128 }))
                .setDescription(description)
                .setFooter({
                    text: `${interaction.guild.name} • ${new Date().toLocaleString('en-US')}`,
                    iconURL: interaction.guild.iconURL({ extension: 'png' }) || undefined
                });

            if (config.deleteResponse) {
                await interaction.editReply({ embeds: [embed] });
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 5000);
            } else {
                await interaction.editReply({ embeds: [embed] });
            }

        } catch (error) {
            console.error('❌ خطأ في الأمر warn:', error);
            try {
                const msg = lang === 'ar'
                    ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                    : `❌ An error occurred: ${error.message || 'Unknown error'}`;
                if (interaction.deferred && !interaction.replied)
                    await interaction.editReply({ content: msg });
                else if (!interaction.replied)
                    await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
            } catch {}
        }
    }
};
