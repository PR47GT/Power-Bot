const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌐 ترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرتب',
        roleTooHigh: '❌ لا يمكنني إدارة هذه الرتبة لأنها أعلى أو تساوي أعلى رتبة لدي.',
        removed: (user, role) => `❌ تم إزالة الرتبة من \`${user}\` | الرتبة: ${role}`,
        added: (user, role) => `✅ تم إعطاء ${user} رتبة ${role}`,
        failed: (err) => `❌ فشل إدارة الرتبة: ${err}`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '❌ Member not found in the server.',
        botNoPerm: '❌ Bot does not have permission to manage roles',
        roleTooHigh: '❌ Cannot manage this role (it is higher or equal to my highest role).',
        removed: (user, role) => `❌ Removed role from ${user} | Role: ${role}`,
        added: (user, role) => `✅ Added role ${role} to \`${user}\``,
        failed: (err) => `❌ Failed to manage role: ${err}`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'role',
        description: 'Add or remove a role | إضافة أو إزالة رتبة',
        description_localizations: {
            ar: 'إضافة أو إزالة رتبة',
            enUS: 'Add or remove a role'
        },
        default_member_permissions: PermissionFlagsBits.ManageRoles.toString(),
        options: [
            { 
                name: 'user', 
                description: 'Member',
                description_localizations: {
                    ar: 'العضو',
                    enUS: 'Member'
                },
                type: 6, 
                required: true 
            },
            { 
                name: 'role', 
                description: 'Role',
                description_localizations: {
                    ar: 'الرتبة',
                    enUS: 'Role'
                },
                type: 8, 
                required: true 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.role || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const role = interaction.options.getRole('role');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (role.position >= interaction.guild.members.me.roles.highest.position) {
                return await interaction.editReply({ content: t.roleTooHigh });
            }
            
            const hasRole = targetMember.roles.cache.has(role.id);
            
            try {
                let successMessage;

                if (hasRole) {
                    await targetMember.roles.remove(role);
                    successMessage = t.removed(targetUser.tag, role);
                } else {
                    await targetMember.roles.add(role);
                    successMessage = t.added(targetUser.tag, role);
                }
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }

            } catch (error) {
                return await interaction.editReply({ content: t.failed(error.message) });
            }
            
        } catch (error) {
            console.error('❌ Error in role:', error.message);
            
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};