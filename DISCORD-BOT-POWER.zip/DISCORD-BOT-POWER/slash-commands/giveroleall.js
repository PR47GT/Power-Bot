const fs = require('fs');
const path = require('path');
const { MessageFlags, PermissionFlagsBits } = require('discord.js');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) {
            return {};
        }
    }
    return {};
}

const wait = (ms) => new Promise(resolve => setTimeout(resolve, ms));

// جلب جميع الأعضاء عبر REST (يتجنب Gateway Opcode 8 تماماً)
async function fetchAllMembersREST(guild) {
    const members = new Map();
    let lastId = undefined;

    while (true) {
        const options = { limit: 1000 };
        if (lastId) options.after = lastId;

        const chunk = await guild.members.list(options);
        if (chunk.size === 0) break;

        chunk.forEach((m, id) => members.set(id, m));

        if (chunk.size < 1000) break;
        lastId = chunk.last().id;

        // استراحة قصيرة بين كل صفحة
        await wait(1000);
    }

    return members;
}

// إضافة رتبة مع إعادة المحاولة عند أي Rate Limit
async function addRoleWithRetry(member, role, reason, maxRetries = 5) {
    for (let attempt = 0; attempt < maxRetries; attempt++) {
        try {
            await member.roles.add(role, reason);
            return true;
        } catch (err) {
            const isRateLimit =
                err.status === 429 ||
                err.code === 429 ||
                err.httpStatus === 429 ||
                (err.message && err.message.toLowerCase().includes('rate limit'));

            if (isRateLimit) {
                const retryAfterMs = ((err.data?.retry_after ?? err.retryAfter ?? 5) * 1000) + 1000;
                await wait(retryAfterMs);
                continue;
            }

            // خطأ غير قابل للإعادة → تجاوز بصمت
            return false;
        }
    }
    return false;
}

// 🌍 نظام اللغات
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرتب.',
        userNoPerm: '❌ لا تملك صلاحية إدارة الرتب.',
        roleHigher: '❌ رتبة البوت أقل من الرتبة المختارة، لا يمكن إضافتها.',
        alreadyAll: (role) => `ℹ️ جميع الأعضاء يملكون رتبة **${role}** بالفعل.`,
        fetching: '🔄 جاري تحميل قائمة الأعضاء...',
        starting: (role, total) => `⏳ جاري إعطاء رتبة **${role}** لـ **${total}** عضو...`,
        progress: (done, total) => `⏳ جاري المعالجة... **${done}** / **${total}**`,
        success: (count, role, skipped) =>
            `✅ **تمت العملية بنجاح!**\n` +
            `> 🎖️ الرتبة: **${role}**\n` +
            `> ✔️ تم الإعطاء: **${count}** عضو\n` +
            (skipped > 0 ? `> ⏭️ يملكونها مسبقاً: **${skipped}** عضو` : '')
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        botNoPerm: '❌ Bot does not have permission to manage roles.',
        userNoPerm: '❌ You do not have permission to manage roles.',
        roleHigher: '❌ The selected role is higher than the bot\'s highest role.',
        alreadyAll: (role) => `ℹ️ All members already have the **${role}** role.`,
        fetching: '🔄 Fetching member list...',
        starting: (role, total) => `⏳ Giving role **${role}** to **${total}** members...`,
        progress: (done, total) => `⏳ Processing... **${done}** / **${total}**`,
        success: (count, role, skipped) =>
            `✅ **Operation completed!**\n` +
            `> 🎖️ Role: **${role}**\n` +
            `> ✔️ Given to: **${count}** members\n` +
            (skipped > 0 ? `> ⏭️ Already had it: **${skipped}** members` : '')
    }
};

module.exports = {
    data: {
    name: 'giveroleall',
    description: 'Give a role to all members',
    default_member_permissions: '8',
    options: [
        {
            name: 'role',
            description: 'The role to give',
            type: 8,
            required: true
        }
    ]
},

    async execute(interaction, client, settings) {

        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const modCommands = loadModCommands();
        const commandConfig = modCommands.giveroleall || {
            enabled: true,
            aliases: [],
            deniedRoles: [],
            allowedRoles: [],
            deniedChannels: [],
            allowedChannels: [],
            deleteCommand: false,
            deleteResponse: false
        };

        if (!commandConfig.enabled) {
            return interaction.editReply({ content: t.disabled });
        }

        const permission = checkPermissions(interaction.member, interaction.channelId, commandConfig);
        if (!permission.allowed) {
            return interaction.editReply({ content: permission.reason });
        }

        if (!interaction.member.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.editReply({ content: t.userNoPerm });
        }

        if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ManageRoles)) {
            return interaction.editReply({ content: t.botNoPerm });
        }

        const role = interaction.options.getRole('role');
        const botHighestRole = interaction.guild.members.me.roles.highest;

        if (role.position >= botHighestRole.position) {
            return interaction.editReply({ content: t.roleHigher });
        }

        // تحميل الأعضاء عبر REST (بدون Gateway)
        await interaction.editReply({ content: t.fetching });
        const allMembers = await fetchAllMembersREST(interaction.guild);

        const humans      = [...allMembers.values()].filter(m => !m.user.bot);
        const needsRole   = humans.filter(m => !m.roles.cache.has(role.id));
        const alreadyHas  = humans.length - needsRole.length;

        if (needsRole.length === 0) {
            return interaction.editReply({ content: t.alreadyAll(role.name) });
        }

        const total = needsRole.length;
        await interaction.editReply({ content: t.starting(role.name, total) });

        const reason = `giveroleall by ${interaction.user.tag}`;
        let successCount = 0;
        let processed    = 0;

        for (const member of needsRole) {
            const ok = await addRoleWithRetry(member, role, reason);
            if (ok) successCount++;
            processed++;

            // تحديث التقدم كل 15 عضو
            if (processed % 15 === 0) {
                await interaction.editReply({
                    content: t.progress(processed, total)
                }).catch(() => {});
            }

            // تأخير بين الطلبات لتقليل الضغط على API
            await wait(600);
        }

        const finalMsg = t.success(successCount, role.name, alreadyHas);

        if (commandConfig.deleteResponse) {
            await interaction.editReply({ content: finalMsg });
            setTimeout(() => interaction.deleteReply().catch(() => {}), 5000);
        } else {
            await interaction.editReply({ content: finalMsg });
        }
    }
};
