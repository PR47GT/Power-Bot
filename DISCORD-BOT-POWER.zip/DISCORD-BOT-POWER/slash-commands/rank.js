const { MessageFlags, AttachmentBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const https = require('https');
const http  = require('http');

// ── canvas ────────────────────────────────────────────────────────────────────
let createCanvas, loadImage, GlobalFonts;
try {
    ({ createCanvas, loadImage, GlobalFonts } = require('@napi-rs/canvas'));
} catch (e1) {
    try { ({ createCanvas, loadImage } = require('canvas')); }
    catch (e2) { createCanvas = null; }
}

// ── helpers ───────────────────────────────────────────────────────────────────
function loadLevelData() {
    const p = path.join(__dirname, '../levelData.json');
    if (fs.existsSync(p)) { try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch (e) {} }
    return {};
}
function calcLevel(xp)    { return Math.floor(0.1 * Math.sqrt(xp)); }
function xpForLevel(lvl)  { return Math.pow(lvl / 0.1, 2); }

function fetchBuffer(url) {
    return new Promise((resolve, reject) => {
        const mod = url.startsWith('https') ? https : http;
        mod.get(url, res => {
            const chunks = [];
            res.on('data', d => chunks.push(d));
            res.on('end', () => resolve(Buffer.concat(chunks)));
            res.on('error', reject);
        }).on('error', reject);
    });
}

// ── themes ────────────────────────────────────────────────────────────────────
// كل ثيم له: base (خلفية داكنة) + لونان nebula + ألوان الحدود + ألوان النصوص
const THEMES = [
    {
        name:    'gold',
        base:    '#04030E',
        nebula1: { color: 'rgba(180,83,9,0.5)',   x: 0.78, y: 0.08 },
        nebula2: { color: 'rgba(8,80,110,0.4)',   x: 0.06, y: 0.92 },
        shimmer: ['rgba(180,83,9,0.28)', 'rgba(8,80,110,0.18)'],
        border:  ['#78350F', '#F59E0B', '#FFD700', '#78350F'],
        corner:  'rgba(245,158,11,0.5)',
        sep:     'rgba(245,158,11,0.75)',
        avGlow:  'rgba(245,158,11,0.6)',
        avRing:  ['#78350F', '#FFD700', '#F59E0B', '#78350F'],
        avInner: 'rgba(253,230,138,0.4)',
        username: '#FFE580',
        boxBg:    'rgba(5,3,18,0.9)',
        boxBorder:['#78350F','#F59E0B','#FFD700','#78350F'],
        boxTint:  'rgba(180,83,9,0.22)',
        boxDiv:   'rgba(245,158,11,0.35)',
        label:    '#FCD34D',
        labelShadow: 'rgba(120,53,15,0.9)',
        valGlow:  'rgba(245,158,11,0.65)',
        divBar:   ['rgba(245,158,11,0.7)', 'rgba(245,158,11,0.05)'],
        bar1:     ['#92400E', '#FFD700', '#F59E0B'],
        bar2:     ['#0E7490', '#22D3EE', '#06B6D4'],
        barTrack: 'rgba(180,83,9,0.35)',
        xpText:   '#FDE68A',
        stars:    'rgba(245,158,11,0.7)',
        diamond:  { c0:'rgba(120,53,6,0.55)', c1:'rgba(245,158,11,0.6)', c2:'rgba(255,215,0,0.55)', c3:'rgba(120,53,6,0.45)', border:['#FFD700','#F59E0B','#78350F'], shine:'rgba(255,215,0,0.4)', glow:'rgba(245,158,11,0.4)' }
    },
    {
        name:    'purple',
        base:    '#06030F',
        nebula1: { color: 'rgba(109,40,217,0.5)',  x: 0.75, y: 0.1 },
        nebula2: { color: 'rgba(91,33,182,0.35)',  x: 0.1,  y: 0.9 },
        shimmer: ['rgba(109,40,217,0.28)', 'rgba(76,29,149,0.2)'],
        border:  ['#4C1D95', '#7C3AED', '#A78BFA', '#4C1D95'],
        corner:  'rgba(139,92,246,0.55)',
        sep:     'rgba(139,92,246,0.75)',
        avGlow:  'rgba(139,92,246,0.65)',
        avRing:  ['#4C1D95', '#A78BFA', '#7C3AED', '#4C1D95'],
        avInner: 'rgba(196,181,253,0.4)',
        username: '#DDD6FE',
        boxBg:    'rgba(4,2,18,0.92)',
        boxBorder:['#4C1D95','#7C3AED','#A78BFA','#4C1D95'],
        boxTint:  'rgba(109,40,217,0.22)',
        boxDiv:   'rgba(139,92,246,0.35)',
        label:    '#C4B5FD',
        labelShadow: 'rgba(76,29,149,0.9)',
        valGlow:  'rgba(139,92,246,0.65)',
        divBar:   ['rgba(139,92,246,0.7)', 'rgba(139,92,246,0.05)'],
        bar1:     ['#4C1D95', '#A78BFA', '#8B5CF6'],
        bar2:     ['#0E7490', '#22D3EE', '#06B6D4'],
        barTrack: 'rgba(109,40,217,0.35)',
        xpText:   '#EDE9FE',
        stars:    'rgba(167,139,250,0.75)',
        diamond:  { c0:'rgba(76,29,149,0.55)', c1:'rgba(139,92,246,0.6)', c2:'rgba(167,139,250,0.55)', c3:'rgba(76,29,149,0.45)', border:['#A78BFA','#7C3AED','#4C1D95'], shine:'rgba(167,139,250,0.4)', glow:'rgba(139,92,246,0.4)' }
    },
    {
        name:    'crimson',
        base:    '#0F0204',
        nebula1: { color: 'rgba(185,28,28,0.48)', x: 0.78, y: 0.08 },
        nebula2: { color: 'rgba(120,10,10,0.32)', x: 0.08, y: 0.92 },
        shimmer: ['rgba(185,28,28,0.26)', 'rgba(153,27,27,0.18)'],
        border:  ['#7F1D1D', '#DC2626', '#F87171', '#7F1D1D'],
        corner:  'rgba(220,38,38,0.5)',
        sep:     'rgba(220,38,38,0.75)',
        avGlow:  'rgba(220,38,38,0.62)',
        avRing:  ['#7F1D1D', '#F87171', '#DC2626', '#7F1D1D'],
        avInner: 'rgba(254,202,202,0.4)',
        username: '#FECACA',
        boxBg:    'rgba(12,2,2,0.92)',
        boxBorder:['#7F1D1D','#DC2626','#F87171','#7F1D1D'],
        boxTint:  'rgba(185,28,28,0.22)',
        boxDiv:   'rgba(220,38,38,0.35)',
        label:    '#FCA5A5',
        labelShadow: 'rgba(127,29,29,0.9)',
        valGlow:  'rgba(220,38,38,0.65)',
        divBar:   ['rgba(220,38,38,0.7)', 'rgba(220,38,38,0.05)'],
        bar1:     ['#7F1D1D', '#F87171', '#EF4444'],
        bar2:     ['#0E7490', '#22D3EE', '#06B6D4'],
        barTrack: 'rgba(185,28,28,0.35)',
        xpText:   '#FEE2E2',
        stars:    'rgba(248,113,113,0.75)',
        diamond:  { c0:'rgba(127,29,29,0.55)', c1:'rgba(220,38,38,0.6)', c2:'rgba(248,113,113,0.55)', c3:'rgba(127,29,29,0.45)', border:['#F87171','#DC2626','#7F1D1D'], shine:'rgba(248,113,113,0.4)', glow:'rgba(220,38,38,0.4)' }
    },
    {
        name:    'emerald',
        base:    '#020F06',
        nebula1: { color: 'rgba(5,150,105,0.48)', x: 0.78, y: 0.08 },
        nebula2: { color: 'rgba(4,120,87,0.32)',  x: 0.08, y: 0.92 },
        shimmer: ['rgba(5,150,105,0.26)', 'rgba(4,120,87,0.18)'],
        border:  ['#064E3B', '#059669', '#34D399', '#064E3B'],
        corner:  'rgba(5,150,105,0.5)',
        sep:     'rgba(52,211,153,0.75)',
        avGlow:  'rgba(5,150,105,0.65)',
        avRing:  ['#064E3B', '#34D399', '#059669', '#064E3B'],
        avInner: 'rgba(167,243,208,0.4)',
        username: '#A7F3D0',
        boxBg:    'rgba(2,12,6,0.92)',
        boxBorder:['#064E3B','#059669','#34D399','#064E3B'],
        boxTint:  'rgba(5,150,105,0.2)',
        boxDiv:   'rgba(52,211,153,0.35)',
        label:    '#6EE7B7',
        labelShadow: 'rgba(6,78,59,0.9)',
        valGlow:  'rgba(5,150,105,0.65)',
        divBar:   ['rgba(52,211,153,0.7)', 'rgba(52,211,153,0.05)'],
        bar1:     ['#064E3B', '#34D399', '#10B981'],
        bar2:     ['#1E40AF', '#60A5FA', '#3B82F6'],
        barTrack: 'rgba(5,150,105,0.35)',
        xpText:   '#D1FAE5',
        stars:    'rgba(52,211,153,0.75)',
        diamond:  { c0:'rgba(6,78,59,0.55)', c1:'rgba(5,150,105,0.6)', c2:'rgba(52,211,153,0.55)', c3:'rgba(6,78,59,0.45)', border:['#34D399','#059669','#064E3B'], shine:'rgba(52,211,153,0.4)', glow:'rgba(5,150,105,0.4)' }
    },
    {
        name:    'ice',
        base:    '#02060F',
        nebula1: { color: 'rgba(14,116,144,0.5)',  x: 0.75, y: 0.08 },
        nebula2: { color: 'rgba(30,58,138,0.36)',  x: 0.08, y: 0.92 },
        shimmer: ['rgba(14,116,144,0.26)', 'rgba(30,58,138,0.2)'],
        border:  ['#0C4A6E', '#0891B2', '#67E8F9', '#0C4A6E'],
        corner:  'rgba(8,145,178,0.52)',
        sep:     'rgba(103,232,249,0.75)',
        avGlow:  'rgba(8,145,178,0.62)',
        avRing:  ['#0C4A6E', '#67E8F9', '#0891B2', '#0C4A6E'],
        avInner: 'rgba(186,230,253,0.4)',
        username: '#BAE6FD',
        boxBg:    'rgba(2,6,18,0.92)',
        boxBorder:['#0C4A6E','#0891B2','#67E8F9','#0C4A6E'],
        boxTint:  'rgba(14,116,144,0.22)',
        boxDiv:   'rgba(103,232,249,0.35)',
        label:    '#7DD3FC',
        labelShadow: 'rgba(12,74,110,0.9)',
        valGlow:  'rgba(8,145,178,0.65)',
        divBar:   ['rgba(103,232,249,0.7)', 'rgba(103,232,249,0.05)'],
        bar1:     ['#0C4A6E', '#67E8F9', '#22D3EE'],
        bar2:     ['#4C1D95', '#A78BFA', '#8B5CF6'],
        barTrack: 'rgba(14,116,144,0.35)',
        xpText:   '#E0F2FE',
        stars:    'rgba(103,232,249,0.75)',
        diamond:  { c0:'rgba(12,74,110,0.55)', c1:'rgba(8,145,178,0.6)', c2:'rgba(103,232,249,0.55)', c3:'rgba(12,74,110,0.45)', border:['#67E8F9','#0891B2','#0C4A6E'], shine:'rgba(103,232,249,0.4)', glow:'rgba(8,145,178,0.4)' }
    }
];

// ── ثيم ثابت لكل مستخدم (hash بناءً على userId) ──────────────────────────────
function pickTheme(userId) {
    let hash = 0;
    const str = String(userId || 'default');
    for (let i = 0; i < str.length; i++) {
        hash = (hash * 31 + str.charCodeAt(i)) >>> 0;
    }
    return THEMES[hash % THEMES.length];
}

// ── رسم بطاقة الرتبة ──────────────────────────────────────────────────────────
async function buildRankCard(member, chatXP, voiceXP, chatLevel, voiceLevel, rank, fullUser) {
    const W = 900, H = 280;
    const canvas = createCanvas(W, H);
    const ctx    = canvas.getContext('2d');

    // الثيم ثابت بناءً على userId
    const T = pickTheme(member.user?.id || member.id);

    // ── خلفية: 1) مخصصة من داشبورد  2) بانر ديسكورد  3) ثيم ──────────────
    let bannerLoaded = false;

    try {
        const LEVEL_FILE = path.join(__dirname, '../levelSystem.json');
        if (fs.existsSync(LEVEL_FILE)) {
            const lvlCfg = JSON.parse(fs.readFileSync(LEVEL_FILE, 'utf8'));
            if (lvlCfg.rankBackground && lvlCfg.rankBackground.startsWith('data:')) {
                const buf = Buffer.from(lvlCfg.rankBackground.split(',')[1], 'base64');
                const bg  = await loadImage(buf);
                const scale = Math.max(W / bg.width, H / bg.height);
                ctx.drawImage(bg, (W - bg.width * scale) / 2, (H - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
                bannerLoaded = true;
            }
        }
    } catch (e) {}

    if (!bannerLoaded && fullUser) {
        try {
            const bannerUrl = fullUser.bannerURL({ size: 1024, extension: 'png', forceStatic: false })
                           || fullUser.bannerURL({ size: 1024, extension: 'jpg', forceStatic: true });
            if (bannerUrl) {
                const buf = await fetchBuffer(bannerUrl);
                const bg  = await loadImage(buf);
                const scale = Math.max(W / bg.width, H / bg.height);
                ctx.drawImage(bg, (W - bg.width * scale) / 2, (H - bg.height * scale) / 2, bg.width * scale, bg.height * scale);
                bannerLoaded = true;
            }
        } catch (e) {}
    }

    if (!bannerLoaded) drawThemedBackground(ctx, W, H, T);

    // طبقة شفافية فوق الخلفية للتوحيد
    ctx.fillStyle = bannerLoaded ? 'rgba(4,3,14,0.52)' : 'rgba(4,3,14,0.48)';
    ctx.fillRect(0, 0, W, H);

    // تأثير scan-line خفي يعطي إحساس احترافي
    for (let y = 0; y < H; y += 4) {
        ctx.fillStyle = 'rgba(0,0,0,0.04)';
        ctx.fillRect(0, y, W, 2);
    }

    // ── إطار خارجي ────────────────────────────────────────────────────────
    const R = 18;
    const borderGrad = ctx.createLinearGradient(0, 0, W, H);
    T.border.forEach((c, i) => borderGrad.addColorStop(i / (T.border.length - 1), c));

    roundRect(ctx, 3, 3, W - 6, H - 6, R);
    ctx.strokeStyle = borderGrad; ctx.lineWidth = 2.8; ctx.stroke();

    roundRect(ctx, 7, 7, W - 14, H - 14, R - 4);
    ctx.strokeStyle = 'rgba(255,255,255,0.05)'; ctx.lineWidth = 1; ctx.stroke();

    // ── توهج الزوايا ───────────────────────────────────────────────────────
    [[3, 3], [W - 3, 3], [3, H - 3], [W - 3, H - 3]].forEach(([cx, cy]) => {
        const g = ctx.createRadialGradient(cx, cy, 0, cx, cy, 60);
        g.addColorStop(0, T.corner); g.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = g; ctx.fillRect(cx - 60, cy - 60, 120, 120);
    });

    // ── خط فاصل عمودي ─────────────────────────────────────────────────────
    const sepGrad = ctx.createLinearGradient(0, 18, 0, H - 18);
    sepGrad.addColorStop(0, 'rgba(0,0,0,0)');
    sepGrad.addColorStop(0.5, T.sep);
    sepGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.strokeStyle = sepGrad; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(200, 18); ctx.lineTo(200, H - 18); ctx.stroke();

    // ── الصورة الشخصية ─────────────────────────────────────────────────────
    const avX = 100, avY = H / 2, avR = 67;

    // توهج خارجي
    const avGlow = ctx.createRadialGradient(avX, avY, avR * 0.5, avX, avY, avR + 28);
    avGlow.addColorStop(0, T.avGlow); avGlow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = avGlow;
    ctx.beginPath(); ctx.arc(avX, avY, avR + 28, 0, Math.PI * 2); ctx.fill();

    // حلقة خارجية
    const ringGrad = ctx.createLinearGradient(avX - avR, avY - avR, avX + avR, avY + avR);
    T.avRing.forEach((c, i) => ringGrad.addColorStop(i / (T.avRing.length - 1), c));
    ctx.beginPath(); ctx.arc(avX, avY, avR + 9, 0, Math.PI * 2);
    ctx.strokeStyle = ringGrad; ctx.lineWidth = 3.5; ctx.stroke();

    // حلقة داخلية
    ctx.beginPath(); ctx.arc(avX, avY, avR + 3, 0, Math.PI * 2);
    ctx.strokeStyle = T.avInner; ctx.lineWidth = 1.2; ctx.stroke();

    // صورة العضو
    ctx.save();
    ctx.beginPath(); ctx.arc(avX, avY, avR, 0, Math.PI * 2); ctx.clip();
    try {
        const avUrl = member.user.displayAvatarURL({ extension: 'png', size: 256, forceStatic: true });
        const avBuf = await fetchBuffer(avUrl);
        const avImg = await loadImage(avBuf);
        ctx.drawImage(avImg, avX - avR, avY - avR, avR * 2, avR * 2);
    } catch (e) {
        ctx.fillStyle = '#0a0a18'; ctx.fillRect(avX - avR, avY - avR, avR * 2, avR * 2);
    }
    ctx.restore();

    // ── اسم المستخدم (مع shadow صحيح) ──────────────────────────────────────
    ctx.textAlign    = 'center';
    ctx.font         = 'bold 13px sans-serif';
    ctx.shadowColor  = 'rgba(0,0,0,0.95)';
    ctx.shadowBlur   = 10;
    ctx.shadowOffsetX = 0;
    ctx.shadowOffsetY = 1;
    ctx.fillStyle    = T.username;
    ctx.fillText(member.displayName || member.user.username, avX, H - 11);
    ctx.shadowBlur = 0; ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;

    // ── الماسة الزخرفية ────────────────────────────────────────────────────
    drawThemedDiamond(ctx, W - 78, H / 2, 26, T.diamond);

    // ── منطقة الإحصائيات ──────────────────────────────────────────────────
    const SX = 218;
    drawStatBox(ctx, SX, 22, 'LEVEL', String(chatLevel), T);
    drawStatBox(ctx, SX, 74, 'RANK',  `#${rank}`,        T);

    // خط فاصل
    const divGrad = ctx.createLinearGradient(SX, 0, W - 115, 0);
    divGrad.addColorStop(0, T.divBar[0]);
    divGrad.addColorStop(0.7, T.divBar[1]);
    divGrad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.strokeStyle = divGrad; ctx.lineWidth = 1;
    ctx.beginPath(); ctx.moveTo(SX, 130); ctx.lineTo(W - 115, 130); ctx.stroke();

    // ── أشرطة XP ──────────────────────────────────────────────────────────
    const chatNextXP = xpForLevel(chatLevel + 1);
    const chatBaseXP = xpForLevel(chatLevel);
    const chatPct    = chatNextXP > chatBaseXP
        ? Math.min(1, (chatXP - chatBaseXP) / (chatNextXP - chatBaseXP)) : 1;
    drawXpBar(ctx, SX, 136, 'CHAT XP', chatXP, chatNextXP, chatPct, T.bar1, T);

    const voiceNextXP = xpForLevel(voiceLevel + 1);
    const voiceBaseXP = xpForLevel(voiceLevel);
    const voicePct    = voiceNextXP > voiceBaseXP
        ? Math.min(1, (voiceXP - voiceBaseXP) / (voiceNextXP - voiceBaseXP)) : 1;
    drawXpBar(ctx, SX, 196, 'VOICE XP', voiceXP, voiceNextXP, voicePct, T.bar2, T);

    return canvas.toBuffer('image/png');
}

// ── دوال الرسم المساعدة ───────────────────────────────────────────────────────

function drawThemedBackground(ctx, W, H, T) {
    ctx.fillStyle = T.base;
    ctx.fillRect(0, 0, W, H);

    const g1 = ctx.createRadialGradient(W * T.nebula1.x, H * T.nebula1.y, 0, W * T.nebula1.x, H * T.nebula1.y, H * 1.5);
    g1.addColorStop(0, T.nebula1.color); g1.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g1; ctx.fillRect(0, 0, W, H);

    const g2 = ctx.createRadialGradient(W * T.nebula2.x, H * T.nebula2.y, 0, W * T.nebula2.x, H * T.nebula2.y, H * 1.0);
    g2.addColorStop(0, T.nebula2.color); g2.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = g2; ctx.fillRect(0, 0, W, H);

    const hGrad = ctx.createLinearGradient(0, 0, W, 0);
    hGrad.addColorStop(0, T.shimmer[0]); hGrad.addColorStop(0.45, 'rgba(0,0,0,0)'); hGrad.addColorStop(1, T.shimmer[1]);
    ctx.fillStyle = hGrad; ctx.fillRect(0, 0, W, H);

    // نجوم بيضاء ثابتة
    ctx.fillStyle = 'rgba(255,255,255,0.75)';
    [[72,28],[185,15],[310,42],[460,10],[590,35],[715,20],[835,48],
     [140,252],[270,238],[415,258],[548,242],[672,252],[798,240]]
        .forEach(([sx, sy]) => { ctx.beginPath(); ctx.arc(sx, sy, 0.9, 0, Math.PI * 2); ctx.fill(); });

    // نجوم بلون الثيم
    ctx.fillStyle = T.stars;
    [[250, 30], [680, 18], [820, 200]].forEach(([sx, sy]) => {
        ctx.beginPath(); ctx.arc(sx, sy, 1.4, 0, Math.PI * 2); ctx.fill();
    });
}

function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y); ctx.lineTo(x + w - r, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + r);
    ctx.lineTo(x + w, y + h - r);
    ctx.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    ctx.lineTo(x + r, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - r);
    ctx.lineTo(x, y + r);
    ctx.quadraticCurveTo(x, y, x + r, y);
    ctx.closePath();
}

function drawStatBox(ctx, sx, sy, label, value, T) {
    const bw = 345, bh = 42, r = 9;

    // خلفية الصندوق
    roundRect(ctx, sx, sy, bw, bh, r);
    ctx.fillStyle = T.boxBg; ctx.fill();

    // حدود الصندوق
    const bGrad = ctx.createLinearGradient(sx, sy, sx + bw, sy + bh);
    T.boxBorder.forEach((c, i) => bGrad.addColorStop(i / (T.boxBorder.length - 1), c));
    roundRect(ctx, sx, sy, bw, bh, r);
    ctx.strokeStyle = bGrad; ctx.lineWidth = 1.8; ctx.stroke();

    // تلوين قسم العنوان
    const labelW = 170;
    ctx.save();
    ctx.beginPath();
    ctx.moveTo(sx + r, sy); ctx.lineTo(sx + labelW, sy);
    ctx.lineTo(sx + labelW, sy + bh); ctx.lineTo(sx + r, sy + bh);
    ctx.quadraticCurveTo(sx, sy + bh, sx, sy + bh - r);
    ctx.lineTo(sx, sy + r); ctx.quadraticCurveTo(sx, sy, sx + r, sy);
    ctx.closePath();
    ctx.fillStyle = T.boxTint; ctx.fill();
    ctx.restore();

    // خط فاصل داخل الصندوق
    ctx.strokeStyle = T.boxDiv; ctx.lineWidth = 1;
    ctx.beginPath();
    ctx.moveTo(sx + labelW, sy + 8); ctx.lineTo(sx + labelW, sy + bh - 8);
    ctx.stroke();

    // أيقونة بلون الثيم
    const iconCX = sx + 22, iconCY = sy + bh / 2;
    ctx.shadowColor = T.valGlow; ctx.shadowBlur = 8;
    ctx.fillStyle   = T.label;
    if (label === 'LEVEL')  drawIconStar(ctx, iconCX, iconCY, 9);
    if (label === 'RANK')   drawIconCrown(ctx, iconCX, iconCY, 9);
    ctx.shadowBlur = 0;

    // نص العنوان (label) — أبيض مع توهج لوني
    ctx.textAlign    = 'left';
    ctx.font         = 'bold 15px sans-serif';
    ctx.shadowColor  = T.labelShadow;
    ctx.shadowBlur   = 6;
    ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 1;
    ctx.fillStyle    = '#FFFFFF';
    ctx.fillText(label, sx + 36, sy + bh / 2 + 5.5);

    // نص القيمة (القيمة الرقمية) — أبيض لامع
    ctx.textAlign    = 'right';
    ctx.font         = 'bold 22px sans-serif';
    ctx.shadowColor  = T.valGlow;
    ctx.shadowBlur   = 14;
    ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 0;
    ctx.fillStyle    = '#FFFFFF';
    ctx.fillText(value, sx + bw - 16, sy + bh / 2 + 7.5);
    ctx.shadowBlur = 0;
}

function drawXpBar(ctx, sx, sy, label, xp, nextXP, pct, barColors, T) {
    const barW = 432, barH = 14, barX = sx, barY = sy + 22, r = 7;
    const [barStart, barMid, barEnd] = barColors;

    // ── أيقونة CHAT / VOICE ───────────────────────────────────────────────
    const iconY = sy + 8;
    ctx.shadowColor = T.valGlow; ctx.shadowBlur = 7;
    ctx.fillStyle   = T.label;
    if (label === 'CHAT XP')  drawIconChat(ctx, barX + 8, iconY, 8);
    if (label === 'VOICE XP') drawIconMic(ctx, barX + 8, iconY, 8);
    ctx.shadowBlur = 0;

    // ── نص العنوان (CHAT XP / VOICE XP) ──────────────────────────────────
    ctx.textAlign    = 'left';
    ctx.font         = 'bold 13px sans-serif';
    ctx.shadowColor  = 'rgba(0,0,0,0.95)';
    ctx.shadowBlur   = 8;
    ctx.shadowOffsetX = 0; ctx.shadowOffsetY = 1;
    ctx.fillStyle    = T.label;
    ctx.fillText(label, barX + 22, sy + 15);
    ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;

    // ── نص القيمة (0 / 100 XP) — مرئي وواضح ─────────────────────────────
    ctx.textAlign    = 'right';
    ctx.font         = 'bold 11px sans-serif';
    ctx.shadowColor  = 'rgba(0,0,0,0.95)';
    ctx.shadowBlur   = 8;
    ctx.shadowOffsetY = 1;
    ctx.fillStyle    = T.xpText;          // لون فاتح خاص بالثيم (ليس شبه شفاف)
    ctx.fillText(
        `${Math.floor(xp).toLocaleString()} / ${Math.floor(nextXP).toLocaleString()} XP`,
        barX + barW, sy + 15
    );
    ctx.shadowBlur = 0; ctx.shadowOffsetY = 0;

    // ── مسار الشريط ───────────────────────────────────────────────────────
    roundRect(ctx, barX, barY, barW, barH, r);
    ctx.fillStyle = 'rgba(6,4,20,0.94)'; ctx.fill();
    roundRect(ctx, barX, barY, barW, barH, r);
    ctx.strokeStyle = T.barTrack; ctx.lineWidth = 1; ctx.stroke();

    // ── ملء الشريط ────────────────────────────────────────────────────────
    if (pct > 0) {
        const fillW = Math.max(barH, barW * pct);

        const grad = ctx.createLinearGradient(barX, 0, barX + fillW, 0);
        grad.addColorStop(0,   barStart);
        grad.addColorStop(0.5, barMid);
        grad.addColorStop(1,   barEnd);

        // طبقة التوهج
        ctx.shadowColor = barEnd; ctx.shadowBlur = 14;
        roundRect(ctx, barX, barY, fillW, barH, r);
        ctx.fillStyle = grad; ctx.fill();
        ctx.shadowBlur = 0;

        // لمعة علوية
        ctx.save();
        roundRect(ctx, barX, barY, fillW, barH, r); ctx.clip();
        const shine = ctx.createLinearGradient(0, barY, 0, barY + barH);
        shine.addColorStop(0, 'rgba(255,255,255,0.18)');
        shine.addColorStop(0.5, 'rgba(255,255,255,0.05)');
        shine.addColorStop(1, 'rgba(0,0,0,0)');
        ctx.fillStyle = shine; ctx.fillRect(barX, barY, fillW, barH);
        ctx.restore();

        // نقطة نهاية الشريط
        ctx.shadowColor = barEnd; ctx.shadowBlur = 8;
        ctx.fillStyle   = '#FFFFFF';
        ctx.beginPath(); ctx.arc(barX + fillW, barY + barH / 2, 3.5, 0, Math.PI * 2); ctx.fill();
        ctx.shadowBlur = 0;
    }
}

// ── أيقونة نجمة (LEVEL) ───────────────────────────────────────────────────────
function drawIconStar(ctx, cx, cy, r) {
    const pts = 5, inner = r * 0.42;
    ctx.beginPath();
    for (let i = 0; i < pts * 2; i++) {
        const angle = (i * Math.PI) / pts - Math.PI / 2;
        const rad   = i % 2 === 0 ? r : inner;
        const x = cx + Math.cos(angle) * rad;
        const y = cy + Math.sin(angle) * rad;
        i === 0 ? ctx.moveTo(x, y) : ctx.lineTo(x, y);
    }
    ctx.closePath(); ctx.fill();
}

// ── أيقونة تاج (RANK) ────────────────────────────────────────────────────────
function drawIconCrown(ctx, cx, cy, r) {
    const top = cy - r * 0.9, bot = cy + r * 0.75, bh = r * 0.35;
    ctx.beginPath();
    // قاعدة التاج
    ctx.rect(cx - r, bot - bh, r * 2, bh);
    ctx.fill();
    // الثلاث أسنان
    ctx.beginPath();
    ctx.moveTo(cx - r, bot - bh);
    ctx.lineTo(cx - r, top + r * 0.3);
    ctx.lineTo(cx - r * 0.45, cy);
    ctx.lineTo(cx, top);
    ctx.lineTo(cx + r * 0.45, cy);
    ctx.lineTo(cx + r, top + r * 0.3);
    ctx.lineTo(cx + r, bot - bh);
    ctx.closePath(); ctx.fill();
    // ثلاث نقاط على رؤوس الأسنان
    ctx.beginPath();
    ctx.arc(cx - r,      top + r * 0.3, r * 0.22, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.arc(cx,          top,            r * 0.22, 0, Math.PI * 2); ctx.fill();
    ctx.beginPath();
    ctx.arc(cx + r,      top + r * 0.3, r * 0.22, 0, Math.PI * 2); ctx.fill();
}

// ── أيقونة فقاعة محادثة (CHAT XP) ───────────────────────────────────────────
function drawIconChat(ctx, cx, cy, r) {
    // جسم الفقاعة
    const x = cx - r, y = cy - r * 0.85, w = r * 2, h = r * 1.6, rc = r * 0.35;
    ctx.beginPath();
    ctx.moveTo(x + rc, y);
    ctx.lineTo(x + w - rc, y);
    ctx.quadraticCurveTo(x + w, y, x + w, y + rc);
    ctx.lineTo(x + w, y + h - rc);
    ctx.quadraticCurveTo(x + w, y + h, x + w - rc, y + h);
    // ذيل الفقاعة
    ctx.lineTo(x + rc * 2, y + h);
    ctx.lineTo(x + rc * 0.5, y + h + r * 0.55);
    ctx.lineTo(x + rc * 0.5, y + h);
    ctx.lineTo(x + rc, y + h);
    ctx.quadraticCurveTo(x, y + h, x, y + h - rc);
    ctx.lineTo(x, y + rc);
    ctx.quadraticCurveTo(x, y, x + rc, y);
    ctx.closePath(); ctx.fill();
    // ثلاث نقاط داخل الفقاعة
    ctx.fillStyle = 'rgba(0,0,0,0.35)';
    const dotY = y + h * 0.52;
    [cx - r * 0.42, cx, cx + r * 0.42].forEach(dx => {
        ctx.beginPath(); ctx.arc(dx, dotY, r * 0.16, 0, Math.PI * 2); ctx.fill();
    });
}

// ── أيقونة ميكروفون (VOICE XP) ──────────────────────────────────────────────
function drawIconMic(ctx, cx, cy, r) {
    // جسم الميكروفون
    const mw = r * 0.7, mh = r * 1.15, mx = cx - mw / 2, my = cy - r;
    const mr = mw / 2;
    ctx.beginPath();
    ctx.moveTo(mx + mr, my);
    ctx.arc(cx, my + mr, mr, -Math.PI, 0);
    ctx.lineTo(mx + mw, my + mh - mr);
    ctx.arc(cx, my + mh - mr, mr, 0, Math.PI);
    ctx.closePath(); ctx.fill();
    // قوس التقوية (u-shape)
    ctx.beginPath();
    ctx.arc(cx, my + mh - mr, r * 0.95, Math.PI * 0.1, Math.PI * 0.9, false);
    ctx.strokeStyle = ctx.fillStyle; ctx.lineWidth = r * 0.3; ctx.stroke();
    // خط القاعدة
    ctx.beginPath();
    ctx.moveTo(cx, my + mh - mr + r * 0.95);
    ctx.lineTo(cx, cy + r);
    ctx.lineWidth = r * 0.28; ctx.stroke();
    // قاعدة دائرية
    ctx.beginPath();
    ctx.arc(cx, cy + r, r * 0.38, 0, Math.PI * 2); ctx.fill();
}

function drawThemedDiamond(ctx, cx, cy, size, d) {
    // توهج خارجي
    const glow = ctx.createRadialGradient(cx, cy, 0, cx, cy, size + 32);
    glow.addColorStop(0, d.glow); glow.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = glow;
    ctx.beginPath(); ctx.arc(cx, cy, size + 32, 0, Math.PI * 2); ctx.fill();

    // جسم الماسة
    const dGrad = ctx.createLinearGradient(cx - size, cy - size, cx + size, cy + size);
    dGrad.addColorStop(0,   d.c0);
    dGrad.addColorStop(0.4, d.c1);
    dGrad.addColorStop(0.7, d.c2);
    dGrad.addColorStop(1,   d.c3);

    ctx.beginPath();
    ctx.moveTo(cx, cy - size);
    ctx.lineTo(cx + size * 0.58, cy);
    ctx.lineTo(cx, cy + size);
    ctx.lineTo(cx - size * 0.58, cy);
    ctx.closePath();
    ctx.fillStyle = dGrad; ctx.fill();

    // حدود الماسة
    const dBorder = ctx.createLinearGradient(cx, cy - size, cx, cy + size);
    d.border.forEach((c, i) => dBorder.addColorStop(i / (d.border.length - 1), c));
    ctx.strokeStyle = dBorder; ctx.lineWidth = 2; ctx.stroke();

    // خطوط اللمعة
    ctx.strokeStyle = d.shine; ctx.lineWidth = 0.9;
    ctx.beginPath(); ctx.moveTo(cx, cy - size); ctx.lineTo(cx + size * 0.58, cy); ctx.stroke();
    ctx.beginPath(); ctx.moveTo(cx, cy - size); ctx.lineTo(cx - size * 0.58, cy); ctx.stroke();
    ctx.beginPath();
    ctx.moveTo(cx - size * 0.3, cy - size * 0.42);
    ctx.lineTo(cx + size * 0.3, cy - size * 0.42);
    ctx.stroke();
}

// ── الترجمات ──────────────────────────────────────────────────────────────────
const LANG = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        notFound: '❌ العضو غير موجود في السيرفر.',
        noCanvas: '⚠️ مكتبة الصور غير مثبتة. شغّل:\nnpm install @napi-rs/canvas',
        error:    (msg) => `❌ حدث خطأ: ${msg}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        notFound: '❌ Member not found in the server.',
        noCanvas: '⚠️ Image library not installed. Run:\nnpm install @napi-rs/canvas',
        error:    (msg) => `❌ Error: ${msg}`
    }
};

// ── الأمر ─────────────────────────────────────────────────────────────────────
module.exports = {
    data: {
        name: 'rank',
        description: '📊 عرض بطاقة مستواك | View your rank card',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'العضو | Member (optional)', type: 6, required: false }
        ]
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            try {
                await interaction.deferReply();
            } catch (deferErr) {
                console.error('❌ /rank: فشل deferReply:', deferErr.message);
                return;
            }

            const isAr = settings?.botLanguage === 'ar';
            const t    = isAr ? LANG.ar : LANG.en;

            if (commandConfig && !commandConfig.enabled)
                return await interaction.editReply({ content: t.disabled });

            if (!createCanvas)
                return await interaction.editReply({ content: t.noCanvas });

            const targetUser   = interaction.options.getUser('user') || interaction.user;
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);

            if (!targetMember)
                return await interaction.editReply({ content: t.notFound });

            const fullUser  = await client.users.fetch(targetUser.id, { force: true }).catch(() => null);
            const levelData = loadLevelData();
            const userData  = levelData[targetUser.id] || {};

            // دعم النظام القديم (xp واحد)
            if (userData.xp !== undefined && userData.chatXP === undefined) {
                userData.chatXP    = userData.xp || 0;
                userData.voiceXP   = 0;
                userData.chatLevel  = calcLevel(userData.chatXP);
                userData.voiceLevel = 0;
            }

            const chatXP    = userData.chatXP    || 0;
            const voiceXP   = userData.voiceXP   || 0;
            const chatLevel  = userData.chatLevel  || calcLevel(chatXP);
            const voiceLevel = userData.voiceLevel || calcLevel(voiceXP);

            const sorted  = Object.entries(levelData)
                .sort((a, b) =>
                    ((b[1].chatXP || b[1].xp || 0) + (b[1].voiceXP || 0)) -
                    ((a[1].chatXP || a[1].xp || 0) + (a[1].voiceXP || 0))
                );
            const rankPos = sorted.findIndex(([id]) => id === targetUser.id) + 1;

            const imgBuffer  = await buildRankCard(
                targetMember, chatXP, voiceXP, chatLevel, voiceLevel, rankPos || '?', fullUser
            );
            const attachment = new AttachmentBuilder(imgBuffer, { name: 'rank.png' });

            await interaction.editReply({ files: [attachment] });

            if (commandConfig?.deleteResponse)
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 10000);

        } catch (error) {
            console.error('❌ خطأ في أمر /rank:', error.message);
            const isAr  = settings?.botLanguage === 'ar';
            const errMsg = isAr
                ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                : `❌ Error: ${error.message || 'Unknown error'}`;
            try {
                if (interaction.deferred || interaction.replied)
                    await interaction.editReply({ content: errMsg });
                else
                    await interaction.reply({ content: errMsg, flags: MessageFlags.Ephemeral });
            } catch (e) {}
        }
    }
};
