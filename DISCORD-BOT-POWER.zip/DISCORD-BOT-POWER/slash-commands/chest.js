const { EmbedBuilder, MessageFlags } = require('discord.js');
const {
    getUser, saveUser, getChest, getRandomLoot,
    addEconXP, XP_SOURCES, addUserStat, updateQuestProgress, addTransaction
} = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:       '⚠️ نظام الاقتصاد معطل حالياً.',
        noChest:        '❌ الصندوق غير موجود.',
        noOwn:          '❌ لا تملك هذا الصندوق.',
        opened:         (name, loot) => `📦 فتحت **${name}** وحصلت على:\n${loot}`,
        openedAll:      (loot) => `📦 فتحت كل صناديقك وحصلت على:\n${loot}`,
        inventoryTitle: '📦 صناديقك',
        emptyInventory: 'لا تملك صناديق.',
        noLoot:         'لا يوجد محتوى.',
        info:           (name, desc, price) => `📦 **${name}**\n${desc}${price ? `\n💰 السعر: ${price}` : ''}`,
        giveSuccess:    (name, user) => `✅ أعطيت صندوق **${name}** إلى **${user}**.`,
        footer:         'الصناديق',
        xpGained:       (n) => `+${n} XP`,
    },
    en: {
        disabled:       '⚠️ Economy system is currently disabled.',
        noChest:        '❌ Chest not found.',
        noOwn:          "❌ You don't own this chest.",
        opened:         (name, loot) => `📦 You opened **${name}** and got:\n${loot}`,
        openedAll:      (loot) => `📦 You opened all your chests and got:\n${loot}`,
        inventoryTitle: '📦 Your Chests',
        emptyInventory: "You don't own any chests.",
        noLoot:         'Nothing.',
        info:           (name, desc, price) => `📦 **${name}**\n${desc}${price ? `\n💰 Price: ${price}` : ''}`,
        giveSuccess:    (name, user) => `✅ You gave chest **${name}** to **${user}**.`,
        footer:         'Chests',
        xpGained:       (n) => `+${n} XP`,
    }
};

function buildLootMessage(lootResults, user, es) {
    const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
    let msg = '';
    lootResults.forEach(l => {
        if (l.type === 'money') {
            user.wallet = (user.wallet || 0) + l.amount;
            user.totalEarned = (user.totalEarned || 0) + l.amount;
            msg += `💰 ${l.amount.toLocaleString()} ${cur}\n`;
        } else if (l.type === 'item') {
            if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};
            user.inventory[l.id] = (user.inventory[l.id] || 0) + (l.amount || 1);
            msg += `🎁 ${l.name} x${l.amount || 1}\n`;
        }
    });
    return msg;
}

module.exports = {
    data: {
        name: 'chest',
        description: 'Manage your chests | إدارة صناديقك',
        default_member_permissions: null,
        options: [
            {
                name: 'open',
                description: 'Open a chest | افتح صندوقاً',
                type: 1,
                options: [{ name: 'name', description: 'Chest name | اسم الصندوق', type: 3, required: true }]
            },
            {
                name: 'inventory',
                description: 'View your chests | شوف صناديقك',
                type: 1,
                options: []
            },
            {
                name: 'info',
                description: 'Get chest information | معلومات صندوق',
                type: 1,
                options: [{ name: 'name', description: 'Chest name | اسم الصندوق', type: 3, required: true }]
            },
            {
                name: 'give',
                description: 'Give a chest to a member | أعط صندوقاً لعضو',
                type: 1,
                options: [
                    { name: 'name', description: 'Chest name | اسم الصندوق', type: 3, required: true },
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                ]
            },
            {
                name: 'open-all',
                description: 'Open all chests at once | افتح كل الصناديق دفعة واحدة',
                type: 1,
                options: []
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const user = getUser(interaction.guildId, interaction.user.id);
            if (!user.chests || Array.isArray(user.chests)) user.chests = {};

            const sub = interaction.options.getSubcommand();
            const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            // ── open ──────────────────────────────────────────────────────────
            if (sub === 'open') {
                const name  = interaction.options.getString('name');
                const chest = getChest(name);
                if (!chest) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noChest).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                if (!(user.chests[name] > 0)) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noOwn).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                const loot    = getRandomLoot(name);
                const lootMsg = buildLootMessage(loot, user, es) || t.noLoot;
                user.chests[name]--;
                if (user.chests[name] <= 0) delete user.chests[name];
                saveUser(interaction.guildId, interaction.user.id, user);

                // ── [FIX] XP + Quest + Transaction ────────────────────────────
                const xpResult = addEconXP(interaction.guildId, interaction.user.id, XP_SOURCES.open_chest || 15);
                addUserStat(interaction.guildId, interaction.user.id, 'chestsOpened', 1);
                updateQuestProgress(interaction.guildId, interaction.user.id, 'open_chests', 1);
                const moneyLoot = loot.filter(l => l.type === 'money').reduce((s, l) => s + l.amount, 0);
                if (moneyLoot > 0) {
                    addTransaction(interaction.guildId, interaction.user.id, 'chest_open', moneyLoot, `Chest: ${name}`);
                    updateQuestProgress(interaction.guildId, interaction.user.id, 'earn_coins', moneyLoot);
                }

                const embed = new EmbedBuilder()
                    .setDescription(t.opened(chest.name || name, lootMsg))
                    .setColor('#FEE75C')
                    .addFields({ name: '⭐ XP', value: t.xpGained(XP_SOURCES.open_chest || 15), inline: true })
                    .setFooter({ text: t.footer });

                if (xpResult.leveled) {
                    embed.addFields({ name: '⬆️', value: `Level ${xpResult.newLevel}!`, inline: true });
                }

                return interaction.reply({ embeds: [embed] });
            }

            // ── inventory ─────────────────────────────────────────────────────
            if (sub === 'inventory') {
                const list = Object.entries(user.chests)
                    .map(([id, qty]) => {
                        const c = getChest(id);
                        return `${c ? c.name : id}: **${qty}**`;
                    }).join('\n') || t.emptyInventory;
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(t.inventoryTitle)
                        .setDescription(list)
                        .setColor('#5865F2').setFooter({ text: t.footer })]
                });
            }

            // ── info ──────────────────────────────────────────────────────────
            if (sub === 'info') {
                const name  = interaction.options.getString('name');
                const chest = getChest(name);
                if (!chest) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noChest).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.info(chest.name || name, chest.description || '', chest.price))
                        .setColor('#5865F2').setFooter({ text: t.footer })]
                });
            }

            // ── give ──────────────────────────────────────────────────────────
            if (sub === 'give') {
                const name   = interaction.options.getString('name');
                const target = interaction.options.getUser('user');
                const chest  = getChest(name);
                if (!chest) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noChest).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                if (!(user.chests[name] > 0)) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noOwn).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                user.chests[name]--;
                if (user.chests[name] <= 0) delete user.chests[name];
                saveUser(interaction.guildId, interaction.user.id, user);

                const targetData = getUser(interaction.guildId, target.id);
                if (!targetData.chests || Array.isArray(targetData.chests)) targetData.chests = {};
                targetData.chests[name] = (targetData.chests[name] || 0) + 1;
                saveUser(interaction.guildId, target.id, targetData);

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.giveSuccess(chest.name || name, target.username))
                        .setColor('#57F287').setFooter({ text: t.footer })]
                });
            }

            // ── open-all ──────────────────────────────────────────────────────
            if (sub === 'open-all') {
                if (Object.keys(user.chests).length === 0) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.emptyInventory).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                let totalMoney = 0;
                let totalChests = 0;
                const items = {};

                for (const [chestId, qty] of Object.entries(user.chests)) {
                    const chest = getChest(chestId);
                    if (!chest) continue;
                    for (let i = 0; i < qty; i++) {
                        totalChests++;
                        const loot = getRandomLoot(chestId);
                        for (const l of loot) {
                            if (l.type === 'money') {
                                totalMoney += l.amount;
                            } else if (l.type === 'item') {
                                if (!items[l.id]) items[l.id] = { name: l.name, amount: 0 };
                                items[l.id].amount += l.amount || 1;
                            }
                        }
                    }
                }

                if (totalMoney > 0) {
                    user.wallet = (user.wallet || 0) + totalMoney;
                    user.totalEarned = (user.totalEarned || 0) + totalMoney;
                }
                for (const [itemId, itemData] of Object.entries(items)) {
                    if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};
                    user.inventory[itemId] = (user.inventory[itemId] || 0) + itemData.amount;
                }
                user.chests = {};
                saveUser(interaction.guildId, interaction.user.id, user);

                // ── [FIX] XP + Quest + Transaction ────────────────────────────
                const xpEach  = XP_SOURCES.open_chest || 15;
                const xpTotal = xpEach * totalChests;
                addEconXP(interaction.guildId, interaction.user.id, xpTotal);
                addUserStat(interaction.guildId, interaction.user.id, 'chestsOpened', totalChests);
                updateQuestProgress(interaction.guildId, interaction.user.id, 'open_chests', totalChests);
                if (totalMoney > 0) {
                    addTransaction(interaction.guildId, interaction.user.id, 'chest_open', totalMoney, `Opened ${totalChests} chests`);
                    updateQuestProgress(interaction.guildId, interaction.user.id, 'earn_coins', totalMoney);
                }

                let summary = '';
                if (totalMoney > 0) summary += `💰 ${totalMoney.toLocaleString()} ${cur}\n`;
                for (const item of Object.values(items)) summary += `🎁 ${item.name} x${item.amount}\n`;
                const finalMsg = summary || t.noLoot;

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.openedAll(finalMsg))
                        .setColor('#FEE75C')
                        .addFields({ name: '⭐ XP', value: t.xpGained(xpTotal), inline: true })
                        .setFooter({ text: t.footer })]
                });
            }

        } catch (err) {
            console.error('[chest] unexpected error:', err);
            const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
