const fs   = require('fs');
const path = require('path');

const DATA_FILE             = path.join(__dirname, '..', 'economyUserData.json');
const ITEMS_FILE            = path.join(__dirname, '..', 'items.json');
const RECIPES_FILE          = path.join(__dirname, '..', 'recipes.json');
const SHOPSTOCK_FILE        = path.join(__dirname, '..', 'shopStock.json');
const ECONOMY_SETTINGS_FILE = path.join(__dirname, '..', 'economySystem.json');
const AUCTION_FILE          = path.join(__dirname, '..', 'auctionData.json');
// [FIX-BJ-01] ملف لتتبع ألعاب Blackjack النشطة — يُمكّن استرجاع الرهان عند إعادة تشغيل البوت
const ACTIVE_GAMES_FILE     = path.join(__dirname, '..', 'activeGames.json');
const RARITY_WEIGHT         = { common: 0, uncommon: 1, rare: 2, epic: 3, legendary: 4 };

// ─── [FIX-MUTEX-01] Simple per-user mutex (no external dependencies) ──────────
// المشكلة: Node.js يُعالج نداءات Discord بشكل async — عمليتان متزامنتان على نفس
// المستخدم يمكنهما قراءة نفس الرصيد قبل أن تكتب أي منهما تعديلها.
// الحل: queue-based mutex يضمن تسلسل العمليات المالية لكل userId.
class _Mutex {
    constructor() { this._q = []; this._locked = false; }
    acquire() {
        return new Promise(resolve => {
            if (!this._locked) { this._locked = true; resolve(); }
            else this._q.push(resolve);
        });
    }
    release() {
        if (this._q.length > 0) { const n = this._q.shift(); n(); }
        else this._locked = false;
    }
    async runExclusive(fn) {
        await this.acquire();
        try { return await fn(); } finally { this.release(); }
    }
}

const _userLocks = new Map();
function _getLock(key) {
    if (!_userLocks.has(key)) _userLocks.set(key, new _Mutex());
    return _userLocks.get(key);
}

// تشغيل دالة بعد الحصول على قفل مستخدم واحد
async function withUserLock(guildId, userId, fn) {
    return _getLock(`${guildId}:${userId}`).runExclusive(fn);
}

// تشغيل دالة بعد الحصول على قفلَي مستخدمَين (ترتيب ثابت لتجنب Deadlock)
async function withTwoUserLocks(guildId, id1, id2, fn) {
    const [first, second] = [id1, id2].sort();
    return _getLock(`${guildId}:${first}`).runExclusive(() =>
        _getLock(`${guildId}:${second}`).runExclusive(fn)
    );
}
// ─────────────────────────────────────────────────────────────────────────────

// ─── In-memory cache (single-process only) ────────────────────────────────────
// NOTE: This cache works correctly for single-process deployments.
// If using PM2 cluster mode or multiple instances, disable the cache and
// always call readJSON(DATA_FILE) directly in loadAll().
let _dataCache = null;
function _ensureCache() {
    if (!_dataCache) _dataCache = readJSON(DATA_FILE);
    return _dataCache;
}

// ─── Atomic file write ────────────────────────────────────────────────────────
function readJSON(file) {
    if (fs.existsSync(file)) {
        try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch (e) { return {}; }
    }
    return {};
}

// [FIX-WRITE-01] writeJSONAtomic مع دعم كامل لـ Windows + OneDrive.
//
// المشكلة على Windows: fs.renameSync يرمي EPERM إذا كان الملف الهدف موجوداً
// ومقفولاً (OneDrive يقفل الملفات أثناء المزامنة).
//
// الحل: محاولتان مرتّبتان:
//   1) الأسلوب الآمن: اكتب .tmp ثم احذف الأصل ثم أعد تسميته (يعمل على Windows)
//   2) الاحتياط:      اكتب مباشرةً على الملف (إذا فشلت المحاولة الأولى)
function writeJSONAtomic(file, data) {
    const tmp     = file + '.tmp';
    const json    = JSON.stringify(data, null, 2);
    const isWin   = process.platform === 'win32';

    try {
        fs.writeFileSync(tmp, json, 'utf8');

        if (isWin && fs.existsSync(file)) {
            // [FIX-WRITE-WIN] Windows لا يسمح بـ rename فوق ملف موجود.
            // نحذف الأصل أولاً ثم نُعيد التسمية.
            try { fs.unlinkSync(file); } catch (_) {}
        }

        fs.renameSync(tmp, file);
        return true;
    } catch (e) {
        // نظّف الملف المؤقت إن وُجد
        try { if (fs.existsSync(tmp)) fs.unlinkSync(tmp); } catch (_) {}

        // الكتابة المباشرة كاحتياط أخير
        try {
            fs.writeFileSync(file, json, 'utf8');
            return true;
        } catch (e2) {
            console.error(`[economyData] WRITE ERROR — file: ${file}`, e2.message);
            return false;
        }
    }
}
function writeJSON(file, data) { return writeJSONAtomic(file, data); }
function loadAll()     { return _ensureCache(); }
function saveAll(data) { _dataCache = data; writeJSONAtomic(DATA_FILE, data); }

// ─── [FIX-BJ-01] Active game tracking for Blackjack crash recovery ─────────────
// المشكلة: إذا أُعيد تشغيل البوت أثناء لعبة Blackjack، الرهان كان يُفقد نهائياً.
// الحل: تسجيل كل لعبة نشطة في ملف، واسترجاع الرهان عند بدء البوت.
function startActiveGame(guildId, userId, bet) {
    try {
        const data = readJSON(ACTIVE_GAMES_FILE);
        if (!data[guildId]) data[guildId] = {};
        data[guildId][userId] = { bet, startedAt: Date.now() };
        writeJSONAtomic(ACTIVE_GAMES_FILE, data);
    } catch (e) {
        console.error('[economyData] startActiveGame error:', e.message);
    }
}

function endActiveGame(guildId, userId) {
    try {
        const data = readJSON(ACTIVE_GAMES_FILE);
        if (data[guildId]) {
            delete data[guildId][userId];
            writeJSONAtomic(ACTIVE_GAMES_FILE, data);
        }
    } catch (e) {
        console.error('[economyData] endActiveGame error:', e.message);
    }
}

// يُستدعى عند بدء البوت — يسترجع رهانات الألعاب غير المنتهية
function recoverActiveGames() {
    try {
        const data = readJSON(ACTIVE_GAMES_FILE);
        const recovered = [];
        for (const [guildId, users] of Object.entries(data)) {
            for (const [userId, game] of Object.entries(users || {})) {
                if (!game || !game.bet) continue;
                const user = getUser(guildId, userId);
                user.wallet = (user.wallet || 0) + game.bet;
                saveUser(guildId, userId, user);
                recovered.push({ guildId, userId, bet: game.bet });
                console.log(`[economyData] BJ recovery: returned ${game.bet} to user ${userId} in guild ${guildId}`);
            }
        }
        // امسح جميع الألعاب النشطة بعد الاسترجاع
        writeJSONAtomic(ACTIVE_GAMES_FILE, {});
        if (recovered.length > 0) {
            console.log(`[economyData] Recovered ${recovered.length} unfinished Blackjack game(s)`);
        }
        return recovered;
    } catch (e) {
        console.error('[economyData] recoverActiveGames error:', e.message);
        return [];
    }
}
// ─────────────────────────────────────────────────────────────────────────────

// ─── Numeric sanitiser ────────────────────────────────────────────────────────
function _sanitiseUser(u) {
    u.wallet      = Math.max(0, Math.floor(isNaN(u.wallet)      ? 0 : (u.wallet      || 0)));
    u.bank        = Math.max(0, Math.floor(isNaN(u.bank)        ? 0 : (u.bank        || 0)));
    u.totalEarned = Math.max(0, Math.floor(isNaN(u.totalEarned) ? 0 : (u.totalEarned || 0)));
    u.dailyStreak = Math.max(0, Math.floor(isNaN(u.dailyStreak) ? 0 : (u.dailyStreak || 0)));
    u.level       = Math.max(1, Math.floor(isNaN(u.level)       ? 1 : (u.level       || 1)));
    u.econXP      = Math.max(0, Math.floor(isNaN(u.econXP)      ? 0 : (u.econXP      || 0)));
    u.econLevel   = Math.max(1, Math.floor(isNaN(u.econLevel)   ? 1 : (u.econLevel   || 1)));
    if (!u.inventory || Array.isArray(u.inventory)) u.inventory = {};
    if (!u.chests    || Array.isArray(u.chests))    u.chests    = {};
    if (!u.notifications) u.notifications = { work: true, daily: true };
    if (!Array.isArray(u.activeEffects)) u.activeEffects = [];
    else u.activeEffects = u.activeEffects.filter(e => e && e.expires > Date.now());
    if (!u.stats)  u.stats  = {};
    if (!u.quests) u.quests = { daily: [], weekly: null, dailyDate: '', weeklyKey: '' };
    if (!Array.isArray(u.transactions)) u.transactions = [];
    return u;
}

function getUser(guildId, userId) {
    const all = loadAll();
    if (!all[guildId]) all[guildId] = {};
    if (!all[guildId][userId]) {
        all[guildId][userId] = {
            wallet: 0, bank: 0,
            lastDaily: null, dailyStreak: 0, lastStreakDate: null,
            lastWork: null, lastWeekly: null, lastRob: null, lastPay: null,
            lastMessage: null, lastCommand: null, lastReaction: null,
            inventory: {}, chests: {}, activeEffects: [],
            totalEarned: 0, level: 1,
            econXP: 0, econLevel: 1,
            notifications: { work: true, daily: true },
            stats: {},
            quests: { daily: [], weekly: null, dailyDate: '', weeklyKey: '' }
        };
        saveAll(all);
    }
    const u = all[guildId][userId];
    if (!u.inventory     || Array.isArray(u.inventory))  u.inventory     = {};
    if (!u.chests        || Array.isArray(u.chests))     u.chests        = {};
    if (!Array.isArray(u.activeEffects))                 u.activeEffects = [];
    if (!u.notifications)                                u.notifications = { work: true, daily: true };
    if (!u.level)                                        u.level         = 1;
    if (u.econXP    === undefined)                       u.econXP        = 0;
    if (!u.econLevel)                                    u.econLevel     = 1;
    if (!u.stats)                                        u.stats         = {};
    if (!u.quests)                                       u.quests        = { daily: [], weekly: null, dailyDate: '', weeklyKey: '' };
    return u;
}

function saveUser(guildId, userId, userData) {
    const all = loadAll();
    if (!all[guildId]) all[guildId] = {};
    all[guildId][userId] = _sanitiseUser(userData);
    saveAll(all);
}

function getAllUsers(guildId) {
    const all   = loadAll();
    const guild = all[guildId] || {};
    return Object.entries(guild).map(([userId, data]) => ({ userId, ...data }));
}

function addWallet(guildId, userId, amount, settings) {
    const all   = loadAll();
    if (!all[guildId]) all[guildId] = {};
    const u     = all[guildId][userId] || getUser(guildId, userId);
    const limit = settings?.walletLimit || 0;
    const mult  = parseFloat(settings?.globalMultiplier || 1);
    const add   = Math.floor(amount * mult);
    u.wallet    = limit > 0 ? Math.min(u.wallet + add, limit) : u.wallet + add;
    u.totalEarned = (u.totalEarned || 0) + add;
    all[guildId][userId] = u;
    saveAll(all);
    return add;
}

function getLeaderboard(guildId, sortBy = 'total', limit = 10) {
    const all   = loadAll();
    const guild = all[guildId] || {};
    return Object.entries(guild)
        .map(([userId, u]) => ({
            userId,
            wallet: u.wallet || 0,
            bank:   u.bank   || 0,
            total:  (u.wallet || 0) + (u.bank || 0)
        }))
        .sort((a, b) => b[sortBy] - a[sortBy])
        .slice(0, limit);
}

function resetEconomy(guildId) {
    const all = loadAll();
    if (all[guildId]) {
        for (const userId in all[guildId]) {
            all[guildId][userId] = {
                wallet: 0, bank: 0,
                lastDaily: null, dailyStreak: 0, lastStreakDate: null,
                lastWork: null, lastWeekly: null, lastRob: null, lastPay: null,
                lastMessage: null, lastCommand: null, lastReaction: null,
                inventory: {}, chests: {}, activeEffects: [], totalEarned: 0, level: 1,
                econXP: 0, econLevel: 1,
                notifications: { work: true, daily: true },
                stats: {},
                quests: { daily: [], weekly: null, dailyDate: '', weeklyKey: '' }
            };
        }
        saveAll(all);
    }
}

function cooldownLeft(lastTime, cooldownMs) {
    if (!lastTime) return 0;
    const left = cooldownMs - (Date.now() - lastTime);
    return left > 0 ? left : 0;
}
function formatTime(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m ${s % 60}s`;
    return `${s}s`;
}

function getRoleMultiplier(member, roleBoosters = [], stackMultipliers = false) {
    const memberRoleIds = member.roles.cache.map(r => r.id);
    const matched = roleBoosters.filter(rb => memberRoleIds.includes(rb.roleId));
    if (!matched.length) return 1;
    if (stackMultipliers) return matched.reduce((sum, rb) => sum + (parseFloat(rb.multiplier) || 1), 0);
    return Math.max(...matched.map(rb => parseFloat(rb.multiplier) || 1));
}

function getChannelMultiplier(channelId, channelBoosters = []) {
    const found = channelBoosters.find(cb => cb.channelId === channelId);
    return found ? (parseFloat(found.multiplier) || 1) : 1;
}

function loadItems() { return readJSON(ITEMS_FILE); }

function _getSystemShopItems() {
    const settings = readJSON(ECONOMY_SETTINGS_FILE);
    return (settings.shop || []).map(item => ({
        id:          item.name,
        name:        item.name,
        price:       item.price  || 0,
        emoji:       item.emoji  || '📦',
        roleId:      item.roleId || null,
        description: item.description || '-',
    }));
}

function getItem(itemId) {
    const items = loadItems();
    if (items[itemId] && !String(itemId).startsWith('_')) return items[itemId];
    const sysItems = _getSystemShopItems();
    return sysItems.find(s => s.id === itemId) || null;
}

function getAllShopItems() {
    const sysItems  = _getSystemShopItems();
    const fileItems = Object.entries(loadItems())
        .filter(([id]) => !String(id).startsWith('_'))
        .map(([id, data]) => ({ id, ...data }));
    const merged = [...sysItems];
    fileItems.forEach(fi => {
        const idx = merged.findIndex(m => m.id === fi.id);
        if (idx >= 0) merged[idx] = fi; else merged.push(fi);
    });
    return merged;
}

function loadChestsFromSystem() {
    const settings    = readJSON(ECONOMY_SETTINGS_FILE);
    const chestsArray = settings.chests || [];
    const chestsObject = {};
    chestsArray.forEach(chest => { chestsObject[chest.name] = chest; });
    return chestsObject;
}

function getChest(chestName) {
    const chests = loadChestsFromSystem();
    return chests[chestName] || null;
}

function getRandomLoot(chestId) {
    const chest = getChest(chestId);
    if (!chest) return [];

    if (chest.lootTable && chest.lootTable.length > 0) {
        const loot = [];
        for (const entry of chest.lootTable) {
            if (Math.random() <= (entry.chance || 1)) {
                loot.push({
                    type:   entry.type,
                    id:     entry.id,
                    name:   entry.name,
                    amount: Math.floor(Math.random() * (entry.max - entry.min + 1)) + entry.min
                });
            }
        }
        return loot;
    }

    const rarityMultipliers = {
        common:    { min: 0.5,  max: 1.5,  moneyChance: 0.7  },
        uncommon:  { min: 1.0,  max: 2.5,  moneyChance: 0.8  },
        rare:      { min: 2.0,  max: 5.0,  moneyChance: 0.9  },
        epic:      { min: 4.0,  max: 10.0, moneyChance: 0.95 },
        legendary: { min: 8.0,  max: 25.0, moneyChance: 1.0  }
    };

    const rarity    = chest.rarity || 'common';
    const mult      = rarityMultipliers[rarity] || rarityMultipliers.common;
    const basePrice = chest.price || 100;
    const loot      = [];

    if (Math.random() <= mult.moneyChance) {
        const minAmount = Math.floor(basePrice * mult.min);
        const maxAmount = Math.floor(basePrice * mult.max);
        const amount    = Math.floor(Math.random() * (maxAmount - minAmount + 1)) + minAmount;
        loot.push({ type: 'money', amount: Math.max(1, amount) });
    }

    const nothingChance = Math.max(0, 0.3 - (RARITY_WEIGHT[rarity] || 0) * 0.05);
    if (Math.random() < nothingChance) return [];

    return loot;
}

function getAllChests() {
    const chests = loadChestsFromSystem();
    return Object.entries(chests).map(([name, data]) => ({ id: name, name: name, ...data }));
}

function loadRecipes() { return readJSON(RECIPES_FILE); }
function getRecipe(recipeId) {
    const recipes = loadRecipes();
    return recipes[recipeId] || null;
}
function getAllRecipes() {
    const recipes = loadRecipes();
    return Object.entries(recipes)
        .filter(([id]) => !String(id).startsWith('_'))
        .map(([id, data]) => ({ id, ...data }));
}

function restockChest(chestId, amount) {
    const stock = readJSON(SHOPSTOCK_FILE);
    if (!stock[chestId]) stock[chestId] = 0;
    stock[chestId] = amount !== undefined ? amount : (getChest(chestId)?.defaultStock || 10);
    writeJSONAtomic(SHOPSTOCK_FILE, stock);
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── ECONOMY XP / LEVEL SYSTEM ─────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

// [FIX-XP-01] إزالة المفتاح المكرر open_chest — كان يُسبّب تشويشاً عند التعديل
const XP_SOURCES = {
    work:       10,
    daily:      25,
    buy_item:   5,
    open_chest: 15,
    craft_item: 20
};

function getXPForLevel(level) {
    return level * 100;
}

function getEconLevelInfo(totalXP) {
    let level     = 1;
    let remaining = Math.max(0, totalXP || 0);
    while (remaining >= getXPForLevel(level)) {
        remaining -= getXPForLevel(level);
        level++;
    }
    const xpNeeded    = getXPForLevel(level);
    const progressPct = Math.floor((remaining / xpNeeded) * 100);
    return { level, currentXP: remaining, xpNeeded, progressPct };
}

function addEconXP(guildId, userId, amount) {
    const user    = getUser(guildId, userId);
    const before  = getEconLevelInfo(user.econXP || 0);
    user.econXP   = (user.econXP || 0) + Math.max(0, amount);
    const after   = getEconLevelInfo(user.econXP);
    user.econLevel = after.level;

    const leveled = after.level > before.level;
    if (leveled) {
        const settings = readJSON(ECONOMY_SETTINGS_FILE);
        if (settings.levelRewards && Array.isArray(settings.levelRewards)) {
            for (let lvl = before.level + 1; lvl <= after.level; lvl++) {
                const reward = settings.levelRewards.find(r => r.level === lvl);
                if (reward && reward.reward > 0) {
                    user.wallet      = (user.wallet      || 0) + reward.reward;
                    user.totalEarned = (user.totalEarned || 0) + reward.reward;
                }
            }
        }
    }
    saveUser(guildId, userId, user);
    return { leveled, newLevel: after.level, oldLevel: before.level };
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── USER STATS ────────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

function addUserStat(guildId, userId, statKey, amount) {
    const user          = getUser(guildId, userId);
    if (!user.stats)     user.stats = {};
    user.stats[statKey] = (user.stats[statKey] || 0) + amount;
    saveUser(guildId, userId, user);
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── DAILY QUEST SYSTEM ───────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

const QUEST_POOL = [
    { type: 'work_times',  targets: [2, 3, 5],        rewards: [150, 200, 350] },
    { type: 'earn_coins',  targets: [200, 500, 1000],  rewards: [200, 350, 600] },
    { type: 'spend_coins', targets: [100, 300, 700],   rewards: [150, 300, 500] },
    { type: 'open_chests', targets: [1, 2, 3],         rewards: [200, 400, 600] },
    { type: 'craft_items', targets: [1, 2, 3],         rewards: [300, 500, 800] },
    { type: 'daily_claim', targets: [1],               rewards: [100]           }
];

const WEEKLY_QUEST_TPL = { type: 'earn_coins', target: 5000, reward: 2500 };

function _seededRandInt(seed, max) {
    let h = 2166136261;
    for (let i = 0; i < seed.length; i++) {
        h ^= seed.charCodeAt(i);
        h  = Math.imul(h, 16777619);
    }
    return Math.abs(h) % max;
}

function _todayStr() {
    return new Date().toISOString().slice(0, 10);
}

function _weekStr() {
    const d   = new Date();
    const jan = new Date(d.getFullYear(), 0, 1);
    const wk  = Math.ceil(((d - jan) / 86400000 + jan.getDay() + 1) / 7);
    return `${d.getFullYear()}-W${wk}`;
}

function _generateDailyQuests(userId, dateStr) {
    const seed  = `${userId}-daily-${dateStr}`;
    const pool  = QUEST_POOL.slice();
    const picks = [];
    let   offset = 0;
    while (picks.length < 3 && pool.length > 0) {
        const idx = _seededRandInt(seed + offset, pool.length);
        const tpl = pool.splice(idx, 1)[0];
        const ti  = _seededRandInt(seed + 't' + offset, tpl.targets.length);
        picks.push({
            type:     tpl.type,
            target:   tpl.targets[ti],
            reward:   tpl.rewards[ti],
            progress: 0,
            claimed:  false
        });
        offset++;
    }
    return picks;
}

function getOrGenerateQuests(guildId, userId) {
    const user     = getUser(guildId, userId);
    const today    = _todayStr();
    const thisWeek = _weekStr();
    let   changed  = false;

    if (!user.quests) user.quests = {};

    if (user.quests.dailyDate !== today || !user.quests.daily || user.quests.daily.length === 0) {
        user.quests.daily     = _generateDailyQuests(userId, today);
        user.quests.dailyDate = today;
        changed = true;
    }

    if (user.quests.weeklyKey !== thisWeek || !user.quests.weekly) {
        user.quests.weekly    = { ...WEEKLY_QUEST_TPL, progress: 0, claimed: false };
        user.quests.weeklyKey = thisWeek;
        changed = true;
    }

    if (changed) saveUser(guildId, userId, user);
    return user.quests;
}

function updateQuestProgress(guildId, userId, type, amount) {
    const user   = getUser(guildId, userId);
    const today  = _todayStr();
    const week   = _weekStr();
    let   changed = false;

    if (!user.quests) user.quests = {};

    if (user.quests.dailyDate !== today) {
        user.quests.daily     = _generateDailyQuests(userId, today);
        user.quests.dailyDate = today;
        changed = true;
    }
    if (user.quests.weeklyKey !== week || !user.quests.weekly) {
        user.quests.weekly    = { ...WEEKLY_QUEST_TPL, progress: 0, claimed: false };
        user.quests.weeklyKey = week;
        changed = true;
    }

    (user.quests.daily || []).forEach(q => {
        if (q.type === type && !q.claimed && q.progress < q.target) {
            q.progress = Math.min(q.progress + amount, q.target);
            changed = true;
        }
    });

    if (user.quests.weekly && user.quests.weekly.type === type && !user.quests.weekly.claimed) {
        user.quests.weekly.progress = Math.min(
            (user.quests.weekly.progress || 0) + amount,
            user.quests.weekly.target
        );
        changed = true;
    }

    if (changed) saveUser(guildId, userId, user);
}

function claimCompletedQuests(guildId, userId) {
    const user = getUser(guildId, userId);
    if (!user.quests) user.quests = {};
    let totalReward = 0;

    (user.quests.daily || []).forEach(q => {
        if (!q.claimed && q.progress >= q.target) {
            q.claimed = true;
            totalReward += q.reward || 0;
        }
    });

    if (user.quests.weekly && !user.quests.weekly.claimed &&
        user.quests.weekly.progress >= user.quests.weekly.target) {
        user.quests.weekly.claimed = true;
        totalReward += user.quests.weekly.reward || 0;
    }

    if (totalReward > 0) {
        user.wallet      = (user.wallet      || 0) + totalReward;
        user.totalEarned = (user.totalEarned || 0) + totalReward;
        if (!user.stats) user.stats = {};
        user.stats.questsDone = (user.stats.questsDone || 0) + 1;
        saveUser(guildId, userId, user);
    }

    return { totalReward };
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── AUCTION HOUSE ─────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

function _loadAuctions()     { return readJSON(AUCTION_FILE); }
function _saveAuctions(data) { writeJSONAtomic(AUCTION_FILE, data); }
function _genAuctionId()     { return Math.random().toString(36).slice(2, 8).toUpperCase(); }

function _normaliseAuction(a) {
    if (!a) return a;
    if (a.cancelled === undefined) a.cancelled = false;
    if (a.sellerClaimed === undefined) a.sellerClaimed = false;
    if (a.winnerClaimed === undefined) a.winnerClaimed = false;
    if (a.active === undefined) a.active = !a.cancelled;
    return a;
}

function getAllAuctions(guildId, includeEnded = false) {
    const data = _loadAuctions();
    return (data[guildId] || [])
        .map(_normaliseAuction)
        .filter(a => a.active && !a.cancelled && !a.claimed && (includeEnded || a.endsAt > Date.now()));
}

function getAuction(guildId, auctionId) {
    const data = _loadAuctions();
    const auction = (data[guildId] || []).find(a => a.id === auctionId);
    return _normaliseAuction(auction || null);
}

function expireAuctions(guildId) {
    const data = _loadAuctions();
    if (!data[guildId]) return;
    const now   = Date.now();
    let changed = false;
    data[guildId].forEach(a => {
        _normaliseAuction(a);
        if (a.endsAt <= now && !a.ended) { a.ended = true; changed = true; }
    });
    if (changed) _saveAuctions(data);
}

function createAuction(guildId, sellerId, itemId, qty, startPrice, durationHours) {
    const data = _loadAuctions();
    if (!data[guildId]) data[guildId] = [];
    const auction = {
        id:               _genAuctionId(),
        sellerId,
        itemId,
        qty:              Math.max(1, qty || 1),
        startPrice:       Math.max(1, startPrice || 1),
        currentBid:       0,
        currentBidderId:  null,
        previousBidderId: null,
        previousBid:      0,
        endsAt:           Date.now() + (durationHours || 24) * 3600000,
        active:           true,
        cancelled:        false,
        sellerClaimed:    false,
        winnerClaimed:    false,
        claimed:          false
    };
    data[guildId].push(auction);
    _saveAuctions(data);
    return auction;
}

function bidOnAuction(guildId, auctionId, bidderId, amount) {
    const data    = _loadAuctions();
    const list    = data[guildId] || [];
    const auction = list.find(a => a.id === auctionId);
    if (!auction) return {};
    _normaliseAuction(auction);
    if (!auction.active || auction.cancelled || auction.claimed || auction.endsAt <= Date.now()) return {};
    const prev = { previousBidderId: auction.currentBidderId, previousBid: auction.currentBid };
    auction.previousBidderId = auction.currentBidderId;
    auction.previousBid      = auction.currentBid;
    auction.currentBidderId  = bidderId;
    auction.currentBid       = amount;
    _saveAuctions(data);
    return prev;
}

function cancelAuction(guildId, auctionId) {
    const data    = _loadAuctions();
    const list    = data[guildId] || [];
    const auction = list.find(a => a.id === auctionId);
    if (auction) { _normaliseAuction(auction); auction.active = false; auction.cancelled = true; _saveAuctions(data); }
}

function claimAuction(guildId, auctionId, side = 'winner') {
    const data    = _loadAuctions();
    const list    = data[guildId] || [];
    const auction = list.find(a => a.id === auctionId);
    if (auction) {
        _normaliseAuction(auction);
        if (side === 'seller') auction.sellerClaimed = true;
        else if (side === 'winner') auction.winnerClaimed = true;
        if (!auction.currentBidderId) auction.winnerClaimed = true;
        auction.claimed = Boolean(auction.sellerClaimed && auction.winnerClaimed);
        if (auction.claimed) auction.active = false;
        _saveAuctions(data);
    }
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── TRANSACTION LOG ──────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

const MAX_TRANSACTIONS = 25;

function addTransaction(guildId, userId, type, amount, note = '') {
    const user = getUser(guildId, userId);
    if (!Array.isArray(user.transactions)) user.transactions = [];
    user.transactions.unshift({ type, amount, note, ts: Date.now() });
    if (user.transactions.length > MAX_TRANSACTIONS) {
        user.transactions = user.transactions.slice(0, MAX_TRANSACTIONS);
    }
    saveUser(guildId, userId, user);
}

function getUserTransactions(guildId, userId, limit = 10) {
    const user = getUser(guildId, userId);
    if (!Array.isArray(user.transactions)) return [];
    return user.transactions.slice(0, Math.min(limit, MAX_TRANSACTIONS));
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── LOAN SYSTEM ──────────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

function getLoan(guildId, userId) {
    const user = getUser(guildId, userId);
    return user.loan || null;
}

function takeLoan(guildId, userId, amount, interestRate, dueHours) {
    const user  = getUser(guildId, userId);
    const interest = Math.floor(amount * (interestRate / 100));
    const totalDue = amount + interest;
    user.loan      = { amount, interest, totalDue, takenAt: Date.now(), dueAt: Date.now() + dueHours * 3600000 };
    user.wallet    = (user.wallet || 0) + amount;
    user.totalEarned = (user.totalEarned || 0) + amount;
    saveUser(guildId, userId, user);
    addTransaction(guildId, userId, 'loan_taken', amount, `Loan: due ${totalDue}`);
    return user.loan;
}

function repayLoan(guildId, userId, amount) {
    const user = getUser(guildId, userId);
    if (!user.loan) return { success: false, reason: 'no_loan' };
    if ((user.wallet || 0) < amount) return { success: false, reason: 'insufficient' };
    user.wallet        = (user.wallet || 0) - amount;
    user.loan.totalDue = Math.max(0, user.loan.totalDue - amount);
    if (user.loan.totalDue <= 0) {
        user.loan = null;
        saveUser(guildId, userId, user);
        addTransaction(guildId, userId, 'loan_repaid', amount, 'Loan fully repaid');
        return { success: true, paid: true };
    }
    saveUser(guildId, userId, user);
    addTransaction(guildId, userId, 'loan_repaid', amount, `Remaining: ${user.loan.totalDue}`);
    return { success: true, paid: false, remaining: user.loan.totalDue };
}

// [FIX-LOAN-01] إضافة دالة لتطبيق غرامة التأخر بشكل صحيح
// المشكلة: الكود القديم يستخدم loadAll/saveAll مباشرةً في loan.js ويُطبّق
// الغرامة مرة واحدة فقط بسبب _penaltyApplied.
// الحل: دالة مركزية هنا تُطبّق الغرامة عبر getUser/saveUser للحفاظ على الاتساق.
function applyLoanOverduePenalty(guildId, userId, penaltyRatePct) {
    const user = getUser(guildId, userId);
    if (!user.loan) return null;
    if (user.loan.dueAt >= Date.now()) return user.loan; // لم يتأخر بعد
    if (user.loan._penaltyApplied) return user.loan;     // طُبّقت مسبقاً

    const penalty = Math.floor(user.loan.totalDue * (penaltyRatePct / 100));
    if (penalty > 0) {
        user.loan.totalDue += penalty;
        user.loan._penaltyApplied = true;
        saveUser(guildId, userId, user);
    }
    return user.loan;
}

// ═══════════════════════════════════════════════════════════════════════════════
// ── SERVER TREASURY ──────────────────────────────────────────────────────────
// ═══════════════════════════════════════════════════════════════════════════════

const TREASURY_FILE = path.join(__dirname, '..', 'treasury.json');

function _loadTreasury()     { return readJSON(TREASURY_FILE); }
function _saveTreasury(data) { writeJSONAtomic(TREASURY_FILE, data); }

function getTreasury(guildId) {
    const t = _loadTreasury();
    return t[guildId] || { balance: 0, log: [] };
}

function addToTreasury(guildId, amount, source) {
    if (!amount || amount <= 0) return;
    const t = _loadTreasury();
    if (!t[guildId]) t[guildId] = { balance: 0, log: [] };
    t[guildId].balance = (t[guildId].balance || 0) + amount;
    t[guildId].log.unshift({ amount, source, ts: Date.now() });
    if (t[guildId].log.length > 50) t[guildId].log = t[guildId].log.slice(0, 50);
    _saveTreasury(t);
}

function withdrawFromTreasury(guildId, amount) {
    const t = _loadTreasury();
    if (!t[guildId] || (t[guildId].balance || 0) < amount) return false;
    t[guildId].balance -= amount;
    t[guildId].log.unshift({ amount: -amount, source: 'admin_withdraw', ts: Date.now() });
    _saveTreasury(t);
    return true;
}

module.exports = {
    getUser, saveUser, getAllUsers, addWallet,
    getLeaderboard, resetEconomy, cooldownLeft, formatTime,
    getRoleMultiplier, getChannelMultiplier,
    getItem, getAllShopItems,
    getChest, getRandomLoot, getAllChests, restockChest,
    getRecipe, getAllRecipes,
    loadAll, saveAll,

    // XP / Level
    addEconXP, getEconLevelInfo, XP_SOURCES,

    // Stats
    addUserStat,

    // Quests
    getOrGenerateQuests, updateQuestProgress, claimCompletedQuests,

    // Auctions
    getAllAuctions, getAuction, createAuction, bidOnAuction,
    cancelAuction, claimAuction, expireAuctions,

    // Transactions
    addTransaction,
    getUserTransactions,

    // Loans
    getLoan,
    takeLoan,
    repayLoan,
    applyLoanOverduePenalty,

    // Treasury
    getTreasury,
    addToTreasury,
    withdrawFromTreasury,

    // Locking (for atomic operations)
    withUserLock,
    withTwoUserLocks,

    // Blackjack game recovery
    startActiveGame,
    endActiveGame,
    recoverActiveGames,
};
