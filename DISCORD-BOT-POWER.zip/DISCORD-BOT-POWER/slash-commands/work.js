const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, getRoleMultiplier, getChannelMultiplier,
        addEconXP, XP_SOURCES, addUserStat, updateQuestProgress, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        cooldown:   (time) => `⏰ يمكنك العمل مرة أخرى بعد **${time}**.`,
        earned:     (amount, cur) => `💼 عملت وحصلت على **${amount.toLocaleString()} ${cur}**.`,
        levelUp:    (lvl, reward, cur) => `\n\n⭐ **مبروك! ارتقيت للمستوى ${lvl}!**${reward > 0 ? `\n🎁 مكافأة: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:    'رصيدك الحالي',
        xpGained:   (n) => `+${n} XP`,
        footer:     'العمل',
        reminder:   (cur, streak) => `⏰ **تنبيه العمل!**\nانتهى وقت الانتظار، استخدم </work:0> الآن وكسب المزيد من **${cur}**!`
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        cooldown:   (time) => `⏰ You can work again in **${time}**.`,
        earned:     (amount, cur) => `💼 You worked and earned **${amount.toLocaleString()} ${cur}**.`,
        levelUp:    (lvl, reward, cur) => `\n\n⭐ **Level up! You reached Level ${lvl}!**${reward > 0 ? `\n🎁 Reward: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:    'Your Balance',
        xpGained:   (n) => `+${n} XP`,
        footer:     'Work',
        reminder:   (cur) => `⏰ **Work Reminder!**\nYour cooldown is over! Use </work:0> now and earn more **${cur}**!`
    }
};

function formatRemaining(ms, lang) {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    const s = totalSeconds % 60;
    if (lang === 'ar') {
        if (h > 0) return `${h} ساعة و ${m} دقيقة`;
        if (m > 0) return `${m} دقيقة و ${s} ثانية`;
        return `${s} ثانية`;
    }
    if (h > 0) return `${h}h ${m}m`;
    if (m > 0) return `${m}m ${s}s`;
    return `${s}s`;
}

module.exports = {
    data: {
        name: 'work',
        description: 'Work to earn coins | اعمل لكسب العملات',
        default_member_permissions: null
    },

    async execute(interaction, client, settings) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const user       = getUser(interaction.guildId, interaction.user.id);
        const cur        = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        const workCfg    = es.work || {};
        const cooldownMs = (workCfg.cooldown || 8) * 3600000;
        const now        = Date.now();

        if (user.lastWork && now - user.lastWork < cooldownMs) {
            const remaining = cooldownMs - (now - user.lastWork);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.cooldown(formatRemaining(remaining, lang)))
                    .setColor('#FEE75C')],
                flags: MessageFlags.Ephemeral
            });
        }

        const min  = workCfg.min || 50;
        const max  = workCfg.max || 300;
        let earned = Math.floor(Math.random() * (max - min + 1)) + min;

        const globalMult  = parseFloat(es.globalMultiplier || 1);
        const roleMult    = interaction.member
            ? getRoleMultiplier(interaction.member, es.roleBoosters || [], es.stackMultipliers || false)
            : 1;
        const channelMult = getChannelMultiplier(interaction.channelId, es.channelBoosters || []);
        earned = Math.floor(earned * globalMult * roleMult * channelMult);

// ── Work Boost effect ──────────────────────────────────────────────────────
const workBoost = (user.activeEffects || []).find(
    e => e.effect === 'work_boost' && e.expires > now
);
if (workBoost) earned = Math.floor(earned * (parseFloat(workBoost.multiplier) || 1));

        const walletLimit = es.walletLimit || 0;
        if (walletLimit > 0) {
            const space = walletLimit - (user.wallet || 0);
            if (space <= 0) earned = 0;
            else earned = Math.min(earned, space);
        }

        const replies    = Array.isArray(workCfg.replies) && workCfg.replies.length > 0 ? workCfg.replies : null;
        const replyText  = replies ? replies[Math.floor(Math.random() * replies.length)] : t.earned(earned, cur);

        user.wallet      = (user.wallet      || 0) + earned;
        user.totalEarned = (user.totalEarned || 0) + earned;
        user.lastWork    = now;
        saveUser(interaction.guildId, interaction.user.id, user);
        addTransaction(interaction.guildId, interaction.user.id, 'work', earned, '');

        // ── XP & Stats ────────────────────────────────────────────────────────
        const xpAmount  = XP_SOURCES.work;
        const xpResult  = addEconXP(interaction.guildId, interaction.user.id, xpAmount);
        addUserStat(interaction.guildId, interaction.user.id, 'workCount', 1);

        // ── Quest progress ────────────────────────────────────────────────────
        updateQuestProgress(interaction.guildId, interaction.user.id, 'work_times', 1);
        updateQuestProgress(interaction.guildId, interaction.user.id, 'earn_coins', earned);

        // ── Build level-up suffix ──────────────────────────────────────────────
        let levelSuffix = '';
        if (xpResult.leveled) {
            // ── [FIX] Read level reward from config, not wallet diff ──
            const _lvlSettings = loadEconomySettings();
            const _lvlRewards  = _lvlSettings?.levelRewards || [];
            let   _lvlReward   = 0;
            for (let _l = xpResult.oldLevel + 1; _l <= xpResult.newLevel; _l++) {
                const _r = _lvlRewards.find(x => x.level === _l);
                if (_r && _r.reward > 0) _lvlReward += _r.reward;
            }
            levelSuffix = t.levelUp(xpResult.newLevel, _lvlReward, cur);
        }

        const refreshedUser = getUser(interaction.guildId, interaction.user.id);
        const embed = new EmbedBuilder()
            .setTitle('💼')
            .setDescription((replies ? `${replyText}\n\n${t.earned(earned, cur)}` : replyText) + levelSuffix)
            .setColor('#57F287')
            .addFields(
                { name: t.balance,  value: `${refreshedUser.wallet.toLocaleString()} ${cur}` },
                { name: '⭐ XP',    value: t.xpGained(xpAmount), inline: true }
            )
            .setFooter({ text: t.footer })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        // ── Channel Reminder (instead of DM) ─────────────────────────────────
        if (cooldownMs > 0 && es.reminderChannelId) {
            setTimeout(async () => {
                try {
                    const ch = await client.channels.fetch(es.reminderChannelId).catch(() => null);
                    if (ch) {
                        const text = lang === 'ar'
                            ? `⏰ <@${interaction.user.id}> راتبك جاهز! استخدم </work:0> الآن وكسب **${cur}**!`
                            : `⏰ <@${interaction.user.id}> Your work is ready! Use </work:0> now!`;
                        await ch.send(text).catch(() => {});
                    }
                } catch (_) {}
            }, cooldownMs);
        } else if (cooldownMs > 0 && user.notifications?.work !== false) {
            // Fallback: DM if no channel set and user has notifications enabled
            setTimeout(async () => {
                try {
                    const dmUser = await client.users.fetch(interaction.user.id).catch(() => null);
                    if (dmUser) {
                        const text = lang === 'ar'
                            ? `⏰ **تنبيه العمل!**\nانتهى وقت الانتظار، استخدم </work:0> الآن!`
                            : `⏰ **Work Reminder!**\nYour cooldown is over! Use </work:0> now!`;
                        await dmUser.send(text).catch(() => {});
                    }
                } catch (_) {}
            }, cooldownMs);
        }
    }
};
