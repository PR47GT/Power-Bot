const fs = require('fs');
const path = require('path');
const { EmbedBuilder, MessageFlags } = require('discord.js');
const { loadData, saveData } = require('./tempRoles');

const MOD_COMMANDS_FILE = path.join(__dirname, '../modCommands.json');

const T = {
    ar: {
        commandDisabled: '❌ هذا الأمر معطّل حالياً',
        noPermissionRole: '⚠️ ليس لديك الصلاحية المناسبة',
        noPermissionUse: '⚠️ ليس لديك صلاحية لاستخدام هذا الأمر',
        wrongChannel: '⚠️ هذا الأمر لا يعمل في هذا الروم',
        deniedChannel: '⚠️ لا يمكن استخدام هذا الأمر في هذا الروم',
        noWarnings: '⚠️ هذا العضو ليس لديه أي تحذيرات',
        warnRemoved: (userId, count) => `✅ تم إزالة تحذير من <@${userId}> عدد التحذيرات المتبقية: ${count}`,
        error: (msg) => `❌ خطأ: ${msg}`,
    },
    en: {
        commandDisabled: '❌ This command is currently disabled',
        noPermissionRole: '⚠️ You do not have the required role permission',
        noPermissionUse: '⚠️ You do not have permission to use this command',
        wrongChannel: '⚠️ This command does not work in this channel',
        deniedChannel: '⚠️ This command cannot be used in this channel',
        noWarnings: '⚠️ This member has no warnings',
        warnRemoved: (userId, count) => `✅ Removed one warning from <@${userId}>. Remaining warnings: ${count}`,
        error: (msg) => `❌ Error: ${msg}`,
    }
};

function getModCommands() {
    try {
        if (fs.existsSync(MOD_COMMANDS_FILE)) {
            return JSON.parse(fs.readFileSync(MOD_COMMANDS_FILE, 'utf8'));
        }
    } catch(e) {}
    return {};
}

function getWarns() {
    return loadData().warns || {};
}

function saveWarns(warns) {
    const data = loadData();
    data.warns = warns;
    saveData(data);
}

module.exports = {
    name: 'unwarn',
    description: 'إزالة تحذير من عضو | Remove a warning from a member',
    description_localizations: {
        enUS: 'Remove a warning from a member',
        ar: 'إزالة تحذير من عضو',
    },

    async execute(interaction, client, settings) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        const modCommands = getModCommands();
        const cmdSettings = modCommands.unwarn || { enabled: true };
        
        if (!cmdSettings.enabled) {
            return await interaction.reply({
                content: t.commandDisabled,
                flags: MessageFlags.Ephemeral
            });
        }

        const member = interaction.member;
        
        if (cmdSettings.allowedRoles && cmdSettings.allowedRoles.length > 0) {
            const hasRole = member.roles.cache.some(r => cmdSettings.allowedRoles.includes(r.id));
            if (!hasRole) {
                return await interaction.reply({
                    content: t.noPermissionRole,
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        if (cmdSettings.deniedRoles && cmdSettings.deniedRoles.length > 0) {
            const hasDeniedRole = member.roles.cache.some(r => cmdSettings.deniedRoles.includes(r.id));
            if (hasDeniedRole) {
                return await interaction.reply({
                    content: t.noPermissionUse,
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        if (cmdSettings.allowedChannels && cmdSettings.allowedChannels.length > 0) {
            if (!cmdSettings.allowedChannels.includes(interaction.channelId)) {
                return await interaction.reply({
                    content: t.wrongChannel,
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        if (cmdSettings.deniedChannels && cmdSettings.deniedChannels.length > 0) {
            if (cmdSettings.deniedChannels.includes(interaction.channelId)) {
                return await interaction.reply({
                    content: t.deniedChannel,
                    flags: MessageFlags.Ephemeral
                });
            }
        }

        const user = interaction.options.getUser('user');

        try {
            const warns = getWarns();
            const guildId = interaction.guildId;
            
            if (!warns[guildId] || !warns[guildId][user.id] || warns[guildId][user.id].length === 0) {
                return await interaction.reply({
                    content: t.noWarnings,
                    flags: MessageFlags.Ephemeral
                });
            }

           warns[guildId][user.id].pop();
            saveWarns(warns);

            const warnCount = warns[guildId][user.id].length;

            // ===== سحب الرتب التي لم تعد تنطبق بعد إزالة التحذير =====
            try {
                const warnActions = settings?.warnActions;
                if (warnActions && warnActions.enabled && Array.isArray(warnActions.thresholds)) {
                    const targetMember = await interaction.guild.members.fetch(user.id).catch(() => null);
                    if (targetMember) {
                        for (const th of warnActions.thresholds) {
                            if (th.action === 'role' && th.roleId && warnCount < th.count) {
                                const role = interaction.guild.roles.cache.get(th.roleId);
                                if (role && targetMember.roles.cache.has(th.roleId)) {
                                    await targetMember.roles.remove(
                                        role,
                                        lang === 'ar' ? 'إزالة تحذير أدت لسحب الرتبة التلقائية' : 'Warning removed — auto role no longer applies'
                                    ).catch(() => {});
                                }
                            }
                        }
                    }
                }
            } catch(e) {
                console.error('❌ خطأ في سحب الرتبة بعد إزالة التحذير:', e.message);
            }

            const embed = new EmbedBuilder()
                .setColor('#51ff00')
                .setDescription(t.warnRemoved(user.id, warnCount));

            await interaction.reply({
                embeds: [embed]
            });
        } catch (error) {
            const errorEmbed = new EmbedBuilder()
                .setColor('#fe0000')
                .setDescription(t.error(error.message));

            await interaction.reply({
                embeds: [errorEmbed],
                flags: MessageFlags.Ephemeral
            });
        }
    }
};