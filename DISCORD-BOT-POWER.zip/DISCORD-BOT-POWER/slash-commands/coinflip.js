const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, cooldownLeft, formatTime, addTransaction, withUserLock } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        cfDisabled: '⚠️ رمية العملة معطلة حالياً.',
        cooldown:   (t) => `⏰ يمكنك اللعب مرة أخرى بعد **${t}**.`,
        noMoney:    (needed, cur) => `❌ تحتاج **${needed.toLocaleString()} ${cur}** للمراهنة. رصيدك غير كافٍ.`,
        minBet:     (min, cur)   => `❌ الحد الأدنى للمراهنة هو **${min.toLocaleString()} ${cur}**.`,
        maxBet:     (max, cur)   => `❌ الحد الأقصى للمراهنة هو **${max.toLocaleString()} ${cur}**.`,
        win:        (amount, cur, side) => `🎉 ربحت! الصورة كانت **${side}** — حصلت على **${amount.toLocaleString()} ${cur}**.`,
        lose:       (amount, cur, side) => `😢 خسرت! الصورة كانت **${side}** — خسرت **${amount.toLocaleString()} ${cur}**.`,
        heads:      'صورة',
        tails:      'كتابة',
        balance:    'رصيدك الحالي',
        footer:     'رمية العملة'
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        cfDisabled: '⚠️ Coinflip is currently disabled.',
        cooldown:   (t) => `⏰ You can play again in **${t}**.`,
        noMoney:    (needed, cur) => `❌ You need **${needed.toLocaleString()} ${cur}** to bet. Insufficient balance.`,
        minBet:     (min, cur)   => `❌ Minimum bet is **${min.toLocaleString()} ${cur}**.`,
        maxBet:     (max, cur)   => `❌ Maximum bet is **${max.toLocaleString()} ${cur}**.`,
        win:        (amount, cur, side) => `🎉 You won! It was **${side}** — received **${amount.toLocaleString()} ${cur}**.`,
        lose:       (amount, cur, side) => `😢 You lost! It was **${side}** — lost **${amount.toLocaleString()} ${cur}**.`,
        heads:      'Heads',
        tails:      'Tails',
        balance:    'Your Balance',
        footer:     'Coinflip'
    }
};

module.exports = {
    data: {
        name: 'coinflip',
        description: 'Bet coins on a coin flip | راهن على رمية عملة',
        default_member_permissions: null,
        options: [
            {
                name: 'choice',
                description: 'Heads or Tails | صورة أو كتابة',
                type: 3,
                required: true,
                choices: [
                    { name: 'Heads / صورة',  value: 'heads' },
                    { name: 'Tails / كتابة', value: 'tails' }
                ]
            },
            {
                name: 'amount',
                description: 'Amount to bet | مبلغ الرهان',
                type: 4,
                required: true,
                min_value: 1
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const cfCfg = es.gambling?.coinflip || {};
            if (!cfCfg.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.cfDisabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const choice = interaction.options.getString('choice');
            const amount = interaction.options.getInteger('amount');
            const user   = getUser(interaction.guildId, interaction.user.id);
            const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            // ── Cooldown ──────────────────────────────────────────────────────
            const cfCdMs = (cfCfg.cooldown || 0) * 60000;
            if (cfCdMs > 0) {
                const cfLeft = cooldownLeft(user.lastCoinflip || 0, cfCdMs);
                if (cfLeft > 0) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.cooldown(formatTime(cfLeft))).setColor('#FEE75C')],
                        flags: MessageFlags.Ephemeral
                    });
                }
            }

            // ── Bet validation ────────────────────────────────────────────────
            if (cfCfg.minBet > 0 && amount < cfCfg.minBet) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.minBet(cfCfg.minBet, cur)).setColor('#FEE75C')],
                    flags: MessageFlags.Ephemeral
                });
            }
            if (cfCfg.maxBet > 0 && amount > cfCfg.maxBet) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.maxBet(cfCfg.maxBet, cur)).setColor('#FEE75C')],
                    flags: MessageFlags.Ephemeral
                });
            }
            if ((user.wallet || 0) < amount) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const result = Math.random() < 0.5 ? 'heads' : 'tails';
            const win    = result === choice;
            const side   = result === 'heads' ? t.heads : t.tails;

            // [FIX-CF-01] تغليف العملية بقفل لمنع race condition مع /pay أو /bank
            let finalWallet = 0;
            await withUserLock(interaction.guildId, interaction.user.id, async () => {
                const freshUser = getUser(interaction.guildId, interaction.user.id);
                // تحقق مجدداً من الرصيد داخل القفل
                if ((freshUser.wallet || 0) < amount) {
                    finalWallet = freshUser.wallet || 0;
                    return;
                }
                freshUser.wallet = Math.max(0, (freshUser.wallet || 0) + (win ? amount : -amount));
                // [FIX-CF-02] توحيد totalEarned: يُحسب الربح الصافي فقط (كما في slots.js)
                if (win) freshUser.totalEarned = (freshUser.totalEarned || 0) + amount;
                if (cfCdMs > 0) freshUser.lastCoinflip = Date.now();
                saveUser(interaction.guildId, interaction.user.id, freshUser);
                addTransaction(
                    interaction.guildId, interaction.user.id,
                    win ? 'coinflip_win' : 'coinflip_loss',
                    win ? amount : -amount,
                    `Coinflip: ${choice} vs ${result}`
                );
                finalWallet = freshUser.wallet;
            });

            const embed = new EmbedBuilder()
                .setTitle(result === 'heads' ? '🪙' : '💸')
                .setDescription(win ? t.win(amount, cur, side) : t.lose(amount, cur, side))
                .setColor(win ? '#57F287' : '#ED4245')
                .addFields({ name: t.balance, value: `${finalWallet.toLocaleString()} ${cur}` })
                .setFooter({ text: t.footer })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (err) {
            console.error('[coinflip] unexpected error:', err);
            const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
