const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, getItem } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:       '⚠️ نظام الاقتصاد معطل حالياً.',
        noItem:         '❌ العنصر غير موجود.',
        noItemOwn:      '❌ لا تملك هذا العنصر في مخزونك.',
        sellSuccess:    (item, price, cur) =>
            `💰 بعت **${item}** وحصلت على **${price.toLocaleString()} ${cur}**.`,
        useEffect:      (item, effect, min) =>
            `✨ استخدمت **${item}**!\n⚡ تأثير **${effect}** مفعّل لمدة **${min}** دقيقة.`,
        useConsumed:    (item) => `✨ استخدمت **${item}**!`,
        notGiveable:    '❌ عناصر الرتب لا يمكن إهداؤها — الرتبة مرتبطة بالمشتري مباشرةً.',
        giveSuccess:    (item, user) =>
            `✅ أهديت **${item}** إلى **${user}**.\n📦 تمت إضافته لمخزونه.`,
        inventoryTitle: '🎒 المخزون',
        inventoryEmpty: 'مخزونك فارغ.',
        activeTitle:    '⏳ التأثيرات الفعالة',
        noActive:       'لا توجد تأثيرات فعالة حالياً.',
        minutes:        'دقيقة',
        balance:        'رصيدك الحالي',
        footer:         'العناصر'
    },
    en: {
        disabled:       '⚠️ Economy system is currently disabled.',
        noItem:         '❌ Item not found.',
        noItemOwn:      "❌ You don't own this item.",
        sellSuccess:    (item, price, cur) =>
            `💰 Sold **${item}** and received **${price.toLocaleString()} ${cur}**.`,
        useEffect:      (item, effect, min) =>
            `✨ You used **${item}**!\n⚡ **${effect}** effect activated for **${min}** minutes.`,
        useConsumed:    (item) => `✨ You used **${item}**!`,
        notGiveable:    '❌ Role items cannot be given — the role is bound to the original buyer.',
        giveSuccess:    (item, user) =>
            `✅ You gave **${item}** to **${user}**.\n📦 Added to their inventory.`,
        inventoryTitle: '🎒 Inventory',
        inventoryEmpty: 'Your inventory is empty.',
        activeTitle:    '⏳ Active Effects',
        noActive:       'No active effects.',
        minutes:        'min',
        balance:        'Your Balance',
        footer:         'Items'
    }
};

module.exports = {
    data: {
        name: 'item',
        description: 'Manage your items | إدارة عناصرك',
        default_member_permissions: null,
        options: [
            {
                name: 'sell',
                description: 'Sell a consumable item | بع عنصراً من مخزونك',
                type: 1,
                options: [{ name: 'name', description: 'Item name | اسم العنصر', type: 3, required: true }]
            },
            {
                name: 'use',
                description: 'Use a consumable item | استخدم عنصراً',
                type: 1,
                options: [{ name: 'name', description: 'Item name | اسم العنصر', type: 3, required: true }]
            },
            {
                name: 'give',
                description: 'Give an item to a member | أهدِ عنصراً لعضو',
                type: 1,
                options: [
                    { name: 'name', description: 'Item name | اسم العنصر', type: 3, required: true },
                    { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                ]
            },
            {
                name: 'inventory',
                description: 'View your inventory | شوف مخزونك',
                type: 1,
                options: []
            },
            {
                name: 'duration',
                description: 'View active item effects | شوف التأثيرات الفعالة',
                type: 1,
                options: []
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const sub  = interaction.options.getSubcommand();
            const cur  = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
            const user = getUser(interaction.guildId, interaction.user.id);
            if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};

            // ── SELL ─────────────────────────────────────────────────────────
            if (sub === 'sell') {
                const name = interaction.options.getString('name');

                // Case-insensitive inventory lookup
                let invKey = name;
                if (!(user.inventory[name] > 0)) {
                    const found = Object.keys(user.inventory).find(
                        k => k.toLowerCase() === name.toLowerCase() && user.inventory[k] > 0
                    );
                    if (!found) {
                        return interaction.reply({
                            embeds: [new EmbedBuilder().setDescription(t.noItemOwn).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        });
                    }
                    invKey = found;
                }

                const shopItem  = getItem(invKey);
                const sellPrice = Math.floor(((shopItem?.price) || 0) * 0.6);
                user.wallet = (user.wallet || 0) + sellPrice;
                user.inventory[invKey]--;
                if (user.inventory[invKey] <= 0) delete user.inventory[invKey];
                saveUser(interaction.guildId, interaction.user.id, user);

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.sellSuccess(shopItem?.name || invKey, sellPrice, cur))
                        .addFields({ name: t.balance, value: `**${user.wallet.toLocaleString()} ${cur}**` })
                        .setColor('#FEE75C')
                        .setFooter({ text: t.footer })]
                });
            }

            // ── USE ──────────────────────────────────────────────────────────
            if (sub === 'use') {
                const name     = interaction.options.getString('name');
                const shopItem = getItem(name);

                // Case-insensitive inventory lookup
                let invKey = name;
                if (!(user.inventory[name] > 0)) {
                    const found = Object.keys(user.inventory).find(
                        k => k.toLowerCase() === name.toLowerCase() && user.inventory[k] > 0
                    );
                    if (!found) {
                        return interaction.reply({
                            embeds: [new EmbedBuilder().setDescription(t.noItemOwn).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        });
                    }
                    invKey = found;
                }

                const resolvedItem = getItem(invKey);
                user.inventory[invKey]--;
                if (user.inventory[invKey] <= 0) delete user.inventory[invKey];

                if (resolvedItem?.effect) {
                    user.activeEffects = (user.activeEffects || []).filter(e => e.expires > Date.now());
                    const durationMs = resolvedItem.duration || 3600000;
                    user.activeEffects.push({
                        id:         invKey,
                        effect:     resolvedItem.effect,
                        multiplier: resolvedItem.multiplier || 1,
                        expires:    Date.now() + durationMs
                    });
                    const minutes = Math.ceil(durationMs / 60000);
                    saveUser(interaction.guildId, interaction.user.id, user);
                    return interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.useEffect(resolvedItem.name || invKey, resolvedItem.effect, minutes))
                            .setColor('#5865F2')
                            .setFooter({ text: t.footer })]
                    });
                }

                saveUser(interaction.guildId, interaction.user.id, user);
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.useConsumed(resolvedItem?.name || invKey))
                        .setColor('#5865F2')
                        .setFooter({ text: t.footer })]
                });
            }

            // ── GIVE ─────────────────────────────────────────────────────────
            if (sub === 'give') {
                const name   = interaction.options.getString('name');
                const target = interaction.options.getUser('user');

                // Case-insensitive inventory lookup
                let invKey = name;
                if (!(user.inventory[name] > 0)) {
                    const found = Object.keys(user.inventory).find(
                        k => k.toLowerCase() === name.toLowerCase() && user.inventory[k] > 0
                    );
                    if (!found) {
                        return interaction.reply({
                            embeds: [new EmbedBuilder().setDescription(t.noItemOwn).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        });
                    }
                    invKey = found;
                }

                const shopItem = getItem(invKey);
                if (shopItem?.roleId) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.notGiveable).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                user.inventory[invKey]--;
                if (user.inventory[invKey] <= 0) delete user.inventory[invKey];
                saveUser(interaction.guildId, interaction.user.id, user);

                const targetData = getUser(interaction.guildId, target.id);
                if (!targetData.inventory || Array.isArray(targetData.inventory)) targetData.inventory = {};
                targetData.inventory[invKey] = (targetData.inventory[invKey] || 0) + 1;
                saveUser(interaction.guildId, target.id, targetData);

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.giveSuccess(shopItem?.name || invKey, target.username))
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })]
                });
            }

            // ── INVENTORY ────────────────────────────────────────────────────
            if (sub === 'inventory') {
                const entries = Object.entries(user.inventory).filter(([, qty]) => qty > 0);
                const list = entries.length > 0
                    ? entries.map(([id, qty]) => {
                        const it = getItem(id);
                        return `${it?.emoji ? it.emoji + ' ' : '📦 '}**${it?.name || id}** × ${qty}`;
                    }).join('\n')
                    : t.inventoryEmpty;

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setAuthor({
                            name:    interaction.user.username,
                            iconURL: interaction.user.displayAvatarURL({ size: 64 }),
                        })
                        .setTitle(t.inventoryTitle)
                        .setDescription(list)
                        .setColor('#5865F2')
                        .setFooter({ text: t.footer })
                        .setTimestamp()]
                });
            }

            // ── DURATION ─────────────────────────────────────────────────────
            if (sub === 'duration') {
                const now    = Date.now();
                const active = (user.activeEffects || []).filter(e => e.expires > now);

                const list = active.length > 0
                    ? active.map(e => {
                        const it  = getItem(e.id);
                        const min = Math.ceil((e.expires - now) / 60000);
                        return `${it?.emoji ? it.emoji + ' ' : '⚡ '}**${it?.name || e.id}** — ${min} ${t.minutes}${e.effect ? ` _(${e.effect})_` : ''}`;
                    }).join('\n')
                    : t.noActive;

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setAuthor({
                            name:    interaction.user.username,
                            iconURL: interaction.user.displayAvatarURL({ size: 64 }),
                        })
                        .setTitle(t.activeTitle)
                        .setDescription(list)
                        .setColor('#FEE75C')
                        .setFooter({ text: t.footer })
                        .setTimestamp()]
                });
            }

        } catch (err) {
            console.error('[item] unexpected error:', err);
            const errEmbed   = new EmbedBuilder()
                .setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.')
                .setColor('#ED4245');
            const errPayload = { embeds: [errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(errPayload).catch(() => {});
            } else {
                await interaction.reply(errPayload).catch(() => {});
            }
        }
    }
};
