const {
    EmbedBuilder, PermissionFlagsBits, MessageFlags,
    StringSelectMenuBuilder, StringSelectMenuOptionBuilder,
    ActionRowBuilder
} = require('discord.js');
const fs   = require('fs');
const path = require('path');

const RULES_FILE = path.join(__dirname, '..', 'rulesSystem.json');

function loadRulesSettings() {
    if (fs.existsSync(RULES_FILE)) {
        try { return JSON.parse(fs.readFileSync(RULES_FILE, 'utf8')); } catch(e) {}
    }
    return { rulesChannelId: '', useEmbed: true, embedDescription: '', embedColor: '#5865F2', rules: [] };
}

function parseEmojiStr(emojiStr) {
    if (!emojiStr) return null;
    const m = emojiStr.match(/<(a?):(\w+):(\d+)>/);
    if (m) return { id: m[3], name: m[2], animated: m[1] === 'a' };
    return null;
}

function buildEmojiOption(emojiStr) {
    if (!emojiStr || !emojiStr.trim()) return null;
    const custom = parseEmojiStr(emojiStr);
    if (custom) return { id: custom.id, name: custom.name };
    return emojiStr.trim();
}

function buildSelectMenu(rules, isEn) {
    const options = rules.slice(0, 25).map((rule, i) => {
        const label = ((rule.title || '').trim() || `${isEn ? 'Rule' : 'القاعدة'} ${i + 1}`).substring(0, 100);
        const opt = new StringSelectMenuOptionBuilder()
            .setLabel(label)
            .setValue(String(i));

        const emojiObj = buildEmojiOption(rule.emoji || '');
        if (emojiObj) opt.setEmoji(emojiObj);
        else opt.setEmoji('📜');

        return opt;
    });

    return new StringSelectMenuBuilder()
        .setCustomId('view_rule_select')
        .setPlaceholder(isEn ? 'Select a rule to view…' : 'اختر قاعدة للعرض…')
        .addOptions(options);
}

module.exports = {
    async execute(interaction, client, settings) {
        const isAdmin = interaction.member.permissions.has(PermissionFlagsBits.ManageGuild)
                     || interaction.member.permissions.has(PermissionFlagsBits.Administrator);
        if (!isAdmin) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(settings.botLanguage === 'en'
                        ? '❌ You do not have permission to use this command.'
                        : '❌ ليس لديك صلاحية لاستخدام هذا الأمر.')
                    .setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const rs    = loadRulesSettings();
        const rules = rs.rules || [];
        const isEn  = settings.botLanguage === 'en';

        if (rules.length === 0) {
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(isEn
                        ? '❌ No rules configured. Please set them up in the dashboard.'
                        : '❌ لا توجد قواعد مُعدّة. يرجى إعدادها من الداشبورد.')
                    .setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const headerEmbed = new EmbedBuilder()
            .setTitle(isEn ? '📋 Server Rules' : '📋 قواعد السيرفر')
            .setDescription(rs.embedDescription
                ? rs.embedDescription
                : (isEn
                    ? 'Choose a rule from the menu below to read its details.'
                    : 'اختر قاعدة من القائمة أدناه لقراءة تفاصيلها.'))
            .setColor(rs.embedColor || '#5865F2');

        const row = new ActionRowBuilder().addComponents(buildSelectMenu(rules, isEn));

        await interaction.reply({ embeds: [headerEmbed], components: [row] });
    }
};