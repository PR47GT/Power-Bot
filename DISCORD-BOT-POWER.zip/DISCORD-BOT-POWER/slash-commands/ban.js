const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'حظر عضو من السيرفر',
        option_user: 'العضو',
        option_reason: 'السبب',
        noReason: '\`لا يوجد سبب\`',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        notBannable: '❌ لا يمكنني حظر هذا العضو. تأكد أن رتبتي أعلى.',
        botNoPerm: '❌ البوت لا يملك صلاحية حظر الأعضاء',
        bannedBy: (mod) => `بواسطة: ${mod}`,
        success: (user, reason) => `🚫 تم حظر \`${user.tag}\`\nالسبب: ${reason}`,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Ban a member from the server',
        option_user: 'User',
        option_reason: 'Reason',
        noReason: '\`No reason provided\`',
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '❌ Member not found in the server.',
        notBannable: '❌ Cannot ban this member. Ensure my role is higher.',
        botNoPerm: '❌ Bot does not have permission to ban members',
        bannedBy: (mod) => `By: ${mod}`,
        success: (user, reason) => `🚫 \`${user.tag}\` has been banned\nReason: ${reason}`,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'ban',
        description: 'Ban a member | حظر عضو',
        default_member_permissions: PermissionFlagsBits.BanMembers.toString(),
        options: [
            { name: 'user', description: 'User', type: 6, required: true },
            { name: 'reason', description: 'Reason', type: 3, required: false }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.ban || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const reason = interaction.options.getString('reason') || t.noReason;
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!targetMember.bannable) {
                return await interaction.editReply({ content: t.notBannable });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.BanMembers)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            const fullReason = `${reason} (${t.bannedBy(interaction.user.tag)})`;
            
            await targetMember.ban({ reason: fullReason });
            
            const successMessage = t.success(targetUser, reason);
            
            if (config.deleteResponse) {
                await interaction.editReply({ content: successMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: successMessage });
            }
            
        } catch (error) {
            console.error('❌ Ban command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};