'use strict';
const fs   = require('fs');
const path = require('path');

const DATA_FILE = path.join(__dirname, '../botData.json');

function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const raw = fs.readFileSync(DATA_FILE, 'utf8').trim();
            if (raw) {
                const parsed = JSON.parse(raw);
                if (!parsed.warns)     parsed.warns     = {};
                if (!parsed.tempRoles) parsed.tempRoles = {};
                return parsed;
            }
        }
    } catch (e) {
        console.error('❌ خطأ بقراءة botData.json:', e.message);
    }
    return { warns: {}, tempRoles: {} };
}

function saveData(data) {
    try {
        fs.writeFileSync(DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
    } catch (e) {
        console.error('❌ خطأ بحفظ botData.json:', e.message);
    }
}

function addTempRole(guildId, userId, roleId, expiresAt) {
    const data = loadData();
    if (!data.tempRoles[guildId])         data.tempRoles[guildId]         = {};
    if (!data.tempRoles[guildId][userId]) data.tempRoles[guildId][userId] = [];
    data.tempRoles[guildId][userId].push({
        roleId,
        expiresAt: new Date(expiresAt).getTime(),
        givenAt:   Date.now()
    });
    saveData(data);
}

async function processExpiredTempRoles(client) {
    const data = loadData();
    let changed = false;
    const now   = Date.now();

    for (const guildId of Object.keys(data.tempRoles)) {
        if (Array.isArray(data.tempRoles[guildId])) {
            delete data.tempRoles[guildId];
            changed = true;
            continue;
        }
        const guild = client.guilds.cache.get(guildId);
        if (!guild) continue;

        for (const userId of Object.keys(data.tempRoles[guildId])) {
            const userRoles = data.tempRoles[guildId][userId];
            if (!Array.isArray(userRoles)) {
                delete data.tempRoles[guildId][userId];
                changed = true;
                continue;
            }
            const remaining = [];
            for (const entry of userRoles) {
                const exp = typeof entry.expiresAt === 'string'
                    ? new Date(entry.expiresAt).getTime()
                    : entry.expiresAt;
                if (isNaN(exp) || exp > now) { remaining.push(entry); continue; }
                changed = true;
                try {
                    const member = await guild.members.fetch(userId).catch(() => null);
                    if (member && member.roles.cache.has(entry.roleId))
                        await member.roles.remove(entry.roleId, 'انتهاء مدة الرتبة المؤقتة').catch(() => {});
                } catch (e) {}
            }
            if (remaining.length === 0) delete data.tempRoles[guildId][userId];
            else data.tempRoles[guildId][userId] = remaining;
        }
        if (Object.keys(data.tempRoles[guildId]).length === 0) delete data.tempRoles[guildId];
    }
    if (changed) saveData(data);
}

module.exports = { addTempRole, processExpiredTempRoles, loadData, saveData };