const {
    EmbedBuilder, MessageFlags,
    ActionRowBuilder, ButtonBuilder, ButtonStyle,
    StringSelectMenuBuilder, ModalBuilder, TextInputBuilder, TextInputStyle
} = require('discord.js');
const { getUser, saveUser, getAllAuctions, getAuction, createAuction, bidOnAuction, cancelAuction, claimAuction, expireAuctions, withTwoUserLocks, withUserLock } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:      '⚠️ نظام الاقتصاد معطل حالياً.',
        auctionOff:    '⚠️ نظام المزاد معطل حالياً.',
        title:         '🏛️ دار المزاد',
        noAuctions:    'لا توجد مزادات نشطة حالياً.',
        created:       (item, price, ends) => `✅ أنشأت مزاداً لـ **${item}**\nالسعر الابتدائي: **${price.toLocaleString()}**\nينتهي: **${ends}**`,
        bidPlaced:     (item, amount, cur) => `✅ قدّمت عرضاً بـ **${amount.toLocaleString()} ${cur}** على **${item}**`,
        claimed:       (item) => `✅ حصلت على **${item}** من المزاد!`,
        sellerClaimed:  (amount, cur) => `✅ استلمت عائد المزاد: **${amount.toLocaleString()} ${cur}**`,
        noBidReturn:    (item) => `✅ انتهى المزاد بدون عروض، وتمت إعادة **${item}** إلى مخزونك.`,
        cancelDone:    (item) => `✅ تم إلغاء مزاد **${item}** وإعادة العنصر إليك.`,
        chooseAuction:  'اختر مزاداً',
        selected:       (id) => `تم اختيار المزاد **${id}**.`,
        needSelect:     'اختر مزاداً من القائمة أولاً.',
        bidButton:      'مزايدة',
        claimButton:    'استلام',
        cancelButton:   'إلغاء',
        refreshButton:  'تحديث',
        modalTitle:     'تقديم عرض مزاد',
        amountLabel:    'مبلغ العرض',
        invalidAmount:  '❌ أدخل مبلغاً صحيحاً.',
        ended:          '❌ هذا المزاد انتهى ولا يقبل مزايدات جديدة.',
        panelExpired:   'انتهت صلاحية لوحة المزاد. استخدم /auction list لعرض لوحة جديدة.',
        unexpected:     '❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.',
        noItem:        '❌ لا يوجد هذا العنصر في مخزونك.',
        noAuction:     '❌ المزاد غير موجود.',
        notYours:      '❌ هذا المزاد ليس لك.',
        bidTooLow:     (cur) => `❌ يجب أن يكون عرضك أعلى من العرض الحالي.`,
        bidOwn:        '❌ لا يمكنك المزايدة على مزادك الخاص.',
        noMoney:       (price, cur) => `❌ رصيدك غير كافٍ. تحتاج **${price.toLocaleString()} ${cur}**.`,
        notWinner:     '❌ لم تفز بهذا المزاد.',
        notEnded:      '❌ المزاد لم ينته بعد.',
        alreadyClaimed:'❌ تم الاستلام مسبقاً.',
        balance:       'رصيدك الحالي',
        footer:        'المزاد',
        noInventory:   '❌ مخزونك فارغ.',
        endsIn:        (t) => `ينتهي بعد ${t}`,
        bidder:        'أعلى مزايد',
        noBids:        'لا توجد عروض',
        startPrice:    'السعر الابتدائي',
        currentBid:    'العرض الحالي',
        seller:        'البائع',
        quantity:      'الكمية'
    },
    en: {
        disabled:      '⚠️ Economy system is currently disabled.',
        auctionOff:    '⚠️ Auction system is currently disabled.',
        title:         '🏛️ Auction House',
        noAuctions:    'No active auctions right now.',
        created:       (item, price, ends) => `✅ Auction created for **${item}**\nStarting price: **${price.toLocaleString()}**\nEnds: **${ends}**`,
        bidPlaced:     (item, amount, cur) => `✅ You placed a bid of **${amount.toLocaleString()} ${cur}** on **${item}**`,
        claimed:       (item) => `✅ You claimed **${item}** from the auction!`,
        sellerClaimed:  (amount, cur) => `✅ Auction proceeds received: **${amount.toLocaleString()} ${cur}**`,
        noBidReturn:    (item) => `✅ The auction ended with no bids, so **${item}** was returned to your inventory.`,
        cancelDone:    (item) => `✅ Auction for **${item}** cancelled. Item returned to you.`,
        chooseAuction:  'Choose an auction',
        selected:       (id) => `Selected auction **${id}**.`,
        needSelect:     'Choose an auction from the menu first.',
        bidButton:      'Bid',
        claimButton:    'Claim',
        cancelButton:   'Cancel',
        refreshButton:  'Refresh',
        modalTitle:     'Place Auction Bid',
        amountLabel:    'Bid amount',
        invalidAmount:  '❌ Enter a valid amount.',
        ended:          '❌ This auction has ended and no longer accepts bids.',
        panelExpired:   'This auction panel expired. Use /auction list to open a fresh one.',
        unexpected:     '❌ An unexpected error occurred. Please try again later.',
        noItem:        '❌ You don\'t have that item in your inventory.',
        noAuction:     '❌ Auction not found.',
        notYours:      '❌ This auction doesn\'t belong to you.',
        bidTooLow:     () => `❌ Your bid must be higher than the current bid.`,
        bidOwn:        '❌ You cannot bid on your own auction.',
        noMoney:       (price, cur) => `❌ Insufficient balance. You need **${price.toLocaleString()} ${cur}**.`,
        notWinner:     '❌ You didn\'t win this auction.',
        notEnded:      '❌ The auction hasn\'t ended yet.',
        alreadyClaimed:'❌ Already claimed.',
        balance:       'Your Balance',
        footer:        'Auction House',
        noInventory:   '❌ Your inventory is empty.',
        endsIn:        (t) => `Ends in ${t}`,
        bidder:        'Top Bidder',
        noBids:        'No bids yet',
        startPrice:    'Starting Price',
        currentBid:    'Current Bid',
        seller:        'Seller',
        quantity:      'Qty'
    }
};

function formatTimeLeft(ms) {
    const s = Math.floor(ms / 1000);
    const m = Math.floor(s / 60);
    const h = Math.floor(m / 60);
    const d = Math.floor(h / 24);
    if (d > 0) return `${d}d ${h % 24}h`;
    if (h > 0) return `${h}h ${m % 60}m`;
    if (m > 0) return `${m}m`;
    return `${s}s`;
}

function publicAuctionEmbed(auctions, t, cur) {
    const embed = new EmbedBuilder()
        .setTitle(t.title)
        .setColor('#5865F2')
        .setFooter({ text: t.footer })
        .setTimestamp();

    if (!auctions.length) return embed.setDescription(t.noAuctions);

    embed.setDescription(auctions.slice(0, 10).map(a => {
        const timeLeft = Math.max(0, a.endsAt - Date.now());
        const bid = a.currentBid > 0
            ? `${a.currentBid.toLocaleString()} ${cur}`
            : `${a.startPrice.toLocaleString()} ${cur} (${t.startPrice})`;
        const topBidder = a.currentBidderId ? `<@${a.currentBidderId}>` : t.noBids;
        return `**[${a.id}]** \`${a.itemId}\` x${a.qty}\n└ ${bid} · ${topBidder} · <@${a.sellerId}> · ${formatTimeLeft(timeLeft)}`;
    }).join('\n\n'));
    return embed;
}

function auctionComponents(auctions, t, panelId, disabled = false) {
    if (!auctions.length) return [];
    const select = new StringSelectMenuBuilder()
        .setCustomId(`${panelId}:select`)
        .setPlaceholder(t.chooseAuction)
        .setDisabled(disabled)
        .addOptions(auctions.slice(0, 25).map(a => ({
            label: `${a.itemId} x${a.qty}`.slice(0, 100),
            description: `${a.id} · ${a.currentBid || a.startPrice}`.slice(0, 100),
            value: a.id
        })));

    const buttons = new ActionRowBuilder().addComponents(
        new ButtonBuilder().setCustomId(`${panelId}:bid`).setLabel(t.bidButton).setStyle(ButtonStyle.Primary).setDisabled(disabled),
        new ButtonBuilder().setCustomId(`${panelId}:claim`).setLabel(t.claimButton).setStyle(ButtonStyle.Success).setDisabled(disabled),
        new ButtonBuilder().setCustomId(`${panelId}:cancel`).setLabel(t.cancelButton).setStyle(ButtonStyle.Danger).setDisabled(disabled),
        new ButtonBuilder().setCustomId(`${panelId}:refresh`).setLabel(t.refreshButton).setStyle(ButtonStyle.Secondary).setDisabled(disabled)
    );

    return [new ActionRowBuilder().addComponents(select), buttons];
}

function buildBidModal(panelId, auctionId, t) {
    return new ModalBuilder()
        .setCustomId(`${panelId}:modal:${auctionId}`)
        .setTitle(t.modalTitle)
        .addComponents(new ActionRowBuilder().addComponents(
            new TextInputBuilder()
                .setCustomId('amount')
                .setLabel(t.amountLabel)
                .setStyle(TextInputStyle.Short)
                .setRequired(true)
                .setMinLength(1)
                .setMaxLength(12)
        ));
}

function statusEmbed(description, t, color = '#5865F2') {
    return new EmbedBuilder()
        .setDescription(description)
        .setColor(color)
        .setFooter({ text: t.footer })
        .setTimestamp();
}

function statusColor(message) {
    const text = String(message || '');
    if (text.includes('✅')) return '#57F287';
    if (text.includes('⚠️') || text.includes('⏰')) return '#FEE75C';
    if (text.includes('❌')) return '#ED4245';
    return '#5865F2';
}

function statusReply(message, t, flags = MessageFlags.Ephemeral) {
    return { embeds: [statusEmbed(message, t, statusColor(message))], flags };
}

module.exports = {
    data: {
        name: 'auction',
        description: 'Auction house — buy & sell items | دار المزاد',
        default_member_permissions: null,
        options: [
            {
                name: 'create',
                description: 'Create an auction | إنشاء مزاد',
                type: 1,
                options: [
                    { name: 'item',     description: 'Item ID to auction | معرف العنصر',      type: 3, required: true },
                    { name: 'price',    description: 'Starting price | السعر الابتدائي',       type: 4, required: true, min_value: 1 },
                    { name: 'hours',    description: 'Duration in hours (1-48) | المدة',       type: 4, required: false, min_value: 1, max_value: 48 },
                    { name: 'quantity', description: 'Quantity (default 1) | الكمية',          type: 4, required: false, min_value: 1 }
                ]
            },
            {
                name: 'list',
                description: 'View active auctions | عرض المزادات النشطة',
                type: 1
            },
            {
                name: 'bid',
                description: 'Place a bid | قدّم عرضاً',
                type: 1,
                options: [
                    { name: 'id',     description: 'Auction ID | رقم المزاد', type: 3, required: true },
                    { name: 'amount', description: 'Bid amount | مبلغ العرض', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'cancel',
                description: 'Cancel your auction | إلغاء مزادك',
                type: 1,
                options: [
                    { name: 'id', description: 'Auction ID | رقم المزاد', type: 3, required: true }
                ]
            },
            {
                name: 'claim',
                description: 'Claim a won auction | استلام مزاد فائز',
                type: 1,
                options: [
                    { name: 'id', description: 'Auction ID | رقم المزاد', type: 3, required: true }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        if (es.auctionEnabled === false) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.auctionOff).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        const sub    = interaction.options.getSubcommand();
        const gId    = interaction.guildId;
        const userId = interaction.user.id;

        expireAuctions(gId);

        // [FIX-AUCTION-01] placeBid مُغلَّفة بقفل مزدوج (المزايد + المزايد السابق)
        // لمنع حالة: مزايدان يقرآن auction.currentBid = X قبل أن يكتب أي منهما،
        // فيُخصم المال من كليهما بينما يفوز واحد فقط دون إرجاع المال للثاني.
        const placeBid = async (actor, auctionId, amount) => {
            // قراءة أولية للحصول على previousBidderId (قبل القفل) لتحديد القفل الثاني
            const auctionPreCheck = getAuction(gId, auctionId);
            if (!auctionPreCheck || auctionPreCheck.cancelled || auctionPreCheck.claimed) {
                return { ok: false, message: t.noAuction };
            }
            const prevBidder = auctionPreCheck.currentBidderId;
            // نحتاج قفل المزايد الحالي + المزايد السابق لإرجاع ماله بأمان
            const lockIds = prevBidder && prevBidder !== actor.id
                ? [actor.id, prevBidder]
                : [actor.id];

            let result = { ok: false, message: t.noAuction };
            const runBid = async () => {
                const auction = getAuction(gId, auctionId);
                const user    = getUser(gId, actor.id);

                if (!auction || auction.cancelled || auction.claimed) {
                    result = { ok: false, message: t.noAuction }; return;
                }
                if (auction.endsAt <= Date.now()) {
                    result = { ok: false, message: t.ended }; return;
                }
                if (auction.sellerId === actor.id) {
                    result = { ok: false, message: t.bidOwn }; return;
                }
                if (!Number.isInteger(amount) || amount < 1) {
                    result = { ok: false, message: t.invalidAmount }; return;
                }
                if (amount <= auction.currentBid || amount < auction.startPrice) {
                    result = { ok: false, message: t.bidTooLow(cur) }; return;
                }
                if ((user.wallet || 0) < amount) {
                    result = { ok: false, message: t.noMoney(amount, cur) }; return;
                }

                const prev = bidOnAuction(gId, auctionId, actor.id, amount);
                if (!prev || Object.keys(prev).length === 0) {
                    result = { ok: false, message: t.noAuction }; return;
                }

                user.wallet = (user.wallet || 0) - amount;
                saveUser(gId, actor.id, user);

                if (prev.previousBidderId && prev.previousBidderId !== actor.id) {
                    const prevUser = getUser(gId, prev.previousBidderId);
                    prevUser.wallet = (prevUser.wallet || 0) + prev.previousBid;
                    saveUser(gId, prev.previousBidderId, prevUser);
                }

                result = {
                    ok: true,
                    embed: new EmbedBuilder()
                        .setDescription(t.bidPlaced(auction.itemId, amount, cur))
                        .addFields({ name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}` })
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })
                        .setTimestamp()
                };
            };

            if (lockIds.length === 2) {
                await withTwoUserLocks(gId, lockIds[0], lockIds[1], runBid);
            } else {
                await withUserLock(gId, lockIds[0], runBid);
            }
            return result;
        };

        const claimSelected = async (actor, auctionId) => {
            const auction = getAuction(gId, auctionId);
            if (!auction || auction.cancelled || auction.claimed) return { ok: false, message: t.noAuction };
            if (auction.endsAt > Date.now()) return { ok: false, message: t.notEnded };

            if (actor.id === auction.sellerId) {
                if (auction.sellerClaimed) return { ok: false, message: t.alreadyClaimed };
                const seller = getUser(gId, actor.id);

                if (!auction.currentBidderId) {
                    if (!seller.inventory || Array.isArray(seller.inventory)) seller.inventory = {};
                    seller.inventory[auction.itemId] = (seller.inventory[auction.itemId] || 0) + auction.qty;
                    saveUser(gId, actor.id, seller);
                    claimAuction(gId, auctionId, 'seller');
                    return { ok: true, embed: new EmbedBuilder().setDescription(t.noBidReturn(auction.itemId)).setColor('#57F287').setFooter({ text: t.footer }) };
                }

                const finalBid = auction.currentBid || 0;
                seller.wallet = (seller.wallet || 0) + finalBid;
                saveUser(gId, actor.id, seller);
                claimAuction(gId, auctionId, 'seller');
                return {
                    ok: true,
                    embed: new EmbedBuilder()
                        .setDescription(t.sellerClaimed(finalBid, cur))
                        .addFields({ name: t.balance, value: `${seller.wallet.toLocaleString()} ${cur}` })
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })
                };
            }

            if (actor.id !== auction.currentBidderId) return { ok: false, message: t.notWinner };
            if (auction.winnerClaimed) return { ok: false, message: t.alreadyClaimed };

            const winner = getUser(gId, actor.id);
            if (!winner.inventory || Array.isArray(winner.inventory)) winner.inventory = {};
            winner.inventory[auction.itemId] = (winner.inventory[auction.itemId] || 0) + auction.qty;
            if (!winner.stats) winner.stats = {};
            winner.stats.auctionsWon = (winner.stats.auctionsWon || 0) + 1;
            saveUser(gId, actor.id, winner);
            claimAuction(gId, auctionId, 'winner');

            return {
                ok: true,
                embed: new EmbedBuilder()
                    .setDescription(t.claimed(auction.itemId))
                    .setColor('#57F287')
                    .setFooter({ text: t.footer })
                    .setTimestamp()
            };
        };

        const cancelSelected = async (actor, auctionId) => {
            const auction = getAuction(gId, auctionId);
            if (!auction || auction.cancelled || auction.claimed) return { ok: false, message: t.noAuction };
            if (auction.sellerId !== actor.id) return { ok: false, message: t.notYours };
            if (auction.endsAt <= Date.now()) return { ok: false, message: t.notEnded };

            cancelAuction(gId, auctionId);

            const user = getUser(gId, actor.id);
            if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};
            user.inventory[auction.itemId] = (user.inventory[auction.itemId] || 0) + auction.qty;
            saveUser(gId, actor.id, user);

            if (auction.currentBidderId) {
                const bidder = getUser(gId, auction.currentBidderId);
                bidder.wallet = (bidder.wallet || 0) + auction.currentBid;
                saveUser(gId, auction.currentBidderId, bidder);
            }

            return {
                ok: true,
                embed: new EmbedBuilder()
                    .setDescription(t.cancelDone(auction.itemId))
                    .setColor('#FEE75C')
                    .setFooter({ text: t.footer })
            };
        };

        // ── CREATE ─────────────────────────────────────────────────────────
        if (sub === 'create') {
            const itemId  = interaction.options.getString('item').trim();
            const price   = interaction.options.getInteger('price');
            const maxDuration = es.auctionMaxDuration || 48;
            const hoursRaw    = interaction.options.getInteger('hours') || 24;
            const hours       = Math.min(hoursRaw, maxDuration);
            const qty     = interaction.options.getInteger('quantity') || 1;
            const user    = getUser(gId, userId);

            if (!user.inventory || !user.inventory[itemId] || user.inventory[itemId] < qty) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noItem).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const auction = createAuction(gId, userId, itemId, qty, price, hours);
            user.inventory[itemId] -= qty;
            if (user.inventory[itemId] <= 0) delete user.inventory[itemId];
            saveUser(gId, userId, user);

            const endsAt = new Date(auction.endsAt).toLocaleString();
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.created(itemId, price, endsAt))
                    .addFields({ name: 'ID', value: `\`${auction.id}\``, inline: true })
                    .setColor('#57F287').setFooter({ text: t.footer }).setTimestamp()]
            });
        }

        // ── LIST ───────────────────────────────────────────────────────────
        if (sub === 'list') {
            const auctions = getAllAuctions(gId);
            const panelId = `auction:${interaction.id}`;
            const selected = new Map();
            await interaction.reply({
                embeds: [publicAuctionEmbed(auctions, t, cur)],
                components: auctionComponents(auctions, t, panelId)
            });
            const message = await interaction.fetchReply();

            if (!auctions.length) return;

            const collector = message.createMessageComponentCollector({
                filter: i => i.customId.startsWith(panelId),
                time: 180000
            });

            collector.on('collect', async i => {
                try {
                    if (i.customId.endsWith(':select')) {
                        const auctionId = i.values[0];
                        selected.set(i.user.id, auctionId);
                        return i.reply(statusReply(t.selected(auctionId), t));
                    }

                    if (i.customId.endsWith(':refresh')) {
                        expireAuctions(gId);
                        const fresh = getAllAuctions(gId);
                        return i.update({
                            embeds: [publicAuctionEmbed(fresh, t, cur)],
                            components: auctionComponents(fresh, t, panelId)
                        });
                    }

                    const auctionId = selected.get(i.user.id);
                    if (!auctionId) {
                        return i.reply(statusReply(t.needSelect, t));
                    }

                    if (i.customId.endsWith(':bid')) {
                        const auction = getAuction(gId, auctionId);
                        if (!auction || auction.endsAt <= Date.now()) {
                            return i.reply(statusReply(t.ended, t));
                        }
                        await i.showModal(buildBidModal(panelId, auctionId, t));
                        const modal = await i.awaitModalSubmit({
                            filter: m => m.customId === `${panelId}:modal:${auctionId}` && m.user.id === i.user.id,
                            time: 60000
                        }).catch(() => null);
                        if (!modal) return;
                        const amount = parseInt(modal.fields.getTextInputValue('amount'), 10);
                        const result = await placeBid(modal.user, auctionId, amount);
                        if (!result.ok) return modal.reply(statusReply(result.message, t));
                        await modal.reply({ embeds: [result.embed], flags: MessageFlags.Ephemeral });
                    } else if (i.customId.endsWith(':claim')) {
                        const result = await claimSelected(i.user, auctionId);
                        if (!result.ok) return i.reply(statusReply(result.message, t));
                        await i.reply({ embeds: [result.embed], flags: MessageFlags.Ephemeral });
                    } else if (i.customId.endsWith(':cancel')) {
                        const result = await cancelSelected(i.user, auctionId);
                        if (!result.ok) return i.reply(statusReply(result.message, t));
                        await i.reply({ embeds: [result.embed], flags: MessageFlags.Ephemeral });
                    }

                    expireAuctions(gId);
                    const fresh = getAllAuctions(gId);
                    await message.edit({
                        embeds: [publicAuctionEmbed(fresh, t, cur)],
                        components: auctionComponents(fresh, t, panelId)
                    }).catch(() => {});
                } catch (err) {
                    console.error('[auction panel] unexpected error:', err);
                    if (!i.replied && !i.deferred) {
                        await i.reply(statusReply(t.unexpected, t)).catch(() => {});
                    }
                }
            });

            collector.on('end', async () => {
                const fresh = getAllAuctions(gId);
                await message.edit({
                    embeds: [publicAuctionEmbed(fresh, t, cur).setFooter({ text: `${t.footer} · ${t.panelExpired}` })],
                    components: auctionComponents(fresh, t, panelId, true)
                }).catch(() => {});
            });

            return;
        }

        // ── BID ────────────────────────────────────────────────────────────
        if (sub === 'bid') {
            const auctionId = interaction.options.getString('id').trim();
            const amount    = interaction.options.getInteger('amount');
            const result = await placeBid(interaction.user, auctionId, amount);
            if (!result.ok) {
                return interaction.reply(statusReply(result.message, t));
            }
            return interaction.reply({ embeds: [result.embed] });
        }

        // ── CANCEL ─────────────────────────────────────────────────────────
        if (sub === 'cancel') {
            const auctionId = interaction.options.getString('id').trim();
            const result = await cancelSelected(interaction.user, auctionId);
            if (!result.ok) {
                return interaction.reply(statusReply(result.message, t));
            }
            return interaction.reply({ embeds: [result.embed] });
        }

        // ── CLAIM ──────────────────────────────────────────────────────────
        if (sub === 'claim') {
            const auctionId = interaction.options.getString('id').trim();
            const result = await claimSelected(interaction.user, auctionId);
            if (!result.ok) {
                return interaction.reply(statusReply(result.message, t));
            }
            return interaction.reply({ embeds: [result.embed] });
        }
    
      } catch (err) {
          console.error('[auction] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
