const { EmbedBuilder } = require('discord.js');

const T = {
    ar: {
        discordJoined: 'انضم لديسكورد',
        serverJoined:  'دخل السيرفر',
        roles:         'الرتب',
        noRoles:       'لا توجد رتب',
        badges:        'البادجات',
        id:            'ID',
        notInServer:   'غير موجود',
        daysAgo:       (n) => `${n} يوم مضى`,
    },
    en: {
        discordJoined: 'Joined Discord',
        serverJoined:  'Joined Server',
        roles:         'Roles',
        noRoles:       'No roles',
        badges:        'Badges',
        id:            'ID',
        notInServer:   'Not in server',
        daysAgo:       (n) => `${n} days ago`,
    },
};

// دالة لجلب بادجات المستخدم (نصية مؤقتًا لحين ربط إيموجيات السيرفر الحقيقية)
function getUserBadges(user) {
    const flags = user.flags?.toArray() || [];
    const badgesMap = {
        Staff:                  'Discord Staff',
        Partner:                'Partner',
        Hypesquad:              'HypeSquad Events',
        BugHunterLevel1:        'Bug Hunter',
        BugHunterLevel2:        'Bug Hunter (Gold)',
        HypesquadBravery:       'Bravery',
        HypesquadBrilliance:    'Brilliance',
        HypesquadBalance:       'Balance',
        EarlySupporter:         'Early Supporter',
        PremiumEarlySupporter:  'Early Nitro Supporter',
        VerifiedBot:            'Verified Bot',
        VerifiedDeveloper:      'Verified Developer',
    };

    const badges = flags.map(flag => badgesMap[flag]).filter(Boolean);

    if (badges.length === 0) return null;
    return badges.join(' • ');
}

module.exports = {
    name: 'user',
    description: 'معلومات عن مستخدم | User information',
    description_localizations: {
        enUS: 'User information',
        ar: 'معلومات عن مستخدم',
    },
    options: [
        {
            name: 'user',
            name_localizations: {
                ar: 'مستخدم',
                enUS: 'user',
            },
            type: 6,
            description: 'المستخدم (اختياري) | User (optional)',
            description_localizations: {
                ar: 'المستخدم الذي تريد معلومات عنه (اختياري)',
                enUS: 'The user you want information about (optional)',
            },
            required: false,
        },
    ],

    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const { guild } = interaction;

        const targetUser = interaction.options.getUser('user') || interaction.user;
        const member = await guild.members.fetch(targetUser.id).catch(() => null);

        // ── Dates ─────────────────────────────────────────────────────────
        const createdAt = `<t:${Math.floor(targetUser.createdTimestamp / 1000)}:R>`;
        const now = Date.now();
        const discordDays = Math.floor((now - targetUser.createdTimestamp) / (1000 * 60 * 60 * 24));

        let joinedAt = null;
        let serverDays = 0;
        if (member) {
            joinedAt = `<t:${Math.floor(member.joinedTimestamp / 1000)}:R>`;
            serverDays = Math.floor((now - member.joinedTimestamp) / (1000 * 60 * 60 * 24));
        }

        // ── Roles ─────────────────────────────────────────────────────────
        const roles = member?.roles.cache
            .filter(r => r.id !== guild.id)
            .sort((a, b) => b.position - a.position)
            .map(r => r.toString())
            .join(', ') || t.noRoles;

        // ── Badges ────────────────────────────────────────────────────────
        const badges = getUserBadges(targetUser);

        // ── Embed ─────────────────────────────────────────────────────────
        const descriptionLines = [
            `${targetUser.toString()}`,
        ];
        if (badges) descriptionLines.push(`**${t.badges}:** ${badges}`);
        descriptionLines.push(`**${t.roles}**\n> ${roles.slice(0, 500)}`);

        const embed = new EmbedBuilder()
            .setColor(member?.displayHexColor && member.displayHexColor !== '#000000' ? member.displayHexColor : 0x5865F2)
            .setAuthor({
                name:    targetUser.username,
                iconURL: targetUser.displayAvatarURL({ dynamic: true, size: 128 }),
            })
            .setThumbnail(targetUser.displayAvatarURL({ dynamic: true, size: 1024 }))
            .setDescription(descriptionLines.join('\n\n'))
            .addFields(
                {
                    name:  t.discordJoined,
                    value: `${createdAt}\n${t.daysAgo(discordDays)}`,
                    inline: true,
                },
                {
                    name:  t.serverJoined,
                    value: member ? `${joinedAt}\n${t.daysAgo(serverDays)}` : t.notInServer,
                    inline: true,
                },
                {
                    name:  t.id,
                    value: `\`${targetUser.id}\``,
                    inline: false,
                },
            )
            .setFooter({
                text:    guild.name,
                iconURL: guild.iconURL({ dynamic: true, size: 128 }) ?? undefined,
            })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });

        if (commandConfig?.deleteResponse) {
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch (e) {}
            }, 5000);
        }
    },
};