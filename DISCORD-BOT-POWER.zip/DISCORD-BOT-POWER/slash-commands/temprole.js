const { MessageFlags, PermissionFlagsBits, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');
const { loadData, saveData } = require('./tempRoles');
 

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

function loadTempRoles() {
    return loadData().tempRoles;
}

function saveTempRoles(tr) {
    const d = loadData();
    d.tempRoles = tr;
    saveData(d);
}
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '⚠️ هذا العضو غير موجود في السيرفر.',
        roleNotFound: '⚠️ هذه الرتبة غير موجودة.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرتب',
        cantManageRole: '⚠️ لا يمكنني إدارة هذه الرتبة (رتبة أعلى من رتبتي).',
        invalidTime: '⚠️ وقت غير صالح. استخدم: 1s, 1m, 1h, 1d, 1w (ثانية, دقيقة, ساعة, يوم, أسبوع)',
        maxTime: '⚠️ الحد الأقصى للمدة هو 30 يوم.',
        embedTitle: '✅ تم إعطاء دور مؤقت',
        embedMember: '👤 العضو',
        embedRole: '🎭 الرتبة',
        embedTime: '⏰ المدة',
        embedFooter: 'سيتم إزالة الرتبة تلقائياً بعد انتهاء المدة',
        failed: (err) => `❌ فشل: ${err}`,
        error: (err) => `❌ خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '⚠️ Member not found in the server.',
        roleNotFound: '⚠️ Role not found.',
        botNoPerm: '❌ Bot does not have permission to manage roles',
        cantManageRole: '⚠️ I cannot manage this role (role is higher than my role).',
        invalidTime: '⚠️ Invalid time format. Use: 1s, 1m, 1h, 1d, 1w (second, minute, hour, day, week)',
        maxTime: '⚠️ Maximum duration is 30 days.',
        embedTitle: '✅ Temporary Role Given',
        embedMember: '👤 Member',
        embedRole: '🎭 Role',
        embedTime: '⏰ Duration',
        embedFooter: 'Auto-remove role after duration ends',
        failed: (err) => `❌ Failed: ${err}`,
        error: (err) => `❌ Error: ${err || 'Unknown error'}`
    }
};

function parseTime(timeString) {
    const regex = /^(\d+)(s|m|h|d|w)$/;
    const match = timeString.match(regex);
    
    if (!match) return null;
    
    const value = parseInt(match[1]);
    const unit = match[2];
    
    const multipliers = {
        s: 1000,
        m: 60 * 1000,
        h: 60 * 60 * 1000,
        d: 24 * 60 * 60 * 1000,
        w: 7 * 24 * 60 * 60 * 1000
    };
    
    return value * multipliers[unit];
}

function formatTime(ms, lang) {
    const seconds = Math.floor(ms / 1000);
    const minutes = Math.floor(seconds / 60);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);
    const weeks = Math.floor(days / 7);
    
    if (lang === 'ar') {
        if (weeks > 0) return `${weeks} أسبوع`;
        if (days > 0) return `${days} يوم`;
        if (hours > 0) return `${hours} ساعة`;
        if (minutes > 0) return `${minutes} دقيقة`;
        return `${seconds} ثانية`;
    } else {
        if (weeks > 0) return `${weeks} week${weeks > 1 ? 's' : ''}`;
        if (days > 0) return `${days} day${days > 1 ? 's' : ''}`;
        if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''}`;
        if (minutes > 0) return `${minutes} minute${minutes > 1 ? 's' : ''}`;
        return `${seconds} second${seconds > 1 ? 's' : ''}`;
    }
}

function startExpiryChecker(client) {
    setInterval(async () => {
        const tempRoles = loadTempRoles();
        const now = Date.now();
        let changed = false;
        
        for (const guildId in tempRoles) {
            const guild = await client.guilds.fetch(guildId).catch(() => null);
            if (!guild) continue;
            
            for (const userId in tempRoles[guildId]) {
               const userRoles = tempRoles[guildId][userId];
if (!Array.isArray(userRoles)) {
    delete tempRoles[guildId][userId];
    changed = true;
    continue;
}
const activeRoles = [];

for (const roleData of userRoles) {
                    if (now >= roleData.expiresAt) {
                        try {
                            const member = await guild.members.fetch(userId).catch(() => null);
                            if (member) {
                                const role = await guild.roles.fetch(roleData.roleId).catch(() => null);
                                if (role && member.roles.cache.has(role.id)) {
                                    await member.roles.remove(role);
                                }
                            }
                        } catch (error) {}
                        changed = true;
                    } else {
                        activeRoles.push(roleData);
                    }
                }
                
                if (activeRoles.length === 0) {
                    delete tempRoles[guildId][userId];
                } else {
                    tempRoles[guildId][userId] = activeRoles;
                }
            }
            
            if (Object.keys(tempRoles[guildId]).length === 0) {
                delete tempRoles[guildId];
            }
        }
        
        if (changed) {
            saveTempRoles(tempRoles);
        }
    }, 10000);
}

module.exports = {
    data: {
        name: 'temprole',
        description: 'Give a temporary role to a member | إعطاء رتبة مؤقتة لعضو',
        description_localizations: {
            ar: 'إعطاء رتبة مؤقتة لعضو',
            'en-US': 'Give a temporary role to a member'
        },
        default_member_permissions: PermissionFlagsBits.ManageRoles.toString(),
        options: [
            {
                name: 'member',
                description: 'Target member | العضو المستهدف',
                description_localizations: {
                    ar: 'العضو المستهدف',
                    'en-US': 'Target member'
                },
                type: 6,
                required: true
            },
            {
                name: 'role',
                description: 'Role to give | الرتبة للإعطاء',
                description_localizations: {
                    ar: 'الرتبة للإعطاء',
                    'en-US': 'Role to give'
                },
                type: 8,
                required: true
            },
            {
                name: 'time',
                description: 'Duration (e.g., 1s, 5m, 2h, 1d, 1w) | المدة (مثال: 1s, 5m, 2h, 1d, 1w)',
                description_localizations: {
                    ar: 'المدة (مثال: 1s, 5m, 2h, 1d, 1w)',
                    'en-US': 'Duration (e.g., 1s, 5m, 2h, 1d, 1w)'
                },
                type: 3,
                required: true
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.temprole || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            if (!interaction.guild.members.me.permissions.has('ManageRoles')) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            const targetUser = interaction.options.getUser('member');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            const role = interaction.options.getRole('role');
            
            if (!role) {
                return await interaction.editReply({ content: t.roleNotFound });
            }
            
            const timeString = interaction.options.getString('time');
            
            if (!timeString) {
                return await interaction.editReply({ content: t.invalidTime });
            }
            
            const duration = parseTime(timeString);
            
            if (!duration) {
                return await interaction.editReply({ content: t.invalidTime });
            }
            
            const maxDuration = 30 * 24 * 60 * 60 * 1000;
            if (duration > maxDuration) {
                return await interaction.editReply({ content: t.maxTime });
            }
            
            if (role.position >= interaction.guild.members.me.roles.highest.position) {
                return await interaction.editReply({ content: t.cantManageRole });
            }
            
            try {
                await targetMember.roles.add(role);
                
                const tempRoles = loadTempRoles();
                
                if (!tempRoles[interaction.guildId]) {
                    tempRoles[interaction.guildId] = {};
                }
                if (!tempRoles[interaction.guildId][targetUser.id]) {
                    tempRoles[interaction.guildId][targetUser.id] = [];
                }
                
                tempRoles[interaction.guildId][targetUser.id].push({
                    roleId: role.id,
                    roleName: role.name,
                    expiresAt: Date.now() + duration,
                    givenAt: Date.now()
                });
                
                saveTempRoles(tempRoles);
                
                const formattedTime = formatTime(duration, lang);
                
                const embed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setTitle(t.embedTitle)
                    .addFields(
                        { name: t.embedMember, value: `${targetMember}`, inline: true },
                        { name: t.embedRole, value: `${role}`, inline: true },
                        { name: t.embedTime, value: `\`${formattedTime}\``, inline: true }
                    )
                    .setFooter({ text: t.embedFooter })
                    .setTimestamp();
                
                await interaction.editReply({ embeds: [embed] });
                
            } catch (error) {
                return await interaction.editReply({ content: t.failed(error.message) });
            }
            
        } catch (error) {
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    },
    
    startExpiryChecker
};