const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, getUserTransactions } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const TYPE_ICONS = {
    work:         '💼', daily:        '💎', weekly:       '🎁',
    rob_win:      '🦹', rob_lose:     '🚓', rob_fine:     '🚓',
    pay_sent:     '📤', pay_received: '📥',
    shop_buy:     '🛒', chest_open:   '📦', craft:        '⚒️',
    gamble_win:   '🎰', gamble_lose:  '🎰',
    loan_taken:   '🏦', loan_repaid:  '✅',
    bank_deposit: '🏦', bank_withdraw:'💸',
    bank_fee:     '💸', pay_tax:      '💸',
    donate:       '❤️', treasury:     '🏛️',
    admin_add:    '🔧', admin_remove: '🔧', admin_set:    '🔧',
};

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        title:    (name) => `📋 سجل معاملات ${name}`,
        empty:    '📭 لا توجد معاملات مسجلة بعد.',
        footer:   'آخر 10 معاملات',
        balance:  'الرصيد الحالي',
        noAcct:   '❌ هذا العضو لا يملك حساباً.',
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        title:    (name) => `📋 ${name}'s Transaction History`,
        empty:    '📭 No transactions recorded yet.',
        footer:   'Last 10 transactions',
        balance:  'Current Balance',
        noAcct:   '❌ This member has no account.',
    }
};

function timeAgo(ts, lang) {
    const diff = Math.floor((Date.now() - ts) / 1000);
    if (lang === 'ar') {
        if (diff < 60)    return `${diff} ثانية`;
        if (diff < 3600)  return `${Math.floor(diff/60)} دقيقة`;
        if (diff < 86400) return `${Math.floor(diff/3600)} ساعة`;
        return `${Math.floor(diff/86400)} يوم`;
    }
    if (diff < 60)    return `${diff}s ago`;
    if (diff < 3600)  return `${Math.floor(diff/60)}m ago`;
    if (diff < 86400) return `${Math.floor(diff/3600)}h ago`;
    return `${Math.floor(diff/86400)}d ago`;
}

module.exports = {
    data: {
        name: 'history',
        description: 'View transaction history | عرض سجل المعاملات',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Target member | عضو معين', type: 6, required: false }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const target = interaction.options.getUser('user') || interaction.user;
            const user   = getUser(interaction.guildId, target.id);
            const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
            const txs    = getUserTransactions(interaction.guildId, target.id, 10);

            const embed = new EmbedBuilder()
                .setTitle(t.title(target.username))
                .setThumbnail(target.displayAvatarURL({ size: 64 }))
                .setColor('#5865F2')
                .setFooter({ text: t.footer })
                .setTimestamp();

            if (txs.length === 0) {
                embed.setDescription(t.empty);
            } else {
                const lines = txs.map(tx => {
                    const icon   = TYPE_ICONS[tx.type] || '💱';
                    const sign   = tx.amount >= 0 ? '+' : '';
                    const amtStr = `**${sign}${tx.amount.toLocaleString()} ${es.currency || '🪙'}**`;
                    const ago    = timeAgo(tx.ts, lang);
                    const note   = tx.note ? ` · ${tx.note}` : '';
                    return `${icon} ${amtStr}${note} · \`${ago}\``;
                });
                embed.setDescription(lines.join('\n'));
            }

            embed.addFields({
                name:  t.balance,
                value: `${(user.wallet || 0).toLocaleString()} ${cur}`,
                inline: true
            });

            return interaction.reply({ embeds: [embed] });

        } catch (err) {
            console.error('[history] unexpected error:', err);
            const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
