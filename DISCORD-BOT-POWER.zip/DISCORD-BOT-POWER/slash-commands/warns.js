const { MessageFlags, EmbedBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

const BOT_DATA_FILE = path.join(__dirname, '../botData.json');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try { return JSON.parse(fs.readFileSync(modPath, 'utf8')); }
        catch(e) { return {}; }
    }
    return {};
}

function getWarns() {
    try {
        if (fs.existsSync(BOT_DATA_FILE)) {
            const raw = fs.readFileSync(BOT_DATA_FILE, 'utf8').trim();
            if (raw) return JSON.parse(raw).warns || {};
        }
    } catch(e) {}
    return {};
}

 

function formatExpiry(expiresAt, lang) {
    if (!expiresAt) return lang === 'ar' ? '♾️ دائم' : '♾️ Permanent';
    const remaining = Math.max(0, new Date(expiresAt).getTime() - Date.now());
    const totalMins = Math.ceil(remaining / 60000);
    if (totalMins <= 0)   return lang === 'ar' ? '🔴 انتهت مدته'         : '🔴 Expired';
    if (totalMins < 60)   return lang === 'ar' ? `⏳ بعد ${totalMins} د` : `⏳ ${totalMins}m left`;
    if (totalMins < 1440) {
        const hrs = Math.ceil(totalMins / 60);
        return lang === 'ar' ? `⏳ بعد ${hrs} ساعة` : `⏳ ${hrs}h left`;
    }
    const days = Math.ceil(totalMins / 1440);
    return lang === 'ar' ? `⏳ بعد ${days} يوم` : `⏳ ${days}d left`;
}

async function fetchUserSafe(client, userId) {
    try { return await client.users.fetch(userId); }
    catch(e) { return null; }
}

module.exports = {
    data: {
        name: 'warns',
        description: 'Show member warnings | عرض تحذيرات عضو',
        options: [{ name: 'user', description: 'User', type: 6, required: true }]
    },

    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.warns || {
                enabled: true, aliases: [],
                deniedRoles: [], allowedRoles: [],
                deniedChannels: [], allowedChannels: [],
                deleteCommand: false, deleteResponse: false
            };

            if (!config.enabled) {
                return await interaction.editReply({
                    content: lang === 'ar' ? '⚠️ هذا الأمر معطل حالياً.' : '⚠️ This command is currently disabled.'
                });
            }

            const permission = checkPermissions(interaction.member, interaction.channelId, config);
            if (!permission.allowed)
                return await interaction.editReply({ content: permission.reason });

            const targetUser = interaction.options.getUser('user');
            const warns      = getWarns();
            const guildId    = interaction.guildId;

            // ===== لا توجد تحذيرات =====
            if (!warns[guildId]?.[targetUser.id]?.length) {
                const embed = new EmbedBuilder()
                    .setColor('#57F287')
                    .setTitle(lang === 'ar' ? '✅ لا توجد تحذيرات' : '✅ No Warnings')
                    .setDescription(
                        lang === 'ar'
                            ? `**${targetUser.username}** ليس لديه أي تحذيرات.`
                            : `**${targetUser.username}** has no warnings.`
                    )
                    .setThumbnail(targetUser.displayAvatarURL({ extension: 'png', size: 128 }))
                     
                return await interaction.editReply({ embeds: [embed] });
            }

            const userWarns = warns[guildId][targetUser.id];
            const count     = userWarns.length;
            const color     = count >= 7 ? '#ED4245' : count >= 4 ? '#FFA500' : '#FED130';

            // جلب معلومات المشرفين
            const modIds = [...new Set(userWarns.map(w => w.moderator).filter(Boolean))];
            const modMap = {};
            await Promise.all(modIds.map(async id => {
                modMap[id] = await fetchUserSafe(client, id);
            }));

            // ===== معلومات العضو مرة واحدة في الأعلى =====
            let description = lang === 'ar'
                ? `**معلومات العضو**\n**العضو:** ${targetUser}\n**الاسم:** \`${targetUser.username}\`\n**الآيدي:** \`${targetUser.id}\`\n\n`
                : `**Member Info**\n**Member:** ${targetUser}\n**Name:** \`${targetUser.username}\`\n**ID:** \`${targetUser.id}\`\n\n`;

            // ===== كل تحذير بشكل مختصر =====
            userWarns.forEach((warn, i) => {
                const date    = new Date(warn.timestamp).toLocaleDateString(
                    lang === 'ar' ? 'ar-SA' : 'en-US',
                    { year: 'numeric', month: 'short', day: 'numeric' }
                );
                const expiry      = formatExpiry(warn.expiresAt, lang);
                const modUser     = warn.moderator ? modMap[warn.moderator] : null;
                const modMention  = warn.moderator ? `<@${warn.moderator}>` : '—';
                const modUsername = modUser ? modUser.username : (warn.moderator || '—');

                if (lang === 'ar') {
                    description +=
                        `**تحذير #${i + 1}**\n` +
                        `** السبب:** \`${warn.reason}\`\n` +
                        `** بواسطة:** ${modMention}  \n` +
                        `** المدة:** ${expiry} ┃   ${date}\n`;
                } else {
                    description +=
                        `**Warning #${i + 1}**\n` +
                        `** Reason:** \`${warn.reason}\`\n` +
                        `** By:** ${modMention} \n` +
                        `** Duration:** ${expiry} ┃   ${date}\n`;
                }

                if (i < userWarns.length - 1) description += '\n';
            });

            if (description.length > 4096) description = description.slice(0, 4090) + '...';

            const embed = new EmbedBuilder()
                .setColor(color)
                .setTitle(lang === 'ar'
                    ? `⚠️ تحذيرات ${targetUser.username} (${count})`
                    : `⚠️ Warnings for ${targetUser.username} (${count})`)
                .setThumbnail(targetUser.displayAvatarURL({ extension: 'png', size: 128 }))
                .setDescription(description)
                .setFooter({
                   text: `${interaction.guild.name} | ${new Date().toLocaleString('en-US')}`,
                    iconURL: interaction.guild.iconURL({ extension: 'png' }) || undefined
                })
                 

            if (config.deleteResponse) {
                await interaction.editReply({ embeds: [embed] });
                setTimeout(async () => {
                    try {
                        const reply = await interaction.fetchReply();
                        if (reply?.deletable) await reply.delete();
                    } catch(err) {
                        if (err.code !== 10008) console.warn(err.message);
                    }
                }, 10000);
            } else {
                await interaction.editReply({ embeds: [embed] });
            }

        } catch(error) {
            try {
                const msg = lang === 'ar'
                    ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                    : `❌ An error occurred: ${error.message || 'Unknown error'}`;
                if (interaction.deferred && !interaction.replied)
                    await interaction.editReply({ content: msg });
                else if (!interaction.replied)
                    await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
            } catch {}
        }
    }
};