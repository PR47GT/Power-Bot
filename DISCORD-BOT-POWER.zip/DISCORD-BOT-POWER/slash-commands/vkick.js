const { MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌐 ترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '⚠️ هذا العضو غير موجود في السيرفر.',
        botNoPerm: '❌ البوت لا يملك صلاحية نقل الأعضاء في الرومات الصوتية',
        notInVoice: '⚠️ هذا العضو ليس في روم صوتي.',
        success: (user) => `✅ تم طرد \`${user}\` من الروم الصوتي`,
        failed: (err) => `❌ فشل طرد العضو: ${err}`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '⚠️ Member not found in the server.',
        botNoPerm: '❌ Bot does not have permission to move members',
        notInVoice: '⚠️ This member is not in a voice channel.',
        success: (user) => `✅ Kicked \`${user}\` from the voice channel`,
        failed: (err) => `❌ Failed to kick member: ${err}`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'vkick',
        description: 'Kick a member from voice channel | طرد عضو من الروم الصوتي',
        description_localizations: {
            ar: 'طرد عضو من الروم الصوتي',
            enUS: 'Kick a member from voice channel'
        },
        options: [
            { 
                name: 'user', 
                description: 'Member',
                description_localizations: {
                    ar: 'العضو',
                    enUS: 'Member'
                },
                type: 6, 
                required: true 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.vkick || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!interaction.guild.members.me.permissions.has('MoveMembers')) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (!targetMember.voice.channel) {
                return await interaction.editReply({ content: t.notInVoice });
            }
            
            try {
                await targetMember.voice.setChannel(null);
                
                const successMessage = t.success(targetUser.tag);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ content: t.failed(error.message) });
            }
            
        } catch (error) {
            console.error('❌ Error in vkick:', error.message);
            
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};