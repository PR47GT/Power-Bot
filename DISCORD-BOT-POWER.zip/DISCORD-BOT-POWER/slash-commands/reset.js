const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags, ComponentType } = require('discord.js');
const { resetEconomy } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        confirm: '✅ تم تصفير اقتصاد السيرفر بالكامل بنجاح.',
        cancelled: '❌ تم إلغاء العملية.',
        warning: '⚠️ **تحذير:** سيتم تصفير أرصدة ومخزون جميع الأعضاء.\nهل أنت متأكد؟',
        yes: '✅ نعم، تصفير الكل',
        no: '❌ إلغاء',
        footer: 'إعادة تعيين الاقتصاد'
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        confirm: '✅ The server economy has been fully reset.',
        cancelled: '❌ Operation cancelled.',
        warning: '⚠️ **Warning:** This will reset all members\' balances and inventories.\nAre you sure?',
        yes: '✅ Yes, reset everything',
        no: '❌ Cancel',
        footer: 'Economy Reset'
    }
};

module.exports = {
    data: {
        name: 'reseteconomy',
        description: 'Reset the entire economy (all balances & inventories) | تصفير الاقتصاد بالكامل',
        default_member_permissions: 'Administrator'
    },

    async execute(interaction, client, settings) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];
        const es = loadEconomySettings();
        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const row = new ActionRowBuilder().addComponents(
            new ButtonBuilder().setCustomId('reset_yes').setLabel(t.yes).setStyle(ButtonStyle.Danger),
            new ButtonBuilder().setCustomId('reset_no').setLabel(t.no).setStyle(ButtonStyle.Secondary)
        );

        const confirmMsg = await interaction.reply({
            embeds: [new EmbedBuilder().setDescription(t.warning).setColor('#FEE75C').setFooter({ text: t.footer })],
            components: [row],
            flags: MessageFlags.Ephemeral,
            fetchReply: true
        });

        const collector = confirmMsg.createMessageComponentCollector({
            componentType: ComponentType.Button,
            filter: i => i.user.id === interaction.user.id,
            time: 15000,
            max: 1
        });

        collector.on('collect', async (btn) => {
            if (btn.customId === 'reset_yes') {
                resetEconomy(interaction.guildId);
                await btn.update({
                    embeds: [new EmbedBuilder().setDescription(t.confirm).setColor('#57F287').setFooter({ text: t.footer })],
                    components: []
                });
            } else {
                await btn.update({
                    embeds: [new EmbedBuilder().setDescription(t.cancelled).setColor('#ED4245').setFooter({ text: t.footer })],
                    components: []
                });
            }
        });

        collector.on('end', async (collected) => {
            if (!collected.size) {
                await interaction.editReply({ components: [] }).catch(() => {});
            }
        });
    }
};
