const {
    MessageFlags,
    ButtonBuilder,
    ButtonStyle,
    ContainerBuilder,
    TextDisplayBuilder,
    SeparatorBuilder,
    SectionBuilder
} = require('discord.js');
const { getUser, saveUser } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const ACCENT_COLOR = 0x5865F2;

const T = {
    ar: {
        systemDisabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        title:          'إعدادات التنبيهات',
        description:    (name) => `إدارة إعدادات التنبيهات الخاصة بك في **${name}**. اضغط على الأزرار أدناه لتفعيلها أو إيقافها.`,
        workLabel:      'أمر العمل',
        workDesc:       (workMention)  => `يُنبهك عندما يمكنك استخدام أمر ${workMention} مرة أخرى.`,
        dailyLabel:     'الأمر اليومي',
        dailyDesc:      (dailyMention) => `يُنبهك عندما يمكنك استخدام أمر ${dailyMention} مرة أخرى.`,
        enabled:        'مفعّل',
        disabled:       'معطّل',
        expired:        '⏱️ انتهت صلاحية لوحة التنبيهات. استخدم الأمر مرة أخرى.',
        errorGeneral:   '❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.'
    },
    en: {
        systemDisabled: '⚠️ Economy system is currently disabled.',
        title:          'Notification Settings',
        description:    (name) => `Manage your notification settings for **${name}**. Click on the buttons below to toggle them.`,
        workLabel:      'Work Command',
        workDesc:       (workMention)  => `Notify when you can use the ${workMention} command again.`,
        dailyLabel:     'Daily Command',
        dailyDesc:      (dailyMention) => `Notify when you can use the ${dailyMention} command again.`,
        enabled:        'Enabled',
        disabled:       'Disabled',
        expired:        '⏱️ This notification panel expired. Run the command again.',
        errorGeneral:   '❌ An unexpected error occurred. Please try again later.'
    }
};

/**
 * Look up slash command IDs and return Discord mention strings.
 * Searches global commands first, then guild commands.
 * Falls back to inline code text if the ID cannot be resolved.
 *
 * @param {import('discord.js').Client} client
 * @param {string} guildId
 * @returns {Promise<{ workMention: string, dailyMention: string }>}
 */
async function resolveCommandMentions(client, guildId) {
    // ── 1. Try global commands ─────────────────────────────────────────────
    if (!client.application.commands.cache.size) {
        await client.application.commands.fetch().catch(() => {});
    }
    const globalCmds = client.application.commands.cache;

    // ── 2. Try guild commands ──────────────────────────────────────────────
    const guild = client.guilds.cache.get(guildId);
    if (guild && !guild.commands.cache.size) {
        await guild.commands.fetch().catch(() => {});
    }
    const guildCmds = guild?.commands?.cache;

    function findId(name) {
        return (
            globalCmds.find(c => c.name === name)?.id ??
            guildCmds?.find(c => c.name === name)?.id ??
            null
        );
    }

    const workId  = findId('work');
    const dailyId = findId('daily');

    return {
        workMention:  workId  ? `</work:${workId}>`   : '`/work`',
        dailyMention: dailyId ? `</daily:${dailyId}>` : '`/daily`'
    };
}

/**
 * Build the main notification panel using Components V2.
 *
 * @param {object}  user
 * @param {object}  t
 * @param {string}  guildName
 * @param {string}  panelId
 * @param {string}  workMention   - Formatted slash command mention for /work
 * @param {string}  dailyMention  - Formatted slash command mention for /daily
 * @param {boolean} expired
 * @param {boolean} disabled
 * @returns {ContainerBuilder[]}
 */
function buildNotificationContainer(
    user, t, guildName, panelId,
    workMention, dailyMention,
    expired = false, disabled = false
) {
    const descriptionText = expired ? t.expired : t.description(guildName);

    const container = new ContainerBuilder()
        .setAccentColor(ACCENT_COLOR)

        // ── Title ─────────────────────────────────────────────────────────────
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(`## **${t.title}**`)
        )

        // ── Description ───────────────────────────────────────────────────────
        .addTextDisplayComponents(
            new TextDisplayBuilder().setContent(descriptionText)
        )

        // ── Separator ─────────────────────────────────────────────────────────
        .addSeparatorComponents(
            new SeparatorBuilder().setDivider(true)
        )

        // ── Work row: text left, button right ─────────────────────────────────
        .addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**${t.workLabel}**\n${t.workDesc(workMention)}`
                    )
                )
                .setButtonAccessory(
                    new ButtonBuilder()
                        .setCustomId(`${panelId}:work`)
                        .setLabel(user.notifications.work ? t.enabled : t.disabled)
                        .setStyle(user.notifications.work ? ButtonStyle.Success : ButtonStyle.Secondary)
                        .setDisabled(disabled)
                )
        )

        // ── Daily row: text left, button right ────────────────────────────────
        .addSectionComponents(
            new SectionBuilder()
                .addTextDisplayComponents(
                    new TextDisplayBuilder().setContent(
                        `**${t.dailyLabel}**\n${t.dailyDesc(dailyMention)}`
                    )
                )
                .setButtonAccessory(
                    new ButtonBuilder()
                        .setCustomId(`${panelId}:daily`)
                        .setLabel(user.notifications.daily ? t.enabled : t.disabled)
                        .setStyle(user.notifications.daily ? ButtonStyle.Success : ButtonStyle.Secondary)
                        .setDisabled(disabled)
                )
        );

    return [container];
}

/**
 * Build a simple single-message container (errors / system disabled).
 *
 * @param {string} message
 * @returns {ContainerBuilder[]}
 */
function buildSimpleContainer(message) {
    return [
        new ContainerBuilder()
            .setAccentColor(0xED4245)
            .addTextDisplayComponents(
                new TextDisplayBuilder().setContent(message)
            )
    ];
}

module.exports = {
    data: {
        name: 'notification',
        description: 'Manage work/daily reminders | إعدادات التنبيهات',
        default_member_permissions: null,
        options: [
            {
                name: 'settings',
                description: 'Configure notifications | إعداد التنبيهات',
                type: 1,
                options: []
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang      = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t         = T[lang];
            const es        = loadEconomySettings();
            const guildName = interaction.guild?.name ?? 'the server';

            // ── Economy disabled ───────────────────────────────────────────────
            if (!es.enabled) {
                return interaction.reply({
                    components: buildSimpleContainer(t.systemDisabled),
                    flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
                });
            }

            // ── Load & ensure notification defaults ────────────────────────────
            const user = getUser(interaction.guildId, interaction.user.id);
            user.notifications = user.notifications || { work: true, daily: true };
            saveUser(interaction.guildId, interaction.user.id, user);

            const panelId = `notification:${interaction.id}`;

            // ── Resolve slash command mentions (/work, /daily) ─────────────────
            // Fetches global + guild commands if not yet cached.
            const { workMention, dailyMention } = await resolveCommandMentions(client, interaction.guildId);

            // ── Send initial panel ─────────────────────────────────────────────
            await interaction.reply({
                components: buildNotificationContainer(
                    user, t, guildName, panelId,
                    workMention, dailyMention
                ),
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            });

            const msg = await interaction.fetchReply();

            // ── Collector (120 s) ──────────────────────────────────────────────
            const collector = msg.createMessageComponentCollector({
                filter: i => i.customId.startsWith(panelId) && i.user.id === interaction.user.id,
                time: 120_000
            });

            collector.on('collect', async i => {
                const fresh = getUser(interaction.guildId, interaction.user.id);
                fresh.notifications = fresh.notifications || { work: true, daily: true };

                if (i.customId.endsWith(':work'))  fresh.notifications.work  = !fresh.notifications.work;
                if (i.customId.endsWith(':daily')) fresh.notifications.daily = !fresh.notifications.daily;

                saveUser(interaction.guildId, interaction.user.id, fresh);

                await i.update({
                    components: buildNotificationContainer(
                        fresh, t, guildName, panelId,
                        workMention, dailyMention
                    ),
                    flags: MessageFlags.IsComponentsV2
                });
            });

            collector.on('end', async () => {
                const fresh = getUser(interaction.guildId, interaction.user.id);
                fresh.notifications = fresh.notifications || { work: true, daily: true };

                await interaction.editReply({
                    components: buildNotificationContainer(
                        fresh, t, guildName, panelId,
                        workMention, dailyMention,
                        true, true
                    ),
                    flags: MessageFlags.IsComponentsV2
                }).catch(() => {});
            });

        } catch (err) {
            console.error('[notification] unexpected error:', err);

            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];

            const payload = {
                components: buildSimpleContainer(t.errorGeneral),
                flags: MessageFlags.IsComponentsV2 | MessageFlags.Ephemeral
            };

            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(payload).catch(() => {});
            } else {
                await interaction.reply(payload).catch(() => {});
            }
        }
    }
};
