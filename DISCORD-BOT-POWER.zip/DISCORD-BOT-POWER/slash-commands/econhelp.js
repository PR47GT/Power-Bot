const { EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle, MessageFlags } = require('discord.js');

// ========================= UI Labels =========================
const UI = {
    ar: {
        title:   (page, total) => `دليل أوامر الاقتصاد — الصفحة ${page} من ${total}`,
        footer:  (page, total) => `الصفحة ${page} من ${total}  •  اضغط على أي أمر لاستخدامه`,
        prev:    '◄  السابق',
        next:    'التالي  ►'
    },
    en: {
        title:   (page, total) => `Economy Command Guide — Page ${page} of ${total}`,
        footer:  (page, total) => `Page ${page} of ${total}  •  Click any command to use it`,
        prev:    '◄  Previous',
        next:    'Next  ►'
    }
};

// ========================= Category Labels =========================
const CAT = {
    ar: {
        general:  '— العامة —',
        bank:     '— البنك —',
        shop:     '— المتجر —',
        items:    '— العناصر —',
        chests:   '— الصناديق —',
        crafting: '— الصياغة —',
        gambling: '— القمار —',
        auction:  '— دار المزاد —',
        stats:    '— الإحصائيات والمهام —'
    },
    en: {
        general:  '— General —',
        bank:     '— Bank —',
        shop:     '— Shop —',
        items:    '— Items —',
        chests:   '— Chests —',
        crafting: '— Crafting —',
        gambling: '— Gambling —',
        auction:  '— Auction House —',
        stats:    '— Statistics & Quests —'
    }
};

// ========================= Command Data =========================
// Each entry: ['parent', 'subcommand|null', 'English description', 'الوصف بالعربي']
// subcommand = null  →  top-level command
// subcommand = 'deposit'  →  /bank deposit
const COMMANDS = {
    general: [
        ['balance',    null,       'Check your current wallet and bank balance.',            'تحقق من رصيد محفظتك والبنك الخاص بك.'],
        ['profile',    null,       'View your full economy profile and financial overview.', 'اعرض ملفك الاقتصادي الكامل ونظرة عامة على أموالك.'],
        ['work',       null,       'Complete a work shift to earn coins.',                   'أكمل وردية عمل لكسب العملات.'],
        ['daily',      null,       'Claim your daily coin reward.',                          'استلم مكافأتك اليومية من العملات.'],
        ['weekly',     null,       'Claim your weekly coin reward.',                         'استلم مكافأتك الأسبوعية من العملات.'],
        ['moneytop',   null,       'Display the wealthiest members leaderboard.',           'اعرض قائمة أغنى الأعضاء في السيرفر.'],
        ['pay',        null,       'Send coins directly to another member.',                 'أرسل عملات مباشرةً إلى عضو آخر.'],
        ['rob',        null,       'Attempt to steal coins from another member.',            'حاول سرقة عملات من عضو آخر.']
    ],
    bank: [
        ['bank',       'deposit',  'Deposit coins from your wallet into the bank.',         'أودع عملات من محفظتك إلى البنك.'],
        ['bank',       'withdraw', 'Withdraw coins from the bank to your wallet.',           'اسحب عملات من البنك إلى محفظتك.'],
        ['bank',       'balance',  'Check your current bank balance.',                      'تحقق من رصيد بنكك الحالي.'],
        ['loan',       'take',     'Borrow a specified amount of coins.',                    'اقترض كمية محددة من العملات.'],
        ['loan',       'repay',    'Repay your outstanding loan.',                           'سدد جزءاً من قرضك القائم.'],
        ['loan',       'check',    'Check your loan status and remaining balance.',          'تحقق من حالة قرضك والمبلغ المتبقي.']
    ],
    shop: [
        ['shop',       'list',     'View all available items and chests.',                  'اعرض جميع العناصر والصناديق المتاحة.'],
        ['shop',       'info',     'View detailed information about an item or chest.',     'اعرض تفاصيل عنصر أو صندوق معين.'],
        ['shop',       'buy',      'Purchase an item or chest from the shop.',              'اشترِ عنصراً أو صندوقاً من المتجر.'],
        ['treasury',   'view',     'View the current server treasury balance.',             'اعرض رصيد خزينة السيرفر الحالية.'],
        ['treasury',   'donate',   'Donate coins to the server treasury.',                  'تبرع بعملات إلى خزينة السيرفر.']
    ],
    items: [
        ['item',       'inventory','View all items in your inventory.',                     'اعرض جميع العناصر في مخزونك.'],
        ['item',       'use',      'Activate an item and apply its effect.',                'فعّل عنصراً وطبّق تأثيره.'],
        ['item',       'sell',     'Sell an item from your inventory for coins.',           'بع عنصراً من مخزونك مقابل عملات.'],
        ['item',       'give',     'Gift an item to another member.',                       'أهدِ عنصراً لعضو آخر.'],
        ['item',       'duration', 'Check remaining duration of active item effects.',      'تحقق من المدة المتبقية لتأثيرات عناصرك الفعّالة.']
    ],
    chests: [
        ['chest',      'inventory','View all chests you currently own.',                    'اعرض جميع الصناديق التي تمتلكها.'],
        ['chest',      'open',     'Open a chest and receive its contents.',                'افتح صندوقاً واحصل على محتوياته.'],
        ['chest',      'open-all', 'Open every chest in your inventory at once.',           'افتح جميع صناديقك دفعةً واحدة.'],
        ['chest',      'info',     'View details of a specific chest.',                     'اعرض تفاصيل صندوق معين.'],
        ['chest',      'give',     'Gift a chest to another member.',                       'أهدِ صندوقاً لعضو آخر.']
    ],
    crafting: [
        ['recipe',     'list',     'Browse all available crafting recipes.',                'تصفح جميع وصفات الصياغة المتاحة.'],
        ['recipe',     'info',     'View materials and output for a recipe.',               'اعرض المواد المطلوبة ومخرجات وصفة معينة.'],
        ['recipe',     'craft',    'Craft an item using a recipe.',                         'اصنع عنصراً باستخدام وصفة صياغة.']
    ],
    gambling: [
        ['coinflip',   null,       'Wager coins on a coin flip — heads or tails.',          'راهن على رمية عملة — صورة أو كتابة.'],
        ['rps',        null,       'Challenge a member to Rock Paper Scissors.',            'تحدَّ عضواً في حجر ورقة مقص.'],
        ['blackjack',  null,       'Play a round of Blackjack against the dealer.',         'العب جولة بلاك جاك ضد الموزع.'],
        ['slots',      null,       'Spin the slot machine and try your luck.',              'أدر آلة الحظ وجرّب طالعك.'],
        ['dice',       null,       'Roll two dice and bet on the combined outcome.',         'ارمِ نردتين وراهن على مجموع النتيجة.']
    ],
    auction: [
        ['auction',    'list',     'Browse all currently active auctions.',                 'تصفح جميع المزادات النشطة حالياً.'],
        ['auction',    'create',   'List one of your items for auction.',                   'ضع أحد عناصرك في المزاد.'],
        ['auction',    'bid',      'Place a bid on an active auction.',                     'قدّم عرضاً على مزاد نشط.'],
        ['auction',    'claim',    'Claim the item from an auction you won.',               'استلم العنصر من مزاد فزت به.'],
        ['auction',    'cancel',   'Cancel your auction and retrieve the item.',            'ألغِ مزادك واسترد العنصر.']
    ],
    stats: [
        ['econlevel',        null,       'View your economy level and XP progress.',        'اعرض مستواك الاقتصادي وتقدم XP.'],
        ['estats',           null,       'View detailed economy statistics.',               'اعرض إحصائيات اقتصادية تفصيلية.'],
        ['history',          null,       'View your recent transaction history.',           'اعرض سجل معاملاتك الأخيرة.'],
        ['quest',            'view',     'Display your active quests and progress.',        'اعرض مهامك النشطة وتقدمك فيها.'],
        ['quest',            'claim',    'Claim the reward for a completed quest.',         'استلم مكافأة مهمة أكملتها.'],
        ['notification',     'settings', 'Configure your work and reward reminders.',      'اضبط تذكيرات العمل والجوائز اليومية.']
    ]
};

// ========================= Build Command Mention =========================
// Returns </commandName subcommand:id> if ID found, otherwise `fallback` text
function cmdMention(parent, sub, cmdMap) {
    const id = cmdMap.get(parent);
    if (!id) return sub ? `\`/${parent} ${sub}\`` : `\`/${parent}\``;
    return sub ? `</${parent} ${sub}:${id}>` : `</${parent}:${id}>`;
}

// ========================= Fetch Command IDs =========================
// Guild commands (registered with applicationGuildCommands) must be fetched
// from the guild, NOT from client.application.commands (those are global).
async function fetchCmdMap(interaction) {
    const map = new Map();
    try {
        const guildCmds = await interaction.guild.commands.fetch();
        guildCmds.forEach(cmd => map.set(cmd.name, cmd.id));
    } catch (_) {}
    return map;
}

// ========================= Build Embed =========================
function buildEmbed(pageIndex, lang, color, pages) {
    const ui     = UI[lang];
    const total  = pages.length;
    const { category, lines } = pages[pageIndex];

    return new EmbedBuilder()
        .setColor(color || 0xF5A623)
        .setTitle(ui.title(pageIndex + 1, total))
        .setDescription(`**${category}**\n\n${lines}`)
        .setFooter({ text: ui.footer(pageIndex + 1, total) });
}

// ========================= Build Buttons =========================
function buildRow(pageIndex, lang, total, disabled = false) {
    const ui = UI[lang];
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId('econ_prev')
            .setLabel(ui.prev)
            .setStyle(ButtonStyle.Secondary)
            .setDisabled(disabled || pageIndex === 0),
        new ButtonBuilder()
            .setCustomId('econ_next')
            .setLabel(ui.next)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(disabled || pageIndex === total - 1)
    );
}

// ========================= Command Export =========================
module.exports = {
    data: {
        name: 'econhelp',
        description: 'Browse all economy commands | تصفح جميع أوامر الاقتصاد',
        default_member_permissions: null,
        options: []
    },

    async execute(interaction, client, settings) {
        const lang  = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const color = settings?.embedColor || 0xF5A623;
        const descIdx = lang === 'ar' ? 3 : 2;

        // Fetch command IDs once for mentions (guild commands)
        const cmdMap = await fetchCmdMap(interaction);

        // Build resolved pages (mentions already injected)
        const pages = Object.keys(COMMANDS).map(key => ({
            category: CAT[lang][key],
            lines: COMMANDS[key].map(row => {
                const [parent, sub, ...descs] = row;
                const mention = cmdMention(parent, sub, cmdMap);
                const desc    = descs[descIdx - 2];   // 0-based after destructure
                return `${mention}\n┗ ${desc}`;
            }).join('\n\n')
        }));

        let current = 0;

        await interaction.reply({
            embeds:     [buildEmbed(current, lang, color, pages)],
            components: [buildRow(current, lang, pages.length)],
            flags:      MessageFlags.Ephemeral
        });

        const msg = await interaction.fetchReply();

        const collector = msg.createMessageComponentCollector({
            filter: (i) =>
                i.user.id === interaction.user.id &&
                ['econ_prev', 'econ_next'].includes(i.customId),
            time: 120_000
        });

        collector.on('collect', async (i) => {
            if (i.customId === 'econ_next' && current < pages.length - 1) current++;
            if (i.customId === 'econ_prev' && current > 0)                 current--;

            await i.update({
                embeds:     [buildEmbed(current, lang, color, pages)],
                components: [buildRow(current, lang, pages.length)]
            });
        });

        collector.on('end', async () => {
            try {
                await interaction.editReply({
                    components: [buildRow(current, lang, pages.length, true)]
                });
            } catch (_) {}
        });
    }
};
