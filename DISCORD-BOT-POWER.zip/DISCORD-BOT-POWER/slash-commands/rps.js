const {
    AttachmentBuilder,
    EmbedBuilder,
    MessageFlags,
    ButtonBuilder,
    ButtonStyle,
    ActionRowBuilder
} = require('discord.js');
const { getUser, saveUser, cooldownLeft, formatTime, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

let canvasApi = null;
try {
    canvasApi = require('@napi-rs/canvas');
} catch (_) {
    canvasApi = null;
}

const GAME_TIMEOUT = 60_000;
const ROUND_TIMEOUT = 45_000;

const CHOICES = {
    rock: {
        emoji: '🪨',
        en: 'Rock',
        ar: 'حجر',
        color: '#ef4444'
    },
    paper: {
        emoji: '📄',
        en: 'Paper',
        ar: 'ورقة',
        color: '#22c55e'
    },
    scissors: {
        emoji: '✂️',
        en: 'Scissors',
        ar: 'مقص',
        color: '#5865f2'
    }
};

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        rpsDisabled: '⚠️ لعبة حجر ورقة مقص معطلة حالياً.',
        selfPlay: '❌ لا يمكنك اللعب ضد نفسك.',
        botTarget: '❌ لا يمكنك التحدي ضد روبوت.',
        badRounds: '❌ عدد الجولات يجب أن يكون بين 1 و 10.',
        minBet: n => `❌ الحد الأدنى للرهان **${n.toLocaleString()}**.`,
        maxBet: n => `❌ الحد الأقصى للرهان **${n.toLocaleString()}**.`,
        noMoney: (n, c) => `❌ رصيدك غير كافٍ. تحتاج **${n.toLocaleString()} ${c}**.`,
        oppNoMoney: name => `❌ **${name}** لا يملك رصيداً كافياً للمشاركة.`,
        challengeTitle: 'Rock Paper Scissors',
        challenge: (challenger, opponent, amount, cur) =>
            `${challenger} تحدى ${opponent} في لعبة **Rock, Paper, Scissors** بمبلغ **${amount.toLocaleString()} ${cur}**.`,
        acceptHint: 'اقبل أو ارفض خلال 60 ثانية.',
        timeout: '⏰ انتهى وقت الرد على التحدي.',
        roundTimeout: '⏰ انتهى وقت الاختيار في هذه الجولة.',
        declined: '❌ تم رفض التحدي.',
        selected: choice => `تم اختيار ${choice}`,
        alreadyPicked: '✅ تم تسجيل اختيارك لهذه الجولة.',
        notYourGame: 'هذه المباراة ليست لك.',
        round: 'الجولة',
        bet: 'الرهان',
        waiting: 'بانتظار اختيار اللاعبين...',
        footer: 'Rock Paper Scissors',
        btnAccept: 'قبول',
        btnDecline: 'رفض',
        winner: (winner, amount, cur) => `${winner} فاز بالمباراة! (+${amount.toLocaleString()} ${cur})`,
        tieGame: 'انتهت المباراة بالتعادل وتم إرجاع الرهان.',
        roundWinner: winner => `${winner} فاز بالجولة.`,
        roundTie: 'تعادل في الجولة.',
        final: 'النتيجة النهائية'
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        rpsDisabled: '⚠️ Rock Paper Scissors is currently disabled.',
        selfPlay: '❌ You cannot challenge yourself.',
        botTarget: '❌ You cannot challenge a bot.',
        badRounds: '❌ Rounds must be between 1 and 10.',
        minBet: n => `❌ Minimum bet is **${n.toLocaleString()}**.`,
        maxBet: n => `❌ Maximum bet is **${n.toLocaleString()}**.`,
        noMoney: (n, c) => `❌ Insufficient balance. Need **${n.toLocaleString()} ${c}**.`,
        oppNoMoney: name => `❌ **${name}** does not have enough balance.`,
        challengeTitle: 'Rock Paper Scissors',
        challenge: (challenger, opponent, amount, cur) =>
            `${challenger} challenged ${opponent} to **Rock, Paper, Scissors** for **${amount.toLocaleString()} ${cur}**.`,
        acceptHint: 'Accept or decline within 60 seconds.',
        timeout: '⏰ Challenge timed out.',
        roundTimeout: '⏰ Round pick timed out.',
        declined: '❌ Challenge was declined.',
        selected: choice => `You selected ${choice}`,
        alreadyPicked: '✅ Your pick is already locked for this round.',
        notYourGame: 'This is not your game.',
        round: 'Round',
        bet: 'Bet',
        waiting: 'Waiting for both players...',
        footer: 'Rock Paper Scissors',
        btnAccept: 'Accept',
        btnDecline: 'Decline',
        winner: (winner, amount, cur) => `${winner} won the game! (+${amount.toLocaleString()} ${cur})`,
        tieGame: 'The game ended in a tie. Bets were returned.',
        roundWinner: winner => `${winner} won the round.`,
        roundTie: 'Round tied.',
        final: 'Final Result'
    }
};

function choiceLabel(choice, lang = 'en') {
    const item = CHOICES[choice];
    if (!item) return '?';
    return `${item.emoji} ${item[lang]}`;
}

function getRoundWinner(a, b) {
    if (a === b) return 'tie';
    if (
        (a === 'rock' && b === 'scissors') ||
        (a === 'paper' && b === 'rock') ||
        (a === 'scissors' && b === 'paper')
    ) {
        return 'challenger';
    }
    return 'opponent';
}

function truncateText(ctx, text, maxWidth) {
    if (ctx.measureText(text).width <= maxWidth) return text;
    let out = text;
    while (out.length > 1 && ctx.measureText(`${out}...`).width > maxWidth) {
        out = out.slice(0, -1);
    }
    return `${out}...`;
}

function roundRect(ctx, x, y, w, h, r) {
    const radius = Math.min(r, w / 2, h / 2);
    ctx.beginPath();
    ctx.moveTo(x + radius, y);
    ctx.arcTo(x + w, y, x + w, y + h, radius);
    ctx.arcTo(x + w, y + h, x, y + h, radius);
    ctx.arcTo(x, y + h, x, y, radius);
    ctx.arcTo(x, y, x + w, y, radius);
    ctx.closePath();
}

function boardCurrencyText(cur) {
    return String(cur)
        .replace(/<a?:[a-zA-Z0-9_]+:\d+>/g, '')
        .replace(/\s+/g, ' ')
        .trim() || 'Coins';
}

function drawPaperIcon(ctx, x, y, w, h) {
    const size = Math.min(w * 0.58, h * 0.86);
    const px = x + (w - size) / 2;
    const py = y + (h - size) / 2 + 2;
    const fold = size * 0.28;

    ctx.save();
    ctx.fillStyle = '#d9e4eb';
    ctx.beginPath();
    ctx.moveTo(px + size * 0.08, py);
    ctx.lineTo(px + size - fold, py);
    ctx.lineTo(px + size, py + fold);
    ctx.lineTo(px + size, py + size * 0.9);
    ctx.quadraticCurveTo(px + size, py + size, px + size * 0.9, py + size);
    ctx.lineTo(px + size * 0.1, py + size);
    ctx.quadraticCurveTo(px, py + size, px, py + size * 0.9);
    ctx.lineTo(px, py + size * 0.1);
    ctx.quadraticCurveTo(px, py, px + size * 0.08, py);
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#b8c6cf';
    ctx.beginPath();
    ctx.moveTo(px + size - fold, py);
    ctx.lineTo(px + size - fold, py + fold * 0.75);
    ctx.quadraticCurveTo(px + size - fold, py + fold, px + size - fold * 0.72, py + fold);
    ctx.lineTo(px + size, py + fold);
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#9aaab5';
    ctx.lineWidth = size * 0.055;
    ctx.lineCap = 'round';
    for (let i = 0; i < 6; i += 1) {
        const yy = py + size * (0.33 + i * 0.105);
        const lineW = i < 2 ? size * 0.32 : size * 0.58;
        ctx.beginPath();
        ctx.moveTo(px + size * 0.16, yy);
        ctx.lineTo(px + size * 0.16 + lineW, yy);
        ctx.stroke();
    }
    ctx.restore();
}

function drawRockIcon(ctx, x, y, w, h) {
    const cx = x + w / 2;
    const cy = y + h / 2 + h * 0.03;
    const scale = Math.min(w, h) / 250;
    const pts = [
        [-108, 5], [-92, -52], [-40, -88], [24, -92], [70, -62],
        [112, -46], [138, -8], [126, 50], [86, 84], [18, 92],
        [-42, 86], [-76, 54], [-122, 46]
    ];

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);

    ctx.fillStyle = '#72808a';
    ctx.beginPath();
    pts.forEach(([px, py], index) => {
        if (index === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#cfdbe2';
    ctx.beginPath();
    [[-96, -6], [-72, -44], [-18, -64], [28, -54], [58, -26], [34, 8], [-18, 18], [-62, 14]]
        .forEach(([px, py], index) => index ? ctx.lineTo(px, py) : ctx.moveTo(px, py));
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#dce6eb';
    ctx.beginPath();
    [[-58, -58], [-14, -78], [34, -64], [12, -42], [-34, -34]]
        .forEach(([px, py], index) => index ? ctx.lineTo(px, py) : ctx.moveTo(px, py));
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#e8f0f4';
    ctx.beginPath();
    [[-98, 10], [-48, 18], [-8, 42], [-48, 62], [-96, 48]]
        .forEach(([px, py], index) => index ? ctx.lineTo(px, py) : ctx.moveTo(px, py));
    ctx.closePath();
    ctx.fill();

    ctx.fillStyle = '#dbe5ea';
    ctx.beginPath();
    [[16, 32], [76, 22], [108, 42], [62, 72], [8, 66]]
        .forEach(([px, py], index) => index ? ctx.lineTo(px, py) : ctx.moveTo(px, py));
    ctx.closePath();
    ctx.fill();

    ctx.strokeStyle = '#65737d';
    ctx.lineWidth = 8;
    ctx.lineJoin = 'round';
    ctx.beginPath();
    pts.forEach(([px, py], index) => {
        if (index === 0) ctx.moveTo(px, py);
        else ctx.lineTo(px, py);
    });
    ctx.closePath();
    ctx.stroke();

    ctx.fillStyle = '#8fa0aa';
    [
        [-35, -22, 8], [50, -18, 8], [-20, 24, 10],
        [92, 46, 8], [16, 78, 8], [-76, 40, 6]
    ].forEach(([px, py, r]) => {
        ctx.beginPath();
        ctx.ellipse(px, py, r * 1.4, r, -0.35, 0, Math.PI * 2);
        ctx.fill();
    });
    ctx.restore();
}

function drawScissorsIcon(ctx, x, y, w, h) {
    const cx = x + w / 2;
    const cy = y + h / 2;
    const scale = Math.min(w, h) / 230;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.scale(scale, scale);
    ctx.lineCap = 'round';
    ctx.lineJoin = 'round';

    ctx.strokeStyle = '#dbe6ee';
    ctx.lineWidth = 18;
    ctx.beginPath();
    ctx.moveTo(-18, 12);
    ctx.lineTo(92, -82);
    ctx.moveTo(-18, -12);
    ctx.lineTo(92, 82);
    ctx.stroke();

    ctx.strokeStyle = '#8798a4';
    ctx.lineWidth = 8;
    ctx.beginPath();
    ctx.moveTo(0, 0);
    ctx.lineTo(98, -86);
    ctx.moveTo(0, 0);
    ctx.lineTo(98, 86);
    ctx.stroke();

    ctx.fillStyle = '#e8f0f4';
    ctx.strokeStyle = '#7b8b96';
    ctx.lineWidth = 9;
    [
        [-68, -48],
        [-68, 48]
    ].forEach(([px, py]) => {
        ctx.beginPath();
        ctx.ellipse(px, py, 38, 31, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
        ctx.fillStyle = '#ef4444';
        ctx.beginPath();
        ctx.ellipse(px, py, 17, 13, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#e8f0f4';
    });

    ctx.fillStyle = '#ef4444';
    ctx.beginPath();
    ctx.arc(0, 0, 15, 0, Math.PI * 2);
    ctx.fill();
    ctx.restore();
}

async function drawAvatar(ctx, user, x, y, size) {
    if (!canvasApi) return;
    try {
        const url = user.displayAvatarURL({ extension: 'png', size: 128 });
        const avatar = await canvasApi.loadImage(url);
        ctx.save();
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.clip();
        ctx.drawImage(avatar, x, y, size, size);
        ctx.restore();
    } catch (_) {
        ctx.fillStyle = '#5865f2';
        ctx.beginPath();
        ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
        ctx.fill();
    }
}

function drawChoiceArt(ctx, choice, x, y, w, h, revealed) {
    ctx.save();
    ctx.shadowColor = 'rgba(0, 0, 0, 0.34)';
    ctx.shadowBlur = 12;
    ctx.shadowOffsetY = 5;
    roundRect(ctx, x, y, w, h, 12);
    ctx.fillStyle = revealed && choice ? CHOICES[choice].color : '#202633';
    ctx.fill();
    ctx.restore();

    ctx.save();
    roundRect(ctx, x, y, w, h, 12);
    ctx.clip();
    const shine = ctx.createLinearGradient(x, y, x, y + h);
    shine.addColorStop(0, 'rgba(255,255,255,0.10)');
    shine.addColorStop(0.45, 'rgba(255,255,255,0.02)');
    shine.addColorStop(1, 'rgba(0,0,0,0.10)');
    ctx.fillStyle = shine;
    ctx.fillRect(x, y, w, h);
    ctx.restore();

    if (!revealed || !choice) {
        ctx.fillStyle = '#d23b43';
        ctx.font = 'bold 126px Arial';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('?', x + w / 2, y + h / 2 + 8);
        return;
    }

    if (choice === 'paper') drawPaperIcon(ctx, x, y, w, h);
    if (choice === 'rock') drawRockIcon(ctx, x, y, w, h);
    if (choice === 'scissors') drawScissorsIcon(ctx, x, y, w, h);
}

async function buildBoardImage({ interaction, opponent, state, t, cur, reveal = false, resultSide = null }) {
    if (!canvasApi) return null;

    const { createCanvas } = canvasApi;
    const canvas = createCanvas(830, 372);
    const ctx = canvas.getContext('2d');

    ctx.fillStyle = '#11141e';
    roundRect(ctx, 0, 0, canvas.width, canvas.height, 16);
    ctx.fill();

    const frameX = 0;
    const frameY = 0;
    const frameW = 830;
    const frameH = 372;
    const topY = 8;
    const cardY = 92;
    const leftX = 8;
    const rightX = 457;
    const cardW = 365;
    const cardH = 272;

    ctx.fillStyle = '#11141e';
    roundRect(ctx, frameX, frameY, frameW, frameH, 14);
    ctx.fill();
    ctx.strokeStyle = '#222736';
    ctx.lineWidth = 3;
    roundRect(ctx, frameX, frameY, frameW, frameH, 14);
    ctx.stroke();

    ctx.fillStyle = '#202631';
    roundRect(ctx, leftX, topY, cardW, 76, 12);
    ctx.fill();
    roundRect(ctx, rightX, topY, cardW, 76, 12);
    ctx.fill();

    const strokePlayer = (side, color) => {
        const px = side === 'challenger' ? leftX : rightX;
        ctx.strokeStyle = color;
        ctx.lineWidth = 3;
        roundRect(ctx, px, topY, cardW, 76, 12);
        ctx.stroke();
    };

    if (resultSide === 'challenger') {
        strokePlayer('challenger', '#22c55e');
        strokePlayer('opponent', '#ef4444');
    } else if (resultSide === 'opponent') {
        strokePlayer('opponent', '#22c55e');
        strokePlayer('challenger', '#ef4444');
    } else if (resultSide === 'tie') {
        strokePlayer('challenger', '#facc15');
        strokePlayer('opponent', '#facc15');
    }

    await drawAvatar(ctx, interaction.user, leftX + 12, topY + 10, 56);
    await drawAvatar(ctx, opponent, rightX + cardW - 68, topY + 10, 56);

    ctx.fillStyle = '#f5f6fb';
    ctx.font = 'bold 32px Arial';
    ctx.textAlign = 'left';
    ctx.fillText(truncateText(ctx, interaction.user.username, 190), leftX + 82, topY + 49);

    ctx.textAlign = 'right';
    ctx.fillText(truncateText(ctx, opponent.username, 190), rightX + cardW - 82, topY + 49);

    ctx.font = 'bold 42px Arial';
    ctx.textAlign = 'center';
    ctx.fillText(String(state.score.challenger), leftX + cardW - 28, topY + 51);
    ctx.fillText(String(state.score.opponent), rightX + 28, topY + 51);
    ctx.font = 'bold 50px Arial';
    ctx.fillText('VS', canvas.width / 2, topY + 52);

    drawChoiceArt(ctx, state.picks.challenger, leftX, cardY, cardW, cardH, reveal);
    drawChoiceArt(ctx, state.picks.opponent, rightX, cardY, cardW, cardH, reveal);

    return new AttachmentBuilder(await canvas.encode('png'), { name: 'rps-board.png' });
}

function buildChallengeEmbed({ interaction, opponent, amount, cur, t }) {
    return new EmbedBuilder()
        .setTitle(t.challengeTitle)
        .setDescription(`${t.challenge(`<@${interaction.user.id}>`, `<@${opponent.id}>`, amount, cur)}\n\n${t.acceptHint}`)
        .setColor('#5865f2')
        .setFooter({ text: t.footer })
        .setTimestamp();
}

function buildBoardEmbed({ state, t, cur, attachment, description, color = '#5865f2' }) {
    const embed = new EmbedBuilder()
        .setTitle('Rock Paper Scissors')
        .setDescription(description || `**${t.round}:** ${state.round}/${state.rounds}\n**${t.bet}:** ${state.amount.toLocaleString()} ${cur}\n${t.waiting}`)
        .setColor(color)
        .setFooter({ text: t.footer });

    if (attachment) embed.setImage('attachment://rps-board.png');
    return embed;
}

function buildAcceptRow(id, t) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`${id}:accept`)
            .setEmoji('✅')
            .setLabel(t.btnAccept)
            .setStyle(ButtonStyle.Success),
        new ButtonBuilder()
            .setCustomId(`${id}:decline`)
            .setEmoji('✖️')
            .setLabel(t.btnDecline)
            .setStyle(ButtonStyle.Danger)
    );
}

function buildPickRow(id, disabled = false) {
    return new ActionRowBuilder().addComponents(
        new ButtonBuilder()
            .setCustomId(`${id}:pick:rock`)
            .setEmoji(CHOICES.rock.emoji)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(disabled),
        new ButtonBuilder()
            .setCustomId(`${id}:pick:paper`)
            .setEmoji(CHOICES.paper.emoji)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(disabled),
        new ButtonBuilder()
            .setCustomId(`${id}:pick:scissors`)
            .setEmoji(CHOICES.scissors.emoji)
            .setStyle(ButtonStyle.Primary)
            .setDisabled(disabled)
    );
}

function quickEmbed(description, color = '#5865f2') {
    return new EmbedBuilder()
        .setDescription(description)
        .setColor(color);
}

async function updateBoardMessage(messageInteraction, state, interaction, opponent, t, cur, options = {}) {
    const attachment = await buildBoardImage({
        interaction,
        opponent,
        state,
        t,
        cur,
        reveal: options.reveal,
        resultSide: options.resultSide
    });
    const embed = buildBoardEmbed({
        state,
        t,
        cur,
        attachment,
        description: options.description,
        color: options.color
    });

    const payload = {
        content: '',
        embeds: [embed],
        components: options.disableButtons ? [buildPickRow(state.id, true)] : [buildPickRow(state.id)],
        files: attachment ? [attachment] : []
    };

    if (messageInteraction?.update) return messageInteraction.update(payload);
    return messageInteraction.edit(payload);
}

module.exports = {
    data: {
        name: 'rps',
        description: 'Play rock paper scissors against someone.',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Opponent user', type: 6, required: true },
            { name: 'rounds', description: 'Number of rounds', type: 4, required: true, min_value: 1, max_value: 10 },
            { name: 'bet', description: 'Bet amount', type: 4, required: true, min_value: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        await interaction.deferReply();

        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];
        const es = loadEconomySettings();

        if (!es.enabled) {
            return interaction.editReply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ed4245')]
            });
        }

        if (es.gambling?.rps?.enabled === false) {
            return interaction.editReply({
                embeds: [new EmbedBuilder().setDescription(t.rpsDisabled).setColor('#ed4245')]
            });
        }

        const opponent = interaction.options.getUser('user');
        const rounds = interaction.options.getInteger('rounds');
        const amount = interaction.options.getInteger('bet');
        const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        if (!rounds || rounds < 1 || rounds > 10) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.badRounds).setColor('#ed4245')] });
        }

        if (opponent.id === interaction.user.id) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.selfPlay).setColor('#ed4245')] });
        }

        if (opponent.bot) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.botTarget).setColor('#ed4245')] });
        }

        const challengerData = getUser(interaction.guildId, interaction.user.id);
          const _rpsCfg    = es.gambling?.rps || {};
          const _rpsMinBet = _rpsCfg.minBet || 0;
          const _rpsMaxBet = _rpsCfg.maxBet || 0;
          if (_rpsMinBet > 0 && amount < _rpsMinBet) {
              return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.minBet(_rpsMinBet)).setColor('#facc15')] });
          }
          if (_rpsMaxBet > 0 && amount > _rpsMaxBet) {
              return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.maxBet(_rpsMaxBet)).setColor('#facc15')] });
          }
          const _rpsCdMs   = (_rpsCfg.cooldown || 0) * 60000;
          if (_rpsCdMs > 0) {
              const _rpsLeft = cooldownLeft(challengerData.lastRps || 0, _rpsCdMs);
              if (_rpsLeft > 0) {
                  return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(`⏰ يمكنك اللعب مرة أخرى بعد **${formatTime(_rpsLeft)}**.`).setColor('#fcc15')] });
              }
              challengerData.lastRps = Date.now();
          }
        if ((challengerData.wallet || 0) < amount) {
            return interaction.editReply({ embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ed4245')] });
        }

        const gameId = `rps:${interaction.id}`;
        const state = {
            id: gameId,
            round: 1,
            rounds,
            amount,
            score: { challenger: 0, opponent: 0 },
            picks: { challenger: null, opponent: null }
        };

        const message = await interaction.editReply({
            content: `<@${opponent.id}>`,
            embeds: [buildChallengeEmbed({ interaction, opponent, amount, cur, t })],
            components: [buildAcceptRow(gameId, t)]
        });

        try {
            const acceptInteraction = await message.awaitMessageComponent({
                filter: i =>
                    i.user.id === opponent.id &&
                    (i.customId === `${gameId}:accept` || i.customId === `${gameId}:decline`),
                time: GAME_TIMEOUT
            });

            if (acceptInteraction.customId === `${gameId}:decline`) {
                return acceptInteraction.update({
                    content: '',
                    embeds: [new EmbedBuilder().setDescription(t.declined).setColor('#ed4245').setFooter({ text: t.footer })],
                    components: []
                });
            }

            const opponentData = getUser(interaction.guildId, opponent.id);
            if ((opponentData.wallet || 0) < amount) {
                return acceptInteraction.update({
                    content: '',
                    embeds: [new EmbedBuilder().setDescription(t.oppNoMoney(opponent.username)).setColor('#ed4245').setFooter({ text: t.footer })],
                    components: []
                });
            }

            await updateBoardMessage(acceptInteraction, state, interaction, opponent, t, cur);

            while (state.round <= state.rounds) {
                state.picks.challenger = null;
                state.picks.opponent = null;

                const collector = message.createMessageComponentCollector({
                    filter: i => i.customId.startsWith(`${gameId}:pick:`),
                    time: ROUND_TIMEOUT
                });

                const roundCompleted = await new Promise(resolve => {
                    collector.on('collect', async i => {
                        const side =
                            i.user.id === interaction.user.id ? 'challenger' :
                            i.user.id === opponent.id ? 'opponent' :
                            null;

                        if (!side) {
                            return i.reply({
                                embeds: [quickEmbed(t.notYourGame, '#ed4245')],
                                flags: MessageFlags.Ephemeral
                            });
                        }

                        if (state.picks[side]) {
                            return i.reply({
                                embeds: [quickEmbed(t.alreadyPicked, '#facc15')],
                                flags: MessageFlags.Ephemeral
                            });
                        }

                        const choice = i.customId.split(':').pop();
                        state.picks[side] = choice;

                        await i.reply({
                            embeds: [quickEmbed(t.selected(choiceLabel(choice, lang)), '#5865f2')],
                            flags: MessageFlags.Ephemeral
                        });

                        if (state.picks.challenger && state.picks.opponent) {
                            collector.stop('done');
                            resolve(true);
                        }
                    });

                    collector.on('end', (_, reason) => {
                        if (reason !== 'done') resolve(false);
                    });
                });

                if (!roundCompleted) {
                    await interaction.editReply({
                        content: '',
                        embeds: [new EmbedBuilder().setDescription(t.roundTimeout).setColor('#71717a').setFooter({ text: t.footer })],
                        components: []
                    }).catch(() => {});
                    return;
                }

                const winnerSide = getRoundWinner(state.picks.challenger, state.picks.opponent);
                let roundText = t.roundTie;
                if (winnerSide === 'challenger') {
                    state.score.challenger += 1;
                    roundText = t.roundWinner(`<@${interaction.user.id}>`);
                } else if (winnerSide === 'opponent') {
                    state.score.opponent += 1;
                    roundText = t.roundWinner(`<@${opponent.id}>`);
                }

                await updateBoardMessage(message, state, interaction, opponent, t, cur, {
                    reveal: true,
                    resultSide: winnerSide === 'tie' ? null : winnerSide,
                    description:
                        `**${t.round}:** ${state.round}/${state.rounds}\n` +
                        `**${t.bet}:** ${state.amount.toLocaleString()} ${cur}\n` +
                        `${roundText}\n\n` +
                        `<@${interaction.user.id}>: ${choiceLabel(state.picks.challenger, lang)}\n` +
                        `<@${opponent.id}>: ${choiceLabel(state.picks.opponent, lang)}`,
                    disableButtons: state.round === state.rounds
                });

                if (state.round >= state.rounds) break;

                state.round += 1;
                await new Promise(resolve => setTimeout(resolve, 2500));
                await updateBoardMessage(message, state, interaction, opponent, t, cur);
            }

            const challengerFinal = getUser(interaction.guildId, interaction.user.id);
            const opponentFinal = getUser(interaction.guildId, opponent.id);

            let finalDescription;
            let finalColor = '#fee75c';
            let finalWinnerSide = 'tie';

            if (state.score.challenger === state.score.opponent) {
                finalDescription = t.tieGame;
            } else if (state.score.challenger > state.score.opponent) {
                challengerFinal.wallet = (challengerFinal.wallet || 0) + amount;
                challengerFinal.totalEarned = (challengerFinal.totalEarned || 0) + amount;
                opponentFinal.wallet = Math.max((opponentFinal.wallet || 0) - amount, 0);
                saveUser(interaction.guildId, interaction.user.id, challengerFinal);
                saveUser(interaction.guildId, opponent.id, opponentFinal);
                // ── [FIX] Transaction log ──────────────────────────────────
                addTransaction(interaction.guildId, interaction.user.id, 'rps_win', amount, `RPS vs ${opponent.username}`);
                addTransaction(interaction.guildId, opponent.id, 'rps_loss', -amount, `RPS vs ${interaction.user.username}`);
                finalDescription = t.winner(`<@${interaction.user.id}>`, amount, cur);
                finalColor = '#22c55e';
                finalWinnerSide = 'challenger';
            } else {
                challengerFinal.wallet = Math.max((challengerFinal.wallet || 0) - amount, 0);
                opponentFinal.wallet = (opponentFinal.wallet || 0) + amount;
                opponentFinal.totalEarned = (opponentFinal.totalEarned || 0) + amount;
                saveUser(interaction.guildId, interaction.user.id, challengerFinal);
                saveUser(interaction.guildId, opponent.id, opponentFinal);
                // ── [FIX] Transaction log ──────────────────────────────────
                addTransaction(interaction.guildId, opponent.id, 'rps_win', amount, `RPS vs ${interaction.user.username}`);
                addTransaction(interaction.guildId, interaction.user.id, 'rps_loss', -amount, `RPS vs ${opponent.username}`);
                finalDescription = t.winner(`<@${opponent.id}>`, amount, cur);
                finalColor = '#22c55e';
                finalWinnerSide = 'opponent';
            }

            await updateBoardMessage(message, state, interaction, opponent, t, cur, {
                reveal: true,
                resultSide: finalWinnerSide,
                color: finalColor,
                disableButtons: true,
                description:
                    `**${t.final}**\n` +
                    `${finalDescription}\n\n` +
                    `**${interaction.user.username}:** ${state.score.challenger}  •  ` +
                    `**${opponent.username}:** ${state.score.opponent}`
            });
        } catch (_) {
            await interaction.editReply({
                content: '',
                embeds: [new EmbedBuilder().setDescription(t.timeout).setColor('#71717a').setFooter({ text: t.footer })],
                components: []
            }).catch(() => {});
        }
    }
};
