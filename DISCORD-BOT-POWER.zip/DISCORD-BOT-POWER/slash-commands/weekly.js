const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, addEconXP, XP_SOURCES, addUserStat, addTransaction } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:  '⚠️ نظام الاقتصاد معطل حالياً.',
        cooldown:  (time) => `⏰ يمكنك استلام الجائزة الأسبوعية مرة أخرى بعد **${time}**.`,
        received:  (amount, cur) => `🎁 استلمت جائزتك الأسبوعية: **${amount.toLocaleString()} ${cur}**.`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **مبروك! ارتقيت للمستوى ${lvl}!**${reward > 0 ? `\n🎁 مكافأة: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:   'رصيدك الحالي',
        xpGained:  (n) => `+${n} XP`,
        footer:    'الجائزة الأسبوعية'
    },
    en: {
        disabled:  '⚠️ Economy system is currently disabled.',
        cooldown:  (time) => `⏰ You can claim your weekly reward again in **${time}**.`,
        received:  (amount, cur) => `🎁 You've received your weekly reward: **${amount.toLocaleString()} ${cur}**.`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **Level up! You reached Level ${lvl}!**${reward > 0 ? `\n🎁 Reward: **${reward.toLocaleString()} ${cur}**` : ''}`,
        balance:   'Your Balance',
        xpGained:  (n) => `+${n} XP`,
        footer:    'Weekly Reward'
    }
};

function formatRemaining(ms, lang) {
    const totalSeconds = Math.floor(ms / 1000);
    const h = Math.floor(totalSeconds / 3600);
    const m = Math.floor((totalSeconds % 3600) / 60);
    if (lang === 'ar') return `${h} ساعة و ${m} دقيقة`;
    return `${h}h ${m}m`;
}

// Weekly XP is higher than daily since it's once a week
const WEEKLY_XP = 100;

module.exports = {
    data: {
        name: 'weekly',
        description: 'Claim your weekly reward | استلم جائزتك الأسبوعية',
        default_member_permissions: null,
        options: []
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const user       = getUser(interaction.guildId, interaction.user.id);
            const cur        = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
            const weeklyCfg  = es.weekly || {};
            const cooldownMs = (weeklyCfg.cooldown || 168) * 3600000;
            const now        = Date.now();

            if (user.lastWeekly && now - user.lastWeekly < cooldownMs) {
                const remaining = cooldownMs - (now - user.lastWeekly);
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.cooldown(formatRemaining(remaining, lang)))
                        .setColor('#FEE75C')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const min    = weeklyCfg.min || 500;
            const max    = weeklyCfg.max || 2000;
            const amount = Math.floor(Math.random() * (max - min + 1)) + min;

            user.wallet      = (user.wallet      || 0) + amount;
            user.totalEarned = (user.totalEarned || 0) + amount;
            user.lastWeekly  = now;
            saveUser(interaction.guildId, interaction.user.id, user);

            // ── [FIX] XP + Stats + Transaction ────────────────────────────────
            const xpResult = addEconXP(interaction.guildId, interaction.user.id, WEEKLY_XP);
            addUserStat(interaction.guildId, interaction.user.id, 'weeklyClaims', 1);
            addTransaction(interaction.guildId, interaction.user.id, 'weekly', amount, '');

            // ── Level-up suffix ────────────────────────────────────────────────
            let levelSuffix = '';
            if (xpResult.leveled) {
                const _wkSettings = loadEconomySettings();
                const lvlRewards = _wkSettings?.levelRewards || [];
                let rewardTotal  = 0;
                for (let lvl = xpResult.oldLevel + 1; lvl <= xpResult.newLevel; lvl++) {
                    const r = lvlRewards.find(x => x.level === lvl);
                    if (r && r.reward > 0) rewardTotal += r.reward;
                }
                levelSuffix = t.levelUp(xpResult.newLevel, rewardTotal, cur);
            }

            const refreshedUser = getUser(interaction.guildId, interaction.user.id);
            const embed = new EmbedBuilder()
                
                .setDescription(t.received(amount, cur) + levelSuffix)
                .setColor('#57F287')
                .addFields(
                    { name: t.balance, value: `${refreshedUser.wallet.toLocaleString()} ${cur}` },
                    { name: '⭐ XP',   value: t.xpGained(WEEKLY_XP), inline: true }
                )
                .setFooter({ text: t.footer })
                .setTimestamp();

            await interaction.reply({ embeds: [embed] });

        } catch (err) {
            console.error('[weekly] unexpected error:', err);
            const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
