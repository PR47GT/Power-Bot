const {
    EmbedBuilder, MessageFlags,
    ButtonBuilder, ButtonStyle, ActionRowBuilder
} = require('discord.js');
const { getUser, saveUser, getAllUsers, getItem } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        cleared:    (name) => `✅ تم حذف كل عناصر **${name}** بنجاح.`,
        removed:    (item, name) => `✅ تمت إزالة **${item}** من مخزون **${name}**.`,
        added:      (qty, item, name) => `✅ تمت إضافة **${qty}x ${item}** إلى مخزون **${name}**.`,
        inventory:  (name) => `🎒 مخزون **${name}**`,
        viewAll:    '📋 كل الأعضاء الذين يملكون عناصر',
        noOwners:   'لا يوجد أعضاء يملكون عناصر حالياً.',
        emptyInv:   'المخزون فارغ.',
        noItem:     '❌ العنصر غير موجود.',
        notOwned:   '❌ العضو لا يملك هذا العنصر.',
        confirmClr: (name) => `⚠️ هل تريد حذف كل عناصر **${name}**؟`,
        confirmed:  '✅ تم الحذف.',
        cancelled:  '❌ تم الإلغاء.',
        notYou:     '❌ هذا الزر ليس لك.',
        btnConfirm: 'تأكيد',
        btnCancel:  'إلغاء',
        footer:     'إدارة العناصر'
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        cleared:    (name) => `✅ Cleared all items from **${name}**'s inventory.`,
        removed:    (item, name) => `✅ Removed **${item}** from **${name}**'s inventory.`,
        added:      (qty, item, name) => `✅ Added **${qty}x ${item}** to **${name}**'s inventory.`,
        inventory:  (name) => `🎒 ${name}'s Inventory`,
        viewAll:    '📋 All Members with Items',
        noOwners:   'No members currently own any items.',
        emptyInv:   'Inventory is empty.',
        noItem:     '❌ Item not found.',
        notOwned:   "❌ Member doesn't own this item.",
        confirmClr: (name) => `⚠️ Clear all items from **${name}**?`,
        confirmed:  '✅ Cleared.',
        cancelled:  '❌ Cancelled.',
        notYou:     '❌ This button is not for you.',
        btnConfirm: 'Confirm',
        btnCancel:  'Cancel',
        footer:     'Item Management'
    }
};

module.exports = {
    data: {
        name: 'aitem',
        description: 'Admin: Manage member items | إدارة: التحكم بعناصر الأعضاء',
        default_member_permissions: '8',
        options: [
            {
                name: 'user',
                description: 'Member item operations | عمليات عناصر العضو',
                type: 2,
                options: [
                    {
                        name: 'add',
                        description: 'Add an item to a member | أضف عنصراً لعضو',
                        type: 1,
                        options: [
                            { name: 'user',   description: 'Target member | العضو',      type: 6, required: true },
                            { name: 'item',   description: 'Item name/id | اسم العنصر',  type: 3, required: true },
                            { name: 'amount', description: 'Amount | الكمية',             type: 4, required: false, min_value: 1 }
                        ]
                    },
                    {
                        name: 'remove',
                        description: 'Remove an item from a member | أزل عنصراً من عضو',
                        type: 1,
                        options: [
                            { name: 'user', description: 'Target member | العضو',     type: 6, required: true },
                            { name: 'item', description: 'Item name/id | اسم العنصر', type: 3, required: true }
                        ]
                    },
                    {
                        name: 'clear',
                        description: 'Clear all items from a member | احذف كل عناصر عضو',
                        type: 1,
                        options: [
                            { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                        ]
                    },
                    {
                        name: 'inventory',
                        description: "View a member's inventory | شوف مخزون عضو",
                        type: 1,
                        options: [
                            { name: 'user', description: 'Target member | العضو', type: 6, required: true }
                        ]
                    },
                    {
                        name: 'view-all',
                        description: 'View all members who own items | عرض كل الأعضاء الذين يملكون عناصر',
                        type: 1,
                        options: []
                    }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const sub = interaction.options.getSubcommand();

        // ── VIEW-ALL ──────────────────────────────────────────────────────────
        if (sub === 'view-all') {
            const allUsers = getAllUsers(interaction.guildId);
            const lines = [];
            for (const u of allUsers) {
                const inv = u.inventory || {};
                if (typeof inv !== 'object' || Array.isArray(inv)) continue;
                const entries = Object.entries(inv).filter(([, qty]) => qty > 0);
                if (!entries.length) continue;
                const member = await interaction.guild.members.fetch(u.userId).catch(() => null);
                const name   = member ? member.displayName : u.userId;
                const list   = entries.map(([id, qty]) => {
                    const it = getItem(id);
                    const emoji = it?.emoji ? `${it.emoji} ` : '';
                    return `  • ${emoji}${it ? it.name : id} x${qty}`;
                }).join('\n');
                lines.push(`**${name}**\n${list}`);
            }
            const desc = lines.length ? lines.join('\n\n') : t.noOwners;
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(t.viewAll)
                    .setDescription(desc)
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }

        const target   = interaction.options.getUser('user');
        const userData = getUser(interaction.guildId, target.id);
        if (!userData.inventory || Array.isArray(userData.inventory)) userData.inventory = {};

        // ── ADD ───────────────────────────────────────────────────────────────
        if (sub === 'add') {
            const itemId = interaction.options.getString('item');
            const amount = interaction.options.getInteger('amount') || 1;
            const it = getItem(itemId) ||
                (() => { const k = Object.keys(userData.inventory).find(k2 => k2.toLowerCase() === itemId.toLowerCase()); return k ? getItem(k) : null; })();
            const key = it ? (it.id || itemId) : itemId;
            userData.inventory[key] = (userData.inventory[key] || 0) + amount;
            saveUser(interaction.guildId, target.id, userData);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.added(amount, it ? it.name : itemId, target.username))
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        // ── REMOVE ────────────────────────────────────────────────────────────
        if (sub === 'remove') {
            const itemId = interaction.options.getString('item');
            const key = Object.keys(userData.inventory).find(
                k => k === itemId || k.toLowerCase() === itemId.toLowerCase()
            );
            if (!key || !(userData.inventory[key] > 0)) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.notOwned).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            const it = getItem(key);
            delete userData.inventory[key];
            saveUser(interaction.guildId, target.id, userData);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.removed(it ? it.name : key, target.username))
                    .setColor('#ED4245').setFooter({ text: t.footer })]
            });
        }

        // ── CLEAR — with confirmation (fixed: withResponse instead of fetchReply) ─
        if (sub === 'clear') {
            const confirmBtn = new ButtonBuilder()
                .setCustomId('aitem_clear_confirm')
                .setLabel(t.btnConfirm)
                .setStyle(ButtonStyle.Danger);
            const cancelBtn = new ButtonBuilder()
                .setCustomId('aitem_clear_cancel')
                .setLabel(t.btnCancel)
                .setStyle(ButtonStyle.Secondary);
            const row = new ActionRowBuilder().addComponents(confirmBtn, cancelBtn);

            // [FIX] Use withResponse instead of deprecated fetchReply
await interaction.reply({
    embeds: [new EmbedBuilder()
        .setDescription(t.confirmClr(target.username))
        .setColor('#FEE75C')
        .setFooter({ text: t.footer })],
    components: [row],
    flags: MessageFlags.Ephemeral
});

const msg = await interaction.fetchReply();

const collector = msg.createMessageComponentCollector({
    time: 30000
});

           
            collector.on('collect', async btn => {
                if (btn.user.id !== interaction.user.id) {
                    return btn.reply({ content: t.notYou, flags: MessageFlags.Ephemeral });
                }
                collector.stop();
                if (btn.customId === 'aitem_clear_confirm') {
                    const fresh = getUser(interaction.guildId, target.id);
                    fresh.inventory = {};
                    saveUser(interaction.guildId, target.id, fresh);
                    await btn.update({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.cleared(target.username))
                            .setColor('#57F287').setFooter({ text: t.footer })],
                        components: []
                    });
                } else {
                    await btn.update({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.cancelled)
                            .setColor('#71717a').setFooter({ text: t.footer })],
                        components: []
                    });
                }
            });
            collector.on('end', (_, reason) => {
                if (reason === 'time') interaction.editReply({ components: [] }).catch(() => {});
            });
            return;
        }

        // ── INVENTORY ─────────────────────────────────────────────────────────
        if (sub === 'inventory') {
            const entries = Object.entries(userData.inventory).filter(([, qty]) => qty > 0);
            const list = entries.length
                ? entries.map(([id, qty]) => {
                    const it = getItem(id);
                    const emoji = it?.emoji ? `${it.emoji} ` : '';
                    return `• ${emoji}${it ? it.name : id}: **${qty}**`;
                }).join('\n')
                : t.emptyInv;
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(t.inventory(target.username))
                    .setDescription(list)
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }
    
      } catch (err) {
          console.error('[aitem] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
