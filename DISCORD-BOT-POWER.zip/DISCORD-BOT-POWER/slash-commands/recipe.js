const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, getRecipe, getAllRecipes, getItem,
        addEconXP, XP_SOURCES, addUserStat, updateQuestProgress } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:  '⚠️ نظام الاقتصاد معطل حالياً.',
        noRecipe:  '❌ الوصفة غير موجودة.',
        missing:   (items) => `❌ تنقصك المواد:\n${items}`,
        crafted:   (item, qty) => `✅ صنعت **${qty}x ${item}** بنجاح!`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **مبروك! ارتقيت للمستوى ${lvl}!**${reward > 0 ? `\n🎁 مكافأة: **${reward.toLocaleString()} ${cur}**` : ''}`,
        listTitle: '📜 جميع الوصفات',
        noRecipes: 'لا توجد وصفات متاحة.',
        info:      (name, desc, cost) => `**${name}**\n${desc}\nالمتطلبات:\n${cost}`,
        need:      (name, need, have) => `• ${name}: تحتاج ${need} (تملك ${have})`,
        xpGained:  (n) => `+${n} XP`,
        footer:    'التصنيع'
    },
    en: {
        disabled:  '⚠️ Economy system is currently disabled.',
        noRecipe:  '❌ Recipe not found.',
        missing:   (items) => `❌ Missing ingredients:\n${items}`,
        crafted:   (item, qty) => `✅ Crafted **${qty}x ${item}** successfully!`,
        levelUp:   (lvl, reward, cur) => `\n\n⭐ **Level up! You reached Level ${lvl}!**${reward > 0 ? `\n🎁 Reward: **${reward.toLocaleString()} ${cur}**` : ''}`,
        listTitle: '📜 All Recipes',
        noRecipes: 'No recipes available.',
        info:      (name, desc, cost) => `**${name}**\n${desc}\nRequirements:\n${cost}`,
        need:      (name, need, have) => `• ${name}: need ${need} (have ${have})`,
        xpGained:  (n) => `+${n} XP`,
        footer:    'Crafting'
    }
};

module.exports = {
    data: {
        name: 'recipe',
        description: 'Craft items using recipes | تصنيع عناصر',
        default_member_permissions: null,
        options: [
            {
                name: 'craft',
                description: 'Craft an item | صنع عنصر',
                type: 1,
                options: [
                    { name: 'recipe_id', description: 'Recipe ID | معرف الوصفة', type: 3, required: true },
                    { name: 'quantity',  description: 'How many | الكمية',        type: 4, required: false, min_value: 1 }
                ]
            },
            {
                name: 'list',
                description: 'List all recipes | قائمة الوصفات',
                type: 1
            },
            {
                name: 'info',
                description: 'Get info about a recipe | معلومات وصفة',
                type: 1,
                options: [
                    { name: 'recipe_id', description: 'Recipe ID | معرف الوصفة', type: 3, required: true }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const sub  = interaction.options.getSubcommand();
        const user = getUser(interaction.guildId, interaction.user.id);
        const cur  = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
        if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};

        if (sub === 'craft') {
            const recipeId = interaction.options.getString('recipe_id');
            const qty      = interaction.options.getInteger('quantity') || 1;
            const recipe   = getRecipe(recipeId);
            if (!recipe) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noRecipe).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const missing = [];
            for (const [itemId, required] of Object.entries(recipe.ingredients || {})) {
                const owned = user.inventory[itemId] || 0;
                if (owned < required * qty) {
                    const it = getItem(itemId);
                    missing.push(t.need(it ? it.name : itemId, required * qty, owned));
                }
            }
            if (missing.length > 0) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.missing(missing.join('\n'))).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            for (const [itemId, required] of Object.entries(recipe.ingredients || {})) {
                user.inventory[itemId] = (user.inventory[itemId] || 0) - required * qty;
                if (user.inventory[itemId] <= 0) delete user.inventory[itemId];
            }
            user.inventory[recipe.resultId] = (user.inventory[recipe.resultId] || 0) + qty;
            saveUser(interaction.guildId, interaction.user.id, user);

            // ── XP & Stats ────────────────────────────────────────────────────
            const xpAmount = XP_SOURCES.craft_item * qty;
            const xpResult = addEconXP(interaction.guildId, interaction.user.id, xpAmount);
            addUserStat(interaction.guildId, interaction.user.id, 'itemsCrafted', qty);
            updateQuestProgress(interaction.guildId, interaction.user.id, 'craft_items', qty);

            let levelSuffix = '';
            if (xpResult.leveled) {
                const newUser   = getUser(interaction.guildId, interaction.user.id);
                const lvlReward = (newUser.wallet || 0) - user.wallet;
                levelSuffix     = t.levelUp(xpResult.newLevel, Math.max(0, lvlReward), cur);
            }

            const resultItem = getItem(recipe.resultId);
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.crafted(resultItem ? resultItem.name : recipe.resultId, qty) + levelSuffix)
                    .addFields({ name: '⭐ XP', value: t.xpGained(xpAmount), inline: true })
                    .setColor('#57F287').setFooter({ text: t.footer })]
            });
        }

        if (sub === 'list') {
            const recipes = getAllRecipes();
            const list    = recipes.length > 0
                ? recipes.map(r => `**${r.name || r.id}** \`${r.id}\``).join('\n')
                : t.noRecipes;
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setTitle(t.listTitle)
                    .setDescription(list)
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }

        if (sub === 'info') {
            const recipeId = interaction.options.getString('recipe_id');
            const recipe   = getRecipe(recipeId);
            if (!recipe) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.noRecipe).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            const costStr = Object.entries(recipe.ingredients || {}).map(([id, amt]) => {
                const it = getItem(id);
                return `• ${it ? it.name : id}: ${amt}`;
            }).join('\n') || '-';
            return interaction.reply({
                embeds: [new EmbedBuilder()
                    .setDescription(t.info(recipe.name || recipeId, recipe.description || '', costStr))
                    .setColor('#5865F2').setFooter({ text: t.footer })]
            });
        }
    
      } catch (err) {
          console.error('[recipe] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};
