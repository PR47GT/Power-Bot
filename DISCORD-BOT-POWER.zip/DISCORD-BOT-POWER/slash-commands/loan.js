const { EmbedBuilder, MessageFlags } = require('discord.js');
const {
    getUser, saveUser, getLoan, takeLoan, repayLoan,
    applyLoanOverduePenalty, addTransaction, withUserLock
} = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:      '⚠️ نظام الاقتصاد معطل حالياً.',
        loanOff:       '⚠️ نظام القروض معطل حالياً.',
        hasLoan:       '❌ لديك قرض نشط بالفعل. سدّده أولاً.',
        tooMuch:       (max, cur) => `❌ الحد الأقصى للقرض هو **${max.toLocaleString()} ${cur}**.`,
        noLoan:        '❌ ليس لديك قرض نشط.',
        noMoney:       (amount, cur) => `❌ لا تملك **${amount.toLocaleString()} ${cur}** في محفظتك.`,
        taken:         (amount, total, cur, hours) => `✅ حصلت على قرض بقيمة **${amount.toLocaleString()} ${cur}**.\nإجمالي المستحق: **${total.toLocaleString()} ${cur}** خلال **${hours}** ساعة.`,
        repaidFull:    '✅ تمّ سداد القرض بالكامل!',
        repaidPartial: (rem, cur) => `✅ تم سداد جزء من القرض. المتبقي: **${rem.toLocaleString()} ${cur}**.`,
        status:        'حالة القرض',
        principal:     '💰 المبلغ الأصلي',
        totalDue:      '📋 الإجمالي المستحق',
        dueAt:         '📅 موعد السداد',
        noLoanField:   '✅ ليس لديك قروض نشطة.',
        overdue:       '⚠️ القرض متأخر!',
        footer:        'نظام القروض',
        balance:       'رصيد المحفظة',
    },
    en: {
        disabled:      '⚠️ Economy system is currently disabled.',
        loanOff:       '⚠️ Loan system is currently disabled.',
        hasLoan:       '❌ You already have an active loan. Repay it first.',
        tooMuch:       (max, cur) => `❌ Maximum loan amount is **${max.toLocaleString()} ${cur}**.`,
        noLoan:        '❌ You have no active loan.',
        noMoney:       (amount, cur) => `❌ You don't have **${amount.toLocaleString()} ${cur}** in your wallet.`,
        taken:         (amount, total, cur, hours) => `✅ You received a loan of **${amount.toLocaleString()} ${cur}**.\nTotal due: **${total.toLocaleString()} ${cur}** within **${hours}** hours.`,
        repaidFull:    '✅ Loan fully repaid!',
        repaidPartial: (rem, cur) => `✅ Partial repayment done. Remaining: **${rem.toLocaleString()} ${cur}**.`,
        status:        'Loan Status',
        principal:     '💰 Principal',
        totalDue:      '📋 Total Due',
        dueAt:         '📅 Due At',
        noLoanField:   '✅ No active loans.',
        overdue:       '⚠️ Loan is overdue!',
        footer:        'Loan System',
        balance:       'Wallet Balance',
    }
};

function formatDate(ts) {
    return new Date(ts).toLocaleDateString('en-GB', {
        day: '2-digit', month: 'short', year: 'numeric',
        hour: '2-digit', minute: '2-digit'
    });
}

module.exports = {
    data: {
        name: 'loan',
        description: 'Borrow and repay loans | القروض والسداد',
        default_member_permissions: null,
        options: [
            {
                name: 'take',
                description: 'Take a loan | أخذ قرض',
                type: 1,
                options: [
                    { name: 'amount', description: 'Amount to borrow | مبلغ القرض', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'repay',
                description: 'Repay your loan | سداد القرض',
                type: 1,
                options: [
                    { name: 'amount', description: 'Amount to repay | المبلغ للسداد', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'check',
                description: 'Check your loan status | فحص حالة القرض',
                type: 1
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const loanCfg = es.loan || {};
            if (!loanCfg.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.loanOff).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const sub = interaction.options.getSubcommand();
            const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            // ── take ──────────────────────────────────────────────────────────────
            if (sub === 'take') {
                // [FIX-LOAN-02] تغليف أخذ القرض بقفل لمنع أخذ قرضَين متزامنَين
                let replyPayload;
                await withUserLock(interaction.guildId, interaction.user.id, async () => {
                    const existingLoan = getLoan(interaction.guildId, interaction.user.id);
                    if (existingLoan && existingLoan.totalDue > 0) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.hasLoan).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const amount = interaction.options.getInteger('amount');
                    const maxAmt = loanCfg.maxAmount || 5000;
                    if (amount > maxAmt) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.tooMuch(maxAmt, cur)).setColor('#FEE75C')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const interestRate = loanCfg.interestRate || 10;
                    const dueHours     = loanCfg.dueHours     || 24;
                    const loan         = takeLoan(interaction.guildId, interaction.user.id, amount, interestRate, dueHours);
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setTitle(`🏦 ${lang === 'ar' ? 'تم منح القرض' : 'Loan Granted'}`)
                            .setDescription(t.taken(amount, loan.totalDue, cur, dueHours))
                            .addFields(
                                { name: t.principal, value: `${amount.toLocaleString()} ${cur}`, inline: true },
                                { name: '📈 ' + (lang === 'ar' ? 'الفائدة' : 'Interest'), value: `${interestRate}%`, inline: true },
                                { name: t.dueAt, value: formatDate(loan.dueAt), inline: false }
                            )
                            .setColor('#57F287').setFooter({ text: t.footer }).setTimestamp()]
                    };
                });
                return interaction.reply(replyPayload);
            }

            // ── repay ─────────────────────────────────────────────────────────────
            if (sub === 'repay') {
                // [FIX-LOAN-03] تغليف السداد بقفل لمنع سداد متزامن
                let replyPayload;
                await withUserLock(interaction.guildId, interaction.user.id, async () => {
                    const loan = getLoan(interaction.guildId, interaction.user.id);
                    if (!loan) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.noLoan).setColor('#FEE75C')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const amount = interaction.options.getInteger('amount');
                    const user   = getUser(interaction.guildId, interaction.user.id);
                    if ((user.wallet || 0) < amount) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const result = repayLoan(interaction.guildId, interaction.user.id, amount);
                    if (!result.success) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const desc    = result.paid ? t.repaidFull : t.repaidPartial(result.remaining, cur);
                    const color   = result.paid ? '#57F287' : '#FEE75C';
                    const updUser = getUser(interaction.guildId, interaction.user.id);
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(desc)
                            .addFields({ name: t.balance, value: `${(updUser.wallet || 0).toLocaleString()} ${cur}` })
                            .setColor(color).setFooter({ text: t.footer })]
                    };
                });
                return interaction.reply(replyPayload);
            }

            // ── check ─────────────────────────────────────────────────────────────
            if (sub === 'check') {
                // [FIX-LOAN-01] استبدال require('./economyData').loadAll/saveAll المباشرَين
                // بدالة applyLoanOverduePenalty المركزية في economyData.js
                // — تُطبّق الغرامة بأمان عبر getUser/saveUser
                const penaltyRate = loanCfg.overdueRate || 5;
                const loan = applyLoanOverduePenalty(interaction.guildId, interaction.user.id, penaltyRate);
                const user = getUser(interaction.guildId, interaction.user.id);

                const embed = new EmbedBuilder()
                    .setTitle(`🏦 ${interaction.user.username} — ${t.status}`)
                    .setColor(loan ? '#FEE75C' : '#57F287')
                    .setFooter({ text: t.footer })
                    .setTimestamp();

                if (!loan) {
                    embed.setDescription(t.noLoanField);
                } else {
                    const isOverdue = loan.dueAt < Date.now();
                    if (isOverdue) {
                        embed.setDescription(t.overdue);
                        embed.setColor('#ED4245');
                    }
                    embed.addFields(
                        { name: t.principal, value: `${loan.amount.toLocaleString()} ${cur}`, inline: true },
                        { name: t.totalDue,  value: `${loan.totalDue.toLocaleString()} ${cur}`, inline: true },
                        { name: t.dueAt,     value: formatDate(loan.dueAt), inline: false }
                    );
                }

                embed.addFields({ name: t.balance, value: `${(user.wallet || 0).toLocaleString()} ${cur}`, inline: true });
                return interaction.reply({ embeds: [embed] });
            }

        } catch (err) {
            // [FIX-LOG-01] تسجيل السياق الكامل
            console.error('[loan] unexpected error', {
                guildId: interaction.guildId,
                userId:  interaction.user.id,
                sub:     interaction.options.getSubcommand?.(),
                error:   err.message
            });
            const _errEmbed  = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
