const { PermissionFlagsBits, MessageFlags, EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

const LEVEL_DATA_FILE = path.join(__dirname, '../levelData.json');

function loadLevelData() {
    if (fs.existsSync(LEVEL_DATA_FILE)) {
        try { return JSON.parse(fs.readFileSync(LEVEL_DATA_FILE, 'utf8')); } catch(e) {}
    }
    return {};
}

function saveLevelData(data) {
    fs.writeFileSync(LEVEL_DATA_FILE, JSON.stringify(data, null, 2), 'utf8');
}

// ── Translations ─────────────────────────────────────────────────────────────
const T = {
    ar: {
        noPermission:   '❌ هذا الأمر للمشرفين فقط.',
        disabled:       '⚠️ هذا الأمر معطل حالياً.',
        title:          '✅ تم تصفير الكل بنجاح',
        description:    (count, user, time) =>
            `تم تصفير XP والمستوى لجميع الأعضاء بنجاح.\n\n` +
            `**الأعضاء المتأثرون:** ${count}\n` +
            `**تم بواسطة:** ${user}\n` +
            `**اليوم الساعة:** ${time}`,
        error:          (msg) => `❌ حدث خطأ: ${msg || 'خطأ غير معروف'}`
    },
    en: {
        noPermission:   '❌ This command is for administrators only.',
        disabled:       '⚠️ This command is currently disabled.',
        title:          '✅ Full Reset Successful',
        description:    (count, user, time) =>
            `Successfully reset XP and levels for all members.\n\n` +
            `**Members affected:** ${count}\n` +
            `**Reset by:** ${user}\n` +
            `**Today at:** ${time}`,
        error:          (msg) => `❌ Error: ${msg || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'resetall',
        description: ' Reset XP and levels for ALL members | تصفير XP ومستوى جميع الأعضاء',
        default_member_permissions: PermissionFlagsBits.Administrator.toString()
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });

            const isAr = settings?.botLanguage === 'ar';
            const t    = isAr ? T.ar : T.en;

            // Double-check admin permission
            if (!interaction.member.permissions.has(PermissionFlagsBits.Administrator)) {
                return await interaction.editReply({ content: t.noPermission });
            }

            if (commandConfig && !commandConfig.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }

            // ── Reset all users ───────────────────────────────────────────
            const levelData = loadLevelData();
            const count     = Object.keys(levelData).length;

            const resetData = {};
            for (const userId of Object.keys(levelData)) {
                resetData[userId] = {
                    chatXP:    0,
                    voiceXP:   0,
                    chatLevel:  0,
                    voiceLevel: 0
                };
            }
            saveLevelData(resetData);

            // ── Build embed ───────────────────────────────────────────────
            const now     = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });

            const embed = new EmbedBuilder()
                .setColor('#ED4245')
                .setTitle(t.title)
                .setDescription(t.description(count, interaction.user.username, timeStr))
                .setFooter({
                    text:    interaction.user.username,
                    iconURL: interaction.user.displayAvatarURL()
                });

            await interaction.editReply({ embeds: [embed] });

            if (commandConfig && commandConfig.deleteResponse) {
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 10000);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر /resetall:', error.message);
            const isAr = settings?.botLanguage === 'ar';
            const errMsg = isAr
                ? `❌ حدث خطأ: ${error.message || 'خطأ غير معروف'}`
                : `❌ Error: ${error.message || 'Unknown error'}`;
            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ content: errMsg });
                } else {
                    await interaction.reply({ content: errMsg, flags: MessageFlags.Ephemeral });
                }
            } catch(e) {}
        }
    }
};
