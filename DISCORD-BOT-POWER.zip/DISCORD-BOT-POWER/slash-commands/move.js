const { MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌐 ترجمة
const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        notVoice: '❌ الروم المحدد ليس روم صوتي.',
        memberNotFound: '⚠️ هذا العضو غير موجود في السيرفر.',
        botNoPerm: '❌ البوت لا يملك صلاحية نقل الأعضاء في الرومات الصوتية',
        notInVoice: '⚠️ هذا العضو ليس في روم صوتي.',
        channelNotFound: '❌ الروم الصوتي غير موجود.',
        success: (user, channel) => `🎤 تم نقل \`${user}\` إلى ${channel}`,
        failed: (err) => `❌ فشل نقل العضو: ${err}`,
        error: (err) => `❌ حدث خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        notVoice: '❌ The selected channel is not a voice channel.',
        memberNotFound: '⚠️ Member not found in the server.',
        botNoPerm: '❌ Bot does not have permission to move members',
        notInVoice: '⚠️ This member is not in a voice channel.',
        channelNotFound: '❌ Voice channel not found.',
        success: (user, channel) => `🎤 Moved \`${user}\` to ${channel}`,
        failed: (err) => `❌ Failed to move member: ${err}`,
        error: (err) => `❌ An error occurred: ${err || 'Unknown error'}`
    }
};

module.exports = {
    data: {
        name: 'move',
        description: 'Move a member to another voice channel | نقل عضو إلى روم صوتي',
        description_localizations: {
            ar: 'نقل عضو إلى روم صوتي',
            enUS: 'Move a member to another voice channel'
        },
        default_member_permissions: '0x0000000000000010',
        options: [
            { 
                name: 'user', 
                description: 'Member',
                description_localizations: {
                    ar: 'العضو',
                    enUS: 'Member'
                },
                type: 6, 
                required: true 
            },
            { 
                name: 'channel', 
                description: 'Voice channel',
                description_localizations: {
                    ar: 'الروم الصوتي',
                    enUS: 'Voice channel'
                },
                type: 7, 
                required: true 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.move || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const targetChannel = interaction.options.getChannel('channel');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetChannel) {
                return await interaction.editReply({ content: t.channelNotFound });
            }

            if (targetChannel.type !== 2) {
                return await interaction.editReply({ content: t.notVoice });
            }
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!interaction.guild.members.me.permissions.has('MoveMembers')) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (!targetMember.voice.channel) {
                return await interaction.editReply({ content: t.notInVoice });
            }
            
            try {
                await targetMember.voice.setChannel(targetChannel);
                
                const successMessage = t.success(targetUser.tag, targetChannel.name);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ content: t.failed(error.message) });
            }
            
        } catch (error) {
            console.error('❌ Error in move:', error.message);
            
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};