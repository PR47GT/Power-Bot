const { EmbedBuilder } = require('discord.js');
const fs = require('fs');
const path = require('path');

function loadLevelData() {
    const p = path.join(__dirname, '../levelData.json');
    if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch(e) { return {}; }
    }
    return {};
}

function calcLevel(xp) {
    return Math.floor(0.1 * Math.sqrt(xp));
}

const MEDALS = ['🥇', '🥈', '🥉'];

module.exports = {
    data: {
        name: 'top',
        description: '🏆 Shows the server leaderboard for chat and voice activity',
        default_member_permissions: null
    },

    async execute(interaction, client, settings, commandConfig) {
        try {
            await interaction.deferReply();

            const levelData = loadLevelData();
            const isAr = settings.botLanguage === 'ar';

            // ── Build sorted lists ──────────────────────────────────────────
            const allUsers = Object.entries(levelData);

            const chatEntries = allUsers
                .map(([userId, data]) => ({
                    userId,
                    xp:    data.chatXP !== undefined ? (data.chatXP || 0) : (data.xp || 0),
                    level: data.chatLevel !== undefined ? data.chatLevel : calcLevel(data.chatXP !== undefined ? (data.chatXP || 0) : (data.xp || 0))
                }))
                .sort((a, b) => b.xp - a.xp)
                .slice(0, 3);

            const voiceEntries = allUsers
                .map(([userId, data]) => ({
                    userId,
                    xp:    data.voiceXP || 0,
                    level: data.voiceLevel !== undefined ? data.voiceLevel : calcLevel(data.voiceXP || 0)
                }))
                .sort((a, b) => b.xp - a.xp)
                .slice(0, 3);

            // ── Resolve usernames in parallel ───────────────────────────────
            const allIds = [...new Set([
                ...chatEntries.map(e => e.userId),
                ...voiceEntries.map(e => e.userId)
            ])];

            const usernameMap = {};
            await Promise.all(allIds.map(async (id) => {
                try {
                    const member = await interaction.guild.members.fetch(id).catch(() => null);
                    if (member) { usernameMap[id] = member.displayName; return; }
                    const user = await client.users.fetch(id).catch(() => null);
                    if (user) { usernameMap[id] = user.username; return; }
                } catch(e) {}
                usernameMap[id] = 'Unknown';
            }));

            // ── Build ranking text for each column (always 3 slots) ────────
            function buildColumn(entries) {
                const slots = [0, 1, 2].map(i => entries[i] || null);
                return slots.map((entry, i) => {
                    const medal = MEDALS[i];
                    if (!entry) {
                        return `${medal} **${i + 1}.** —\n╰ —\n`;
                    }
                    const xpFmt = entry.xp.toLocaleString();
                    return `${medal} **${i + 1}.** <@${entry.userId}>\n╰ Level ${entry.level} • ${xpFmt} XP\n`;
                }).join('\n');
            }

            const chatText  = buildColumn(chatEntries);
            const voiceText = buildColumn(voiceEntries);

            // ── Time string ─────────────────────────────────────────────────
            const now     = new Date();
            const timeStr = now.toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
            const todayStr = isAr ? 'اليوم' : 'Today';

            // ── Build embed ─────────────────────────────────────────────────
            const embed = new EmbedBuilder()
                .setColor('#2b2d31')
                .setTitle(isAr ? '🏆 لوحة المتصدرين' : 'All-Time 🏆 Server Leaderboard')
                .setDescription(isAr
                    ? 'أفضل الأعضاء حسب نشاط الشات والصوت'
                    : 'Top members ranked by chat and voice activity'
                )
                .addFields(
                    {
                        name: isAr ? '💬 تصنيف الشات' : '💬 Chat Rankings',
                        value: chatText,
                        inline: true
                    },
                    {
                        name: isAr ? '🎵 تصنيف الصوت' : '🎵 Voice Rankings',
                        value: voiceText,
                        inline: true
                    }
                )
                .setFooter({
                    text: isAr
                        ? `تتحدث لوحة المتصدرين كل 30 ثانية • ${todayStr} الساعة ${timeStr}`
                        : `Leaderboard updates every 30 seconds • ${todayStr} at ${timeStr}`,
                    iconURL: client.user?.displayAvatarURL() || null
                });

            const guildIcon = interaction.guild.iconURL({ dynamic: true, size: 128 });
            if (guildIcon) embed.setThumbnail(guildIcon);

            await interaction.editReply({ embeds: [embed] });

            if (commandConfig && commandConfig.deleteResponse) {
                setTimeout(() => { interaction.deleteReply().catch(() => {}); }, 10000);
            }

        } catch (error) {
            console.error('❌ خطأ في أمر /top:', error.message);
            try {
                if (interaction.deferred || interaction.replied) {
                    await interaction.editReply({ content: `❌ حدث خطأ أثناء تحميل لوحة المتصدرين.` });
                } else {
                    await interaction.reply({ content: `❌ حدث خطأ أثناء تحميل لوحة المتصدرين.` });
                }
            } catch(e) {}
        }
    }
};
