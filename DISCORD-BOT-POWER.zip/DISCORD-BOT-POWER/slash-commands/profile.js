const { EmbedBuilder, AttachmentBuilder, MessageFlags } = require('discord.js');
const { getUser, getLeaderboard } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');
const https = require('https');
const http  = require('http');

let createCanvas, loadImage, canvasOK = false;
try { ({ createCanvas, loadImage } = require('@napi-rs/canvas')); canvasOK = true; } catch(_) {
  try { ({ createCanvas, loadImage } = require('canvas')); canvasOK = true; } catch(__) {} }

const T = {
  ar: { disabled:'⚠️ نظام الاقتصاد معطل.', noAccount:'❌ لا يملك هذا العضو حساباً.',
        wallet:'المحفظة', bank:'البنك', total:'الإجمالي', level:'المستوى',
        streak:'السلسلة', days:'يوم', rank:'ترتيب',
        items:'العناصر', chests:'الصناديق' },
  en: { disabled:'⚠️ Economy is disabled.', noAccount:'❌ No account found.',
        wallet:'Wallet', bank:'Bank', total:'Total', level:'Level',
        streak:'Streak', days:'days', rank:'Rank',
        items:'Items', chests:'Chests' }
};

function fetchBuf(url) {
  return new Promise(res => {
    try {
      (url.startsWith('https') ? https : http).get(url, r => {
        const c=[]; r.on('data',d=>c.push(d)); r.on('end',()=>res(Buffer.concat(c))); r.on('error',()=>res(null));
      }).on('error',()=>res(null));
    } catch(e) { res(null); }
  });
}

function fmtNum(n) {
  n = Number(n)||0;
  if (n>=1e9) return (n/1e9).toFixed(1)+'B';
  if (n>=1e6) return (n/1e6).toFixed(1)+'M';
  if (n>=1e3) return (n/1e3).toFixed(1)+'K';
  return String(n);
}

function hexRgb(h) {
  h = (h||'#5865F2').replace('#','');
  if (h.length === 3) h = h[0]+h[0]+h[1]+h[1]+h[2]+h[2];
  return [parseInt(h.slice(0,2),16),parseInt(h.slice(2,4),16),parseInt(h.slice(4,6),16)];
}

function roundRect(ctx, x, y, w, h, r) {
  ctx.beginPath();
  ctx.moveTo(x+r,y); ctx.lineTo(x+w-r,y); ctx.arcTo(x+w,y,x+w,y+r,r);
  ctx.lineTo(x+w,y+h-r); ctx.arcTo(x+w,y+h,x+w-r,y+h,r);
  ctx.lineTo(x+r,y+h); ctx.arcTo(x,y+h,x,y+h-r,r);
  ctx.lineTo(x,y+r); ctx.arcTo(x,y,x+r,y,r); ctx.closePath();
}

function getUserRank(guildId, userId) {
  try {
    const lb = getLeaderboard(guildId, 'total', 1000);
    const idx = lb.findIndex(u => u.userId === userId);
    return idx >= 0 ? idx + 1 : null;
  } catch(_) { return null; }
}

async function buildCard(target, user, es, lang, guildId) {
  const t  = T[lang];
  const pc = es.profileCard || {};
  const showWallet = pc.showWallet !== false;
  const showRank   = pc.showRank   !== false;

  const accent = pc.accentColor || '#5865F2';
  const [ar,ag,ab] = hexRgb(accent);
  const textCol = pc.textColor || '#ffffff';
  const bgBase  = pc.backgroundColor || '#0d0d1a';
  const [br,bg2,bb] = hexRgb(bgBase);
  const overlayAlpha = 1 - ((pc.bgOpacity != null ? Number(pc.bgOpacity) : 80) / 100);

  const W=760, H=280;
  const canvas = createCanvas(W, H);
  const ctx = canvas.getContext('2d');
  ctx.imageSmoothingEnabled = true;

  // ── BACKGROUND ──
  let bgLoaded = false;
  if (pc.backgroundImage && pc.backgroundImage.length > 20) {
    try {
      let buf;
      if (pc.backgroundImage.startsWith('data:')) {
        buf = Buffer.from(pc.backgroundImage.split(',')[1], 'base64');
      } else {
        buf = await fetchBuf(pc.backgroundImage);
      }
      if (buf) {
        const img = await loadImage(buf);
        const s = Math.max(W/img.width, H/img.height);
        ctx.drawImage(img, (W-img.width*s)/2, (H-img.height*s)/2, img.width*s, img.height*s);
        bgLoaded = true;
      }
    } catch(_) {}
  }
  if (!bgLoaded) {
    const gd = ctx.createLinearGradient(0,0,W,H);
    gd.addColorStop(0,  `rgb(${br},${bg2},${bb})`);
    gd.addColorStop(0.45,`rgba(${ar},${ag},${ab},0.3)`);
    gd.addColorStop(1,  `rgb(${Math.max(br-10,0)},${Math.max(bg2-10,0)},${Math.max(bb-10,0)})`);
    ctx.fillStyle = gd;
    ctx.fillRect(0,0,W,H);
    ctx.fillStyle = `rgba(${ar},${ag},${ab},0.07)`;
    for(let x=20;x<W;x+=28) for(let y=20;y<H;y+=28) { ctx.beginPath(); ctx.arc(x,y,1.5,0,Math.PI*2); ctx.fill(); }
  }

  const ov = ctx.createLinearGradient(0,0,0,H);
  ov.addColorStop(0,   `rgba(0,0,0,${overlayAlpha * 0.6})`);
  ov.addColorStop(0.5, `rgba(0,0,0,${overlayAlpha * 0.4})`);
  ov.addColorStop(1,   `rgba(0,0,0,${overlayAlpha * 0.95})`);
  ctx.fillStyle = ov;
  ctx.fillRect(0,0,W,H);

  const tg = ctx.createLinearGradient(0,0,W,0);
  tg.addColorStop(0,'transparent'); tg.addColorStop(0.3,accent); tg.addColorStop(0.7,accent); tg.addColorStop(1,'transparent');
  ctx.fillStyle = tg; ctx.fillRect(0,0,W,4);

  // ── AVATAR ──
  const avX=32, avY=28, avR=52;
  const avCX=avX+avR, avCY=avY+avR;
  try {
    const avUrl = target.displayAvatarURL({ extension:'png', size:128, forceStatic:true });
    const buf = await fetchBuf(avUrl);
    if (buf) {
      const img = await loadImage(buf);
      ctx.save();
      ctx.beginPath(); ctx.arc(avCX,avCY,avR,0,Math.PI*2); ctx.clip();
      ctx.drawImage(img,avX,avY,avR*2,avR*2);
      ctx.restore();
    }
  } catch(_) {}
  ctx.beginPath(); ctx.arc(avCX,avCY,avR+3,0,Math.PI*2);
  ctx.strokeStyle=accent; ctx.lineWidth=3; ctx.stroke();
  ctx.beginPath(); ctx.arc(avCX,avCY,avR+8,0,Math.PI*2);
  ctx.strokeStyle=`rgba(${ar},${ag},${ab},0.25)`; ctx.lineWidth=6; ctx.stroke();

  // ── RANK BADGE ──
  if (showRank) {
    const rankPos = getUserRank(guildId, target.id);
    const rankStr = rankPos ? `# ${rankPos}` : '# -';
    const rbW=90, rbH=32, rbX=W-rbW-18, rbY=14;
    roundRect(ctx,rbX,rbY,rbW,rbH,16);
    ctx.fillStyle=`rgba(${ar},${ag},${ab},0.22)`; ctx.fill();
    ctx.strokeStyle=accent; ctx.lineWidth=1.5; ctx.stroke();
    ctx.fillStyle=accent; ctx.font='bold 14px Arial, sans-serif';
    ctx.textAlign='center'; ctx.fillText(rankStr, rbX+rbW/2, rbY+22); ctx.textAlign='left';
  }

  // ── USERNAME ──
  const fontMap = { Serif:'Georgia,serif', Mono:'Courier New,monospace', Rounded:'Trebuchet MS,sans-serif',
    Display:'Impact,sans-serif', Light:'Helvetica Neue,sans-serif', Bold:'Arial Black,sans-serif',
    Italic:'Georgia,serif', Default:'Arial,sans-serif' };
  const fontFam = fontMap[pc.font||'Default'] || 'Arial,sans-serif';
  ctx.fillStyle=textCol;
  ctx.font=`bold 32px ${fontFam}`;
  ctx.shadowColor='rgba(0,0,0,0.8)'; ctx.shadowBlur=12;
  ctx.fillText(target.username, 160, 90);
  ctx.shadowBlur=0;

  // ── STATS CARDS ──
  const wallet=Number(user.wallet)||0, bank=Number(user.bank)||0;
  const total=wallet+bank, streak=Number(user.dailyStreak)||0, level=Number(user.level)||1;

  const invCount = user.inventory && typeof user.inventory === 'object'
    ? Object.values(user.inventory).reduce((s, v) => s + (Number(v) || 0), 0) : 0;
  const chestCount = user.chests && typeof user.chests === 'object'
    ? Object.values(user.chests).reduce((s, v) => s + (Number(v) || 0), 0) : 0;

  const stats = [];
  if (showWallet) {
    stats.push({ label:t.wallet, value:fmtNum(wallet) });
    stats.push({ label:t.bank,   value:fmtNum(bank)   });
    stats.push({ label:t.total,  value:fmtNum(total)  });
  }
  stats.push({ label:t.level,  value:'Lv.'+level        });
  stats.push({ label:t.streak, value:streak+' '+t.days  });
  stats.push({ label:t.items,  value:String(invCount)   });
  stats.push({ label:t.chests, value:String(chestCount) });

  if (stats.length > 0) {
    const cH  = 72;
    const cY  = H - cH - 16;
    const gap = 8;
    const sidePad = 16;

    // [FIX] Dynamic box width: shrink to fit all boxes within card width.
    // With 7 boxes at 128px each = 944px > 760px (card) → overflow bug.
    // Now boxes are auto-sized to always fit within the available width.
    const maxCW     = 120;
    const available = W - sidePad * 2;
    const rawTotal  = stats.length * maxCW + (stats.length - 1) * gap;
    const cW        = rawTotal > available
        ? Math.floor((available - gap * (stats.length - 1)) / stats.length)
        : maxCW;
    const totalW2   = stats.length * cW + (stats.length - 1) * gap;
    const sx        = Math.round((W - totalW2) / 2);

    // Choose font size based on box width
    const valFontSize   = cW >= 80 ? 20 : (cW >= 60 ? 16 : 13);
    const labelFontSize = cW >= 80 ? 12 : (cW >= 60 ? 10 : 9);

    stats.forEach((s, i) => {
      const cx = sx + i * (cW + gap);
      roundRect(ctx, cx, cY, cW, cH, 10);
      ctx.fillStyle='rgba(0,0,0,0.55)'; ctx.fill();
      ctx.strokeStyle=`rgba(${ar},${ag},${ab},0.35)`; ctx.lineWidth=1; ctx.stroke();

      ctx.fillStyle=textCol;
      ctx.font=`bold ${valFontSize}px ${fontFam}`;
      ctx.textAlign='center';

      // Truncate value if too wide for box
      let valText = s.value;
      const maxTextW = cW - 6;
      while (ctx.measureText(valText).width > maxTextW && valText.length > 1) {
        valText = valText.slice(0, -1);
      }
      ctx.fillText(valText, cx + cW/2, cY + 28);

      ctx.fillStyle='rgba(255,255,255,0.55)';
      ctx.font=`${labelFontSize}px ${fontFam}`;
      let labelText = s.label;
      while (ctx.measureText(labelText).width > maxTextW && labelText.length > 1) {
        labelText = labelText.slice(0, -1) + '…';
      }
      ctx.fillText(labelText, cx + cW/2, cY + 52);
    });
    ctx.textAlign='left';
  }

  // ── BOTTOM ACCENT ──
  const bottomGrad = ctx.createLinearGradient(0,0,W,0);
  bottomGrad.addColorStop(0,'transparent');
  bottomGrad.addColorStop(0.3,`rgba(${ar},${ag},${ab},0.8)`);
  bottomGrad.addColorStop(0.7,`rgba(${ar},${ag},${ab},0.8)`);
  bottomGrad.addColorStop(1,'transparent');
  ctx.fillStyle=bottomGrad; ctx.fillRect(0,H-4,W,4);

  return canvas.toBuffer('image/png');
}

module.exports = {
  data: {
    name:'profile',
    description:"View your economy profile | عرض الملف الاقتصادي",
    default_member_permissions:null,
    options:[{ name:'user', description:'Member to view | العضو', type:6, required:false }]
  },
  async execute(interaction, client, settings) {
    const lang = settings?.botLanguage==='ar'?'ar':'en';
    const es   = loadEconomySettings();
    const t    = T[lang];
    const pc   = es.profileCard || {};
    const showWallet = pc.showWallet !== false;
    const showRank   = pc.showRank   !== false;

    if (!es.enabled) return interaction.reply({ embeds:[new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')], flags:MessageFlags.Ephemeral });

    const target = interaction.options.getUser('user') || interaction.user;
    const user   = getUser(interaction.guildId, target.id);
    if (!user || (user.wallet === undefined && user.bank === undefined))
      return interaction.reply({ embeds:[new EmbedBuilder().setDescription(t.noAccount).setColor('#ED4245')], flags:MessageFlags.Ephemeral });

    if (canvasOK) {
      try {
        await interaction.deferReply();
        const buf = await buildCard(target, user, es, lang, interaction.guildId);
        await interaction.editReply({ files:[new AttachmentBuilder(buf,{name:'profile.png'})] });
        return;
      } catch(e) {
        try { await interaction.deleteReply(); } catch(_) {}
      }
    }

    // ── Embed fallback ──
    const wallet=Number(user.wallet)||0, bank=Number(user.bank)||0;
    const cur=`${es.currency||'🪙'} ${es.currencyName||'Coins'}`;
    const fields = [];
    if (showWallet) {
      fields.push({name:t.wallet, value:`${fmtNum(wallet)} ${cur}`, inline:true});
      fields.push({name:t.bank,   value:`${fmtNum(bank)} ${cur}`,   inline:true});
      fields.push({name:t.total,  value:`${fmtNum(wallet+bank)} ${cur}`, inline:true});
    }
    fields.push({name:t.level,  value:'Lv. '+(user.level||1), inline:true});
    fields.push({name:t.streak, value:`${user.dailyStreak||0} ${t.days}`, inline:true});
    if (showRank) {
      const rankPos = getUserRank(interaction.guildId, target.id);
      if (rankPos) fields.push({name:t.rank, value:`#${rankPos}`, inline:true});
    }

    await interaction.reply({ embeds:[new EmbedBuilder()
      .setTitle(`${target.username}`)
      .setColor(pc.accentColor||'#5865F2')
      .setThumbnail(target.displayAvatarURL({dynamic:true}))
      .addFields(...fields)
      .setTimestamp()] });
  }
};
