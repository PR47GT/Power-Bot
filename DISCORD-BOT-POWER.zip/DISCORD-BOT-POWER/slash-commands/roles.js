const { EmbedBuilder } = require('discord.js');

const T = {
    ar: {
        title: (guildName) => ` قائمة الرتب في ${guildName}`,
        noRoles: 'لا توجد رتب',
        roleFormat: (role, count) => `${role.toString()} - \`${count}\` عضو`,
        more: '... والمزيد',
        footer: (count) => `عدد الرتب: ${count}`,
    },
    en: {
        title: (guildName) => ` Roles in ${guildName}`,
        noRoles: 'No roles found',
        roleFormat: (role, count) => `${role.toString()} - \`${count}\` members`,
        more: '... and more',
        footer: (count) => `Roles count: ${count}`,
    },
};

module.exports = {
    name: 'roles',
    description: 'عرض قائمة الرتب في السيرفر | Display server roles list',
    description_localizations: {
        enUS: 'Display server roles list',
        ar: 'عرض قائمة الرتب في السيرفر',
    },

    async execute(interaction, client, settings, commandConfig) {
        // تحديد اللغة من الإعدادات
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        const guild = interaction.guild;
        
        // جلب الرتب (استثناء @everyone)
        const roles = guild.roles.cache
            .filter(r => r.name !== '@everyone')
            .sort((a, b) => b.position - a.position);
        
        // بناء قائمة الرتب
        let rolesList = '';
        let index = 1;
        
        for (const [_, role] of roles) {
            const memberCount = role.members.size;
            rolesList += `${index}. ${t.roleFormat(role, memberCount)}\n`;
            index++;
        }
        
        // معالجة النص الطويل
        if (rolesList.length > 4000) {
            rolesList = rolesList.slice(0, 3950) + `\n... ${t.more}`;
        }
        
        // إنشاء Embed
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle(t.title(guild.name))
            .setDescription(rolesList || t.noRoles)
            .setFooter({ text: t.footer(roles.size) })
            .setTimestamp();
        
        // إضافة صورة السيرفر كـ thumbnail (اختياري)
        if (guild.iconURL()) {
            embed.setThumbnail(guild.iconURL({ dynamic: true, size: 128 }));
        }
        
        // إرسال الرد
        await interaction.reply({ embeds: [embed] });
        
        // حذف رد البوت تلقائياً إذا كان مفعلاً
        if (commandConfig?.deleteResponse) {
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch(e) {
                    // الرسالة قد تكون محذوفة بالفعل
                }
            }, 5000);
        }
    },
};