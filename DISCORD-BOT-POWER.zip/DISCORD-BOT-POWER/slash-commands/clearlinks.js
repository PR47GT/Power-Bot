const { MessageFlags, PermissionFlagsBits } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

const T = {
    ar: {
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        botNoPerm: '❌ البوت لا يملك صلاحية إدارة الرسائل',
        invalidAmount: '⚠️ عدد الرسائل يجب أن يكون بين 1 و 100',
        noLinks: '⚠️ لم يتم العثور على رسائل تحتوي روابط.',
        searching: (amount) => `🔍 جاري البحث عن روابط في آخر ${amount} رسالة...`,
        deleting: (count) => `🔄 جاري حذف ${count} رسالة تحتوي روابط...`,
        success: (count) => {
            const line = '─'.repeat(27);
          return `✅ تم حذف الرسائل التي تحتوي على روابط\nالعدد: \`${count}\``;
        },
        olderThan14: '⚠️ لا يمكن حذف رسائل أقدم من 14 يوم.',
        failed: (err) => `❌ فشل: ${err}`,
        error: (err) => `❌ خطأ: ${err || 'خطأ غير معروف'}`
    },
    en: {
        disabled: '⚠️ This command is currently disabled.',
        botNoPerm: '❌ Bot does not have permission to manage messages',
        invalidAmount: '⚠️ Amount must be between 1 and 100',
        noLinks: '⚠️ No messages containing links found.',
        searching: (amount) => `🔍 Searching for links in the last ${amount} messages...`,
        deleting: (count) => `🔄 Deleting ${count} messages containing links...`,
        success: (count) => {
            const line = '─'.repeat(28);
            return `✅ Successfully deleted messages\nContent: Links\nAmount: \`${count}\``;
        },
        olderThan14: '⚠️ Cannot delete messages older than 14 days.',
        failed: (err) => `❌ Failed: ${err}`,
        error: (err) => `❌ Error: ${err || 'Unknown error'}`
    }
};

// 🔗 التحقق إذا كانت الرسالة تحتوي رابط
function containsLink(content) {
    const urlRegex = /(https?:\/\/[^\s]+|www\.[^\s]+|discord\.gg\/[^\s]+|discord\.com\/invite\/[^\s]+)/gi;
    return urlRegex.test(content);
}

module.exports = {
    data: {
        name: 'clearlinks',
        description: 'Delete messages containing links | حذف الرسائل التي تحتوي روابط',
        description_localizations: {
            ar: 'حذف الرسائل التي تحتوي روابط',
            'en-US': 'Delete messages containing links'
        },
        default_member_permissions: PermissionFlagsBits.ManageMessages.toString(),
        options: [
            {
                name: 'amount',
                description: 'Number of messages to scan (1-100) | عدد الرسائل للفحص (1-100)',
                description_localizations: {
                    ar: 'عدد الرسائل للفحص (1-100)',
                    'en-US': 'Number of messages to scan (1-100)'
                },
                type: 4,
                required: false
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.clearlinks || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            if (!interaction.guild.members.me.permissions.has('ManageMessages')) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            let amount = interaction.options.getInteger('amount') || 100;
            
            if (amount < 1 || amount > 100) {
                return await interaction.editReply({ content: t.invalidAmount });
            }
            
            await interaction.editReply({ content: t.searching(amount) });
            
            const channel = interaction.channel;
            
            // جمع الرسائل
            const messages = await channel.messages.fetch({ limit: amount }).catch(() => null);
            
            if (!messages || messages.size === 0) {
                return await interaction.editReply({ content: t.noLinks });
            }
            
            // تصفية الرسائل التي تحتوي روابط وليست أقدم من 14 يوم
            const twoWeeksAgo = Date.now() - 14 * 24 * 60 * 60 * 1000;
            const linkMessages = messages.filter(msg => 
                containsLink(msg.content) && 
                msg.createdTimestamp > twoWeeksAgo &&
                !msg.author.bot // اختياري: تجاهل رسائل البوتات
            );
            
            if (linkMessages.length === 0) {
                return await interaction.editReply({ content: t.noLinks });
            }
            
            await interaction.editReply({ content: t.deleting(linkMessages.length) });
            
            // حذف الرسائل
            let deletedCount = 0;
            
            try {
                if (linkMessages.length === 1) {
                    await linkMessages.first().delete();
                    deletedCount = 1;
                } else {
                    const deleted = await channel.bulkDelete(linkMessages, true);
                    deletedCount = deleted.size;
                }
            } catch (error) {
                return await interaction.editReply({ content: t.olderThan14 });
            }
            
            const resultMessage = t.success(deletedCount);
            
            if (config.deleteResponse) {
                await interaction.editReply({ content: resultMessage });
                
                setTimeout(() => {
                    interaction.deleteReply().catch(() => {});
                }, 5000);
            } else {
                await interaction.editReply({ content: resultMessage });
            }
            
        } catch (error) {
            try {
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: t.error(error.message) });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: t.error(error.message),
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch {}
        }
    }
};