const { MessageFlags, EmbedBuilder } = require('discord.js');
const fs   = require('fs');
const path = require('path');

// ─── Palettes ─────────────────────────────────────────────────────────────────
const COLOR_PALETTES = {
    rainbow: {
        nameEn: 'Rainbow Spectrum', nameAr: 'طيف قوس قزح',
        colors: [
            { id: 'red',      nameEn: 'Red',     nameAr: 'أحمر',    hex: '#E74C3C' },
            { id: 'orange',   nameEn: 'Orange',   nameAr: 'برتقالي', hex: '#E67E22' },
            { id: 'yellow',   nameEn: 'Yellow',   nameAr: 'أصفر',    hex: '#F1C40F' },
            { id: 'lime',     nameEn: 'Lime',     nameAr: 'ليموني',  hex: '#2ECC71' },
            { id: 'green',    nameEn: 'Green',    nameAr: 'أخضر',    hex: '#27AE60' },
            { id: 'teal',     nameEn: 'Teal',     nameAr: 'زيتوني',  hex: '#1ABC9C' },
            { id: 'cyan',     nameEn: 'Cyan',     nameAr: 'سماوي',   hex: '#00BCD4' },
            { id: 'blue',     nameEn: 'Blue',     nameAr: 'أزرق',    hex: '#3498DB' },
            { id: 'indigo',   nameEn: 'Indigo',   nameAr: 'نيلي',    hex: '#5865F2' },
            { id: 'purple',   nameEn: 'Purple',   nameAr: 'بنفسجي',  hex: '#9B59B6' },
            { id: 'pink',     nameEn: 'Pink',     nameAr: 'وردي',    hex: '#E91E63' },
            { id: 'rose',     nameEn: 'Rose',     nameAr: 'روز',     hex: '#F06292' },
            { id: 'white',    nameEn: 'White',    nameAr: 'أبيض',    hex: '#FEFEFE' },
            { id: 'gold',     nameEn: 'Gold',     nameAr: 'ذهبي',    hex: '#FFD700' },
            { id: 'silver',   nameEn: 'Silver',   nameAr: 'فضي',     hex: '#BDC3C7' },
        ]
    },
    pastel: {
        nameEn: 'Pastel Dream', nameAr: 'ألوان ناعمة',
        colors: [
            { id: 'pastel_pink',     nameEn: 'Pastel Pink',   nameAr: 'وردي ناعم',    hex: '#FFB3C1' },
            { id: 'pastel_peach',    nameEn: 'Peach',         nameAr: 'خوخي',         hex: '#FFCBA4' },
            { id: 'pastel_yellow',   nameEn: 'Pastel Yellow', nameAr: 'أصفر ناعم',    hex: '#FFF176' },
            { id: 'pastel_lime',     nameEn: 'Pastel Lime',   nameAr: 'ليموني ناعم',  hex: '#CCFF90' },
            { id: 'pastel_mint',     nameEn: 'Mint',          nameAr: 'نعناعي',       hex: '#A8F0C6' },
            { id: 'pastel_sky',      nameEn: 'Sky Blue',      nameAr: 'سماوي ناعم',   hex: '#AECBFA' },
            { id: 'pastel_lavender', nameEn: 'Lavender',      nameAr: 'لافندر',       hex: '#C5B3E6' },
            { id: 'pastel_lilac',    nameEn: 'Lilac',         nameAr: 'ليلكي',        hex: '#D4ADFC' },
            { id: 'pastel_rose',     nameEn: 'Rose Quartz',   nameAr: 'ورد كوارتز',   hex: '#F4B8C1' },
            { id: 'pastel_coral',    nameEn: 'Coral',         nameAr: 'مرجاني',       hex: '#FFB347' },
           { id: 'pastel_teal',     nameEn: 'Pastel Teal',   nameAr: 'زيتوني ناعم',  hex: '#99D9D9' },
            { id: 'pastel_mauve',    nameEn: 'Mauve',         nameAr: 'موف',          hex: '#E8B4B8' },
            { id: 'pastel_seafoam',  nameEn: 'Seafoam',       nameAr: 'زبد البحر',    hex: '#B5EAD7' },
            { id: 'pastel_apricot',  nameEn: 'Apricot',       nameAr: 'مشمشي',        hex: '#FFDAC1' },
            { id: 'pastel_honeydew', nameEn: 'Honeydew',      nameAr: 'أخضر عسلي',    hex: '#E2F0CB' },
            { id: 'pastel_periwinkle', nameEn: 'Periwinkle',  nameAr: 'أزرق بنفسجي',  hex: '#C7CEEA' },
            { id: 'pastel_blush',    nameEn: 'Blush',         nameAr: 'خجول',         hex: '#F6DFEB' },
            { id: 'pastel_cream',    nameEn: 'Peach Cream',   nameAr: 'كريمي خوخي',   hex: '#FFE5D9' },
        ]
    },
    neon: {
        nameEn: 'Neon Glow', nameAr: 'ألوان نيون',
        colors: [
            { id: 'black',          nameEn: 'Black',         nameAr: 'أسود',           hex: '#0D0D0D' },
            { id: 'charcoal',       nameEn: 'Charcoal',      nameAr: 'فحمي',           hex: '#2B2B2B' },
            { id: 'dark_gray',      nameEn: 'Dark Gray',     nameAr: 'رمادي غامق',     hex: '#4A4A4A' },
            { id: 'gray',           nameEn: 'Gray',          nameAr: 'رمادي',          hex: '#6A6A6A' },
            { id: 'mid_gray',       nameEn: 'Mid Gray',      nameAr: 'رمادي متوسط',    hex: '#8A8A8A' },
            { id: 'light_gray',     nameEn: 'Light Gray',    nameAr: 'رمادي فاتح',     hex: '#AAAAAA' },
            { id: 'neon_silver',    nameEn: 'Silver',        nameAr: 'فضي',            hex: '#CCCCCC' },
            { id: 'neon_white',     nameEn: 'White',         nameAr: 'أبيض',           hex: '#EEEEEE' },
            { id: 'soft_white',     nameEn: 'Soft White',    nameAr: 'أبيض هادئ',      hex: '#E8EDE3' },
            { id: 'pale_green',     nameEn: 'Pale Green',    nameAr: 'أخضر باهت',      hex: '#DDE5D1' },
            { id: 'light_olive',    nameEn: 'Light Olive',   nameAr: 'زيتوني فاتح',    hex: '#C9D2B3' },
            { id: 'olive',          nameEn: 'Olive',         nameAr: 'زيتوني',         hex: '#B6C099' },
            { id: 'stone',          nameEn: 'Stone',         nameAr: 'حجري',           hex: '#A39E8B' },
            { id: 'dusty_rose',     nameEn: 'Dusty Rose',    nameAr: 'وردي غامق',      hex: '#8D6E73' },
            { id: 'rosewood',       nameEn: 'Rosewood',      nameAr: 'وردي خشبي',      hex: '#7B4F5C' },
            { id: 'wine',           nameEn: 'Wine',          nameAr: 'خمري',           hex: '#6A2C48' },
            { id: 'deep_purple',    nameEn: 'Deep Purple',   nameAr: 'بنفسجي داكن',    hex: '#2E1A47' },
            { id: 'dark_purple',    nameEn: 'Dark Purple',   nameAr: 'بنفسجي غامق',    hex: '#3B2A5A' },
            { id: 'neon_purple',    nameEn: 'Purple',        nameAr: 'بنفسجي',         hex: '#4A3A6D' },
            { id: 'mid_purple',     nameEn: 'Mid Purple',    nameAr: 'بنفسجي متوسط',   hex: '#5B4C80' },
            { id: 'soft_purple',    nameEn: 'Soft Purple',   nameAr: 'بنفسجي هادئ',    hex: '#6C5F92' },
            { id: 'lavender',       nameEn: 'Lavender',      nameAr: 'لافندر',         hex: '#7E73A5' },
            { id: 'light_lavender', nameEn: 'Light Lavender',nameAr: 'لافندر فاتح',    hex: '#9187B7' },
            { id: 'pastel_purple',  nameEn: 'Pastel Purple', nameAr: 'بنفسجي فاتح',    hex: '#A59CCA' },
            { id: 'ice_blue',       nameEn: 'Ice Blue',      nameAr: 'أزرق ثلجي',      hex: '#CDE7F0' },
            { id: 'light_sky',      nameEn: 'Light Sky',     nameAr: 'سماوي فاتح',     hex: '#A9D3E3' },
            { id: 'sky_blue',       nameEn: 'Sky Blue',      nameAr: 'سماوي',          hex: '#85BED6' },
            { id: 'soft_blue',      nameEn: 'Soft Blue',     nameAr: 'أزرق هادئ',      hex: '#61AAC9' },
            { id: 'neon_blue',      nameEn: 'Blue',          nameAr: 'أزرق',           hex: '#4D95B5' },
            { id: 'steel_blue',     nameEn: 'Steel Blue',    nameAr: 'أزرق فولاذي',    hex: '#3A7FA1' },
            { id: 'deep_blue',      nameEn: 'Deep Blue',     nameAr: 'أزرق داكن',      hex: '#2A6A8D' },
            { id: 'navy_blue',      nameEn: 'Navy Blue',     nameAr: 'كحلي',           hex: '#1D5679' },
            { id: 'pale_beige',     nameEn: 'Pale Beige',    nameAr: 'بيج فاتح',       hex: '#EAD9D6' },
            { id: 'light_beige',    nameEn: 'Light Beige',   nameAr: 'بيج',            hex: '#D8BEB8' },
            { id: 'beige',          nameEn: 'Beige',         nameAr: 'بيج متوسط',      hex: '#C6A39A' },
            { id: 'soft_brown',     nameEn: 'Soft Brown',    nameAr: 'بني فاتح',       hex: '#B4887C' },
            { id: 'neon_brown',     nameEn: 'Brown',         nameAr: 'بني',            hex: '#A26D5E' },
            { id: 'dark_brown',     nameEn: 'Dark Brown',    nameAr: 'بني غامق',       hex: '#8F5446' },
            { id: 'deep_brown',     nameEn: 'Deep Brown',    nameAr: 'بني داكن',       hex: '#7C3B2E' },
            { id: 'chocolate',      nameEn: 'Chocolate',     nameAr: 'شوكولا',         hex: '#6A241A' },
            { id: 'dark_teal',      nameEn: 'Dark Teal',     nameAr: 'تركواز داكن',    hex: '#1F4F46' },
            { id: 'neon_teal',      nameEn: 'Teal',          nameAr: 'تركواز',         hex: '#2E6B5E' },
            { id: 'sea_green',      nameEn: 'Sea Green',     nameAr: 'أخضر بحري',      hex: '#3E8776' },
            { id: 'aqua_green',     nameEn: 'Aqua Green',    nameAr: 'أخضر مائي',      hex: '#4FA38F' },
            { id: 'neon_mint',      nameEn: 'Mint',          nameAr: 'نعناعي',         hex: '#60BFA8' },
            { id: 'light_mint',     nameEn: 'Light Mint',    nameAr: 'نعناعي فاتح',    hex: '#7BD0B9' },
            { id: 'pale_mint',      nameEn: 'Pale Mint',     nameAr: 'نعناعي باهت',    hex: '#96E0CB' },
            { id: 'ice_mint',       nameEn: 'Ice Mint',      nameAr: 'نعناعي ثلجي',    hex: '#B1F0DD' },
            { id: 'cream',          nameEn: 'Cream',         nameAr: 'كريمي',          hex: '#F2E5B8' },
            { id: 'light_gold',     nameEn: 'Light Gold',    nameAr: 'ذهبي فاتح',      hex: '#E6C76A' },
            { id: 'neon_gold',      nameEn: 'Gold',          nameAr: 'ذهبي',           hex: '#D9A83D' },
            { id: 'neon_orange',    nameEn: 'Orange',        nameAr: 'برتقالي',        hex: '#CC8A20' },
            { id: 'dark_orange',    nameEn: 'Dark Orange',   nameAr: 'برتقالي غامق',   hex: '#BF6C10' },
            { id: 'burnt_orange',   nameEn: 'Burnt Orange',  nameAr: 'برتقالي محروق',  hex: '#A85A0D' },
            { id: 'deep_orange',    nameEn: 'Deep Orange',   nameAr: 'برتقالي داكن',   hex: '#8F480A' },
            { id: 'brown_orange',   nameEn: 'Brown Orange',  nameAr: 'برتقالي بني',    hex: '#773707' },
        ]
    },
    earthy: {
        nameEn: 'Earthy Tones', nameAr: 'ألوان ترابية',
        colors: [
            { id: 'red_1',    nameEn: 'Dark Red',      nameAr: 'أحمر داكن',        hex: '#5A0B00' },
            { id: 'red_2',    nameEn: 'Red Brown',     nameAr: 'أحمر بني',         hex: '#7A1405' },
            { id: 'red_3',    nameEn: 'Crimson',       nameAr: 'قرمزي',            hex: '#A32010' },
            { id: 'red_4',    nameEn: 'Bright Red',    nameAr: 'أحمر ساطع',        hex: '#D12E1B' },
            { id: 'red_5',    nameEn: 'Coral Red',     nameAr: 'أحمر مرجاني',      hex: '#F04E37' },
            { id: 'red_6',    nameEn: 'Salmon',        nameAr: 'سلموني',           hex: '#F07A6A' },
            { id: 'red_7',    nameEn: 'Soft Pink',     nameAr: 'وردي ناعم',        hex: '#E9A19A' },
            { id: 'red_8',    nameEn: 'Light Rose',    nameAr: 'وردي فاتح',        hex: '#E8B9B4' },
            { id: 'blue_1',   nameEn: 'Lavender',      nameAr: 'لافندر',           hex: '#B8B5FF' },
            { id: 'blue_2',   nameEn: 'Soft Violet',   nameAr: 'بنفسجي ناعم',      hex: '#9F9CFF' },
            { id: 'blue_3',   nameEn: 'Periwinkle',    nameAr: 'أزرق بنفسجي',      hex: '#7B78FF' },
            { id: 'blue_4',   nameEn: 'Bright Blue',   nameAr: 'أزرق ساطع',        hex: '#4E49FF' },
            { id: 'blue_5',   nameEn: 'Royal Blue',    nameAr: 'أزرق ملكي',        hex: '#2E27F0' },
            { id: 'blue_6',   nameEn: 'Deep Blue',     nameAr: 'أزرق عميق',        hex: '#1D16C9' },
            { id: 'blue_7',   nameEn: 'Indigo',        nameAr: 'نيلي',             hex: '#140FA3' },
            { id: 'blue_8',   nameEn: 'Navy',          nameAr: 'كحلي',             hex: '#0C087A' },
            { id: 'green_1',  nameEn: 'Dark Green',    nameAr: 'أخضر داكن',        hex: '#1F5A12' },
            { id: 'green_2',  nameEn: 'Forest Green',  nameAr: 'أخضر غابة',        hex: '#2F7A1D' },
            { id: 'green_3',  nameEn: 'Leaf Green',    nameAr: 'أخضر ورقي',        hex: '#46A329' },
            { id: 'green_4',  nameEn: 'Bright Green',  nameAr: 'أخضر ساطع',        hex: '#63D93A' },
            { id: 'green_5',  nameEn: 'Lime Green',    nameAr: 'أخضر ليموني',      hex: '#7EF04F' },
            { id: 'green_6',  nameEn: 'Light Lime',    nameAr: 'ليموني فاتح',      hex: '#92F76A' },
            { id: 'green_7',  nameEn: 'Mint Green',    nameAr: 'أخضر نعناعي',      hex: '#A6F98A' },
            { id: 'green_8',  nameEn: 'Pale Green',    nameAr: 'أخضر باهت',        hex: '#BBFCA8' },
            { id: 'purple_1', nameEn: 'Light Lilac',   nameAr: 'ليلكي فاتح',       hex: '#E0B3E6' },
            { id: 'purple_2', nameEn: 'Pink Lilac',    nameAr: 'ليلكي وردي',       hex: '#D08AE0' },
            { id: 'purple_3', nameEn: 'Violet',        nameAr: 'بنفسجي',           hex: '#BA63D9' },
            { id: 'purple_4', nameEn: 'Bright Purple', nameAr: 'بنفسجي ساطع',      hex: '#A03AF0' },
            { id: 'purple_5', nameEn: 'Royal Purple',  nameAr: 'بنفسجي ملكي',      hex: '#8427D9' },
            { id: 'purple_6', nameEn: 'Deep Purple',   nameAr: 'بنفسجي عميق',      hex: '#6A1DC0' },
            { id: 'purple_7', nameEn: 'Dark Violet',   nameAr: 'بنفسجي داكن',      hex: '#5314A3' },
            { id: 'purple_8', nameEn: 'Eggplant',      nameAr: 'بنفسجي باذنجاني',  hex: '#3C0C7A' },
            { id: 'orange_1', nameEn: 'Dark Brown',    nameAr: 'بني داكن',         hex: '#5A3200' },
            { id: 'orange_2', nameEn: 'Brown Orange',  nameAr: 'برتقالي بني',      hex: '#7A4605' },
            { id: 'orange_3', nameEn: 'Amber Brown',   nameAr: 'عنبر بني',         hex: '#A3631D' },
            { id: 'orange_4', nameEn: 'Orange Gold',   nameAr: 'برتقالي ذهبي',     hex: '#C97A27' },
            { id: 'orange_5', nameEn: 'Bright Orange', nameAr: 'برتقالي ساطع',     hex: '#E08A2E' },
            { id: 'orange_6', nameEn: 'Pumpkin',       nameAr: 'قرع',              hex: '#F0A03A' },
            { id: 'orange_7', nameEn: 'Light Orange',  nameAr: 'برتقالي فاتح',     hex: '#F7B45A' },
            { id: 'orange_8', nameEn: 'Peach',         nameAr: 'خوخي',             hex: '#FCD29A' },
            { id: 'cyan_1',   nameEn: 'Dark Teal',     nameAr: 'تركوازي داكن',     hex: '#234F52' },
            { id: 'cyan_2',   nameEn: 'Teal',          nameAr: 'تركوازي',          hex: '#2F6F73' },
            { id: 'cyan_3',   nameEn: 'Sea Blue',      nameAr: 'أزرق بحري',        hex: '#3F8F94' },
            { id: 'cyan_4',   nameEn: 'Aqua Blue',     nameAr: 'أزرق مائي',        hex: '#52B5BA' },
            { id: 'cyan_5',   nameEn: 'Bright Cyan',   nameAr: 'سماوي ساطع',       hex: '#63D3D9' },
            { id: 'cyan_6',   nameEn: 'Light Cyan',    nameAr: 'سماوي فاتح',       hex: '#7AEAF0' },
            { id: 'cyan_7',   nameEn: 'Pale Aqua',     nameAr: 'مائي باهت',        hex: '#98F3F7' },
            { id: 'cyan_8',   nameEn: 'Ice Blue',      nameAr: 'أزرق جليدي',       hex: '#B8FAFC' },
            { id: 'yellow_1', nameEn: 'Cream Yellow',  nameAr: 'أصفر كريمي',       hex: '#F2EFA0' },
            { id: 'yellow_2', nameEn: 'Soft Yellow',   nameAr: 'أصفر ناعم',        hex: '#F0E76A' },
            { id: 'yellow_3', nameEn: 'Sunny Yellow',  nameAr: 'أصفر مشمس',        hex: '#E8D93A' },
            { id: 'yellow_4', nameEn: 'Golden Yellow', nameAr: 'أصفر ذهبي',        hex: '#D9C227' },
            { id: 'yellow_5', nameEn: 'Mustard',       nameAr: 'خردلي',            hex: '#C0A81D' },
            { id: 'yellow_6', nameEn: 'Dark Gold',     nameAr: 'ذهبي داكن',        hex: '#A38C14' },
            { id: 'yellow_7', nameEn: 'Olive Gold',    nameAr: 'ذهبي زيتوني',      hex: '#7A680C' },
            { id: 'yellow_8', nameEn: 'Brown Gold',   nameAr: 'ذهبي بني',         hex: '#5A4B08' },
        ]
    },
    ocean: {
        nameEn: 'Ocean Breeze', nameAr: 'نسيم المحيط',
        colors: [
            { id: 'ocean_1',  nameEn: 'Midnight Blue', nameAr: 'أزرق منتصف الليل', hex: '#03045E' },
            { id: 'ocean_2',  nameEn: 'Deep Ocean',    nameAr: 'محيط عميق',        hex: '#023E8A' },
            { id: 'ocean_3',  nameEn: 'Ocean Blue',    nameAr: 'أزرق محيطي',       hex: '#0077B6' },
            { id: 'ocean_4',  nameEn: 'Cerulean',      nameAr: 'أزرق سماوي',       hex: '#0096C7' },
            { id: 'ocean_5',  nameEn: 'Turquoise Blue',nameAr: 'أزرق فيروزي',      hex: '#00B4D8' },
            { id: 'ocean_6',  nameEn: 'Aqua',          nameAr: 'مائي',             hex: '#48CAE4' },
            { id: 'ocean_7',  nameEn: 'Light Aqua',    nameAr: 'مائي فاتح',        hex: '#90E0EF' },
            { id: 'ocean_8',  nameEn: 'Pale Aqua',     nameAr: 'مائي باهت',        hex: '#ADE8F4' },
            { id: 'ocean_9',  nameEn: 'Ice Blue',      nameAr: 'أزرق ثلجي',        hex: '#CAF0F8' },
            { id: 'ocean_10', nameEn: 'Dark Teal',     nameAr: 'تركوازي داكن',     hex: '#006466' },
            { id: 'ocean_11', nameEn: 'Deep Teal',     nameAr: 'تركوازي عميق',     hex: '#144552' },
            { id: 'ocean_12', nameEn: 'Navy Slate',    nameAr: 'كحلي رمادي',       hex: '#1B3A4B' },
            { id: 'ocean_13', nameEn: 'Sea Blue',      nameAr: 'أزرق بحري',        hex: '#065A82' },
            { id: 'ocean_14', nameEn: 'Marine Blue',   nameAr: 'أزرق بحري غامق',   hex: '#0A4D68' },
            { id: 'ocean_15', nameEn: 'Lagoon',        nameAr: 'بحيرة مرجانية',    hex: '#088395' },
            { id: 'ocean_16', nameEn: 'Bright Cyan',   nameAr: 'سماوي ساطع',       hex: '#05BFDB' },
            { id: 'ocean_17', nameEn: 'Teal Green',    nameAr: 'أخضر تركوازي',     hex: '#00A9A5' },
            { id: 'ocean_18', nameEn: 'Sky Blue',      nameAr: 'أزرق سماوي فاتح',  hex: '#37AFE1' },
            { id: 'ocean_19', nameEn: 'Steel Navy',    nameAr: 'كحلي فولاذي',      hex: '#1E3A5F' },
            { id: 'ocean_20', nameEn: 'Denim Blue',    nameAr: 'أزرق جينز',        hex: '#274472' },
        ]
    },
    sunset: {
        nameEn: 'Sunset Glow', nameAr: 'توهج الغروب',
        colors: [
            { id: 'sunset_1',  nameEn: 'Red',           nameAr: 'أحمر',            hex: '#FF0000' },
            { id: 'sunset_2',  nameEn: 'Orange Red',    nameAr: 'أحمر برتقالي',    hex: '#FF4500' },
            { id: 'sunset_3',  nameEn: 'Tomato',        nameAr: 'طماطمي',          hex: '#FF6347' },
            { id: 'sunset_4',  nameEn: 'Coral',         nameAr: 'مرجاني',          hex: '#FF7F50' },
            { id: 'sunset_5',  nameEn: 'Light Salmon',  nameAr: 'سلموني فاتح',     hex: '#FFA07A' },
            { id: 'sunset_6',  nameEn: 'Sunset Orange', nameAr: 'برتقالي الغروب',  hex: '#FFB347' },
            { id: 'sunset_7',  nameEn: 'Gold',          nameAr: 'ذهبي',            hex: '#FFD700' },
            { id: 'sunset_8',  nameEn: 'Pink',          nameAr: 'وردي',            hex: '#FFC0CB' },
            { id: 'sunset_9',  nameEn: 'Hot Pink',      nameAr: 'وردي فاقع',       hex: '#FF69B4' },
            { id: 'sunset_10', nameEn: 'Medium Violet', nameAr: 'بنفسجي متوسط',    hex: '#C71585' },
            { id: 'sunset_11', nameEn: 'Dark Magenta',  nameAr: 'أرجواني داكن',    hex: '#8B008B' },
            { id: 'sunset_12', nameEn: 'Indigo',        nameAr: 'نيلي',            hex: '#4B0082' },
            { id: 'sunset_13', nameEn: 'Dark Orange',   nameAr: 'برتقالي داكن',    hex: '#FF8C00' },
            { id: 'sunset_14', nameEn: 'Sunset Red',    nameAr: 'أحمر الغروب',     hex: '#FF5733' },
            { id: 'sunset_15', nameEn: 'Rose Red',      nameAr: 'أحمر وردي',       hex: '#E84855' },
            { id: 'sunset_16', nameEn: 'Burnt Coral',   nameAr: 'مرجاني محروق',    hex: '#EE6C4D' },
            { id: 'sunset_17', nameEn: 'Flame Orange',  nameAr: 'برتقالي ناري',    hex: '#F26430' },
            { id: 'sunset_18', nameEn: 'Dusty Rose',    nameAr: 'وردي غامق',       hex: '#DA627D' },
            { id: 'sunset_19', nameEn: 'Berry',         nameAr: 'توتي',            hex: '#A53860' },
            { id: 'sunset_20', nameEn: 'Deep Magenta',  nameAr: 'أرجواني عميق',    hex: '#6A0572' },
            { id: 'sunset_21', nameEn: 'Amber Glow',    nameAr: 'توهج العنبر',     hex: '#FFAA5A' },
            { id: 'sunset_22', nameEn: 'Peach Orange',  nameAr: 'برتقالي خوخي',    hex: '#FF7B54' },
            { id: 'sunset_23', nameEn: 'Crimson Red',   nameAr: 'قرمزي',           hex: '#D72638' },
            { id: 'sunset_24', nameEn: 'Deep Wine',     nameAr: 'خمري عميق',       hex: '#9C1F3E' },
        ]
    },
    monochrome: {
        nameEn: 'Monochrome', nameAr: 'أحادي اللون',
        colors: [
            { id: 'mono_1',  nameEn: 'Black',        nameAr: 'أسود',            hex: '#000000' },
            { id: 'mono_2',  nameEn: 'Near Black',   nameAr: 'أسود تقريباً',    hex: '#0D0D0D' },
            { id: 'mono_3',  nameEn: 'Charcoal',     nameAr: 'فحمي',            hex: '#1A1A1A' },
            { id: 'mono_4',  nameEn: 'Dark Gray',    nameAr: 'رمادي غامق',      hex: '#262626' },
            { id: 'mono_5',  nameEn: 'Deep Gray',    nameAr: 'رمادي عميق',      hex: '#333333' },
            { id: 'mono_6',  nameEn: 'Graphite',     nameAr: 'غرافيتي',         hex: '#404040' },
            { id: 'mono_7',  nameEn: 'Gray',         nameAr: 'رمادي',           hex: '#4D4D4D' },
            { id: 'mono_8',  nameEn: 'Medium Gray',  nameAr: 'رمادي متوسط',     hex: '#595959' },
            { id: 'mono_9',  nameEn: 'Slate Gray',   nameAr: 'رمادي إردوازي',   hex: '#666666' },
            { id: 'mono_10', nameEn: 'Mid Gray',     nameAr: 'رمادي وسطي',      hex: '#808080' },
            { id: 'mono_11', nameEn: 'Light Gray',   nameAr: 'رمادي فاتح',      hex: '#999999' },
            { id: 'mono_12', nameEn: 'Silver Gray',  nameAr: 'رمادي فضي',       hex: '#B3B3B3' },
            { id: 'mono_13', nameEn: 'Silver',       nameAr: 'فضي',             hex: '#CCCCCC' },
            { id: 'mono_14', nameEn: 'Pale Gray',    nameAr: 'رمادي باهت',      hex: '#E6E6E6' },
            { id: 'mono_15', nameEn: 'Off White',    nameAr: 'أبيض مائل',       hex: '#F5F5F5' },
            { id: 'mono_16', nameEn: 'White',        nameAr: 'أبيض',            hex: '#FFFFFF' },
        ]
    },
    metallic: {
        nameEn: 'Metallic Shine', nameAr: 'لمعان معدني',
        colors: [
            { id: 'metal_1',  nameEn: 'Rose Gold',    nameAr: 'ذهب وردي',       hex: '#B76E79' },
            { id: 'metal_2',  nameEn: 'Silver',       nameAr: 'فضي',            hex: '#C0C0C0' },
            { id: 'metal_3',  nameEn: 'Gold',         nameAr: 'ذهبي',           hex: '#D4AF37' },
            { id: 'metal_4',  nameEn: 'Bronze',       nameAr: 'برونزي',         hex: '#CD7F32' },
            { id: 'metal_5',  nameEn: 'Copper',       nameAr: 'نحاسي',          hex: '#B87333' },
            { id: 'metal_6',  nameEn: 'Bronze Gray',  nameAr: 'برونزي رمادي',   hex: '#8C7853' },
            { id: 'metal_7',  nameEn: 'Platinum',     nameAr: 'بلاتيني',        hex: '#E5E4E2' },
            { id: 'metal_8',  nameEn: 'Dark Silver',  nameAr: 'فضي داكن',       hex: '#A9A9A9' },
            { id: 'metal_9',  nameEn: 'Bright Gold',  nameAr: 'ذهبي ساطع',      hex: '#FFD700' },
            { id: 'metal_10', nameEn: 'Steel Gray',   nameAr: 'رمادي فولاذي',   hex: '#71797E' },
            { id: 'metal_11', nameEn: 'Slate Gray',   nameAr: 'رمادي إردوازي',  hex: '#54626F' },
            { id: 'metal_12', nameEn: 'Gunmetal',     nameAr: 'معدني داكن',     hex: '#3B3C36' },
            { id: 'metal_13', nameEn: 'Antique Gold', nameAr: 'ذهبي عتيق',      hex: '#C9B037' },
            { id: 'metal_14', nameEn: 'Brass',        nameAr: 'نحاسي أصفر',     hex: '#AF8F5C' },
            { id: 'metal_15', nameEn: 'Ash Gray',     nameAr: 'رمادي رمادي',    hex: '#9E9E9E' },
            { id: 'metal_16', nameEn: 'Iron Gray',    nameAr: 'رمادي حديدي',    hex: '#7C7C7C' },
            { id: 'metal_17', nameEn: 'Champagne',    nameAr: 'شامبانيا',       hex: '#DDD6C1' },
            { id: 'metal_18', nameEn: 'Bronze Gold',  nameAr: 'برونزي ذهبي',    hex: '#B08D57' },
            { id: 'metal_19', nameEn: 'Olive Metal',  nameAr: 'معدني زيتوني',   hex: '#8D8974' },
            { id: 'metal_20', nameEn: 'Pewter',       nameAr: 'قصديري',         hex: '#5D5C61' },
        ]
    },
    tropical: {
        nameEn: 'Tropical Vibes', nameAr: 'أجواء استوائية',
        colors: [
            { id: 'trop_1',  nameEn: 'Tropical Orange', nameAr: 'برتقالي استوائي', hex: '#FF6B35' },
            { id: 'trop_2',  nameEn: 'Mango Yellow',    nameAr: 'أصفر مانجو',      hex: '#F7C548' },
            { id: 'trop_3',  nameEn: 'Turquoise',       nameAr: 'تركواز',          hex: '#2EC4B6' },
            { id: 'trop_4',  nameEn: 'Teal Green',      nameAr: 'أخضر تركوازي',    hex: '#20A39E' },
            { id: 'trop_5',  nameEn: 'Watermelon Pink', nameAr: 'وردي بطيخي',      hex: '#EF476F' },
            { id: 'trop_6',  nameEn: 'Sunny Yellow',    nameAr: 'أصفر مشمس',       hex: '#FFD166' },
            { id: 'trop_7',  nameEn: 'Emerald Green',   nameAr: 'أخضر زمردي',      hex: '#06D6A0' },
            { id: 'trop_8',  nameEn: 'Ocean Teal',      nameAr: 'تركوازي محيطي',   hex: '#118AB2' },
            { id: 'trop_9',  nameEn: 'Deep Teal',       nameAr: 'تركوازي داكن',    hex: '#073B4C' },
            { id: 'trop_10', nameEn: 'Papaya Orange',   nameAr: 'برتقالي بابايا',  hex: '#FF9F1C' },
            { id: 'trop_11', nameEn: 'Aqua Blue',       nameAr: 'أزرق مائي',       hex: '#2AB7CA' },
            { id: 'trop_12', nameEn: 'Coral Red',       nameAr: 'أحمر مرجاني',     hex: '#FE4A49' },
            { id: 'trop_13', nameEn: 'Poppy Red',       nameAr: 'أحمر خشخاش',      hex: '#F94144' },
            { id: 'trop_14', nameEn: 'Pumpkin Orange',  nameAr: 'برتقالي قرعي',    hex: '#F3722C' },
            { id: 'trop_15', nameEn: 'Amber Orange',    nameAr: 'برتقالي كهرماني', hex: '#F8961E' },
            { id: 'trop_16', nameEn: 'Golden Yellow',   nameAr: 'أصفر ذهبي',       hex: '#F9C74F' },
            { id: 'trop_17', nameEn: 'Palm Green',      nameAr: 'أخضر نخيلي',      hex: '#90BE6D' },
            { id: 'trop_18', nameEn: 'Jade Green',      nameAr: 'أخضر يشمي',       hex: '#43AA8B' },
            { id: 'trop_19', nameEn: 'Lagoon Teal',     nameAr: 'تركوازي بحيرة',   hex: '#4D908E' },
            { id: 'trop_20', nameEn: 'Slate Blue',      nameAr: 'أزرق إردوازي',    hex: '#577590' },
            { id: 'trop_21', nameEn: 'Deep Sea Blue',   nameAr: 'أزرق بحر عميق',   hex: '#277DA1' },
            { id: 'trop_22', nameEn: 'Peach Pink',      nameAr: 'وردي خوخي',       hex: '#FF9770' },
            { id: 'trop_23', nameEn: 'Banana Yellow',   nameAr: 'أصفر موزي',       hex: '#FFD670' },
            { id: 'trop_24', nameEn: 'Lime Yellow',     nameAr: 'أصفر ليموني',     hex: '#E9FF70' },
            { id: 'trop_25', nameEn: 'Sky Aqua',        nameAr: 'سماوي مائي',      hex: '#70D6FF' },
            { id: 'trop_26', nameEn: 'Flamingo Pink',   nameAr: 'وردي فلامنجو',    hex: '#FF70A6' },
            { id: 'trop_27', nameEn: 'Caribbean Teal',  nameAr: 'تركوازي كاريبي',  hex: '#00B4A6' },
            { id: 'trop_28', nameEn: 'Orchid Pink',     nameAr: 'وردي أوركيد',     hex: '#F15BB5' },
        ]
    },
    galaxy: {
        nameEn: 'Galaxy', nameAr: 'مجرة',
        colors: [
            { id: 'galaxy_1',  nameEn: 'Deep Space',      nameAr: 'فضاء عميق',       hex: '#0B0033' },
            { id: 'galaxy_2',  nameEn: 'Cosmic Purple',   nameAr: 'بنفسجي كوني',     hex: '#1A0057' },
            { id: 'galaxy_3',  nameEn: 'Nebula Violet',   nameAr: 'بنفسجي سديمي',    hex: '#2E0A78' },
            { id: 'galaxy_4',  nameEn: 'Galaxy Purple',   nameAr: 'بنفسجي مجري',     hex: '#4B0F9E' },
            { id: 'galaxy_5',  nameEn: 'Cosmic Violet',   nameAr: 'بنفسجي كوني فاتح', hex: '#6A1FC4' },
            { id: 'galaxy_6',  nameEn: 'Star Purple',     nameAr: 'بنفسجي نجمي',     hex: '#8B3AE0' },
            { id: 'galaxy_7',  nameEn: 'Comet Violet',    nameAr: 'بنفسجي مذنبي',    hex: '#A85FF0' },
            { id: 'galaxy_8',  nameEn: 'Light Nebula',    nameAr: 'سديمي فاتح',      hex: '#C48CF7' },
            { id: 'galaxy_9',  nameEn: 'Void Purple',     nameAr: 'بنفسجي العدم',    hex: '#3D1A6E' },
            { id: 'galaxy_10', nameEn: 'Dark Cosmos',     nameAr: 'كوني داكن',       hex: '#221046' },
            { id: 'galaxy_11', nameEn: 'Vivid Violet',    nameAr: 'بنفسجي زاهي',     hex: '#5E17EB' },
            { id: 'galaxy_12', nameEn: 'Electric Purple', nameAr: 'بنفسجي كهربائي',  hex: '#7C3AED' },
        ]
    },
    cyberpunk: {
        nameEn: 'Cyberpunk', nameAr: 'سايبربانك',
        colors: [
            { id: 'cyber_1',  nameEn: 'Neon Pink',      nameAr: 'وردي نيون',        hex: '#FF006E' },
            { id: 'cyber_2',  nameEn: 'Neon Orange',    nameAr: 'برتقالي نيون',     hex: '#FB5607' },
            { id: 'cyber_3',  nameEn: 'Neon Yellow',    nameAr: 'أصفر نيون',        hex: '#FFBE0B' },
            { id: 'cyber_4',  nameEn: 'Electric Purple',nameAr: 'بنفسجي كهربائي',   hex: '#8338EC' },
            { id: 'cyber_5',  nameEn: 'Neon Blue',      nameAr: 'أزرق نيون',        hex: '#3A86FF' },
            { id: 'cyber_6',  nameEn: 'Neon Aqua',      nameAr: 'مائي نيون',        hex: '#00F5D4' },
            { id: 'cyber_7',  nameEn: 'Magenta Glow',   nameAr: 'أرجواني متوهج',    hex: '#F72585' },
            { id: 'cyber_8',  nameEn: 'Vivid Magenta',  nameAr: 'أرجواني زاهي',     hex: '#B5179E' },
            { id: 'cyber_9',  nameEn: 'Deep Violet',    nameAr: 'بنفسجي عميق',      hex: '#7209B7' },
            { id: 'cyber_10', nameEn: 'Ultraviolet',    nameAr: 'فوق بنفسجي',       hex: '#560BAD' },
            { id: 'cyber_11', nameEn: 'Cyber Indigo',   nameAr: 'نيلي سايبري',      hex: '#3A0CA3' },
            { id: 'cyber_12', nameEn: 'Electric Indigo',nameAr: 'نيلي كهربائي',     hex: '#4361EE' },
            { id: 'cyber_13', nameEn: 'Cyber Cyan',     nameAr: 'سماوي سايبري',     hex: '#00F0FF' },
            { id: 'cyber_14', nameEn: 'Neon Magenta',   nameAr: 'أرجواني نيون',     hex: '#FF00E5' },
            { id: 'cyber_15', nameEn: 'Neon Green',     nameAr: 'أخضر نيون',        hex: '#39FF14' },
            { id: 'cyber_16', nameEn: 'Electric Violet',nameAr: 'بنفسجي كهربائي فاتح', hex: '#D400FF' },
            { id: 'cyber_17', nameEn: 'Neon Rose',      nameAr: 'وردي نيون',        hex: '#FF0090' },
            { id: 'cyber_18', nameEn: 'Neon Mint',      nameAr: 'نعناعي نيون',      hex: '#00FFA3' },
            { id: 'cyber_19', nameEn: 'Cyber Purple',   nameAr: 'بنفسجي سايبري',    hex: '#7B2FF7' },
            { id: 'cyber_20', nameEn: 'Cyber Cyan Light', nameAr: 'سماوي سايبري فاتح', hex: '#0FF0FC' },
            { id: 'cyber_21', nameEn: 'Muted Cyber Purple', nameAr: 'بنفسجي سايبري هادئ', hex: '#784BA0' },
        ]
    },
    autumn: {
        nameEn: 'Autumn Harvest', nameAr: 'حصاد الخريف',
        colors: [
            { id: 'autumn_1',  nameEn: 'Dark Rust',      nameAr: 'صدأ داكن',        hex: '#7C2D12' },
            { id: 'autumn_2',  nameEn: 'Rust Brown',     nameAr: 'بني صدأي',        hex: '#9A3412' },
            { id: 'autumn_3',  nameEn: 'Burnt Orange',   nameAr: 'برتقالي محروق',   hex: '#C2410C' },
            { id: 'autumn_4',  nameEn: 'Pumpkin',        nameAr: 'قرع',             hex: '#EA580C' },
            { id: 'autumn_5',  nameEn: 'Bright Pumpkin', nameAr: 'قرع ساطع',        hex: '#F97316' },
            { id: 'autumn_6',  nameEn: 'Light Pumpkin',  nameAr: 'قرع فاتح',        hex: '#FB923C' },
            { id: 'autumn_7',  nameEn: 'Amber',          nameAr: 'عنبري',           hex: '#D97706' },
            { id: 'autumn_8',  nameEn: 'Dark Amber',     nameAr: 'عنبري داكن',      hex: '#B45309' },
            { id: 'autumn_9',  nameEn: 'Brown Amber',    nameAr: 'عنبري بني',       hex: '#92400E' },
            { id: 'autumn_10', nameEn: 'Deep Brown',     nameAr: 'بني عميق',        hex: '#78350F' },
            { id: 'autumn_11', nameEn: 'Golden Brown',   nameAr: 'بني ذهبي',        hex: '#A16207' },
            { id: 'autumn_12', nameEn: 'Golden Mustard', nameAr: 'خردلي ذهبي',      hex: '#CA8A04' },
            { id: 'autumn_13', nameEn: 'Saddle Brown',   nameAr: 'بني سرجي',        hex: '#8B4513' },
            { id: 'autumn_14', nameEn: 'Sienna',         nameAr: 'سيينا',           hex: '#A0522D' },
            { id: 'autumn_15', nameEn: 'Peru Brown',     nameAr: 'بني بيروي',       hex: '#CD853F' },
            { id: 'autumn_16', nameEn: 'Chocolate Orange', nameAr: 'برتقالي شوكولا', hex: '#D2691E' },
            { id: 'autumn_17', nameEn: 'Dark Goldenrod', nameAr: 'ذهبي داكن',       hex: '#B8860B' },
            { id: 'autumn_18', nameEn: 'Goldenrod',      nameAr: 'ذهبي',            hex: '#DAA520' },
            { id: 'autumn_19', nameEn: 'Walnut Brown',   nameAr: 'بني جوزي',        hex: '#8B5A2B' },
            { id: 'autumn_20', nameEn: 'Coffee Brown',   nameAr: 'بني قهوة',        hex: '#6B4226' },
            { id: 'autumn_21', nameEn: 'Tawny Brown',    nameAr: 'بني أسمر',        hex: '#A9744F' },
            { id: 'autumn_22', nameEn: 'Dark Umber',     nameAr: 'أمبر داكن',       hex: '#5C3317' },
            { id: 'autumn_23', nameEn: 'Chestnut Brown', nameAr: 'بني كستنائي',     hex: '#7C4A2D' },
            { id: 'autumn_24', nameEn: 'Deep Umber',     nameAr: 'أمبر عميق',       hex: '#4E3524' },
            { id: 'autumn_25', nameEn: 'Autumn Amber',   nameAr: 'عنبري خريفي',     hex: '#96470E' },
        ]
    }
};

module.exports = { COLOR_PALETTES };

// ─── Settings helpers ──────────────────────────────────────────────────────────
function loadColorSettings() {
    const p = path.join(__dirname, '../colorRolesSettings.json');
    if (fs.existsSync(p)) {
        try { return JSON.parse(fs.readFileSync(p, 'utf8')); } catch(e) {}
    }
    return {
        enabled: true,
        selectedPalette: 'rainbow',
        colorRoleIds: {},
        commands: {
            color:  { enabled: true },
            colors: { enabled: true }
        }
    };
}

function saveColorSettings(data) {
    fs.writeFileSync(
        path.join(__dirname, '../colorRolesSettings.json'),
        JSON.stringify(data, null, 2),
        'utf8'
    );
}

// ─── Translations ──────────────────────────────────────────────────────────────
const LANG = {
    ar: {
        cmdDisabled: '⚠️ هذا الأمر معطل حالياً.',
        noPalette:   '⚠️ لم يتم اختيار لوحة ألوان بعد. يرجى الإعداد من الداشبورد.',
        assignedTitle: 'تم تحديث اللون',
        assignedDesc:  (name, num) => `تم تحديث لون رتبتك إلى **${name}** (Color ${num}).\nاستخدم الأمر \`/color\` لتغيير لونك مرة أخرى.`,
        removedTitle:  '🗑️ تم إزالة اللون',
        removedDesc:   (name) => `تم إزالة رتبة اللون **${name}**.`,
        error:       '❌ حدث خطأ أثناء تعيين الرتبة.',
        noPerms:     '❌ البوت لا يملك صلاحيات كافية لإدارة الرتب.',
        invalidNum:  (max) => `⚠️ الرقم غير صحيح. أدخل رقماً بين **1** و **${max}**.\nاستخدم \`/colors\` لعرض الألوان وأرقامها.`,
        notFound:    '❌ اللون غير موجود.',
    },
    en: {
        cmdDisabled: '⚠️ This command is currently disabled.',
        noPalette:   '⚠️ No color palette selected. Please configure it from the dashboard.',
        assignedTitle: ' Color Updated',
        assignedDesc:  (name, num) => `Your color role has been updated to **${name}** (Color ${num}).\nUse the \`/color\` command to change your color again.`,
        removedTitle:  '🗑️ Color Removed',
        removedDesc:   (name) => `Color role **${name}** has been removed.`,
        error:       '❌ An error occurred while assigning the role.',
        noPerms:     '❌ Bot lacks permissions to manage roles.',
        invalidNum:  (max) => `⚠️ Invalid number. Enter a number between **1** and **${max}**.\nUse \`/colors\` to see the list.`,
        notFound:    '❌ Color not found.',
    }
};

// ─── Slash command data ────────────────────────────────────────────────────────
module.exports.data = {
    name: 'color',
    description: '🎨 Pick a color role for yourself | اختر لون رتبتك',
    options: [
        { name: 'number', description: 'Color number from /colors list', type: 4, required: false }
    ]
};

// ─── Helper: جمع كل IDs رتب الألوان ───────────────────────────────────────────
function getAllColorRoleIds(cs) {
    const ids = new Set();
    for (const pal of Object.values(COLOR_PALETTES)) {
        for (const col of pal.colors) {
            const rid = cs.colorRoleIds?.[col.id];
            if (rid) ids.add(rid);
        }
    }
    return ids;
}

// ─── Helper: إنشاء أو جلب رتبة اللون ─────────────────────────────────────────
async function findOrCreateColorRole(guild, chosen, palette, cs) {
    const existingRoleId = cs.colorRoleIds?.[chosen.id];

    // جرب الجلب من الكاش
    let role = existingRoleId ? guild.roles.cache.get(existingRoleId) : null;

    if (!role) {
        // ابحث بالاسم
        const colorIndex = palette.colors.findIndex(c => c.id === chosen.id);
        const roleName   = colorIndex >= 0 ? `Color ${colorIndex + 1}` : `Color - ${chosen.nameEn}`;
        role = guild.roles.cache.find(r => r.name === roleName) || null;

        if (!role) {
            // أنشئ الرتبة بـ color (hex string) وبدون أي صلاحيات
            role = await guild.roles.create({
                name:        roleName,
                colors:      { primaryColor: chosen.hex },
                permissions: 0n,           // صفر صلاحيات تماماً
                mentionable: false,
                hoist:       false,
                reason:      'Color Roles System'
            });
        } else {
            // الرتبة موجودة — صفّر صلاحياتها إن وجدت
            if (role.permissions.bitfield !== 0n) {
                await role.setPermissions(0n, 'Color role - clearing permissions').catch(() => {});
            }
        }
    } else {
        // الرتبة موجودة في الكاش — صفّر صلاحياتها إن وجدت
        if (role.permissions.bitfield !== 0n) {
            await role.setPermissions(0n, 'Color role - clearing permissions').catch(() => {});
        }
    }

    return role;
}

// ─── Helper: تطبيق اللون على العضو ───────────────────────────────────────────
async function applyColor(interaction, settings, colorId) {
    const isAr = settings?.botLanguage === 'ar';
    const t    = isAr ? LANG.ar : LANG.en;
    const cs   = loadColorSettings();

    const palette = COLOR_PALETTES[cs.selectedPalette];
    if (!palette) return interaction.editReply({ content: t.noPalette });

    const chosen = palette.colors.find(c => c.id === colorId);
    if (!chosen)  return interaction.editReply({ content: t.notFound });

    const colorName = isAr ? chosen.nameAr : chosen.nameEn;

    if (!interaction.guild.members.me.permissions.has('ManageRoles')) {
        return interaction.editReply({ content: t.noPerms });
    }

    const member          = interaction.member;
    const allColorIds     = getAllColorRoleIds(cs);
    const existingRoleId  = cs.colorRoleIds?.[colorId];
    const memberHasRole   = existingRoleId && member.roles.cache.has(existingRoleId);

    // إزالة كل رتب الألوان من العضو
    for (const rid of allColorIds) {
        if (member.roles.cache.has(rid)) {
            await member.roles.remove(rid).catch(() => {});
        }
    }

    // Toggle: إذا كان لديه نفس اللون → فقط أزلناه
    if (memberHasRole) {
        const removedEmbed = new EmbedBuilder()
            .setColor(chosen.hex)
            .setTitle(t.removedTitle)
            .setDescription(t.removedDesc(colorName));
        return interaction.editReply({ embeds: [removedEmbed] });
    }

    // جلب أو إنشاء الرتبة
    const role = await findOrCreateColorRole(interaction.guild, chosen, palette, cs);

    // حفظ الـ ID
    if (!cs.colorRoleIds) cs.colorRoleIds = {};
    cs.colorRoleIds[colorId] = role.id;
    saveColorSettings(cs);

    // إضافة الرتبة للعضو
    await member.roles.add(role);

    const colorIndex    = palette.colors.findIndex(c => c.id === colorId) + 1;
    const assignedEmbed = new EmbedBuilder()
        .setColor(chosen.hex)
        .setTitle(t.assignedTitle)
        .setDescription(t.assignedDesc(colorName, colorIndex));
    return interaction.editReply({ embeds: [assignedEmbed] });
}

// ─── Execute (slash command) ───────────────────────────────────────────────────
module.exports.execute = async function(interaction, client, settings, commandConfig) {
    try {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const isAr = settings?.botLanguage === 'ar';
        const t    = isAr ? LANG.ar : LANG.en;

        if (commandConfig && commandConfig.enabled === false) {
            return interaction.editReply({ content: t.cmdDisabled });
        }

        const cs = loadColorSettings();
        const palette = COLOR_PALETTES[cs.selectedPalette];
        if (!palette) return interaction.editReply({ content: t.noPalette });

        // الألوان النشطة
        const hasAnyRole   = cs.colorRoleIds && Object.keys(cs.colorRoleIds).length > 0;
        const activeColors = hasAnyRole
            ? palette.colors.filter(c => {
                const rid = cs.colorRoleIds[c.id];
                return rid && !!interaction.guild.roles.cache.get(rid);
            })
            : palette.colors;

        const number = interaction.options?.getInteger('number');
        if (!number || number < 1 || number > activeColors.length) {
            return interaction.editReply({ content: t.invalidNum(activeColors.length) });
        }

        const chosen = activeColors[number - 1];
        await applyColor(interaction, settings, chosen.id);

    } catch (err) {
        console.error('❌ خطأ في /color:', err);
        try {
            const msg = `❌ ${err.message || 'Error'}`;
            if (interaction.deferred || interaction.replied) await interaction.editReply({ content: msg });
            else await interaction.reply({ content: msg, flags: MessageFlags.Ephemeral });
        } catch(e) {}
    }
};

// ─── Handle select menu (color_role_picker) ────────────────────────────────────
module.exports.handleColorPicker = async function(interaction, client, settings) {
    try {
        await interaction.deferReply({ flags: MessageFlags.Ephemeral });

        const isAr = settings?.botLanguage === 'ar';
        const t    = isAr ? LANG.ar : LANG.en;
        const cs   = loadColorSettings();

        if (!COLOR_PALETTES[cs.selectedPalette]) {
            return interaction.editReply({ content: t.noPalette });
        }

        const colorId = interaction.values[0];
        await applyColor(interaction, settings, colorId);

    } catch (err) {
        console.error('❌ خطأ في color_role_picker:', err);
        try {
            const t = settings?.botLanguage === 'ar' ? LANG.ar : LANG.en;
            if (interaction.deferred || interaction.replied) await interaction.editReply({ content: t.error });
            else await interaction.reply({ content: t.error, flags: MessageFlags.Ephemeral });
        } catch(e) {}
    }
};