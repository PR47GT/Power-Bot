const { PermissionFlagsBits, MessageFlags } = require('discord.js');
const fs = require('fs');
const path = require('path');
const { checkPermissions } = require('../utils/permissionChecker');

function loadModCommands() {
    const modPath = path.join(__dirname, '../modCommands.json');
    if (fs.existsSync(modPath)) {
        try {
            return JSON.parse(fs.readFileSync(modPath, 'utf8'));
        } catch(e) { 
            return {}; 
        }
    }
    return {};
}

// 🌍 نظام اللغات
const T = {
    ar: {
        description: 'إزالة الإسكات عن عضو',
        option_user: 'العضو',
        disabled: '⚠️ هذا الأمر معطل حالياً.',
        memberNotFound: '❌ العضو غير موجود في السيرفر.',
        notModeratable: '❌ لا يمكنني إزالة الإسكات عن هذا العضو. تأكد أن رتبتي أعلى.',
        botNoPerm: '❌ البوت لا يملك صلاحية إزالة الإسكات عن الأعضاء',
        notTimedOut: '⚠️ هذا العضو ليس في حالة إسكات.',
        failed: '❌ فشل إزالة الإسكات:',
        success: (user) => `✅ تم فك الإسكات عن \`${user.tag}\``,
        error: '❌ حدث خطأ:'
    },
    en: {
        description: 'Remove timeout from a member',
        option_user: 'User',
        disabled: '⚠️ This command is currently disabled.',
        memberNotFound: '❌ Member not found in the server.',
        notModeratable: '❌ Cannot remove timeout from this member. Ensure my role is higher.',
        botNoPerm: '❌ Bot does not have permission to moderate members',
        notTimedOut: '⚠️ This member is not timed out.',
        failed: '❌ Failed to remove timeout:',
        success: (user) => `✅ Timeout removed from \`${user.tag}\``,
        error: '❌ An error occurred:'
    }
};

module.exports = {
    data: {
        name: 'untimeout',
        description: 'Remove timeout | فك الإسكات',
        default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
        options: [
            { 
                name: 'user', 
                description: 'User', 
                type: 6, 
                required: true 
            }
        ]
    },
    
    async execute(interaction, client, settings, commandConfig) {

        // ✅ نفس نظامك
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        try {
            await interaction.deferReply({ flags: MessageFlags.Ephemeral });
            
            const modCommands = loadModCommands();
            const config = commandConfig || modCommands.untimeout || { 
                enabled: true,
                aliases: [],
                deniedRoles: [], 
                allowedRoles: [], 
                deniedChannels: [], 
                allowedChannels: [],
                deleteCommand: false,
                deleteResponse: false
            };
            
            if (!config.enabled) {
                return await interaction.editReply({ content: t.disabled });
            }
            
            const permission = checkPermissions(
                interaction.member, 
                interaction.channelId, 
                config
            );
            
            if (!permission.allowed) {
                return await interaction.editReply({ content: permission.reason });
            }
            
            const targetUser = interaction.options.getUser('user');
            const targetMember = await interaction.guild.members.fetch(targetUser.id).catch(() => null);
            
            if (!targetMember) {
                return await interaction.editReply({ content: t.memberNotFound });
            }
            
            if (!targetMember.moderatable) {
                return await interaction.editReply({ content: t.notModeratable });
            }
            
            if (!interaction.guild.members.me.permissions.has(PermissionFlagsBits.ModerateMembers)) {
                return await interaction.editReply({ content: t.botNoPerm });
            }
            
            if (!targetMember.isCommunicationDisabled()) {
                return await interaction.editReply({ content: t.notTimedOut });
            }
            
            try {
                await targetMember.timeout(null);
                
                const successMessage = t.success(targetUser);
                
                if (config.deleteResponse) {
                    await interaction.editReply({ content: successMessage });
                    
                    setTimeout(() => {
                        interaction.deleteReply().catch(() => {});
                    }, 5000);
                } else {
                    await interaction.editReply({ content: successMessage });
                }
                
            } catch (error) {
                return await interaction.editReply({ 
                    content: `${t.failed} ${error.message}`
                });
            }
            
        } catch (error) {
            console.error('❌ Untimeout command error:', error.message);
            
            try {
                const msg = `${t.error} ${error.message || 'Unknown error'}`;
                
                if (interaction.deferred && !interaction.replied) {
                    await interaction.editReply({ content: msg });
                } else if (!interaction.replied) {
                    await interaction.reply({ 
                        content: msg,
                        flags: MessageFlags.Ephemeral
                    });
                }
            } catch(e) {}
        }
    }
};