const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled: '⚠️ نظام الاقتصاد معطل حالياً.',
        noAccount: '❌ هذا العضو لا يملك حساباً.',
        title: ' ',
        wallet: '💰 المحفظة',
        bank: '🏦 البنك',
        total: '📊 الإجمالي',
        footer: 'استخدم /profile لمزيد من المعلومات'
    },
    en: {
        disabled: '⚠️ Economy system is currently disabled.',
        noAccount: '❌ This member has no account.',
        title: '',
        wallet: '💰 Wallet',
        bank: '🏦 Bank',
        total: '📊 Total',
        footer: 'Use /profile for more information'
    }
};

module.exports = {
    data: {
        name: 'balance',
        description: "Check your balance or another member's | شوف رصيدك أو رصيد عضو",
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'The user to check | العضو المراد فحصه', type: 6, required: false }
        ]
    },

    async execute(interaction, client, settings) {
        try {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const target = interaction.options.getUser('user') || interaction.user;
        const user   = getUser(interaction.guildId, target.id);
        const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        if (!user) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.noAccount).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const wallet = user.wallet || 0;
        const bank   = user.bank   || 0;
        const total  = wallet + bank;

        const embed = new EmbedBuilder()
            .setAuthor({ 
                name: `${t.title}  ${target.username}`, 
                iconURL: target.displayAvatarURL({ dynamic: true, size: 128 }) 
            })
            .setColor('#5865F2')
            .addFields(
                { name: t.wallet, value: `${wallet.toLocaleString()} ${cur}`, inline: true },
                { name: t.bank,   value: `${bank.toLocaleString()} ${cur}`,   inline: true },
                { name: t.total,  value: `${total.toLocaleString()} ${cur}`,  inline: true }
            )
            .setFooter({ text: t.footer })
            .setTimestamp();

        await interaction.reply({ embeds: [embed] });
    
      } catch (err) {
          console.error('[balance] unexpected error:', err);
          const _errEmbed = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
          const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
          if (interaction.replied || interaction.deferred) {
              await interaction.followUp(_errPayload).catch(() => {});
          } else {
              await interaction.reply(_errPayload).catch(() => {});
          }
      }
    }
};