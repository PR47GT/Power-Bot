const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, getOrGenerateQuests, claimCompletedQuests } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

// ── Quest type icons ───────────────────────────────────────────────────────────
const QUEST_ICON = {
    work_times:  '💼',
    earn_coins:  '💰',
    spend_coins: '🛒',
    open_chests: '📦',
    craft_items: '🔨',
    daily_claim: '🎁',
};

const T = {
    ar: {
        disabled:    '⚠️ نظام الاقتصاد معطل حالياً.',
        title:       '📋 مهامك اليومية',
        weeklyTitle: '📅 المهمة الأسبوعية',
        noQuests:    'لا توجد مهام متاحة.',
        claimed:     (reward, cur) => `✅ تم صرف جميع المكافآت المكتملة!\n💰 حصلت على **${reward.toLocaleString()} ${cur}**`,
        noClaim:     '❌ لا توجد مهام مكتملة لصرفها حالياً.',
        done:        '✅ مكتمل',
        claimable:   '🎁 جاهز للصرف',
        footer:      'المهام اليومية • تتجدد يومياً عند منتصف الليل',
        balance:     'رصيدك الحالي',
        summary:     (done, total) => `${done}/${total} مهام مكتملة`,
        reward:      'المكافأة',
        typeName: {
            work_times:  (n) => `اعمل ${n} مرات`,
            earn_coins:  (n) => `اكسب ${n} عملة من العمل`,
            spend_coins: (n) => `أنفق ${n} عملة في المتجر`,
            open_chests: (n) => `افتح ${n} صنادي`,
            craft_items: (n) => `صنع ${n} عناصر`,
            daily_claim: ()  => 'استلم الجائزة اليومية',
        }
    },
    en: {
        disabled:    '⚠️ Economy system is currently disabled.',
        title:       '📋 Daily Quests',
        weeklyTitle: '📅 Weekly Quest',
        noQuests:    'No quests available.',
        claimed:     (reward, cur) => `✅ All completed rewards claimed!\n💰 You received **${reward.toLocaleString()} ${cur}**`,
        noClaim:     '❌ No completed quests to claim right now.',
        done:        '✅ Done',
        claimable:   '🎁 Claim now!',
        footer:      'Daily Quests • Resets daily at midnight',
        balance:     'Your Balance',
        summary:     (done, total) => `${done}/${total} quests completed`,
        reward:      'Reward',
        typeName: {
            work_times:  (n) => `Work ${n} times`,
            earn_coins:  (n) => `Earn ${n} coins from work`,
            spend_coins: (n) => `Spend ${n} coins in shop`,
            open_chests: (n) => `Open ${n} chest(s)`,
            craft_items: (n) => `Craft ${n} item(s)`,
            daily_claim: ()  => 'Claim daily reward',
        }
    }
};

// ── Progress bar using ▰▱ (cleaner than █░) ────────────────────────────────────
function progressBar(cur, target, len = 10) {
    const pct    = Math.min(cur / target, 1);
    const filled = Math.round(pct * len);
    const bar    = '▰'.repeat(filled) + '▱'.repeat(len - filled);
    const pctStr = `${Math.round(pct * 100)}%`;
    return `${bar} **${pctStr}**`;
}

// ── Embed color based on overall completion ────────────────────────────────────
function pickColor(quests) {
    const all = [...quests.daily, ...(quests.weekly ? [quests.weekly] : [])];
    if (all.length === 0) return '#5865F2';
    const allClaimed    = all.every(q => q.claimed);
    const anyClaimable  = all.some(q => !q.claimed && q.progress >= q.target);
    if (allClaimed)   return '#57F287'; // green — all done
    if (anyClaimable) return '#FEE75C'; // gold  — ready to claim
    return '#5865F2';                   // blue  — in progress
}

module.exports = {
    data: {
        name: 'quest',
        description: 'View and claim daily quests | عرض وصرف المهام اليومية',
        default_member_permissions: null,
        options: [
            { name: 'view',  description: 'View your quests | عرض مهامك',                            type: 1 },
            { name: 'claim', description: 'Claim completed quest rewards | صرف مكافآت المهام المكتملة', type: 1 }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const cur    = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
            const sub    = interaction.options.getSubcommand();
            const user   = getUser(interaction.guildId, interaction.user.id);
            const quests = getOrGenerateQuests(interaction.guildId, interaction.user.id, es);

            // ── /quest view ───────────────────────────────────────────────────
            if (sub === 'view') {
                const allQuests   = [...quests.daily, ...(quests.weekly ? [quests.weekly] : [])];
                const doneCount   = quests.daily.filter(q => q.claimed).length;
                const totalDaily  = quests.daily.length;

                const embed = new EmbedBuilder()
                    .setAuthor({
                        name:    interaction.user.username,
                        iconURL: interaction.user.displayAvatarURL({ size: 64 }),
                    })
                    .setTitle(t.title)
                    .setColor(pickColor(quests))
                    .setFooter({ text: t.footer })
                    .setTimestamp();

                // Summary line at the top
                if (totalDaily > 0) {
                    embed.setDescription(`> ${t.summary(doneCount, totalDaily)}`);
                } else {
                    embed.setDescription(`> ${t.noQuests}`);
                }

                // ── Daily quest fields ─────────────────────────────────────
                quests.daily.forEach((q, i) => {
                    const icon     = QUEST_ICON[q.type] || '📌';
                    const name     = t.typeName[q.type]?.(q.target) || q.type;
                    const progress = Math.min(q.progress, q.target);
                    const isDone   = progress >= q.target;

                    let statusLine;
                    if (q.claimed)    statusLine = t.done;
                    else if (isDone)  statusLine = t.claimable;
                    else              statusLine = `**${progress.toLocaleString()}** / ${q.target.toLocaleString()}`;

                    const bar   = progressBar(progress, q.target);
                    const value = [
                        bar,
                        statusLine,
                        `> ${t.reward}: **${q.reward.toLocaleString()} ${cur}**`,
                    ].join('\n');

                    embed.addFields({
                        name:   `${icon} ${i + 1}. ${name}`,
                        value,
                        inline: false,
                    });
                });

                // ── Weekly quest field ─────────────────────────────────────
                if (quests.weekly) {
                    const wq   = quests.weekly;
                    const icon = QUEST_ICON[wq.type] || '📅';
                    const name = t.typeName[wq.type]?.(wq.target) || wq.type;
                    const prog = Math.min(wq.progress, wq.target);
                    const done = prog >= wq.target;

                    let statusLine;
                    if (wq.claimed)  statusLine = t.done;
                    else if (done)   statusLine = t.claimable;
                    else             statusLine = `**${prog.toLocaleString()}** / ${wq.target.toLocaleString()}`;

                    embed.addFields({
                        name:  `${icon} ${t.weeklyTitle} — ${name}`,
                        value: [
                            progressBar(prog, wq.target, 14),
                            statusLine,
                            `> ${t.reward}: **${wq.reward.toLocaleString()} ${cur}**`,
                        ].join('\n'),
                        inline: false,
                    });
                }

                return interaction.reply({ embeds: [embed] });
            }

            // ── /quest claim ──────────────────────────────────────────────────
            if (sub === 'claim') {
                const result = claimCompletedQuests(interaction.guildId, interaction.user.id, es);
                if (result.totalReward === 0) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noClaim).setColor('#FEE75C')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                const updatedUser = getUser(interaction.guildId, interaction.user.id);
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setAuthor({
                            name:    interaction.user.username,
                            iconURL: interaction.user.displayAvatarURL({ size: 64 }),
                        })
                        .setDescription(t.claimed(result.totalReward, cur))
                        .addFields({ name: `💳 ${t.balance}`, value: `**${updatedUser.wallet.toLocaleString()} ${cur}**` })
                        .setColor('#57F287')
                        .setFooter({ text: t.footer })
                        .setTimestamp()]
                });
            }

        } catch (err) {
            console.error('[quest] unexpected error:', err);
            const _errEmbed   = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
