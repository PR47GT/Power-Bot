/**
 * moneytop.js — نسخة احترافية بـ Canvas مع دعم الإيموجي كصور
 * يتطلب: npm install @napi-rs/canvas
 */

const { EmbedBuilder, MessageFlags, AttachmentBuilder } = require('discord.js');
const { createCanvas, loadImage } = require('@napi-rs/canvas');
const https = require('https');
const http  = require('http');

const { getLeaderboard }      = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

// ─────────────────────────────────────────────
// ترجمات
// ─────────────────────────────────────────────
const T = {
    ar: {
        disabled : '⚠️ نظام الاقتصاد معطل حالياً.',
        noData   : '❌ لا يوجد أعضاء في قائمة الاقتصاد.',
        title    : '🏆  أغنى الأعضاء',
        wallet   : 'المحفظة',
        bank     : 'البنك',
        total    : 'الإجمالي',
    },
    en: {
        disabled : '⚠️ Economy system is currently disabled.',
        noData   : '❌ No economy members found.',
        title    : '🏆  Richest Members',
        wallet   : 'Wallet',
        bank     : 'Bank',
        total    : 'Total',
    },
};

// ألوان أول 3 مراكز
const TOP3 = [
    { ring: '#FFD700', name: '#FFD700', amt: '#FFD700', amtGlow: 'rgba(255,215,0,0.45)'    },
    { ring: '#C0C8D8', name: '#C0C8D8', amt: '#C0C8D8', amtGlow: 'rgba(192,200,216,0.45)' },
    { ring: '#CD7F32', name: '#E8944A', amt: '#E8944A', amtGlow: 'rgba(205,127,50,0.45)'  },
];

// ─────────────────────────────────────────────
// تنسيق الأرقام
// ─────────────────────────────────────────────
function fmt(n) {
    if (n >= 1_000_000) return (n / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (n >= 1_000)     return (n / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
    return n.toLocaleString();
}

// ─────────────────────────────────────────────
// جلب Buffer من URL مع دعم redirect
// ─────────────────────────────────────────────
function fetchBuffer(url) {
    return new Promise((resolve, reject) => {
        const mod = url.startsWith('https') ? https : http;
        mod.get(url, { headers: { 'User-Agent': 'Mozilla/5.0' } }, res => {
            if (res.statusCode >= 300 && res.statusCode < 400 && res.headers.location) {
                return fetchBuffer(res.headers.location).then(resolve).catch(reject);
            }
            if (res.statusCode !== 200) return reject(new Error(`HTTP ${res.statusCode}`));
            const chunks = [];
            res.on('data', c => chunks.push(c));
            res.on('end',  () => resolve(Buffer.concat(chunks)));
            res.on('error', reject);
        }).on('error', reject);
    });
}

// ─────────────────────────────────────────────
// جلب صورة الإيموجي
// ─────────────────────────────────────────────
const _emojiCache = new Map();

async function loadEmojiImg(emojiStr) {
    if (!emojiStr) return null;
    if (_emojiCache.has(emojiStr)) return _emojiCache.get(emojiStr);

    let url = null;

    const discordMatch = emojiStr.match(/<a?:[\w]+:(\d+)>/);
    if (discordMatch) {
        const ext = emojiStr.startsWith('<a:') ? 'gif' : 'png';
        url = `https://cdn.discordapp.com/emojis/${discordMatch[1]}.${ext}?size=64`;
    } else {
        const points = [...emojiStr]
            .map(c => c.codePointAt(0))
            .filter(cp => cp !== 0xFE0F)
            .map(cp => cp.toString(16))
            .join('-');
        if (points) url = `https://cdn.jsdelivr.net/gh/twitter/twemoji@v14.0.2/assets/72x72/${points}.png`;
    }

    if (!url) return null;
    try {
        const img = await loadImage(await fetchBuffer(url));
        _emojiCache.set(emojiStr, img);
        return img;
    } catch {
        _emojiCache.set(emojiStr, null);
        return null;
    }
}

// ─────────────────────────────────────────────
// رسم مستطيل بزوايا دائرية
// ─────────────────────────────────────────────
function roundRect(ctx, x, y, w, h, r) {
    ctx.beginPath();
    ctx.moveTo(x + r, y);
    ctx.lineTo(x + w - r, y);
    ctx.arcTo(x + w, y,     x + w, y + r,     r);
    ctx.lineTo(x + w, y + h - r);
    ctx.arcTo(x + w, y + h, x + w - r, y + h, r);
    ctx.lineTo(x + r, y + h);
    ctx.arcTo(x,     y + h, x,     y + h - r, r);
    ctx.lineTo(x,     y + r);
    ctx.arcTo(x,     y,     x + r, y,         r);
    ctx.closePath();
}

// ─────────────────────────────────────────────
// رسم صورة دائرية مقصوصة
// ─────────────────────────────────────────────
function drawCircle(ctx, img, x, y, size) {
    ctx.save();
    ctx.beginPath();
    ctx.arc(x + size / 2, y + size / 2, size / 2, 0, Math.PI * 2);
    ctx.closePath();
    ctx.clip();
    ctx.drawImage(img, x, y, size, size);
    ctx.restore();
}

// ─────────────────────────────────────────────
// بناء الصورة
// ─────────────────────────────────────────────
async function buildImage(entries, currencyEmojiStr) {
    const W      = 760;
    const ROW_H  = 64;
    const PAD_X  = 6;
    const GAP_Y  = 5;
    const TOP    = 6;
    const BOTTOM = 6;
    const H      = TOP + entries.length * (ROW_H + GAP_Y) - GAP_Y + BOTTOM;

    const canvas = createCanvas(W, H);
    const ctx    = canvas.getContext('2d');

    // شفاف — بدون خلفية
    ctx.clearRect(0, 0, W, H);

    const currencyImg = await loadEmojiImg(currencyEmojiStr);

    for (let i = 0; i < entries.length; i++) {
        const { username, amount, avatarImg } = entries[i];
        const isTop3 = i < 3;
        const pal    = isTop3 ? TOP3[i] : null;
        const rowY   = TOP + i * (ROW_H + GAP_Y);
        const cardW  = W - PAD_X * 2;

        // ── خلفية البطاقة موحدة ──
        ctx.fillStyle = '#1e2029';
        roundRect(ctx, PAD_X, rowY, cardW, ROW_H, 10);
        ctx.fill();

        // ── حد البطاقة ──
        ctx.strokeStyle = isTop3 ? `${pal.ring}35` : 'rgba(255,255,255,0.06)';
        ctx.lineWidth   = 1;
        roundRect(ctx, PAD_X, rowY, cardW, ROW_H, 10);
        ctx.stroke();

        // ── شريط جانبي ملوّن (أول 3 فقط) ──
        if (isTop3) {
            ctx.save();
            ctx.beginPath();
            // مستطيل صغير في يسار البطاقة مع زوايا دائرية جهة اليسار
            ctx.moveTo(PAD_X,     rowY + 12);
            ctx.lineTo(PAD_X,     rowY + ROW_H - 12);
            ctx.arcTo(PAD_X,     rowY + ROW_H - 12, PAD_X + 4, rowY + ROW_H - 12, 0);
            ctx.lineTo(PAD_X + 4, rowY + ROW_H - 12);
            ctx.lineTo(PAD_X + 4, rowY + 12);
            ctx.closePath();
            const barG = ctx.createLinearGradient(0, rowY + 12, 0, rowY + ROW_H - 12);
            barG.addColorStop(0,   pal.ring);
            barG.addColorStop(1,   pal.ring + '66');
            ctx.fillStyle = barG;
            ctx.fill();
            ctx.restore();
        }

        // ── رقم الترتيب ──
        const rankX = PAD_X + 18;
        ctx.font      = 'bold 12px sans-serif';
        ctx.fillStyle = isTop3 ? pal.ring : 'rgba(255,255,255,0.18)';
        ctx.textAlign = 'center';
        ctx.fillText(`#${i + 1}`, rankX + 10, rowY + ROW_H / 2 + 4);
        ctx.textAlign = 'left';

        // ── صورة العضو ──
        const AV  = 40;
        const avX = PAD_X + 52;
        const avY = rowY + (ROW_H - AV) / 2;
        const cx  = avX + AV / 2;
        const cy  = avY + AV / 2;

        // حلقة ملوّنة للـ top3
        if (isTop3) {
            ctx.save();
            ctx.shadowColor = pal.ring;
            ctx.shadowBlur  = 10;
            ctx.beginPath();
            ctx.arc(cx, cy, AV / 2 + 2, 0, Math.PI * 2);
            ctx.strokeStyle = pal.ring;
            ctx.lineWidth   = 2;
            ctx.stroke();
            ctx.restore();
        }

        if (avatarImg) {
            drawCircle(ctx, avatarImg, avX, avY, AV);
        } else {
            ctx.beginPath();
            ctx.arc(cx, cy, AV / 2, 0, Math.PI * 2);
            ctx.fillStyle = '#1A2040';
            ctx.fill();
            ctx.font      = 'bold 18px sans-serif';
            ctx.fillStyle = isTop3 ? pal.ring : '#4A5270';
            ctx.textAlign = 'center';
            ctx.fillText(username.charAt(0).toUpperCase(), cx, cy + 6);
            ctx.textAlign = 'left';
        }

        // ── اسم العضو (ملوّن للـ top3 فقط) ──
        const nameX = avX + AV + 14;
        ctx.font      = 'bold 15px sans-serif';
        ctx.fillStyle = isTop3 ? pal.name : '#8892b0';
        ctx.fillText(username, nameX, rowY + ROW_H / 2 + 5);

        // ── المبلغ + إيموجي العملة ──
        const EMOJI_S   = 24;
        const GAP       = 7;
        const rightEdge = W - PAD_X - 18;

        ctx.font      = 'bold 17px sans-serif';
        ctx.fillStyle = isTop3 ? pal.amt : '#4a5580';

        const amtStr = fmt(amount);
        const amtW   = ctx.measureText(amtStr).width;
        const totalW = currencyImg ? amtW + GAP + EMOJI_S : amtW;
        const amtX   = rightEdge - totalW;
        const textY  = rowY + ROW_H / 2 + 6;

        // توهّج المبلغ للـ top3
        if (isTop3) {
            ctx.save();
            ctx.shadowColor = pal.amtGlow;
            ctx.shadowBlur  = 14;
        }
        ctx.fillText(amtStr, amtX, textY);
        if (isTop3) ctx.restore();

        // إيموجي العملة
        if (currencyImg) {
            // تعتيم خفيف للباقين
            if (!isTop3) ctx.globalAlpha = 0.4;
            ctx.drawImage(currencyImg, amtX + amtW + GAP, textY - EMOJI_S + 4, EMOJI_S, EMOJI_S);
            ctx.globalAlpha = 1;
        }
    }

    return canvas.toBuffer('image/png');
}

// ─────────────────────────────────────────────
// الأمر الرئيسي
// ─────────────────────────────────────────────
module.exports = {
    data: {
        name        : 'moneytop',
        description : 'Show the richest members | عرض أغنى الأعضاء',
        default_member_permissions: null,
    },

    async execute(interaction, client, settings) {
        try {
            await interaction.deferReply();

            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];

            const economy = loadEconomySettings();
            if (!economy?.enabled) {
                return interaction.editReply({
                    embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(t.disabled)],
                });
            }

            const lb       = economy.leaderboard || {};
            const sortBy   = lb.sortBy || 'total';
            const limit    = Math.min(lb.perPage || 10, 20);
            const currency = economy.currency || '🪙';

            const rankedUsers = getLeaderboard(interaction.guildId, sortBy, limit);
            if (!rankedUsers?.length) {
                return interaction.editReply({
                    embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(t.noData)],
                });
            }

            // ── بيانات الأعضاء ──
            const entries = [];
            for (const data of rankedUsers) {
                const member = await interaction.guild.members.fetch(data.userId).catch(() => null);
                if (!member) continue;

                let avatarImg = null;
                try {
                    const url = member.user.displayAvatarURL({ extension: 'png', size: 128 });
                    avatarImg = await loadImage(await fetchBuffer(url));
                } catch { /* null */ }

                entries.push({
                    username  : member.displayName,
                    amount    : data[sortBy] ?? 0,
                    avatarImg,
                });
            }

            if (!entries.length) {
                return interaction.editReply({
                    embeds: [new EmbedBuilder().setColor('#ED4245').setDescription(t.noData)],
                });
            }

            // ── بناء الصورة ──
            const buf  = await buildImage(entries, currency);
            const file = new AttachmentBuilder(buf, { name: 'leaderboard.png' });

            // ── تاريخ ووقت الآن ──
            const now     = new Date();
            const dateStr = now.toLocaleString('en-US', {
                month  : 'numeric',
                day    : 'numeric',
                year   : 'numeric',
                hour   : 'numeric',
                minute : '2-digit',
                second : '2-digit',
                hour12 : true,
            });

            // ── صورة السيرفر المصغرة ──
            const guildIcon = interaction.guild.iconURL({ extension: 'png', size: 64 }) ?? null;

            const embed = new EmbedBuilder()
                .setColor('#FFD700')
                .setTitle(t.title)
                .setImage('attachment://leaderboard.png')
                .setFooter({
                    text    : `${interaction.guild.name} | ${dateStr}`,
                    iconURL : guildIcon ?? undefined,
                });

            await interaction.editReply({ embeds: [embed], files: [file] });

        } catch (err) {
            console.error('[moneytop]', err);
            const e = new EmbedBuilder().setColor('#ED4245').setDescription('❌ حدث خطأ، يرجى المحاولة لاحقاً.');
            const p = { embeds: [e], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(p).catch(() => {});
            } else {
                await interaction.reply(p).catch(() => {});
            }
        }
    },
};