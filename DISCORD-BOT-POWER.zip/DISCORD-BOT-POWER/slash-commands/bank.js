const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, addToTreasury, addTransaction, withUserLock } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:    '⚠️ نظام الاقتصاد معطل حالياً.',
        bankOff:     '⚠️ نظام البنك معطل حالياً.',
        noMoney:     (amount, cur) => `❌ لا تملك **${amount.toLocaleString()} ${cur}** في محفظتك.`,
        noBankMoney: (amount, cur) => `❌ لا تملك **${amount.toLocaleString()} ${cur}** في البنك.`,
        limitReach:  (max, cur)   => `❌ الحد الأقصى للبنك هو **${max.toLocaleString()} ${cur}**.`,
        deposited:   (amount, cur) => `🏦 أودعت **${amount.toLocaleString()} ${cur}** في البنك.`,
        withdrew:    (amount, cur, fee) => fee > 0
            ? `💸 سحبت **${amount.toLocaleString()} ${cur}** من البنك (رسوم: ${fee.toLocaleString()} ${cur}).`
            : `💸 سحبت **${amount.toLocaleString()} ${cur}** من البنك.`,
        balance:     'رصيدك',
        wallet:      '💰 المحفظة',
        bank:        '🏦 البنك',
        footer:      'البنك'
    },
    en: {
        disabled:    '⚠️ Economy system is currently disabled.',
        bankOff:     '⚠️ Bank system is currently disabled.',
        noMoney:     (amount, cur) => `❌ You don't have **${amount.toLocaleString()} ${cur}** in your wallet.`,
        noBankMoney: (amount, cur) => `❌ You don't have **${amount.toLocaleString()} ${cur}** in your bank.`,
        limitReach:  (max, cur)   => `❌ Bank limit is **${max.toLocaleString()} ${cur}**.`,
        deposited:   (amount, cur) => `🏦 Deposited **${amount.toLocaleString()} ${cur}** into your bank.`,
        withdrew:    (amount, cur, fee) => fee > 0
            ? `💸 Withdrew **${amount.toLocaleString()} ${cur}** from bank (fee: ${fee.toLocaleString()} ${cur}, received: ${amount.toLocaleString()} ${cur}).`
            : `💸 Withdrew **${amount.toLocaleString()} ${cur}** from your bank.`,
        balance:     'Your Balance',
        wallet:      '💰 Wallet',
        bank:        '🏦 Bank',
        footer:      'Bank'
    }
};

module.exports = {
    data: {
        name: 'bank',
        description: 'Deposit or withdraw from your bank | إيداع أو سحب من البنك',
        default_member_permissions: null,
        options: [
            {
                name: 'deposit',
                description: 'Deposit coins into your bank | أودع عملات في البنك',
                type: 1,
                options: [
                    { name: 'amount', description: 'Amount to deposit | المبلغ', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'withdraw',
                description: 'Withdraw coins from your bank | اسحب عملات من البنك',
                type: 1,
                options: [
                    { name: 'amount', description: 'Amount to withdraw | المبلغ', type: 4, required: true, min_value: 1 }
                ]
            },
            {
                name: 'balance',
                description: 'Check your bank balance | فحص رصيد البنك',
                type: 1,
                options: []
            }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const bankCfg = es.bank || {};
            if (!bankCfg.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.bankOff).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const sub = interaction.options.getSubcommand();
            const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

            // balance لا تحتاج قفل (قراءة فقط)
            if (sub === 'balance') {
                const user = getUser(interaction.guildId, interaction.user.id);
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setAuthor({ name: interaction.user.username, iconURL: interaction.user.displayAvatarURL({ dynamic: true }) })
                        .setColor('#5865F2')
                        .addFields(
                            { name: t.wallet, value: `${(user.wallet || 0).toLocaleString()} ${cur}`, inline: true },
                            { name: t.bank,   value: `${(user.bank   || 0).toLocaleString()} ${cur}`, inline: true }
                        )
                        .setFooter({ text: t.footer })]
                });
            }

            // [FIX-BANK-01] تغليف إيداع/سحب بقفل لمنع race condition
            // (مثال: يُشغّل المستخدم /bank deposit و /pay في آن واحد)
            let replyPayload;
            await withUserLock(interaction.guildId, interaction.user.id, async () => {
                const user = getUser(interaction.guildId, interaction.user.id);

                if (sub === 'deposit') {
                    const amount    = interaction.options.getInteger('amount');
                    if ((user.wallet || 0) < amount) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.noMoney(amount, cur)).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    const bankLimit = bankCfg.limit || 0;
                    if (bankLimit > 0 && (user.bank || 0) + amount > bankLimit) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.limitReach(bankLimit, cur)).setColor('#FEE75C')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    user.wallet = (user.wallet || 0) - amount;
                    user.bank   = (user.bank   || 0) + amount;
                    saveUser(interaction.guildId, interaction.user.id, user);
                    addTransaction(interaction.guildId, interaction.user.id, 'bank_deposit', -amount, '');
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(t.deposited(amount, cur))
                            .addFields(
                                { name: t.wallet, value: `${user.wallet.toLocaleString()} ${cur}`, inline: true },
                                { name: t.bank,   value: `${user.bank.toLocaleString()} ${cur}`,   inline: true }
                            )
                            .setColor('#57F287').setFooter({ text: t.footer })]
                    };
                    return;
                }

                if (sub === 'withdraw') {
                    const amount    = interaction.options.getInteger('amount');
                    const feeRate   = bankCfg.withdrawFee || 0;
                    const fee       = Math.floor(amount * (feeRate / 100));
                    const netAmount = amount - fee;

                    if ((user.bank || 0) < amount) {
                        replyPayload = {
                            embeds: [new EmbedBuilder().setDescription(t.noBankMoney(amount, cur)).setColor('#ED4245')],
                            flags: MessageFlags.Ephemeral
                        };
                        return;
                    }
                    user.bank   = (user.bank   || 0) - amount;
                    user.wallet = (user.wallet || 0) + netAmount;
                    saveUser(interaction.guildId, interaction.user.id, user);
                    if (es.treasuryEnabled && fee > 0) addToTreasury(interaction.guildId, fee, 'bank_fee');
                    addTransaction(interaction.guildId, interaction.user.id, 'bank_withdraw', netAmount, fee > 0 ? `Fee: ${fee}` : '');
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(t.withdrew(netAmount, cur, fee))
                            .addFields(
                                { name: t.wallet, value: `${user.wallet.toLocaleString()} ${cur}`, inline: true },
                                { name: t.bank,   value: `${user.bank.toLocaleString()} ${cur}`,   inline: true }
                            )
                            .setColor('#FEE75C').setFooter({ text: t.footer })]
                    };
                }
            });

            return interaction.reply(replyPayload);

        } catch (err) {
            // [FIX-LOG-01] تسجيل السياق الكامل
            console.error('[bank] unexpected error', {
                guildId: interaction.guildId,
                userId:  interaction.user.id,
                sub:     interaction.options.getSubcommand?.(),
                error:   err.message
            });
            const _errEmbed  = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
