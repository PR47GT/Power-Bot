const { EmbedBuilder, MessageFlags } = require('discord.js');
const { getUser, saveUser, getAllShopItems, getAllChests, getChest, getItem,
        addEconXP, XP_SOURCES, addUserStat, updateQuestProgress } = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');
const fs   = require('fs');
const path = require('path');

const SHOPSTOCK_FILE = path.join(__dirname, '..', 'shopStock.json');

function readStock() {
    try { return JSON.parse(fs.readFileSync(SHOPSTOCK_FILE, 'utf8')); } catch(_) { return {}; }
}
function writeStock(stock) {
    try {
        const tmp = SHOPSTOCK_FILE + '.tmp';
        fs.writeFileSync(tmp, JSON.stringify(stock, null, 2), 'utf8');
        fs.renameSync(tmp, SHOPSTOCK_FILE);
    } catch(_) {
        fs.writeFileSync(SHOPSTOCK_FILE, JSON.stringify(stock, null, 2), 'utf8');
    }
}

const T = {
    ar: {
        disabled:      '⚠️ نظام الاقتصاد معطل حالياً.',
        title:         '🛒 المتجر',
        itemsSection:  '🏷️ العناصر',
        consumablesSection: '✨ العناصر الاستهلاكية',
        chestsSection: '📦 الصناديق',
        empty:         'المتجر فارغ حالياً.',
        noItem:        '❌ العنصر غير موجود في المتجر.',
        infoTitle:     (name) => `🏷️ ${name}`,
        price:         'السعر',
        desc:          'الوصف',
        rarity:        'الندرة',
        outOfStock:    '❌ الصندوق نفد من المخزون.',
        noMoney:       (price, cur) => `❌ رصيدك غير كافٍ. تحتاج **${price.toLocaleString()} ${cur}**.`,
        alreadyRole:   '❌ أنت تملك هذه الرتبة بالفعل.',
        boughtItem:    (name, price, cur, emoji) => `✅ اشتريت **${name}** بـ **${price.toLocaleString()} ${cur}**.\n${emoji || '📦'} تمت إضافته إلى مخزونك.`,
        boughtRole:    (name, price, cur, emoji) => `✅ اشتريت رتبة **${name}** بـ **${price.toLocaleString()} ${cur}**.\n${emoji || '🎖️'} تمت إضافة الرتبة لحسابك.`,
        boughtChest:   (name, price, cur, emoji) => `✅ اشتريت صندوق **${name}** بـ **${price.toLocaleString()} ${cur}**.\n${emoji || '📦'} تمت إضافته إلى مخزون صناديقك.`,
        balance:       'رصيدك الحالي',
        stock:         'المخزون',
        unlimited:     '∞',
        noDesc:        'بدون وصف',
        roleItem:      'عنصر رتبة',
        xpGained:      (n) => `+${n} XP`,
        howToBuy:      '💡 للشراء: /shop buy   [اسم العنصر]',
        footer:        'المتجر'
    },
    en: {
        disabled:      '⚠️ Economy system is currently disabled.',
        title:         '🛒 Shop',
        itemsSection:  '🏷️ Items',
        consumablesSection: '✨ Consumable Items',
        chestsSection: '📦 Chests',
        empty:         'The shop is currently empty.',
        noItem:        '❌ Item not found in shop.',
        infoTitle:     (name) => `🏷️ ${name}`,
        price:         'Price',
        desc:          'Description',
        rarity:        'Rarity',
        outOfStock:    '❌ This chest is out of stock.',
        noMoney:       (price, cur) => `❌ Insufficient balance. You need **${price.toLocaleString()} ${cur}**.`,
        alreadyRole:   '❌ You already own this role.',
        boughtItem:    (name, price, cur, emoji) => `✅ Bought **${name}** for **${price.toLocaleString()} ${cur}**.\n${emoji || '📦'} Added to your inventory.`,
        boughtRole:    (name, price, cur, emoji) => `✅ Purchased role **${name}** for **${price.toLocaleString()} ${cur}**.\n${emoji || '🎖️'} Role has been added to your account.`,
        boughtChest:   (name, price, cur, emoji) => `✅ Bought chest **${name}** for **${price.toLocaleString()} ${cur}**.\n${emoji || '📦'} Added to your chest inventory.`,
        balance:       'Your Balance',
        stock:         'Stock',
        unlimited:     '∞',
        noDesc:        'No description',
        roleItem:      'Role item',
        xpGained:      (n) => `+${n} XP`,
        howToBuy:      '💡 To buy: /shop buy  [item name]',
        footer:        'Shop'
    }
};

const RARITY_EMOJI = {
    common:    '⚪',
    uncommon:  '🟢',
    rare:      '🔵',
    epic:      '🟣',
    legendary: '🟡'
};

function safeDesc(raw, fallback) {
    const s = (raw || '').trim();
    return s && s !== '-' ? s : (fallback || '');
}

module.exports = {
    data: {
        name: 'shop',
        description: 'Browse and buy from the shop | تصفح المتجر وتسوّق',
        default_member_permissions: null,
        options: [
            {
                name: 'list',
                description: 'List all shop items and chests | عرض كل العناصر والصناديق',
                type: 1,
                options: []
            },
            {
                name: 'info',
                description: 'View details of an item or chest | تفاصيل عنصر أو صندوق',
                type: 1,
                options: [
                    { name: 'name', description: 'Item or chest name | اسم العنصر أو الصندوق', type: 3, required: true }
                ]
            },
            {
                name: 'buy',
                description: 'Buy an item or chest | اشتر عنصراً أو صندوقاً',
                type: 1,
                options: [
                    { name: 'name', description: 'Item or chest name | اسم العنصر أو الصندوق', type: 3, required: true }
                ]
            }
        ]
    },

    async execute(interaction, client, settings) {
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t    = T[lang];
        const es   = loadEconomySettings();

        if (!es.enabled) {
            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        const sub = interaction.options.getSubcommand();
        const cur = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;

        // ── LIST ─────────────────────────────────────────────────────────────
        if (sub === 'list') {
            const items  = getAllShopItems();
            const chests = getAllChests();
            const stock  = readStock();

            const hasItems  = items  && items.length  > 0;
            const hasChests = chests && chests.length > 0;

            if (!hasItems && !hasChests) {
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setTitle(t.title)
                        .setDescription(t.empty)
                        .setColor('#5865F2').setFooter({ text: t.footer })]
                });
            }

           const embed = new EmbedBuilder()
    .setTitle(t.title)
    
    .setColor('#5865F2')
   .setFooter({ text: t.howToBuy })
 

            if (hasItems) {
                // [FIX-SECTIONS] Split into role/shop items and consumable items so each gets its own header
                // Consumable items (from items.json) always have a 'duration' field;
                // shop/role items (from economySystem.json) never do.
                const shopOnlyItems   = items.filter(it => !it.duration);
                const consumableItems = items.filter(it =>  it.duration);

                if (shopOnlyItems.length > 0) {
                    const itemDesc = shopOnlyItems.map(it => {
                        const emoji   = it.emoji ? `${it.emoji} ` : '📦 ';
                        const roleTag = it.roleId ? ` _(${t.roleItem})_` : '';
                        const desc    = safeDesc(it.description, it.roleId ? t.roleItem : t.noDesc);
                        return `${emoji}**${it.name || it.id}**${roleTag}\n└ ${(it.price || 0).toLocaleString()} ${cur}  ·  ${desc}`;
                    }).join('\n\n');
                    embed.addFields({ name: t.itemsSection, value: itemDesc.slice(0, 1024) || '-' });
                }

                if (consumableItems.length > 0) {
                    const consumableDesc = consumableItems.map(it => {
                        const emoji = it.emoji ? `${it.emoji} ` : '✨ ';
                        const desc  = safeDesc(it.description, t.noDesc);
                        return `${emoji}**${it.name || it.id}**\n└ ${(it.price || 0).toLocaleString()} ${cur}  ·  ${desc}`;
                    }).join('\n\n');
                    embed.addFields({ name: t.consumablesSection, value: consumableDesc.slice(0, 1024) || '-' });
                }
            }

            if (hasChests) {
                const chestDesc = chests.map(c => {
                    const emoji    = c.emoji ? `${c.emoji} ` : (RARITY_EMOJI[c.rarity] || '📦') + ' ';
                    const inStock  = stock[c.name] !== undefined ? stock[c.name] : -1;
                    const stockStr = inStock < 0 ? t.unlimited : String(inStock);
                    const desc     = safeDesc(c.description, '');
                    const descPart = desc ? `${desc}  ·  ` : '';
                    return `${emoji}**${c.name}** — ${(c.price || 0).toLocaleString()} ${cur}\n└ ${descPart}${t.stock}: ${stockStr}`;
                }).join('\n\n');
                embed.addFields({ name: t.chestsSection, value: chestDesc.slice(0, 1024) || '-' });
            }

            // [FIX-1] Recipes section removed from /shop list.
            // Recipes are craftable only — use /recipe list to view them.

            return interaction.reply({ embeds: [embed] });
        }

        // ── INFO ─────────────────────────────────────────────────────────────
        if (sub === 'info') {
            const name   = interaction.options.getString('name').trim();
            const items  = getAllShopItems();
            const chests = getAllChests();
            const stock  = readStock();
            const nameLower = name.toLowerCase();

            const it = items.find(i =>
                (i.id  || '').toLowerCase() === nameLower ||
                (i.name|| '').toLowerCase() === nameLower
            );
            if (it) {
                const emoji = it.emoji ? `${it.emoji} ` : '📦 ';
                const embed = new EmbedBuilder()
                    .setTitle(`${emoji}${it.name || it.id}`)
                    .addFields(
                        { name: t.price, value: `${(it.price || 0).toLocaleString()} ${cur}`, inline: true },
                        { name: t.desc,  value: safeDesc(it.description, it.roleId ? t.roleItem : t.noDesc), inline: true }
                    )
                    .setColor('#5865F2').setFooter({ text: t.footer });
                if (it.roleId) embed.addFields({ name: '🎖️ Role', value: `<@&${it.roleId}>`, inline: true });
                return interaction.reply({ embeds: [embed] });
            }

            const ch = chests.find(c => (c.name || '').toLowerCase() === nameLower);
            if (ch) {
                const emoji    = ch.emoji ? `${ch.emoji} ` : (RARITY_EMOJI[ch.rarity] || '📦') + ' ';
                const inStock  = stock[ch.name] !== undefined ? stock[ch.name] : -1;
                const stockStr = inStock < 0 ? t.unlimited : String(inStock);
                const embed = new EmbedBuilder()
                    .setTitle(`${emoji}${ch.name}`)
                    .addFields(
                        { name: t.price,  value: `${(ch.price || 0).toLocaleString()} ${cur}`, inline: true },
                        { name: t.rarity, value: `${RARITY_EMOJI[ch.rarity] || '⚪'} ${ch.rarity || 'common'}`, inline: true },
                        { name: t.stock,  value: stockStr, inline: true },
                        { name: t.desc,   value: safeDesc(ch.description, t.noDesc), inline: false }
                    )
                    .setColor('#FEE75C').setFooter({ text: t.footer });
                return interaction.reply({ embeds: [embed] });
            }

            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.noItem).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }

        // ── BUY ──────────────────────────────────────────────────────────────
        if (sub === 'buy') {
            const name      = interaction.options.getString('name').trim();
            const nameLower = name.toLowerCase();
            const items     = getAllShopItems();
            const chests    = getAllChests();
            const stock     = readStock();
            const user      = getUser(interaction.guildId, interaction.user.id);

            const chest = chests.find(c => (c.name || '').toLowerCase() === nameLower);
            if (chest) {
                const price   = chest.price || 0;
                const inStock = stock[chest.name] !== undefined ? stock[chest.name] : -1;

                if (inStock === 0) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.outOfStock).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }
                if ((user.wallet || 0) < price) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noMoney(price, cur)).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                if (inStock > 0) {
                    stock[chest.name] = inStock - 1;
                    writeStock(stock);
                }

                if (!user.chests || Array.isArray(user.chests)) user.chests = {};
                user.wallet = (user.wallet || 0) - price;
                user.chests[chest.name] = (user.chests[chest.name] || 0) + 1;
                saveUser(interaction.guildId, interaction.user.id, user);

                // ── XP & Stats ──────────────────────────────────────────────
                addEconXP(interaction.guildId, interaction.user.id, XP_SOURCES.buy_item);
                addUserStat(interaction.guildId, interaction.user.id, 'buyCount', 1);
                addUserStat(interaction.guildId, interaction.user.id, 'totalSpent', price);
                updateQuestProgress(interaction.guildId, interaction.user.id, 'spend_coins', price);

                // [FIX-3] Use the chest's own emoji
                const chestEmoji = chest.emoji || (RARITY_EMOJI[chest.rarity] || '📦');
                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.boughtChest(chest.name, price, cur, chestEmoji))
                        .addFields(
                            { name: t.balance,  value: `${user.wallet.toLocaleString()} ${cur}` },
                            { name: '⭐ XP',    value: t.xpGained(XP_SOURCES.buy_item), inline: true }
                        )
                        .setColor('#57F287').setFooter({ text: t.footer })]
                });
            }

            // ── Try item ──
            const shopItem = items.find(i =>
                (i.id  || '').toLowerCase() === nameLower ||
                (i.name|| '').toLowerCase() === nameLower
            );
            if (shopItem) {
                const price = shopItem.price || 0;

                if ((user.wallet || 0) < price) {
                    return interaction.reply({
                        embeds: [new EmbedBuilder().setDescription(t.noMoney(price, cur)).setColor('#ED4245')],
                        flags: MessageFlags.Ephemeral
                    });
                }

                // [FIX-3] Use the item's own emoji
                const itemEmoji = shopItem.emoji || null;

                if (shopItem.roleId) {
                    if (interaction.guild) {
                        const member = await interaction.guild.members.fetch(interaction.user.id);
                        if (member.roles.cache.has(shopItem.roleId)) {
                            return interaction.reply({
                                embeds: [new EmbedBuilder().setDescription(t.alreadyRole).setColor('#FEE75C')],
                                flags: MessageFlags.Ephemeral
                            });
                        }
                        await member.roles.add(shopItem.roleId).catch(() => {});
                    }
                    user.wallet = (user.wallet || 0) - price;
                    saveUser(interaction.guildId, interaction.user.id, user);

                    addEconXP(interaction.guildId, interaction.user.id, XP_SOURCES.buy_item);
                    addUserStat(interaction.guildId, interaction.user.id, 'buyCount', 1);
                    addUserStat(interaction.guildId, interaction.user.id, 'totalSpent', price);
                    updateQuestProgress(interaction.guildId, interaction.user.id, 'spend_coins', price);

                    return interaction.reply({
                        embeds: [new EmbedBuilder()
                            .setDescription(t.boughtRole(shopItem.name || name, price, cur, itemEmoji))
                            .addFields(
                                { name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}` },
                                { name: '⭐ XP',   value: t.xpGained(XP_SOURCES.buy_item), inline: true }
                            )
                            .setColor('#57F287').setFooter({ text: t.footer })]
                    });
                }

                if (!user.inventory || Array.isArray(user.inventory)) user.inventory = {};
                user.wallet = (user.wallet || 0) - price;
                user.inventory[shopItem.id || name] = (user.inventory[shopItem.id || name] || 0) + 1;
                saveUser(interaction.guildId, interaction.user.id, user);

                addEconXP(interaction.guildId, interaction.user.id, XP_SOURCES.buy_item);
                addUserStat(interaction.guildId, interaction.user.id, 'buyCount', 1);
                addUserStat(interaction.guildId, interaction.user.id, 'totalSpent', price);
                updateQuestProgress(interaction.guildId, interaction.user.id, 'spend_coins', price);

                return interaction.reply({
                    embeds: [new EmbedBuilder()
                        .setDescription(t.boughtItem(shopItem.name || name, price, cur, itemEmoji))
                        .addFields(
                            { name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}` },
                            { name: '⭐ XP',   value: t.xpGained(XP_SOURCES.buy_item), inline: true }
                        )
                        .setColor('#57F287').setFooter({ text: t.footer })]
                });
            }

            return interaction.reply({
                embeds: [new EmbedBuilder().setDescription(t.noItem).setColor('#ED4245')],
                flags: MessageFlags.Ephemeral
            });
        }
    }
};
