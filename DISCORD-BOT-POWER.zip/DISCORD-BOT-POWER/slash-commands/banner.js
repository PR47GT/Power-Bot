const { EmbedBuilder } = require('discord.js');

const T = {
    ar: {
        title: (username) => ` البانر الخاص بـ ${username}`,
        noBanner: (username) => `❌ ${username} ليس لديه بانر`,
    },
    en: {
        title: (username) => ` ${username}'s Banner`,
        noBanner: (username) => `❌ ${username} has no banner`,
    },
};

module.exports = {
    name: 'banner',
    description: 'عرض البانر الخاص بالمستخدم | Display user banner',
    description_localizations: {
        enUS: 'Display user banner',
        ar: 'عرض البانر الخاص بالمستخدم',
    },
    options: [
        { 
            name: 'user', 
            name_localizations: {
                ar: 'مستخدم',
                enUS: 'user',
            },
            type: 6, 
            description: 'المستخدم (اختياري) | User (optional)',
            description_localizations: {
                ar: 'المستخدم الذي تريد عرض البانر الخاص به (اختياري)',
                enUS: 'The user whose banner you want to display (optional)',
            },
            required: false 
        }
    ],

    async execute(interaction, client, settings, commandConfig) {
        // تحديد اللغة من الإعدادات
        const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
        const t = T[lang];

        const targetUser = interaction.options.getUser('user') || interaction.user;
        const userFetch = await client.users.fetch(targetUser.id, { force: true });
        
        const bannerUrl = userFetch.bannerURL({ dynamic: true, size: 4096 });
        
        if (!bannerUrl) {
            return interaction.reply({
                content: t.noBanner(targetUser.username),
                flags: 64 // Ephemeral
            });
        }
        
        const embed = new EmbedBuilder()
            .setColor(0x5865F2)
            .setTitle(t.title(targetUser.username))
            .setImage(bannerUrl)
            .setFooter({ 
                text: ` ${lang === 'ar' ? 'طلب بواسطة' : 'Requested by'} ${interaction.user.username}`,
                iconURL: interaction.user.displayAvatarURL({ dynamic: true, size: 64 })
            })
            .setTimestamp();
        
        await interaction.reply({ embeds: [embed] });
        
        // حذف الرد بعد 5 ثواني إذا كان الإعداد مفعلاً
        if (commandConfig?.deleteResponse) {
            setTimeout(async () => {
                try {
                    await interaction.deleteReply();
                } catch(e) {}
            }, 5000);
        }
    },
};