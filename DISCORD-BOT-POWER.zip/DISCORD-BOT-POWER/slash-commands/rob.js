const { EmbedBuilder, MessageFlags } = require('discord.js');
const {
    getUser, saveUser, cooldownLeft, formatTime,
    addToTreasury, addTransaction, withTwoUserLocks
} = require('./economyData');
const { loadEconomySettings } = require('../features/economy/economyRoutes');

const T = {
    ar: {
        disabled:   '⚠️ نظام الاقتصاد معطل حالياً.',
        robOff:     '⚠️ السرقة معطلة حالياً.',
        selfRob:    '❌ لا يمكنك سرقة نفسك.',
        botRob:     '❌ لا يمكنك سرقة روبوت.',
        cooldown:   (time) => `⏰ يمكنك السرقة مرة أخرى بعد **${time}**.`,
        noTarget:   (min, cur) => `❌ هذا العضو لا يملك ما يكفي للسرقة (الحد الأدنى: ${min.toLocaleString()} ${cur}).`,
        success:    (amount, cur, name) => `🦹 نجحت في سرقة **${amount.toLocaleString()} ${cur}** من **${name}**!`,
        failed:     (fine, cur) => `🚓 فشلت السرقة وعليك دفع غرامة **${fine.toLocaleString()} ${cur}**!`,
        shielded:   (name) => `🛡️ **${name}** محمي بدرع سرقة! فشلت محاولتك.`,
        balance:    'رصيدك الحالي',
        footer:     'السرقة'
    },
    en: {
        disabled:   '⚠️ Economy system is currently disabled.',
        robOff:     '⚠️ Robbery is currently disabled.',
        selfRob:    '❌ You cannot rob yourself.',
        botRob:     '❌ You cannot rob a bot.',
        cooldown:   (time) => `⏰ You can rob again in **${time}**.`,
        noTarget:   (min, cur) => `❌ This member doesn't have enough to rob (minimum: ${min.toLocaleString()} ${cur}).`,
        success:    (amount, cur, name) => `🦹 You successfully robbed **${amount.toLocaleString()} ${cur}** from **${name}**!`,
        failed:     (fine, cur) => `🚓 You got caught and paid a fine of **${fine.toLocaleString()} ${cur}**!`,
        shielded:   (name) => `🛡️ **${name}** has an active Rob Shield! Your attempt failed.`,
        balance:    'Your Balance',
        footer:     'Rob'
    }
};

module.exports = {
    data: {
        name: 'rob',
        description: 'Attempt to rob a member | حاول سرقة عضو',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Member to rob | العضو المراد سرقته', type: 6, required: true }
        ]
    },

    async execute(interaction, client, settings) {
        try {
            const lang = settings?.botLanguage === 'ar' ? 'ar' : 'en';
            const t    = T[lang];
            const es   = loadEconomySettings();

            if (!es.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.disabled).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const robCfg = es.rob || {};
            if (!robCfg.enabled) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.robOff).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const target = interaction.options.getUser('user');
            if (target.id === interaction.user.id) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.selfRob).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }
            if (target.bot) {
                return interaction.reply({
                    embeds: [new EmbedBuilder().setDescription(t.botRob).setColor('#ED4245')],
                    flags: MessageFlags.Ephemeral
                });
            }

            const cur        = `${es.currency || '🪙'} ${es.currencyName || 'Coins'}`;
            const cooldownMs = (robCfg.cooldown || 60) * 60000;

            // [FIX-ROB-01] تغليف العملية بقفل مزدوج لضمان عدم تزامن
            // عمليتَي rob/pay على نفس المستخدمَين في آن واحد
            let replyPayload;
            await withTwoUserLocks(interaction.guildId, interaction.user.id, target.id, async () => {
                const user       = getUser(interaction.guildId, interaction.user.id);
                const targetData = getUser(interaction.guildId, target.id);

                const left = cooldownLeft(user.lastRob, cooldownMs);
                if (left > 0) {
                    replyPayload = {
                        embeds: [new EmbedBuilder().setDescription(t.cooldown(formatTime(left))).setColor('#FEE75C')],
                        flags: MessageFlags.Ephemeral
                    };
                    return;
                }

                // [FIX-ROB-02] إضافة حد أدنى لرصيد الضحية قبل السماح بالسرقة
                // الحد الأدنى: minVictimWallet من الإعدادات أو 1 افتراضياً
                const minVictim = robCfg.minVictimWallet || 1;
                if ((targetData.wallet || 0) < minVictim) {
                    replyPayload = {
                        embeds: [new EmbedBuilder().setDescription(t.noTarget(minVictim, cur)).setColor('#FEE75C')],
                        flags: MessageFlags.Ephemeral
                    };
                    return;
                }

                const now    = Date.now();
                const shield = (targetData.activeEffects || []).find(
                    e => e.effect === 'rob_shield' && e.expires > now
                );
                if (shield) {
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(t.shielded(target.username))
                            .setColor('#5865F2')],
                        flags: MessageFlags.Ephemeral
                    };
                    return;
                }

                user.lastRob  = Date.now();
                const success = Math.random() * 100 < (robCfg.successRate || 40);

                if (success) {
                    const maxPct  = (robCfg.maxPercent || 30) / 100;
                    const amount  = Math.max(1, Math.floor((targetData.wallet || 0) * maxPct * Math.random()));
                    user.wallet       = (user.wallet       || 0) + amount;
                    user.totalEarned  = (user.totalEarned  || 0) + amount;
                    targetData.wallet = Math.max((targetData.wallet || 0) - amount, 0);
                    saveUser(interaction.guildId, interaction.user.id, user);
                    saveUser(interaction.guildId, target.id, targetData);
                    addTransaction(interaction.guildId, interaction.user.id, 'rob_win',  amount,  `Robbed from ${target.username}`);
                    addTransaction(interaction.guildId, target.id,           'rob_loss', -amount, `Robbed by ${interaction.user.username}`);
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(t.success(amount, cur, target.username))
                            .addFields({ name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}` })
                            .setColor('#57F287').setFooter({ text: t.footer })]
                    };
                } else {
                    // [PATCH-09] Support both finePrecent (legacy) and finePercent (corrected spelling).
                    const finePct = (robCfg.finePercent || robCfg.finePrecent || 20) / 100;
                    const fine    = Math.floor((user.wallet || 0) * finePct);
                    user.wallet   = Math.max((user.wallet || 0) - fine, 0);
                    saveUser(interaction.guildId, interaction.user.id, user);
                    if (es.treasuryEnabled && fine > 0) addToTreasury(interaction.guildId, fine, 'rob_fine');
                    addTransaction(interaction.guildId, interaction.user.id, 'rob_fine', -fine, 'Rob failed - fine paid');
                    replyPayload = {
                        embeds: [new EmbedBuilder()
                            .setDescription(t.failed(fine, cur))
                            .addFields({ name: t.balance, value: `${user.wallet.toLocaleString()} ${cur}` })
                            .setColor('#ED4245').setFooter({ text: t.footer })]
                    };
                }
            });

            return interaction.reply(replyPayload);

        } catch (err) {
            // [FIX-LOG-01] تسجيل السياق الكامل
            console.error('[rob] unexpected error', {
                guildId:  interaction.guildId,
                userId:   interaction.user.id,
                targetId: interaction.options.getUser?.('user')?.id,
                error:    err.message
            });
            const _errEmbed  = new EmbedBuilder().setDescription('❌ حدث خطأ غير متوقع، يرجى المحاولة لاحقاً.').setColor('#ED4245');
            const _errPayload = { embeds: [_errEmbed], flags: MessageFlags.Ephemeral };
            if (interaction.replied || interaction.deferred) {
                await interaction.followUp(_errPayload).catch(() => {});
            } else {
                await interaction.reply(_errPayload).catch(() => {});
            }
        }
    }
};
