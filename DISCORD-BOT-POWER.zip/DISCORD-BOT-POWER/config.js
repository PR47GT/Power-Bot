module.exports = {
    token: ' ',
    clientId: ' ',
    guildId: ' ',
    dashboardPort: 3000,
    settings: {
        mutedRoleName: "Muted",
        auditLogWaitTime: 800,
        kickDetectionTime: 3000
    }
};
