const { REST, Routes, PermissionFlagsBits, ApplicationCommandOptionType } = require('discord.js');
const config = require('./config');

// ---------- Helper functions ----------
function userOpt(description) {
    return { name: 'user', description, type: ApplicationCommandOptionType.User, required: true };
}
function amtOpt(description) {
    return { name: 'amount', description, type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 };
}
function walletOpt(description) {
    return {
        name: 'wallet', description,
        type: ApplicationCommandOptionType.String,
        required: false,
        choices: [
            { name: 'Wallet', value: 'wallet' },
            { name: 'Bank',   value: 'bank' }
        ]
    };
}

// ---------- All commands ----------
const commands = [
    // ========================= Moderation =========================
    { name: 'clear', description: 'Bulk delete a specified number of messages from a channel', default_member_permissions: PermissionFlagsBits.ManageMessages.toString(),
      options: [{ name: 'amount', description: 'Number of messages to delete (1–100)', type: 4, required: true, min_value: 1, max_value: 100 }] },

    { name: 'ban', description: 'Permanently ban a member from the server', default_member_permissions: PermissionFlagsBits.BanMembers.toString(),
      options: [{ name: 'user', description: 'The member to ban', type: 6, required: true }, { name: 'reason', description: 'Reason for the ban', type: 3, required: false }] },

    { name: 'kick', description: 'Remove a member from the server', default_member_permissions: PermissionFlagsBits.KickMembers.toString(),
      options: [{ name: 'user', description: 'The member to kick', type: 6, required: true }, { name: 'reason', description: 'Reason for the kick', type: 3, required: false }] },

    { name: 'timeout', description: 'Temporarily mute a member for a specified duration', default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
      options: [
          { name: 'user',     description: 'The member to time out', type: 6, required: true },
          { name: 'duration', description: 'Duration in minutes (1–40320)',  type: 4, required: true, min_value: 1, max_value: 40320 },
          { name: 'reason',   description: 'Reason for the timeout', type: 3, required: false }
      ] },

    { name: 'untimeout', description: 'Remove an active timeout from a member', default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
      options: [{ name: 'user', description: 'The member to un-timeout', type: 6, required: true }] },

    { name: 'unban', description: 'Revoke a ban and allow a user back into the server', default_member_permissions: PermissionFlagsBits.BanMembers.toString(),
      options: [{ name: 'user_id', description: 'The ID of the banned user', type: 3, required: true }] },

 {
    name: 'warn',description: 'Warn a member',description_localizations: {'en-US': 'Warn a member', ar: 'تحذير عضو في السيرفر'},
    default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
     options: [{name: 'user',description: 'Member to warn',type: 6,required: true},
     { name: 'reason',description: 'Reason for the warning',type: 3,required: false},
     { name: 'duration',description: 'Warning duration (e.g. 30m, 1h, 2d)',type: 3, required: false }]},  
       
    { name: 'unwarn', description: 'Remove the most recent warning from a member', default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
      options: [{ name: 'user', description: 'The member to unwarn', type: 6, required: true }] },

    { name: 'warns', description: 'Display all active warnings for a member', default_member_permissions: PermissionFlagsBits.ModerateMembers.toString(),
      options: [{ name: 'user', description: 'The member to check', type: 6, required: true }] },

    { name: 'giveroleall', description: 'Assign a role to every member in the server', default_member_permissions: '8',
      options: [{ name: 'role', description: 'The role to assign', type: 8, required: true }] },

    { name: 'clearuser', description: 'Delete recent messages from a specific member in the current channel', default_member_permissions: PermissionFlagsBits.ManageMessages.toString(),
      options: [
          { name: 'user',   description: 'The target member', type: 6, required: true },
          { name: 'amount', description: 'Number of messages to delete (1–100)', type: 4, required: false }
      ] },

    // ========================= Channel Management =========================
    { name: 'lock', description: 'Prevent members from sending messages in a channel', default_member_permissions: PermissionFlagsBits.ManageChannels.toString(),
      options: [{ name: 'channel', description: 'Channel to lock (defaults to current)', type: 7, required: false }] },

    { name: 'unlock', description: 'Restore send-message permissions in a channel', default_member_permissions: PermissionFlagsBits.ManageChannels.toString(),
      options: [{ name: 'channel', description: 'Channel to unlock (defaults to current)', type: 7, required: false }] },

    { name: 'hide', description: 'Make a channel invisible to regular members', default_member_permissions: PermissionFlagsBits.ManageChannels.toString(),
      options: [{ name: 'channel', description: 'Channel to hide (defaults to current)', type: 7, required: false }] },

    { name: 'show', description: 'Make a hidden channel visible to regular members', default_member_permissions: PermissionFlagsBits.ManageChannels.toString(),
      options: [{ name: 'channel', description: 'Channel to show (defaults to current)', type: 7, required: false }] },

    { name: 'lockall',   description: 'Lock every channel in the server simultaneously', default_member_permissions: PermissionFlagsBits.Administrator.toString() },
    { name: 'unlockall', description: 'Unlock every channel in the server simultaneously', default_member_permissions: PermissionFlagsBits.Administrator.toString() },

    { name: 'clearlinks', description: 'Scan and delete messages that contain links', default_member_permissions: PermissionFlagsBits.ManageMessages.toString(),
      options: [{ name: 'amount', description: 'Number of messages to scan (1–100)', type: 4, required: false }] },

    { name: 'clearbots', description: 'Scan and delete messages sent by bots', default_member_permissions: PermissionFlagsBits.ManageMessages.toString(),
      options: [{ name: 'amount', description: 'Number of messages to scan (1–100)', type: 4, required: false }] },

    // ========================= Member Management =========================
    { name: 'setnick', description: "Change or reset a member's nickname", default_member_permissions: PermissionFlagsBits.ManageNicknames.toString(),
      options: [
          { name: 'user',     description: 'The target member',                          type: 6, required: true  },
          { name: 'nickname', description: 'New nickname — leave blank to reset', type: 3, required: false }
      ] },

    { name: 'role', description: 'Add or remove a role from a member', default_member_permissions: PermissionFlagsBits.ManageRoles.toString(),
      options: [
          { name: 'user', description: 'The target member', type: 6, required: true },
          { name: 'role', description: 'The role to add or remove', type: 8, required: true }
      ] },

    { name: 'temprole', description: 'Assign a role to a member for a limited time, then auto-remove it', default_member_permissions: PermissionFlagsBits.ManageRoles.toString(),
      options: [
          { name: 'member', description: 'The target member',              type: 6, required: true },
          { name: 'role',   description: 'The role to assign temporarily', type: 8, required: true },
          { name: 'time',   description: 'Duration (e.g. 1h, 2d)',         type: 3, required: true }
      ] },

    // ========================= Voice =========================
    { name: 'move', description: 'Move a member to a different voice channel', default_member_permissions: PermissionFlagsBits.MoveMembers.toString(),
      options: [
          { name: 'user',    description: 'The member to move',        type: 6, required: true },
          { name: 'channel', description: 'Destination voice channel', type: 7, required: true }
      ] },

    { name: 'vkick', description: 'Disconnect a member from their current voice channel', default_member_permissions: PermissionFlagsBits.MoveMembers.toString(),
      options: [{ name: 'user', description: 'The member to disconnect', type: 6, required: true }] },

    { name: 'vmove', description: 'Move all members from one voice channel to another', default_member_permissions: PermissionFlagsBits.MoveMembers.toString(),
      options: [
          { name: 'source', description: 'Source voice channel',      type: 7, required: true, channel_types: [2] },
          { name: 'target', description: 'Destination voice channel', type: 7, required: true, channel_types: [2] }
      ] },

    // ========================= Info =========================
    { name: 'ping',   description: 'Display the bot latency and API response time', default_member_permissions: null },
    { name: 'roles',  description: 'List all roles available in the server',        default_member_permissions: null },
    { name: 'server', description: 'Display detailed information about this server', default_member_permissions: null },
    { name: 'rules',  description: 'Post the server rules in the current channel',   default_member_permissions: PermissionFlagsBits.ManageGuild.toString() },

    { name: 'user', description: 'Show account details and server info for a user', default_member_permissions: null,
      options: [{ name: 'user', description: 'User to look up (defaults to yourself)', type: 6, required: false }] },

    { name: 'avatar', description: "Display a user's full-size avatar", default_member_permissions: null,
      options: [{ name: 'user', description: 'User to look up (defaults to yourself)', type: 6, required: false }] },

    { name: 'banner', description: "Display a user's profile banner", default_member_permissions: null,
      options: [{ name: 'user', description: 'User to look up (defaults to yourself)', type: 6, required: false }] },

    { name: 'ticket',     description: 'Open a new support ticket',            default_member_permissions: '8' },
    { name: 'apply-send', description: 'Post the staff application submission message', default_member_permissions: PermissionFlagsBits.Administrator.toString() },

    // ========================= Leveling System =========================
    { name: 'rank', description: 'View your current level, XP, and ranking progress', default_member_permissions: null,
      options: [{ name: 'user', description: 'User to check (defaults to yourself)', type: 6, required: false }] },

    { name: 'top', description: 'Show the server XP leaderboard', default_member_permissions: null },

    { name: 'setxp', description: 'Manually set the XP amount for a member', default_member_permissions: PermissionFlagsBits.Administrator.toString(),
      options: [
          { name: 'user',   description: 'The target member', type: 6, required: true },
          { name: 'type',   description: 'Which XP pool to modify', type: 3, required: true,
            choices: [
                { name: 'Chat XP',  value: 'chat'  },
                { name: 'Voice XP', value: 'voice' },
                { name: 'Both',     value: 'both'  }
            ]
          },
          { name: 'amount', description: 'XP value to set', type: 4, required: true, min_value: 0 }
      ] },

    { name: 'resetall', description: 'Wipe XP and level data for every member in the server', default_member_permissions: PermissionFlagsBits.Administrator.toString() },

    { name: 'resetxp', description: 'Reset XP and level progress for a single member', default_member_permissions: PermissionFlagsBits.Administrator.toString(),
      options: [{ name: 'user', description: 'The member to reset', type: 6, required: true }] },

    // ========================= Color Commands =========================
    { name: 'color',  description: 'Pick a color role for yourself from the available palette', type: 1,
      options: [{ name: 'number', description: 'Color number from the /colors list', type: 4, required: false }] },
    { name: 'colors', description: 'Browse all available color roles you can choose from', type: 1 },

    // ========================= Economy — Admin =========================
    {
        name: 'achest',
        description: 'Admin: Manage chest stock and member chest inventories',
        default_member_permissions: String(PermissionFlagsBits.Administrator),
        options: [
            {
                name: 'restock', description: 'Restock a chest with additional supply',
                type: ApplicationCommandOptionType.Subcommand,
                options: [
                    { name: 'name',   description: 'Chest name',    type: ApplicationCommandOptionType.String,  required: true },
                    { name: 'amount', description: 'Stock quantity', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
                ]
            },
            {
                name: 'user', description: 'Manage chests in a specific member\'s inventory',
                type: ApplicationCommandOptionType.SubcommandGroup,
                options: [
                    { name: 'add', description: 'Give one or more chests to a member',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [
                          { name: 'user',   description: 'Target member', type: ApplicationCommandOptionType.User,    required: true  },
                          { name: 'name',   description: 'Chest name',    type: ApplicationCommandOptionType.String,  required: true  },
                          { name: 'amount', description: 'Quantity',       type: ApplicationCommandOptionType.Integer, required: false, min_value: 1 }
                      ] },
                    { name: 'remove', description: 'Remove a chest from a member\'s inventory',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [
                          { name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User,   required: true },
                          { name: 'name', description: 'Chest name',    type: ApplicationCommandOptionType.String, required: true }
                      ] },
                    { name: 'inventory', description: 'View all chests in a member\'s inventory',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [{ name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User, required: true }] },
                    { name: 'view-all', description: 'List every member who owns at least one chest',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [] }
                ]
            }
        ]
    },

    {
        name: 'aitem',
        description: 'Admin: Manage items in member inventories',
        default_member_permissions: String(PermissionFlagsBits.Administrator),
        options: [
            {
                name: 'user', description: 'Perform item actions on a specific member',
                type: ApplicationCommandOptionType.SubcommandGroup,
                options: [
                    { name: 'add', description: 'Add an item to a member\'s inventory',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [
                          { name: 'user',   description: 'Target member',  type: ApplicationCommandOptionType.User,    required: true  },
                          { name: 'item',   description: 'Item name or ID', type: ApplicationCommandOptionType.String,  required: true  },
                          { name: 'amount', description: 'Quantity',        type: ApplicationCommandOptionType.Integer, required: false, min_value: 1 }
                      ] },
                    { name: 'remove', description: 'Remove an item from a member\'s inventory',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [
                          { name: 'user', description: 'Target member',  type: ApplicationCommandOptionType.User,   required: true },
                          { name: 'item', description: 'Item name or ID', type: ApplicationCommandOptionType.String, required: true }
                      ] },
                    { name: 'clear', description: 'Clear all items from a member\'s inventory',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [{ name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User, required: true }] },
                    { name: 'inventory', description: 'View the full inventory of a member',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [{ name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User, required: true }] },
                    { name: 'view-all', description: 'List every member who owns at least one item',
                      type: ApplicationCommandOptionType.Subcommand,
                      options: [] }
                ]
            }
        ]
    },

    {
        name: 'amoney',
        description: 'Admin: Manage coin balances for any member',
        default_member_permissions: String(PermissionFlagsBits.Administrator),
        options: [
            { name: 'add',      description: 'Add coins to a member\'s wallet or bank',         type: ApplicationCommandOptionType.Subcommand, options: [ userOpt('Target member'), amtOpt('Amount to add'),    walletOpt('Destination (wallet or bank)') ] },
            { name: 'remove',   description: 'Remove coins from a member\'s wallet or bank',    type: ApplicationCommandOptionType.Subcommand, options: [ userOpt('Target member'), amtOpt('Amount to remove'), walletOpt('Source (wallet or bank)')      ] },
            { name: 'set',      description: 'Set the exact balance of a member\'s wallet or bank', type: ApplicationCommandOptionType.Subcommand,
              options: [
                  userOpt('Target member'),
                  { name: 'amount', description: 'New balance', type: ApplicationCommandOptionType.Integer, required: true, min_value: 0 },
                  walletOpt('Target (wallet or bank)')
              ] },
            { name: 'balance',  description: 'Check the current balance of a member', type: ApplicationCommandOptionType.Subcommand, options: [ userOpt('Target member') ] },
            { name: 'transfer', description: 'Transfer coins from one member to another',         type: ApplicationCommandOptionType.Subcommand,
              options: [
                  { name: 'from',   description: 'Sender member',   type: ApplicationCommandOptionType.User,    required: true },
                  { name: 'to',     description: 'Receiver member',  type: ApplicationCommandOptionType.User,    required: true },
                  { name: 'amount', description: 'Amount to transfer', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
              ] }
        ]
    },

    {
        name: 'reseteconomy',
        description: 'Wipe all economy data for every member — this action is irreversible',
        default_member_permissions: String(PermissionFlagsBits.Administrator)
    },

    // ========================= Economy — User =========================
    { name: 'balance', description: 'Check your current wallet and bank balance', default_member_permissions: null,
      options: [{ name: 'user', description: 'User to check (defaults to yourself)', type: ApplicationCommandOptionType.User, required: false }] },

    { name: 'profile', description: 'View your economy profile and full financial overview', default_member_permissions: null,
      options: [{ name: 'user', description: 'User to view (defaults to yourself)', type: ApplicationCommandOptionType.User, required: false }] },

    { name: 'work',     description: 'Complete a work shift to earn coins',      default_member_permissions: null },
    { name: 'daily',    description: 'Claim your daily coin reward',             default_member_permissions: null },
    { name: 'weekly',   description: 'Claim your weekly coin reward',            default_member_permissions: null },
    { name: 'moneytop', description: 'Display the wealthiest members leaderboard', default_member_permissions: null },

    {
        name: 'bank', description: 'Manage your bank account — deposit, withdraw, or check balance',
        default_member_permissions: null,
        options: [
            { name: 'deposit',  description: 'Deposit coins from your wallet into the bank', type: ApplicationCommandOptionType.Subcommand,
              options: [{ name: 'amount', description: 'Amount to deposit', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }] },
            { name: 'withdraw', description: 'Withdraw coins from the bank into your wallet', type: ApplicationCommandOptionType.Subcommand,
              options: [{ name: 'amount', description: 'Amount to withdraw', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }] },
            { name: 'balance',  description: 'Check your current bank balance', type: ApplicationCommandOptionType.Subcommand }
        ]
    },

    { name: 'pay', description: 'Send coins directly to another member', default_member_permissions: null,
      options: [
          { name: 'user',   description: 'The recipient member', type: ApplicationCommandOptionType.User,    required: true },
          { name: 'amount', description: 'Amount to send',        type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
      ] },

    { name: 'rob', description: 'Attempt to steal coins from another member (risk involved)', default_member_permissions: null,
      options: [{ name: 'user', description: 'The member to rob', type: ApplicationCommandOptionType.User, required: true }] },

    {
        name: 'shop', description: 'Browse the shop, view item details, and make purchases',
        default_member_permissions: null,
        options: [
            { name: 'list', description: 'View all available items and chests in the shop', type: ApplicationCommandOptionType.Subcommand },
            { name: 'info', description: 'View detailed information about a specific item or chest', type: ApplicationCommandOptionType.Subcommand,
              options: [{ name: 'name', description: 'Item or chest name', type: ApplicationCommandOptionType.String, required: true }] },
            { name: 'buy',  description: 'Purchase an item or chest from the shop', type: ApplicationCommandOptionType.Subcommand,
              options: [{ name: 'name', description: 'Item or chest name', type: ApplicationCommandOptionType.String, required: true }] }
        ]
    },

    {
        name: 'item', description: 'Manage items in your inventory — use, sell, give, or inspect',
        default_member_permissions: null,
        options: [
            { name: 'sell',      description: 'Sell an item from your inventory for coins',       type: ApplicationCommandOptionType.Subcommand, options: [{ name: 'name', description: 'Item name', type: ApplicationCommandOptionType.String, required: true }] },
            { name: 'use',       description: 'Activate an item and apply its effect',            type: ApplicationCommandOptionType.Subcommand, options: [{ name: 'name', description: 'Item name', type: ApplicationCommandOptionType.String, required: true }] },
            { name: 'give',      description: 'Gift an item from your inventory to another member', type: ApplicationCommandOptionType.Subcommand,
              options: [
                  { name: 'name', description: 'Item name',       type: ApplicationCommandOptionType.String, required: true },
                  { name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User,   required: true }
              ] },
            { name: 'inventory', description: 'View all items currently in your inventory',       type: ApplicationCommandOptionType.Subcommand },
            { name: 'duration',  description: 'Check the remaining duration of your active item effects', type: ApplicationCommandOptionType.Subcommand }
        ]
    },

    {
        name: 'chest', description: 'Manage your chest inventory — open, inspect, or share chests',
        default_member_permissions: null,
        options: [
            { name: 'open',      description: 'Open a chest and receive its contents',       type: ApplicationCommandOptionType.Subcommand, options: [{ name: 'name', description: 'Chest name', type: ApplicationCommandOptionType.String, required: true }] },
            { name: 'inventory', description: 'View all chests you currently own',           type: ApplicationCommandOptionType.Subcommand },
            { name: 'info',      description: 'View the contents and details of a chest',    type: ApplicationCommandOptionType.Subcommand, options: [{ name: 'name', description: 'Chest name', type: ApplicationCommandOptionType.String, required: true }] },
            { name: 'give',      description: 'Gift a chest from your inventory to another member', type: ApplicationCommandOptionType.Subcommand,
              options: [
                  { name: 'name', description: 'Chest name',    type: ApplicationCommandOptionType.String, required: true },
                  { name: 'user', description: 'Target member', type: ApplicationCommandOptionType.User,   required: true }
              ] },
            { name: 'open-all',  description: 'Open every chest in your inventory at once', type: ApplicationCommandOptionType.Subcommand }
        ]
    },

    {
        name: 'recipe', description: 'Craft new items by combining materials using recipes',
        default_member_permissions: null,
        options: [
            { name: 'craft', description: 'Craft an item using a recipe',
              type: ApplicationCommandOptionType.Subcommand,
              options: [
                  { name: 'recipe_id', description: 'Recipe ID',          type: ApplicationCommandOptionType.String,  required: true  },
                  { name: 'quantity',  description: 'Number of times to craft', type: ApplicationCommandOptionType.Integer, required: false, min_value: 1 }
              ] },
            { name: 'list', description: 'Browse all available crafting recipes',
              type: ApplicationCommandOptionType.Subcommand },
            { name: 'info', description: 'View the required materials and output for a recipe',
              type: ApplicationCommandOptionType.Subcommand,
              options: [{ name: 'recipe_id', description: 'Recipe ID', type: ApplicationCommandOptionType.String, required: true }] }
        ]
    },

    // ========================= Gambling =========================
    {
        name: 'coinflip', description: 'Wager coins on a coin flip — choose heads or tails',
        default_member_permissions: null,
        options: [
            { name: 'choice', description: 'Your prediction', type: ApplicationCommandOptionType.String, required: true,
              choices: [{ name: 'Heads', value: 'heads' }, { name: 'Tails', value: 'tails' }] },
            { name: 'amount', description: 'Amount to wager', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
        ]
    },

    {
        name: 'rps',
        description: 'Challenge another member to a Rock Paper Scissors match',
        default_member_permissions: null,
        options: [
            { name: 'user',   description: 'The opponent to challenge', type: 6, required: true },
            { name: 'rounds', description: 'Number of rounds to play',  type: 4, required: true, min_value: 1, max_value: 10 },
            { name: 'bet',    description: 'Coins to wager per match',  type: 4, required: true, min_value: 1 }
        ]
    },

    {
        name: 'blackjack', description: 'Play a round of Blackjack against the dealer',
        default_member_permissions: null,
        options: [
            { name: 'amount', description: 'Coins to wager', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
        ]
    },

    {
        name: 'slots', description: 'Spin the slot machine and try your luck',
        default_member_permissions: null,
        options: [
            { name: 'amount', description: 'Coins to wager', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
        ]
    },

    {
        name: 'auction',
        description: 'Auction house — list, bid on, and claim auctioned items',
        default_member_permissions: null,
        options: [
            {
                name: 'create',
                description: 'List one of your items for auction',
                type: ApplicationCommandOptionType.Subcommand,
                options: [
                    { name: 'item',     description: 'Item ID to auction',        type: ApplicationCommandOptionType.String,  required: true  },
                    { name: 'price',    description: 'Starting bid price',         type: ApplicationCommandOptionType.Integer, required: true,  min_value: 1 },
                    { name: 'hours',    description: 'Auction duration in hours (1–48)', type: ApplicationCommandOptionType.Integer, required: false, min_value: 1, max_value: 48 },
                    { name: 'quantity', description: 'Quantity to auction (default 1)',   type: ApplicationCommandOptionType.Integer, required: false, min_value: 1 }
                ]
            },
            {
                name: 'list',
                description: 'Browse all currently active auctions',
                type: ApplicationCommandOptionType.Subcommand
            },
            {
                name: 'bid',
                description: 'Place a bid on an active auction',
                type: ApplicationCommandOptionType.Subcommand,
                options: [
                    { name: 'id',     description: 'Auction ID',  type: ApplicationCommandOptionType.String,  required: true },
                    { name: 'amount', description: 'Your bid amount', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
                ]
            },
            {
                name: 'cancel',
                description: 'Cancel your own active auction and retrieve the item',
                type: ApplicationCommandOptionType.Subcommand,
                options: [
                    { name: 'id', description: 'Auction ID', type: ApplicationCommandOptionType.String, required: true }
                ]
            },
            {
                name: 'claim',
                description: 'Claim the item from an auction you won',
                type: ApplicationCommandOptionType.Subcommand,
                options: [
                    { name: 'id', description: 'Auction ID', type: ApplicationCommandOptionType.String, required: true }
                ]
            }
        ]
    },

    {
        name: 'dice', description: 'Roll two dice and bet on the combined outcome',
        default_member_permissions: null,
        options: [
            {
                name: 'bet', description: 'Select a bet type',
                type: ApplicationCommandOptionType.String, required: true,
                choices: [
                    { name: '📈 High (8–12) → 2×',   value: 'high'   },
                    { name: '📉 Low (2–6) → 2×',      value: 'low'    },
                    { name: '7️⃣  Seven (7) → 5×',      value: 'seven'  },
                    { name: '🎯 Double (same) → 4×',   value: 'double' },
                    { name: '2 → 32×',  value: '2'  },
                    { name: '3 → 16×',  value: '3'  },
                    { name: '4 → 11×',  value: '4'  },
                    { name: '5 → 8×',   value: '5'  },
                    { name: '6 → 6×',   value: '6'  },
                    { name: '8 → 6×',   value: '8'  },
                    { name: '9 → 8×',   value: '9'  },
                    { name: '10 → 11×', value: '10' },
                    { name: '11 → 16×', value: '11' },
                    { name: '12 → 32×', value: '12' }
                ]
            },
            { name: 'amount', description: 'Coins to wager', type: ApplicationCommandOptionType.Integer, required: true, min_value: 1 }
        ]
    },

{
    name: 'econhelp',
    description: 'Browse all economy commands',
    default_member_permissions: null,
    options: [],
    integration_types: [0, 1],
    contexts: [0, 1, 2]
},

    // ========================= Economy — Stats & Levels =========================
    {
        name: 'econlevel',
        description: 'View your economy level and XP progress',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Member to check (defaults to yourself)', type: ApplicationCommandOptionType.User, required: false }
        ]
    },

    {
        name: 'estats',
        description: 'View detailed economy statistics and performance metrics',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Member to check (defaults to yourself)', type: ApplicationCommandOptionType.User, required: false }
        ]
    },

    // ========================= Economy — Quests =========================
    {
        name: 'quest',
        description: 'View your active daily quests and claim completed rewards',
        default_member_permissions: null,
        options: [
            { name: 'view',  description: 'Display your current active quests and progress', type: ApplicationCommandOptionType.Subcommand },
            { name: 'claim', description: 'Claim the reward for a completed quest',          type: ApplicationCommandOptionType.Subcommand }
        ]
    },

    // ========================= Notifications =========================
    {
        name: 'notification', description: 'Configure your personal work and daily reward reminders',
        default_member_permissions: null,
        options: [
            { name: 'settings', description: 'Open the notification settings panel', type: ApplicationCommandOptionType.Subcommand }
        ]
    },

    // ========================= Economy — Misc =========================
    {
        name: 'history',
        description: 'View your recent transaction history',
        default_member_permissions: null,
        options: [
            { name: 'user', description: 'Member to check (defaults to yourself)', type: 6, required: false }
        ]
    },

    {
        name: 'loan',
        description: 'Borrow coins and manage your outstanding loan',
        default_member_permissions: null,
        options: [
            { name: 'take',  description: 'Take out a coin loan',          type: 1,
              options: [{ name: 'amount', description: 'Amount to borrow', type: 4, required: true, min_value: 1 }] },
            { name: 'repay', description: 'Make a repayment on your loan', type: 1,
              options: [{ name: 'amount', description: 'Amount to repay',  type: 4, required: true, min_value: 1 }] },
            { name: 'check', description: 'Check your current loan status and outstanding balance', type: 1 }
        ]
    },

    {
        name: 'treasury',
        description: 'Interact with the server treasury — view funds, donate, or withdraw',
        default_member_permissions: null,
        options: [
            { name: 'view',     description: 'View the current treasury balance', type: 1 },
            { name: 'donate',   description: 'Donate coins to the server treasury', type: 1,
              options: [{ name: 'amount', description: 'Amount to donate', type: 4, required: true, min_value: 1 }] },
            { name: 'withdraw', description: '[Admin] Withdraw coins from the treasury', type: 1,
              options: [
                  { name: 'amount', description: 'Amount to withdraw', type: 4, required: true, min_value: 1 },
                  { name: 'user',   description: 'Recipient member (defaults to yourself)', type: 6, required: false }
              ]
            }
        ]
    },

];

const rest = new REST({ version: '10' }).setToken(config.token);

async function deployCommands() {
    try {
        console.log('🔄 Registering slash commands...');

        // كل الأوامر على السيرفر بدون econhelp
        await rest.put(
            Routes.applicationGuildCommands(config.clientId, config.guildId),
            { body: commands.filter(c => c.name !== 'econhelp') }
        );

        // econhelp كـ Global فقط
        await rest.put(
            Routes.applicationCommands(config.clientId),
            { body: [commands.find(c => c.name === 'econhelp')] }
        );

        console.log('✅ All commands registered successfully.');
    } catch (error) {
        console.error('❌ Error registering commands:', error);
    }
}

module.exports = { deployCommands, commands };

 
if (require.main === module) {
    deployCommands();
}
