# Discord Logger Bot

بوت ديسكورد لإدارة السيرفر وتسجيل الأحداث، مزود بلوحة تحكم وميزات حماية وتذاكر ومستويات واقتصاد وسحوبات.

A Discord bot for server management and event logging, with a dashboard plus protection, tickets, levels, economy, and giveaway features.

## المتطلبات | Requirements

- Node.js
- حساب Discord Developer وتطبيق Bot
- بوت مضاف إلى سيرفر Discord مع الصلاحيات المناسبة
- A Discord Developer account and bot application
- The bot added to a Discord server with appropriate permissions

## التثبيت والتشغيل | Installation and startup

1. افتح الطرفية داخل مجلد المشروع. / Open a terminal in the project folder.
2. ثبّت الاعتمادات. / Install dependencies:

   ```bash
   npm install
   ```

3. افتح `config.js` وأدخل بيانات البوت التالية. / Open `config.js` and enter the following bot details:

   - `token`: توكن البوت / The bot token
   - `clientId`: معرّف التطبيق / The application ID
   - `guildId`: معرّف السيرفر / The server ID
   - `dashboardPort`: منفذ لوحة التحكم؛ الافتراضي `3000` / Dashboard port; defaults to `3000`

4. شغّل البوت. / Start the bot:

   ```bash
   npm start
   ```

## لوحة التحكم | Dashboard

بعد تشغيل البوت، افتح الرابط التالي في المتصفح:

After starting the bot, open this address in your browser:

```text
http://localhost:3000
```

## الميزات | Features

- تسجيل أحداث السيرفر / Server event logging
- أوامر إدارية، تحذيرات، وعقوبات / Moderation commands, warnings, and punishments
- حماية وAnti-Bot / Protection and anti-bot tools
- نظام تذاكر / Ticket system
- نظام مستويات واقتصاد / Leveling and economy system
- سحوبات / Giveaways
- أوامر Slash / Slash commands
- لوحة تحكم مبنية بـ Express وEJS / Dashboard built with Express and EJS

## الأمان | Security

- لا تشارك `token` مع أي شخص. / Never share your `token` with anyone.
- إذا تسرّب التوكن، أعد إنشاؤه فوراً من Discord Developer Portal. / If the token is exposed, regenerate it immediately in the Discord Developer Portal.
- تأكد من منح البوت أقل الصلاحيات اللازمة فقط. / Give the bot only the permissions it needs.

## الحقوق | Copyright

هذا المشروع مملوك لـ GT وتم تطويره بواسطة GT، وتفاصيل الاستخدام موجودة في ملف [LICENSE](LICENSE).

This project is owned and developed by GT. See [LICENSE](LICENSE) for usage terms.
