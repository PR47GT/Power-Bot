const path = require('path');
const fs   = require('fs');
const {
    EmbedBuilder, ModalBuilder, TextInputBuilder, TextInputStyle,
    ActionRowBuilder, ButtonBuilder, ButtonStyle, StringSelectMenuBuilder,
    MessageFlags
} = require('discord.js');

module.exports = function setupApplySystem({
    app, client, loadData,
    getSettings, getGuildChannels, getGuildRoles
}) {

    if (typeof getSettings      !== 'function') getSettings      = () => ({});
    if (typeof getGuildChannels !== 'function') getGuildChannels = () => [];
    if (typeof getGuildRoles    !== 'function') getGuildRoles    = () => [];

    const APPLY_FILE = path.join(__dirname, 'applySystem.json');
    const applyCooldowns = new Map();
    let applyDataCache = null; // كاش بالذاكرة لتفادي قراءة الملف من القرص بكل تفاعل

    // تنظيف دوري لـ applyCooldowns كل ساعة (حذف أي entry أقدم من 24 ساعة)
    setInterval(() => {
        const now = Date.now();
        for (const [key, ts] of applyCooldowns) {
            if (now - ts > 24 * 3600 * 1000) applyCooldowns.delete(key);
        }
    }, 60 * 60 * 1000);

    // ── الترجمات ──────────────────────────────────────────────────────────────
    const T = {
        ar: {
            noPermission:        '❌ ليس لديك صلاحية لاستخدام هذا الأمر.',
            noReviewPermission:  '❌ ليس لديك صلاحية لمراجعة الطلبات.',
            noCategories:        '⚠️ لم يتم إعداد أي قسم تقديم بعد.',
            categoryUnavailable: '⚠️ هذا القسم غير متوفر حالياً.',
            categoryGone:        '⚠️ القسم لم يعد متوفراً.',
            categoryNotFound:    '⚠️ القسم غير موجود.',
            categoryNeedsQ:      '⚠️ هذا القسم يحتاج أسئلة أولاً.',
            categoryNotSetup:    '⚠️ نظام التقديم غير مُعد حالياً لهذا القسم.',
            cooldown:            (h) => `⏳ يجب الانتظار ${h} ساعة قبل التقديم مرة أخرى.`,
            cooldownCat:         (h) => `⏳ يجب الانتظار ${h} ساعة قبل التقديم على هذا القسم مرة أخرى.`,
            sentSuccess:         '✅ تم إرسال رسالة التقديم بنجاح!',
            sentCatSuccess:      (name) => `✅ تم إرسال رسالة قسم **${name}** في هذا الروم!`,
            submitSuccess:       (name) => `✅ تم إرسال طلبك على قسم **${name}** بنجاح! سيتم إعلامك بالنتيجة.`,
            pickCategory:        '📋 اختر القسم الذي تريد التقديم عليه:',
            pickCategoryHolder:  'اختر القسم الذي تريد التقديم عليه',
            pickSendCategory:    '📋 اختر القسم الذي تريد إرسال رسالته:',
            pickSendHolder:      'اختر القسم الذي تريد إرساله في هذا الروم',
            applyBtn:            (name) => `📝 ${name}`,
            embedTitle:          (name) => `📋 ${name}`,
            embedDesc:           (name) => `اضغط الزر أدناه للتقديم على: **${name}**`,
            newAppTitle:         (name) => `📋 طلب تقديم جديد — ${name}`,
            accepted:            '✅ تم القبول',
            rejected:            '❌ تم الرفض',
            acceptedBy:          (tag) => `بواسطة ${tag}`,
            acceptBtn:           '✅ قبول',
            rejectBtn:           '❌ رفض',
            ruleNotFound:        '❌ القاعدة غير موجودة.',
            modalTitle:          'نموذج التقديم',
        },
        en: {
            noPermission:        '❌ You do not have permission to use this command.',
            noReviewPermission:  '❌ You do not have permission to review applications.',
            noCategories:        '⚠️ No application categories have been set up yet.',
            categoryUnavailable: '⚠️ This category is currently unavailable.',
            categoryGone:        '⚠️ This category no longer exists.',
            categoryNotFound:    '⚠️ Category not found.',
            categoryNeedsQ:      '⚠️ This category needs at least one question.',
            categoryNotSetup:    '⚠️ This application category is not fully configured.',
            cooldown:            (h) => `⏳ Please wait ${h} hours before applying again.`,
            cooldownCat:         (h) => `⏳ Please wait ${h} hours before applying to this category again.`,
            sentSuccess:         '✅ Application message sent successfully!',
            sentCatSuccess:      (name) => `✅ Application message for **${name}** sent to this channel!`,
            submitSuccess:       (name) => `✅ Your application for **${name}** was submitted! You will be notified of the result.`,
            pickCategory:        '📋 Choose the category you want to apply for:',
            pickCategoryHolder:  'Select a category to apply for',
            pickSendCategory:    '📋 Choose the category you want to send a message for:',
            pickSendHolder:      'Select a category to send to this channel',
            applyBtn:            (name) => `📝 ${name}`,
            embedTitle:          (name) => `📋 ${name}`,
            embedDesc:           (name) => `Click the button below to apply for: **${name}**`,
            newAppTitle:         (name) => `📋 New Application — ${name}`,
            accepted:            '✅ Accepted',
            rejected:            '❌ Rejected',
            acceptedBy:          (tag) => `By ${tag}`,
            acceptBtn:           '✅ Accept',
            rejectBtn:           '❌ Reject',
            ruleNotFound:        '❌ Rule not found.',
            modalTitle:          'Application Form',
        }
    };

    function getLang() {
        return T[(getSettings() || {}).botLanguage] || T.ar;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────
    function genAppId() {
        return 'app_' + Math.random().toString(36).slice(2, 10);
    }

    function normalizeApplication(a) {
        a = a || {};
        const onA = a.onAccept || {};
        const onR = a.onReject || {};
        return {
            id:          a.id || genAppId(),
            name:        (a.name || 'تقديم').toString(),
            icon:        a.icon || 'fa-user-shield',
            description: a.description || '',
            questions:   Array.isArray(a.questions) ? a.questions.map(q => {
                if (typeof q === 'string') return { text: q, isParagraph: false, isRequired: true };
                return {
                    text: (q.text || '').toString(),
                    isParagraph: !!q.isParagraph,
                    isRequired:  !!q.isRequired
                };
            }) : [],
            onAccept: {
                sendDm:    !!onA.sendDm,
                dmMessage: onA.dmMessage || '',
                addRoles:  Array.isArray(onA.addRoles) ? onA.addRoles : (onA.addRole ? [onA.addRole] : [])
            },
            onReject: {
                sendDm:    !!onR.sendDm,
                dmMessage: onR.dmMessage || '',
                addRoles:  Array.isArray(onR.addRoles) ? onR.addRoles : (onR.addRole ? [onR.addRole] : [])
            },
            logChannel: a.logChannel || '',
            cooldown:   typeof a.cooldown === 'number' ? a.cooldown : 0
        };
    }

    function loadApplyData() {
        if (applyDataCache) return applyDataCache;

        let raw = null;
        if (fs.existsSync(APPLY_FILE)) {
            try { raw = JSON.parse(fs.readFileSync(APPLY_FILE, 'utf8')); } catch(e) {}
        }

        let result;
        if (!raw) {
            result = { applications: [] };
        } else if (Array.isArray(raw.applications)) {
            result = { applications: raw.applications.map(normalizeApplication) };
        } else if (raw.questions || raw.onAccept || raw.onReject || raw.description || raw.logChannel) {
            result = {
                applications: [ normalizeApplication(Object.assign({
                    id: 'app_default',
                    name: 'تقديم على الإدارة',
                    icon: 'fa-user-shield'
                }, raw)) ]
            };
        } else {
            result = { applications: [] };
        }

        applyDataCache = result;
        return applyDataCache;
    }

    function saveApplyData(data) {
        const safe = { applications: (data.applications || []).map(normalizeApplication) };
        fs.writeFileSync(APPLY_FILE, JSON.stringify(safe, null, 2), 'utf8');
        applyDataCache = safe; // تحديث الكاش مباشرة بدل ما ننتظر قراءة جديدة من القرص
    }

    function findApp(applyData, appId) {
        return (applyData.applications || []).find(a => a.id === appId) || null;
    }

    function getQuestionTexts(app) {
        return (app.questions || [])
            .map(q => typeof q === 'string' ? q : (q.text || ''))
            .filter(t => t && t.trim());
    }

    function checkCooldown(userId, appCfg) {
        const cooldownMs = (appCfg.cooldown || 0) * 1000;
        if (cooldownMs <= 0) return null;
        const key = `${userId}:${appCfg.id}`;
        const lastUsed = applyCooldowns.get(key);
        if (lastUsed && Date.now() - lastUsed < cooldownMs) {
            const remaining = Math.ceil((cooldownMs - (Date.now() - lastUsed)) / 1000);
            return (remaining / 3600).toFixed(1);
        }
        return null;
    }

    function buildApplyModal(appCfg) {
        const lang = getLang();
        const questionTexts = getQuestionTexts(appCfg);
        const modal = new ModalBuilder()
            .setCustomId('apply_submit_' + appCfg.id)
            .setTitle((appCfg.name || lang.modalTitle).substring(0, 45));

        const rows = questionTexts.slice(0, 5).map((q, i) => {
            const qObj = appCfg.questions[i];
            const isParagraph = (typeof qObj === 'object' && qObj.isParagraph === true);
            const isRequired  = (typeof qObj === 'object') ? (qObj.isRequired === true) : true;
            return new ActionRowBuilder().addComponents(
                new TextInputBuilder()
                    .setCustomId('apply_q_' + i)
                    .setLabel(q.substring(0, 45))
                    .setStyle(isParagraph ? TextInputStyle.Paragraph : TextInputStyle.Short)
                    .setRequired(isRequired)
                    .setMaxLength(1000)
            );
        });
        modal.addComponents(...rows);
        return modal;
    }

    function buildSingleAppMessage(appCfg) {
        const lang = getLang();
        if (!appCfg || getQuestionTexts(appCfg).length === 0) return null;

        const embed = new EmbedBuilder()
            .setColor('#5865F2')
            .setTitle(lang.embedTitle(appCfg.name || ''))
            .setDescription(appCfg.description || lang.embedDesc(appCfg.name))
            .setTimestamp();

        const btn = new ButtonBuilder()
            .setCustomId('apply_open_form_' + appCfg.id)
            .setLabel(lang.applyBtn(appCfg.name || ''))
            .setStyle(ButtonStyle.Primary);

        return { embeds: [embed], components: [ new ActionRowBuilder().addComponents(btn) ] };
    }

    // ── Routes ────────────────────────────────────────────────────────────────
    app.get('/apply-system', async (req, res) => {
        if (typeof loadData === 'function') {
            try { await loadData(true); } catch(e) {}
        }
        const applyData = loadApplyData();
        res.render('apply-system', {
            settings:      getSettings()      || {},
            guildChannels: getGuildChannels() || [],
            guildRoles:    getGuildRoles()    || [],
            applyData
        });
    });

    function tr(ar, en) {
        const lang = (getSettings() || {}).uiLanguage;
        return lang === 'ar' ? ar : en;
    }

    app.post('/api/apply-system/save', (req, res) => {
        try {
            if (Array.isArray(req.body.applications)) {
                saveApplyData({ applications: req.body.applications });
                return res.json({ success: true });
            }
            const current = loadApplyData();
            const first = current.applications[0] || normalizeApplication({
                id: 'app_default', name: 'تقديم على الإدارة'
            });
            if (req.body.description !== undefined) first.description = req.body.description;
            if (req.body.logChannel  !== undefined) first.logChannel  = req.body.logChannel;
            if (req.body.cooldown    !== undefined) first.cooldown    = parseInt(req.body.cooldown) || 0;
            if (req.body.questions   !== undefined) first.questions   = req.body.questions;
            if (req.body.onAccept    !== undefined) first.onAccept    = req.body.onAccept;
            if (req.body.onReject    !== undefined) first.onReject    = req.body.onReject;
            saveApplyData({ applications: [first] });
            res.json({ success: true });
        } catch(err) {
            console.error('❌ خطأ في حفظ apply system:', err);
            res.json({ success: false, error: err.message });
        }
    });

    app.post('/api/apply-system/send-message', async (req, res) => {
        try {
            const { channelId, appId } = req.body || {};
            if (!channelId) return res.json({ success: false, error: tr('لم يتم تحديد الروم.', 'No channel selected.') });
            if (!appId)     return res.json({ success: false, error: tr('لم يتم تحديد القسم.', 'No category selected.') });

            const applyData = loadApplyData();
            const appCfg = findApp(applyData, appId);
            if (!appCfg) return res.json({ success: false, error: tr('القسم غير موجود.', 'Category not found.') });

            const payload = buildSingleAppMessage(appCfg);
            if (!payload) return res.json({ success: false, error: tr('هذا القسم غير مُعد بالكامل.', 'This category is not fully configured.') });

            let channel = null;
            for (const [, guild] of client.guilds.cache) {
                const ch = guild.channels.cache.get(channelId);
                if (ch) { channel = ch; break; }
            }
            if (!channel) return res.json({ success: false, error: tr('الروم غير موجود أو البوت لا يصل إليه.', 'Channel not found or bot has no access.') });
            if (!channel.isTextBased || !channel.isTextBased()) {
                return res.json({ success: false, error: tr('لا يمكن الإرسال على هذا النوع من الرومات.', 'This channel type does not support messages.') });
            }

            await channel.send(payload);
            res.json({ success: true });
        } catch(err) {
            console.error('❌ Apply send error:', err);
            res.json({ success: false, error: err.message || tr('فشل الإرسال', 'Send failed') });
        }
    });

    // ── Discord Interactions ──────────────────────────────────────────────────
    client.on('interactionCreate', async (interaction) => {
        try {
            const lang = getLang();

            // ---------- /apply ----------
            if (interaction.isChatInputCommand() && interaction.commandName === 'apply') {
                if (interaction.replied || interaction.deferred) return;
                const applyData = loadApplyData();
                const apps = applyData.applications.filter(a => getQuestionTexts(a).length > 0);

                if (apps.length === 0) {
                    return interaction.reply({ content: lang.noCategories, flags: MessageFlags.Ephemeral });
                }

                if (apps.length === 1) {
                    const appCfg = apps[0];
                    const remHrs = checkCooldown(interaction.user.id, appCfg);
                    if (remHrs) return interaction.reply({ content: lang.cooldown(remHrs), flags: MessageFlags.Ephemeral });
                    return interaction.showModal(buildApplyModal(appCfg));
                }

                const select = new StringSelectMenuBuilder()
                    .setCustomId('apply_pick_category')
                    .setPlaceholder(lang.pickCategoryHolder)
                    .addOptions(apps.slice(0, 25).map(a => ({
                        label: (a.name || 'تقديم').substring(0, 100),
                        description: (a.description || '').substring(0, 100) || undefined,
                        value: a.id
                    })));

                return interaction.reply({
                    content: lang.pickCategory,
                    components: [ new ActionRowBuilder().addComponents(select) ],
                    flags: MessageFlags.Ephemeral
                });
            }

            // ---------- /apply-send ----------
            if (interaction.isChatInputCommand() && interaction.commandName === 'apply-send') {
                if (interaction.replied || interaction.deferred) return;
                if (!interaction.member.permissions.has('ManageGuild')) {
                    return interaction.reply({ content: lang.noPermission, flags: MessageFlags.Ephemeral });
                }

                const applyData = loadApplyData();
                const apps = applyData.applications.filter(a => getQuestionTexts(a).length > 0);
                if (!apps.length) {
                    return interaction.reply({ content: lang.noCategories, flags: MessageFlags.Ephemeral });
                }

                if (apps.length === 1) {
                    const payload = buildSingleAppMessage(apps[0]);
                    if (payload) await interaction.channel.send(payload).catch(() => {});
                    return interaction.reply({ content: lang.sentSuccess, flags: MessageFlags.Ephemeral });
                }

                const sendSelect = new StringSelectMenuBuilder()
                    .setCustomId('apply_send_pick')
                    .setPlaceholder(lang.pickSendHolder)
                    .addOptions(apps.slice(0, 25).map(a => ({
                        label: (a.name || 'تقديم').substring(0, 100),
                        description: (a.description || '').substring(0, 100) || undefined,
                        value: a.id
                    })));

                return interaction.reply({
                    content: lang.pickSendCategory,
                    components: [ new ActionRowBuilder().addComponents(sendSelect) ],
                    flags: MessageFlags.Ephemeral
                });
            }

            // ---------- تأكيد اختيار القسم للإرسال ----------
            if (interaction.isStringSelectMenu?.() && interaction.customId === 'apply_send_pick') {
                if (!interaction.member.permissions.has('ManageGuild')) {
                    return interaction.update({ content: lang.noPermission, components: [] });
                }
                const appId = interaction.values[0];
                const applyData = loadApplyData();
                const appCfg = findApp(applyData, appId);
                if (!appCfg) {
                    return interaction.update({ content: lang.categoryNotFound, components: [] });
                }
                const payload = buildSingleAppMessage(appCfg);
                if (!payload) {
                    return interaction.update({ content: lang.categoryNeedsQ, components: [] });
                }
                await interaction.channel.send(payload).catch(() => {});
                return interaction.update({ content: lang.sentCatSuccess(appCfg.name), components: [] });
            }

            // ---------- اختيار قسم من القائمة المنسدلة ----------
            if (interaction.isStringSelectMenu?.() && interaction.customId === 'apply_pick_category') {
                const appId = interaction.values[0];
                const applyData = loadApplyData();
                const appCfg = findApp(applyData, appId);
                if (!appCfg || getQuestionTexts(appCfg).length === 0) {
                    return interaction.reply({ content: lang.categoryUnavailable, flags: MessageFlags.Ephemeral });
                }
                const remHrs = checkCooldown(interaction.user.id, appCfg);
                if (remHrs) return interaction.reply({ content: lang.cooldownCat(remHrs), flags: MessageFlags.Ephemeral });
                return interaction.showModal(buildApplyModal(appCfg));
            }

            // ---------- زر فتح فورم قسم ----------
            if (interaction.isButton() && interaction.customId.startsWith('apply_open_form_')) {
                const appId = interaction.customId.replace('apply_open_form_', '');
                const applyData = loadApplyData();
                const appCfg = findApp(applyData, appId);
                if (!appCfg || getQuestionTexts(appCfg).length === 0) {
                    return interaction.reply({ content: lang.categoryNotSetup, flags: MessageFlags.Ephemeral });
                }
                const remHrs = checkCooldown(interaction.user.id, appCfg);
                if (remHrs) return interaction.reply({ content: lang.cooldownCat(remHrs), flags: MessageFlags.Ephemeral });
                return interaction.showModal(buildApplyModal(appCfg));
            }

            // ---------- إرسال إجابات المودال ----------
            if (interaction.isModalSubmit() && interaction.customId.startsWith('apply_submit_')) {
                const appId = interaction.customId.replace('apply_submit_', '');
                const applyData = loadApplyData();
                const appCfg = findApp(applyData, appId);
                if (!appCfg) {
                    return interaction.reply({ content: lang.categoryGone, flags: MessageFlags.Ephemeral });
                }

                const questionTexts = getQuestionTexts(appCfg);
                applyCooldowns.set(`${interaction.user.id}:${appCfg.id}`, Date.now());

                const embed = new EmbedBuilder()
                    .setColor('#5865F2')
                    .setAuthor({ name: interaction.user.tag, iconURL: interaction.user.displayAvatarURL() })
                    .setTitle(lang.newAppTitle(appCfg.name))
                    .setTimestamp()
                    .setFooter({ text: `ID: ${interaction.user.id}` });

                questionTexts.slice(0, 5).forEach((q, i) => {
                    const answer = interaction.fields.getTextInputValue('apply_q_' + i) || '—';
                    embed.addFields({ name: `❕ ${q}`, value: `\`\`\`${answer}\`\`\``, inline: false });
                });

                const acceptBtn = new ButtonBuilder()
                    .setCustomId(`apply_accept_${appCfg.id}_${interaction.user.id}`)
                    .setLabel(lang.acceptBtn)
                    .setStyle(ButtonStyle.Success);
                const rejectBtn = new ButtonBuilder()
                    .setCustomId(`apply_reject_${appCfg.id}_${interaction.user.id}`)
                    .setLabel(lang.rejectBtn)
                    .setStyle(ButtonStyle.Danger);
                const row = new ActionRowBuilder().addComponents(acceptBtn, rejectBtn);

                if (appCfg.logChannel) {
                    const logCh = interaction.guild.channels.cache.get(appCfg.logChannel);
                    if (logCh) {
                        await logCh.send({ embeds: [embed], components: [row] }).catch(() => {});
                    }
                }

                await interaction.reply({ content: lang.submitSuccess(appCfg.name), flags: MessageFlags.Ephemeral });
                return;
            }

            // ---------- زر القبول/الرفض ----------
            if (interaction.isButton()) {
                const cid = interaction.customId;
                if (!cid.startsWith('apply_accept_') && !cid.startsWith('apply_reject_')) return;

                if (!interaction.member.permissions.has('ManageGuild')) {
                    return interaction.reply({ content: lang.noReviewPermission, flags: MessageFlags.Ephemeral });
                }

                const isAccept = cid.startsWith('apply_accept_');
                const rest     = cid.replace('apply_accept_', '').replace('apply_reject_', '');
                let appId = null, userId = rest;
                const lastUnderscore = rest.lastIndexOf('_');
                if (lastUnderscore > -1) {
                    appId  = rest.substring(0, lastUnderscore);
                    userId = rest.substring(lastUnderscore + 1);
                }

                const applyData = loadApplyData();
                const appCfg = appId ? findApp(applyData, appId) : (applyData.applications[0] || null);
                const actionCfg = appCfg ? (isAccept ? appCfg.onAccept : appCfg.onReject) : null;

                if (actionCfg && actionCfg.sendDm && actionCfg.dmMessage) {
                    try {
                        const member = await interaction.guild.members.fetch(userId).catch(() => null);
                        if (member) await member.send(actionCfg.dmMessage).catch(() => {});
                    } catch(e) {}
                }

                const rolesToAdd = (actionCfg && actionCfg.addRoles && actionCfg.addRoles.length)
                    ? actionCfg.addRoles
                    : (actionCfg && actionCfg.addRole ? [actionCfg.addRole] : []);

                if (rolesToAdd.length > 0) {
                    try {
                        const member = await interaction.guild.members.fetch(userId).catch(() => null);
                        if (member) {
                            for (const roleId of rolesToAdd) {
                                if (roleId) await member.roles.add(roleId).catch(() => {});
                            }
                        }
                    } catch(e) {}
                }

                const updatedEmbed = EmbedBuilder.from(interaction.message.embeds[0])
                    .setColor(isAccept ? '#57F287' : '#ED4245')
                    .addFields({
                        name:   isAccept ? lang.accepted : lang.rejected,
                        value:  lang.acceptedBy(interaction.user.tag),
                        inline: false
                    });

                try {
    await interaction.update({
        embeds: [updatedEmbed],
        components: []
    });
} catch (err) {
    if (err.code === 10062 || err.code === 40060) {
        await interaction.message.edit({
            embeds: [updatedEmbed],
            components: []
        }).catch(() => {});
    } else {
        throw err;
    }
}
            }

        } catch (err) {
            console.error('❌ خطأ في معالج apply system:', err);
        }
    });

    return { loadApplyData, saveApplyData, findApp };
};