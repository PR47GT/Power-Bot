const { Router } = require('express');
const path        = require('path');
const fs          = require('fs');

const antibotModule      = require('../features/antibot/antibot');
const verificationModule = require('../features/antibot/verification');

/**
 * @param {object} deps
 * @param {import('discord.js').Client}  deps.client
 * @param {object}   deps.config
 * @param {Function} deps.getSettings    - دالة تُعيد أحدث قيمة لـ settings
 * @param {Function} deps.getProtection  - دالة تُعيد أحدث قيمة لـ protection
 * @param {Function} deps.loadData
 * @param {Function} deps.loadAntibot
 * @param {Function} deps.getCached
 * @param {Function} deps.loadTicketSettings
 * @param {string}   deps.GENERAL_COMMANDS_FILE
 */
module.exports = function createDashboardRouter(deps) {
    const {
        client,
        config,
        getSettings,
        getProtection,
        loadData,
        loadAntibot,
        getCached,
        loadTicketSettings,
        GENERAL_COMMANDS_FILE,
    } = deps;

    const router = Router();

    // ==================== صفحة الإحصائيات (Analytics Dashboard) ====================
    router.get('/', async (req, res) => {
        await loadData(true);

        // نقرأ القيم الحية بعد loadData لضمان الحصول على أحدث حالة
        const settings   = getSettings();
        const protection = getProtection();

        let serverStats = {};
        let topMembers  = [];
        let antibotData = loadAntibot();

        try {
            const guild = client.guilds.cache.get(config.guildId) || await client.guilds.fetch(config.guildId);

            // ── أعلى 50 عضو بالليفل ──
            try {
                const levelPath = path.join(__dirname, '..', 'levelData.json');
                if (fs.existsSync(levelPath)) {
                    const levelData = JSON.parse(fs.readFileSync(levelPath, 'utf8'));

                    const sorted = Object.entries(levelData)
                        .map(([userId, data]) => ({
                            userId,
                            chatXP:     data.chatXP    || 0,
                            voiceXP:    data.voiceXP   || 0,
                            chatLevel:  data.chatLevel  || 0,
                            voiceLevel: data.voiceLevel || 0,
                            totalXP:   (data.chatXP || 0) + (data.voiceXP || 0)
                        }))
                        .sort((a, b) => b.totalXP - a.totalXP)
                        .slice(0, 50);

                    const memberResults = await Promise.all(sorted.map(async (entry, i) => {
                        try {
                            const member = guild.members.cache.get(entry.userId)
                                        || await guild.members.fetch(entry.userId).catch(() => null);
                            if (member) {
                                return {
                                    rank:        i + 1,
                                    userId:      entry.userId,
                                    username:    member.user.username,
                                    displayName: member.displayName,
                                    avatarUrl:   member.user.displayAvatarURL({ size: 64, extension: 'png' }),
                                    chatXP:      entry.chatXP,
                                    voiceXP:     entry.voiceXP,
                                    chatLevel:   entry.chatLevel,
                                    voiceLevel:  entry.voiceLevel,
                                    totalXP:     entry.totalXP
                                };
                            }
                        } catch (e) {}
                        return null;
                    }));
                    topMembers = memberResults.filter(Boolean);
                }
            } catch (e) {
                req.log?.warn('[Dashboard] تعذر جلب بيانات الليفل: ' + e.message);
            }

            // ── إحصائيات الأعضاء (باستخدام الكاش لتجنب Rate Limit) ──
            const allMembers     = guild.members.cache;
            const botMembers     = allMembers.filter(m => m.user && m.user.bot);
            const humanMembers   = allMembers.filter(m => m.user && !m.user.bot);
            const onlineMembers  = allMembers.filter(m => m.presence && m.presence.status === 'online');
            const idleMembers    = allMembers.filter(m => m.presence && m.presence.status === 'idle');
            const dndMembers     = allMembers.filter(m => m.presence && m.presence.status === 'dnd');
            const offlineMembers = allMembers.filter(m => !m.presence || m.presence.status === 'offline');

            // ── إحصائيات القنوات ──
            const textChannels         = guild.channels.cache.filter(c => c.type === 0).size;
            const voiceChannels        = guild.channels.cache.filter(c => c.type === 2).size;
            const categoryChannels     = guild.channels.cache.filter(c => c.type === 4).size;
            const forumChannels        = guild.channels.cache.filter(c => c.type === 15).size;
            const announcementChannels = guild.channels.cache.filter(c => c.type === 5).size;
            const stageChannels        = guild.channels.cache.filter(c => c.type === 13).size;
            const threadChannels       = guild.channels.cache.filter(c => c.type === 11 || c.type === 12).size;

            // ── إحصائيات الرتب ──
            const totalRoles = guild.roles.cache.filter(r => r.name !== '@everyone').size;
            const colorRoles = guild.roles.cache.filter(r => r.color !== 0 && r.name !== '@everyone').size;

            // ── إحصائيات الإيموجي ──
            const totalEmojis    = guild.emojis.cache.size;
            const animatedEmojis = guild.emojis.cache.filter(e => e.animated).size;

            // ── أكثر القنوات نشاطاً (مرتبة حسب آخر رسالة) ──
            let activeChannelsList = [];
            try {
                const sortedChannels = guild.channels.cache
                    .filter(c => c.type === 0 && c.lastMessageId)
                    .sort((a, b) => {
                        const aId = BigInt(a.lastMessageId || '0');
                        const bId = BigInt(b.lastMessageId || '0');
                        return bId > aId ? 1 : bId < aId ? -1 : 0;
                    });

                let rank = 0;
                sortedChannels.each(ch => {
                    if (rank < 10) {
                        activeChannelsList.push({
                            name:     ch.name,
                            messages: Math.max(1, 10 - rank)
                        });
                        rank++;
                    }
                });
            } catch (e) {
                req.log?.warn('[Dashboard] تعذر جلب القنوات النشطة: ' + e.message);
            }

            // ── إحصائيات الويب هوكس (مع كاش 5 دقائق) ──
            let totalWebhooks  = 0;
            let activeWebhooks = 0;
            try {
                const webhooks = await getCached('webhooks', 5 * 60 * 1000, () => guild.fetchWebhooks());
                totalWebhooks  = webhooks.size;
                activeWebhooks = webhooks.filter(w => w.token).size;
            } catch (e) {
                req.log?.warn('[Dashboard] تعذر جلب Webhooks: ' + e.message);
            }

            // ── إحصائيات الدعوات + أكثر أعضاء دعواً ──
            let totalInvites     = 0;
            let permanentInvites = 0;
            let topInvitersList  = [];
            try {
                const invites    = await getCached('invites', 2 * 60 * 1000, () => guild.invites.fetch());
                totalInvites     = invites.size;
                permanentInvites = invites.filter(i => i.maxAge === 0).size;

                const inviterMap = {};
                invites.forEach(inv => {
                    if (!inv.inviter) return;
                    const id   = inv.inviter.id;
                    const uses = Number(inv.uses) || 0;
                    if (!inviterMap[id]) {
                        inviterMap[id] = {
                            name:      inv.inviter.username,
                            avatarUrl: inv.inviter.displayAvatarURL({ size: 64, extension: 'png' }),
                            invites:   0,
                            lastDate:  inv.createdAt || null
                        };
                    }
                    inviterMap[id].invites += uses;
                    if (inv.createdAt && (!inviterMap[id].lastDate || inv.createdAt > inviterMap[id].lastDate)) {
                        inviterMap[id].lastDate = inv.createdAt;
                    }
                });

                topInvitersList = Object.values(inviterMap)
                    .filter(inv => inv.invites > 0)
                    .sort((a, b) => b.invites - a.invites)
                    .slice(0, 10)
                    .map(inv => ({
                        name:      inv.name,
                        avatarUrl: inv.avatarUrl,
                        invites:   inv.invites,
                        date:      inv.lastDate
                            ? inv.lastDate.toLocaleDateString(settings.uiLanguage === 'ar' ? 'ar-SA' : 'en-US')
                            : 'N/A'
                    }));
            } catch (e) {
                req.log?.warn('[Dashboard] تعذر جلب Invites: ' + e.message);
            }

            // ── معلومات المالك ──
            let ownerTag = 'N/A';
            try {
                const owner = await getCached('guildOwner', 5 * 60 * 1000, () => guild.fetchOwner());
                if (owner && owner.user) ownerTag = owner.user.tag;
            } catch (e) {
                req.log?.warn('[Dashboard] تعذر جلب المالك: ' + e.message);
            }

            const createdAt = guild.createdAt
                ? guild.createdAt.toLocaleDateString(settings.uiLanguage === 'ar' ? 'ar-SA' : 'en-US')
                : 'N/A';

            // ── التذاكر المفتوحة ──
            let openTickets = 0;
            try {
                const ticketSettings = loadTicketSettings();
                openTickets = Object.keys(ticketSettings.openTickets || {}).length;
            } catch (e) {}

            // ── التحذيرات ──
            let totalWarnings = 0;
            const warningsPath = path.join(__dirname, '..', 'features', 'warnings', 'warnings.json');
            if (fs.existsSync(warningsPath)) {
                try {
                    const warningsData = JSON.parse(fs.readFileSync(warningsPath, 'utf8'));
                    totalWarnings = Object.values(warningsData)
                        .reduce((sum, arr) => sum + (Array.isArray(arr) ? arr.length : 0), 0);
                } catch (e) {}
            }

            // ── الردود التلقائية ──
            let autoReplies = 0;
            const autoReplyPath = path.join(__dirname, '..', 'autoReply.json');
            if (fs.existsSync(autoReplyPath)) {
                try {
                    const autoReplyData = JSON.parse(fs.readFileSync(autoReplyPath, 'utf8'));
                    autoReplies = (autoReplyData.replies || []).length;
                } catch (e) {}
            }

            // ── الأوامر العامة ──
            let generalCmds = 0;
            if (fs.existsSync(GENERAL_COMMANDS_FILE)) {
                try {
                    const gc = JSON.parse(fs.readFileSync(GENERAL_COMMANDS_FILE, 'utf8'));
                    generalCmds = Object.keys(gc).length;
                } catch (e) {}
            }

            // ── تجميع كل الإحصائيات ──
            serverStats = {
                id:                guild.id,
                name:              guild.name,
                iconUrl:           guild.iconURL({ size: 256 }) || '',
                ownerTag,
                createdAt,
                verificationLevel: guild.verificationLevel || 'N/A',

                totalMembers:  guild.memberCount || allMembers.size,
                humanMembers:  humanMembers.size,
                botMembers:    botMembers.size,
                onlineMembers: onlineMembers.size,
                idleMembers:   idleMembers.size,
                dndMembers:    dndMembers.size,
                offlineMembers:offlineMembers.size,

                totalRoles,
                colorRoles,

                totalChannels:       guild.channels.cache.size,
                textChannels,
                voiceChannels,
                categoryChannels,
                forumChannels,
                announcementChannels,
                stageChannels,
                threadChannels,

                boostCount: guild.premiumSubscriptionCount || 0,
                boostTier:  guild.premiumTier || 0,

                totalEmojis,
                animatedEmojis,

                totalWebhooks,
                activeWebhooks,

                totalInvites,
                permanentInvites,

                openTickets,
                totalWarnings,
                autoReplies,
                generalCommands: generalCmds,

                activeChannels: activeChannelsList,
                topInviters:    topInvitersList,
                memberGrowth:   '+' + Math.max(0, Math.floor((humanMembers.size || 0) * 0.05))
            };

        } catch (err) {
            req.log?.error('خطأ في تحميل إحصائيات السيرفر: ' + err.message);
            serverStats = {
                id: config.guildId || 'N/A',
                name: settings.uiLanguage === 'ar' ? 'السيرفر' : 'Server',
                iconUrl: '', ownerTag: 'N/A', createdAt: 'N/A', verificationLevel: 'N/A',
                totalMembers: 0, humanMembers: 0, botMembers: 0,
                onlineMembers: 0, idleMembers: 0, dndMembers: 0, offlineMembers: 0,
                totalRoles: 0, colorRoles: 0,
                totalChannels: 0, textChannels: 0, voiceChannels: 0,
                categoryChannels: 0, forumChannels: 0, announcementChannels: 0,
                stageChannels: 0, threadChannels: 0,
                boostCount: 0, boostTier: 0,
                totalEmojis: 0, animatedEmojis: 0,
                totalWebhooks: 0, activeWebhooks: 0,
                totalInvites: 0, permanentInvites: 0,
                openTickets: 0, totalWarnings: 0, autoReplies: 0, generalCommands: 0,
                activeChannels: [], topInviters: [], memberGrowth: '+0'
            };
        }

        antibotData.stats = antibotData.stats || {};
        antibotData.stats.live =
            (verificationModule.pendingVerification?.size || 0) +
            (antibotModule.pendingBotApprovals?.size || 0);

        const now = new Date();
        const lastUpdated = now.toLocaleString(settings.uiLanguage === 'ar' ? 'ar-SA' : 'en-US', {
            year: 'numeric', month: 'short', day: 'numeric',
            hour: '2-digit', minute: '2-digit', second: '2-digit'
        });

        res.render('dashboard', {
            settings,
            serverStats,
            protection,
            antibot:     antibotData,
            topMembers,
            lastUpdated,
            isAr:        settings.uiLanguage === 'ar'
        });
    });

    return router;
};
