// routes/giveaway.js
'use strict';

const express = require('express');
const router  = express.Router();

let _client, _loadData, _getSettings, _getGuildChannels, _getGuildRoles;

const {
    loadGiveaways,
    saveGiveaways,
    flushSync,
    getDefaultConfig,
    createGiveaway,
    endGiveaway,
    pauseGiveaway,
    pickWinners,
    buildMemberRolesMap
} = require('../features/giveaway/giveaway');

// ==================== Helpers ====================
function sanitizeString(val, maxLen = 200) {
    if (typeof val !== 'string') return '';
    return val.trim().slice(0, maxLen);
}

function safeInt(val, defaultVal = 0, min = 0, max = Infinity) {
    const n = parseInt(val, 10);
    if (isNaN(n)) return defaultVal;
    return Math.max(min, Math.min(max, n));
}

function jsonError(res, message, code = 400) {
    return res.status(code).json({ success: false, message });
}

// ==================== GET / ====================
router.get('/', async (req, res) => {
    try {
        await _loadData(true);
        const settings      = _getSettings();
        const guildChannels = _getGuildChannels();
        const guildRoles    = _getGuildRoles();
        const guild       = _client.guilds.cache.first();
const guildEmojis = guild ? guild.emojis.cache.map(e => ({
    id: e.id,
    name: e.name,
    animated: e.animated,
    url: e.imageURL({ extension: e.animated ? 'gif' : 'png', size: 32 })
})) : [];
        const data            = loadGiveaways();
        const giveaways       = data.giveaways  || [];
        const giveawayWinners = data.winners     || [];
        const config          = data.config      || getDefaultConfig();

        const giveawayStats = {
            total:             giveaways.length,
            active:            giveaways.filter(g => g.status === 'active').length,
            totalParticipants: giveaways.reduce((s, g) => s + (g.participants?.length || 0), 0),
            totalWinners:      giveaways.reduce((s, g) => s + (g.winners?.length     || 0), 0)
        };

        const enriched = giveaways.map(g => {
            const ch = guildChannels.find(c => c.id === g.channelId);
            return { ...g, channelName: ch ? ch.name : g.channelId };
        });

        res.render('giveaway', {
            settings,
            guildChannels,
            guildEmojis,
            guildRoles,
            giveaways:       enriched,
            giveawayWinners,
            giveawayStats,
            giveawayConfig:  config,
            success:         req.query.success === 'true',
            error:           req.query.error   === 'true'
        });
    } catch (err) {
        console.error('[Giveaway] GET /giveaway error:', err);
        res.status(500).send('Internal Server Error');
    }
});

// ==================== POST /create ====================
router.post('/create', async (req, res) => {
    try {
        const settings = _getSettings();
        const data     = loadGiveaways();
        const config   = data.config || getDefaultConfig();
        const maxW     = Math.max(1, safeInt(config.maxWinners, 10, 1, 50));

        const prize       = sanitizeString(req.body.prize, 200);
        const channelId   = sanitizeString(req.body.channelId, 30);
        const description = sanitizeString(req.body.description, 500);
        const hostedBy    = sanitizeString(req.body.hostedBy, 100);
        const pingRole    = sanitizeString(req.body.pingRole, 30);
        const imageUrl    = sanitizeString(req.body.imageUrl, 500);
        const requiredRole  = sanitizeString(req.body.requiredRole,  30);
        const blacklistRole = sanitizeString(req.body.blacklistRole, 30);

        if (!prize)     return res.redirect('/giveaway?error=true');
        if (!channelId) return res.redirect('/giveaway?error=true');

        const winnersCount = safeInt(req.body.winnersCount, 1, 1, maxW);

        const dDays    = safeInt(req.body.dDays,    0, 0, 30);
        const dHours   = safeInt(req.body.dHours,   0, 0, 23);
        const dMinutes = safeInt(req.body.dMinutes, 0, 0, 59);
        const dSeconds = safeInt(req.body.dSeconds, 0, 0, 59);

        const durationMs = (dDays * 86400 + dHours * 3600 + dMinutes * 60 + dSeconds) * 1000;
        if (durationMs < 10000) return res.redirect('/giveaway?error=true');

        const minAccountAge = safeInt(req.body.minAccountAge, 0, 0, 36500);
        const minServerAge  = safeInt(req.body.minServerAge,  0, 0, 36500);
        const minInvites    = safeInt(req.body.minInvites,    0, 0, 999999);
        const minMessages   = safeInt(req.body.minMessages,   0, 0, 999999);

        const rawBonusRoles   = [].concat(req.body['bonusRole[]']   || []);
        const rawBonusAmounts = [].concat(req.body['bonusAmount[]'] || []);
        const bonusRoles   = rawBonusRoles.map(r => sanitizeString(r, 30));
        const bonusAmounts = rawBonusAmounts.map(a => safeInt(a, 1, 1, 50));

        await createGiveaway(_client, {
            channelId, prize, winnersCount, durationMs,
            description, hostedBy, pingRole, imageUrl,
            requiredRole, minAccountAge, minServerAge,
            blacklistRole, minInvites, minMessages,
            bonusRoles, bonusAmounts
        }, settings);

        res.redirect('/giveaway?success=true');
    } catch (err) {
        console.error('[Giveaway] POST /create error:', err);
        res.redirect('/giveaway?error=true');
    }
});

// ==================== POST /delete ====================
router.post('/delete', async (req, res) => {
    try {
        const messageId = sanitizeString(req.body.messageId, 30);
        if (!messageId) return jsonError(res, 'Missing messageId');

        const data = loadGiveaways();
        const gw   = data.giveaways.find(g => g.messageId === messageId);

        if (gw) {
            try {
                const ch  = _client.channels.cache.get(gw.channelId);
                const msg = ch ? await ch.messages.fetch(messageId).catch(() => null) : null;
                if (msg) await msg.delete().catch(() => {});
            } catch (_) {}

            data.giveaways = data.giveaways.filter(g => g.messageId !== messageId);
            saveGiveaways(data);
            flushSync();
        }

        res.json({ success: true });
    } catch (err) {
        console.error('[Giveaway] POST /delete error:', err);
        jsonError(res, err.message, 500);
    }
});

// ==================== POST /end ====================
router.post('/end', async (req, res) => {
    try {
        const messageId = sanitizeString(req.body.messageId, 30);
        if (!messageId) return jsonError(res, 'Missing messageId');

        const settings = _getSettings();
        await endGiveaway(_client, messageId, settings);
        res.json({ success: true });
    } catch (err) {
        console.error('[Giveaway] POST /end error:', err);
        jsonError(res, err.message, 500);
    }
});

// ==================== POST /pause (also resumes) ====================
router.post('/pause', (req, res) => {
    try {
        const messageId = sanitizeString(req.body.messageId, 30);
        if (!messageId) return jsonError(res, 'Missing messageId');

        const result = pauseGiveaway(messageId);
        res.json({ success: result });
    } catch (err) {
        console.error('[Giveaway] POST /pause error:', err);
        jsonError(res, err.message, 500);
    }
});

// ==================== POST /reroll ====================
router.post('/reroll', async (req, res) => {
    try {
        const messageId = sanitizeString(req.body.messageId, 30);
        if (!messageId) return jsonError(res, 'Missing messageId');

        const data = loadGiveaways();
        const gw   = data.giveaways.find(g => g.messageId === messageId);
        if (!gw) return jsonError(res, 'Giveaway not found', 404);

        const config = data.config || getDefaultConfig();
        const settings = _getSettings();
        const lang     = settings?.botLanguage === 'ar' ? 'ar' : 'en';

        const guild          = _client.guilds.cache.get(gw.guildId);
        const memberRolesMap = await buildMemberRolesMap(guild, gw.participants);

        const newWinners = pickWinners(
            gw.participants,
            gw.winnersCount,
            gw.bonusEntries || [],
            [],
            memberRolesMap
        );

        gw.winners = newWinners;

        const channel = _client.channels.cache.get(gw.channelId);
        if (channel && newWinners.length > 0) {
            const mentions   = newWinners.map(id => `<@${id}>`).join(', ');
            const rerollText = config.rerollMsg
                ? config.rerollMsg.replace(/\{winner\}/g, mentions)
                : (lang === 'ar'
                    ? `🔄 الفائزون الجدد: ${mentions}`
                    : `🔄 New winner(s): ${mentions}`);

            await channel.send({ content: rerollText }).catch(() => {});
        }

        if (!Array.isArray(data.winners)) data.winners = [];

       for (const userId of newWinners) {
            let username  = userId;
            let avatarURL = null;
            try {
                const member = guild?.members.cache.get(userId)
                            || await guild?.members.fetch(userId).catch(() => null);
                if (member) {
                    username  = member.user.username;
                    avatarURL = member.user.displayAvatarURL({ extension: 'png', size: 64 });
                }
            } catch (_) {}

            data.winners.push({
                giveawayId:  messageId,
                userId,
                username,
                avatarURL,
                prize:       gw.prize,
                wonAt:       Date.now(),
                channelId:   gw.channelId,
                channelName: channel?.name || gw.channelId
            });
        }

        saveGiveaways(data);
        flushSync();
        res.json({ success: true });
    } catch (err) {
        console.error('[Giveaway] POST /reroll error:', err);
        jsonError(res, err.message, 500);
    }
});

// ==================== POST /reroll-single ====================
router.post('/reroll-single', async (req, res) => {
    try {
        const messageId    = sanitizeString(req.body.messageId, 30);
        const oldUserId    = sanitizeString(req.body.userId,    30);
        if (!messageId || !oldUserId) return jsonError(res, 'Missing parameters');

        const data = loadGiveaways();
        const gw   = data.giveaways.find(g => g.messageId === messageId);
        if (!gw) return jsonError(res, 'Giveaway not found', 404);

        const guild          = _client.guilds.cache.get(gw.guildId);
        const memberRolesMap = await buildMemberRolesMap(guild, gw.participants);
        const settings       = _getSettings();
        const lang           = settings?.botLanguage === 'ar' ? 'ar' : 'en';

        const newWinners = pickWinners(
            gw.participants,
            1,
            gw.bonusEntries || [],
            (gw.winners || []).filter(id => id !== oldUserId),
            memberRolesMap
        );

        if (newWinners.length === 0) {
            return jsonError(res,
                lang === 'ar' ? 'لا يوجد مشاركون مؤهلون' : 'No eligible participants'
            );
        }

        const newUserId = newWinners[0];

        // Replace in giveaway.winners
        const idx = (gw.winners || []).indexOf(oldUserId);
        if (idx !== -1) gw.winners[idx] = newUserId;
        else gw.winners = (gw.winners || []).concat([newUserId]);

        const channel = _client.channels.cache.get(gw.channelId);
        if (channel) {
            await channel.send({
                content: lang === 'ar'
                    ? `🔄 الفائز الجديد: <@${newUserId}> (استبدل <@${oldUserId}>)`
                    : `🔄 New winner: <@${newUserId}> (replaced <@${oldUserId}>)`
            }).catch(() => {});
        }

        // Remove old winner from data.winners log and add new one
        if (Array.isArray(data.winners)) {
            data.winners = data.winners.filter(
                w => !(w.giveawayId === messageId && w.userId === oldUserId)
            );
        } else {
            data.winners = [];
        }

        let newUsername  = newUserId;
        let newAvatarURL = null;
        try {
            const member = guild?.members.cache.get(newUserId)
                        || await guild?.members.fetch(newUserId).catch(() => null);
            if (member) {
                newUsername  = member.user.username;
                newAvatarURL = member.user.displayAvatarURL({ extension: 'png', size: 64 });
            }
        } catch (_) {}

        data.winners.push({
            giveawayId:  messageId,
            userId:      newUserId,
            username:    newUsername,
            avatarURL:   newAvatarURL,
            prize:       gw.prize,
            wonAt:       Date.now(),
            channelId:   gw.channelId,
            channelName: channel?.name || gw.channelId
        });

        saveGiveaways(data);
        flushSync();
        res.json({ success: true });
    } catch (err) {
        console.error('[Giveaway] POST /reroll-single error:', err);
        jsonError(res, err.message, 500);
    }
});

// ==================== POST /settings ====================
router.post('/settings', (req, res) => {
    try {
        const data   = loadGiveaways();
        const config = data.config || getDefaultConfig();

        config.defaultColor         = /^#[0-9a-fA-F]{6}$/.test(req.body.defaultColor)
                                        ? req.body.defaultColor : '#5865F2';
       config.entryEmoji           = sanitizeString(req.body.entryEmoji, 60) || '🎉';
        config.winnersChannel       = sanitizeString(req.body.winnersChannel, 30);
        config.maxWinners           = safeInt(req.body.maxWinners, 10, 1, 50);
        config.dmWinners            = req.body.dmWinners     === 'true' || req.body.dmWinners     === 'on';
        config.deleteOnEnd          = req.body.deleteOnEnd   === 'true' || req.body.deleteOnEnd   === 'on';
        config.allowMultipleEntries = req.body.allowMultipleEntries === 'true' || req.body.allowMultipleEntries === 'on';
        config.endReminder          = req.body.endReminder   === 'true' || req.body.endReminder   === 'on';
        config.noDuplicateWinners   = req.body.noDuplicateWinners === 'true' || req.body.noDuplicateWinners === 'on';
        config.startTitle           = sanitizeString(req.body.startTitle, 100);
        config.endTitle             = sanitizeString(req.body.endTitle,   100);
        config.winnerDm             = sanitizeString(req.body.winnerDm,   500);
        config.rerollMsg            = sanitizeString(req.body.rerollMsg,  500);

        data.config = config;
        saveGiveaways(data);
        flushSync();

        res.redirect('/giveaway?success=true');
    } catch (err) {
        console.error('[Giveaway] POST /settings error:', err);
        res.redirect('/giveaway?error=true');
    }
});

// ==================== Module Init ====================
module.exports = function(options) {
    _client           = options.client;
    _loadData         = options.loadData;
    _getSettings      = options.getSettings;
    _getGuildChannels = options.getGuildChannels;
    _getGuildRoles    = options.getGuildRoles;
    return router;
};
