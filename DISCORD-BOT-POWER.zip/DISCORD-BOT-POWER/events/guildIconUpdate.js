const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildUpdate',
    once: false,

    async execute(client, settings, oldGuild, newGuild) {
        // نتحقق إذا كانت صورة السيرفر تغيرت
        if (oldGuild.icon === newGuild.icon) return;

        const loggerName = 'guildIconUpdate';
        const loggerSettings = settings[loggerName];
        if (!loggerSettings || !loggerSettings.enabled) return;

        const guild = newGuild; // السيرفر الحالي
        const channel = guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;

        const lang = settings.botLanguage || 'ar';
        const shortDate = new Date().toLocaleString('en-US');
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });

        // روابط الصور القديمة والجديدة للسيرفر
        const oldIcon = oldGuild.iconURL({ size: 256, dynamic: true }) || "No old icon";
        const newIcon = newGuild.iconURL({ size: 256, dynamic: true }) || "No new icon";

        const titles = {
            ar: "🖼️〡تم تغيير صورة السيرفر",
            en: "🖼️〡Server Icon Updated"
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات السيرفر" : " Server Info",
                    value: lang === 'ar'
                        ? `\n**السيرفر:** \`${guild.name}\`\n\n**معرف السيرفر:** \`${guild.id}\`\n\u200B`
                        : `\n**Server:** \`${guild.name}\`\n\n**Server ID:** \`${guild.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " وقت التغيير" : " Changed At",
                    value: `\`${detailedDate}\``
                }
            )
            .setImage(newIcon)  // الصورة الجديدة كبيرة
            .setThumbnail(oldIcon)  // الصورة القديمة صغيرة
            .setFooter({
                text: lang === 'ar'
                    ? `${guild.name} | الصغيرة: الصورة القديمة | الكبيرة: الصورة الجديدة | ${shortDate}`
                    : `${guild.name}  ${shortDate}`,
                iconURL: guild.iconURL()
            });

        channel.send({ embeds: [embed] });
    }
};