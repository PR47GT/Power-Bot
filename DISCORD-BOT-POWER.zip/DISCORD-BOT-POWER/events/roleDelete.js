const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'roleDelete',
    once: false,
    
    async execute(client, settings, role) {
        const loggerName = 'roleDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = role.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        const logs = await role.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.RoleDelete });
        const executor = logs.entries.first()?.executor ?? { id: "Unknown", tag: "Unknown#0000" };
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🗑️〡تم حذف رتبة",
            en: "🗑️〡Role Deleted"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الرتبة" : " Role Info",
                    value: lang === 'ar'
                        ? `\n**اسم الرتبة:** \`${role.name}\`\n\n**معرف الرتبة:** \`${role.id}\`\n\u200B`
                        : `\n**Role Name:** \`${role.name}\`\n\n**Role ID:** \`${role.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${role.guild.name} | ${shortDate}`,
                iconURL: role.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};