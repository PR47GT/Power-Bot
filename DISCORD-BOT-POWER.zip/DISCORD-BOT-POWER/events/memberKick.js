const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    once: false,
    
    async execute(client, settings, member) {
        const loggerName = 'memberKick';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = member.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(res => setTimeout(res, 1000));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        let reason = "";
        
        try {
            const logs = await member.guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.MemberKick });
            const log = logs.entries.find(entry => entry.target.id === member.user.id && Date.now() - entry.createdTimestamp < 10000);
            if (!log) return;
            executor = log.executor;
            reason = log.reason || (lang === 'ar' ? "لم يُقدَّم سبب" : "No reason provided");
        } catch (err) {
            return;
        }
        
        // تنسيق التاريخ المفصل (داخل معلومات الطرد)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🦿〡تم طرده من السيرفر",
            en: "🦿〡Member Kicked"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${member.user.id}>\n\n**اسم العضو:** \`${member.user.tag}\`\n\n**معرّف العضو:** \`${member.user.id}\`\n\u200B`
                        : `\n**Member:** <@${member.user.id}>\n\n**Member Name:** \`${member.user.tag}\`\n\n**Member ID:** \`${member.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " السبب" : " Reason",
                    value: `\`\`\`${reason}\`\`\``
                },
                {
                    name: lang === 'ar' ? " تم الطرد بواسطة" : " Kicked By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرّف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${member.guild.name} | ${shortDate}`,
                iconURL: member.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};