const { EmbedBuilder } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'userUpdate',
    once: false,

    async execute(client, settings, oldUser, newUser) {
        if (oldUser.avatar === newUser.avatar) return;

        const loggerName = 'avatarUpdate';
        const loggerSettings = settings[loggerName];
        if (!loggerSettings || !loggerSettings.enabled) return;

        const guild = client.guilds.cache.get(config.guildId);
        if (!guild) return;

        const channel = guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;

        const lang = settings.botLanguage || 'ar';
        const shortDate = new Date().toLocaleString('en-US');
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });

        const oldAvatar = oldUser.displayAvatarURL({ size: 256, dynamic: true });
        const newAvatar = newUser.displayAvatarURL({ size: 256, dynamic: true });

        const titles = {
            ar: "🖼️〡تم تغيير صورة عضو",
            en: "🖼️〡Member Avatar Updated"
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${newUser.id}>\n\n**اسم العضو:** \`${newUser.tag}\`\n\n**معرف العضو:** \`${newUser.id}\`\n\u200B`
                        : `\n**Member:** <@${newUser.id}>\n\n**Member Name:** \`${newUser.tag}\`\n\n**Member ID:** \`${newUser.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " وقت التغيير" : " Changed At",
                    value: `\`${detailedDate}\``
                }
            )
            .setImage(newAvatar)
            .setThumbnail(oldAvatar)
            .setFooter({
                text: lang === 'ar'
                    ? `${guild.name} | الصغيرة: الصورة القديمة | الكبيرة: الصورة الجديدة | ${shortDate}`
                    : `${guild.name} | Small: Old Avatar | Large: New Avatar | ${shortDate}`,
                iconURL: guild.iconURL()
            });

        channel.send({ embeds: [embed] });
    }
};
