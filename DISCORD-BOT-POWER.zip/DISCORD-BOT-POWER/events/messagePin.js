const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'channelPinsUpdate',
    once: false,

    async execute(client, settings, channel, time) {
        const loggerName = 'messagePin';
        const loggerSettings = settings[loggerName];
if (!loggerSettings || !loggerSettings.enabled) return;

        if (!loggerSettings.enabled) return;

        const logChannel = channel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;

        const lang = settings.botLanguage || 'ar';

        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));

        let executor = null;
        let action = 'pin';
        try {
            const pinLogs = await channel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MessagePin });
            const pinLog = pinLogs.entries.find(e => Date.now() - e.createdTimestamp < 5000);
            if (pinLog) { executor = pinLog.executor; action = 'pin'; }

            if (!executor) {
                const unpinLogs = await channel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MessageUnpin });
                const unpinLog = unpinLogs.entries.find(e => Date.now() - e.createdTimestamp < 5000);
                if (unpinLog) { executor = unpinLog.executor; action = 'unpin'; }
            }
        } catch {}

        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });
        const shortDate = new Date().toLocaleString('en-US');

        const titles = {
            pin:   { ar: "📌〡تم تثبيت رسالة", en: "📌〡Message Pinned" },
            unpin: { ar: "📌〡تم إلغاء تثبيت رسالة", en: "📌〡Message Unpinned" }
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[action][lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                   {
                    name: lang === 'ar' ? " الروم" : " Channel",
                    value: lang === 'ar'
                    ? `**الروم:** <#${channel.id}>

                       **اسم الروم:** \`${channel.name}\`

                       **معرف الروم:** \`${channel.id}\``

                       : `**Channel:** <#${channel.id}>

                         **Channel Name:** \`${channel.name}\`

                         **ID:** \`${channel.id}\``
                },
                {
                    name: lang === 'ar' ? " تم التنفيذ بواسطة" : " Executed By",
                    value: executor
                        ? (lang === 'ar'
                            ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                            : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                        : (lang === 'ar' ? 'غير معروف' : 'Unknown')
                }
            )
            .setFooter({ text: `${channel.guild.name} | ${shortDate}`, iconURL: channel.guild.iconURL() });

        logChannel.send({ embeds: [embed] });
    }
};
