const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'voiceStateUpdate',
    once: false,
    
    async execute(client, settings, oldState, newState) {
        const loggerName = 'voiceMuteDeafen';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = newState.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        if (!newState.channel) return;
        
        const muteChanged = oldState.serverMute !== newState.serverMute;
        const deafChanged = oldState.serverDeaf !== newState.serverDeaf;
        if (!muteChanged && !deafChanged) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        const logs = await newState.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberUpdate });
        const entry = logs.entries.first();
        if (!entry || entry.target.id !== newState.id) return;
        
        const executor = entry.executor ?? { id: "Unknown", tag: "Unknown#0000" };
        
        const muteStatus = {
            ar: newState.serverMute ? "مفعلة" : "معطلة",
            en: newState.serverMute ? "Enabled" : "Disabled"
        };
        
        const deafStatus = {
            ar: newState.serverDeaf ? "مفعلة" : "معطلة",
            en: newState.serverDeaf ? "Enabled" : "Disabled"
        };
        
        // تنسيق التاريخ المفصل (داخل معلومات التغيير)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🎙️〡تغيرت حالة صوت العضو",
            en: "🎙️〡Member Voice State Changed"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${newState.id}>\n\n**الاسم:** \`${newState.member.user.tag}\`\n\n**المعرف:** \`${newState.id}\`\n\u200B`
                        : `\n**Member:** <@${newState.id}>\n\n**Name:** \`${newState.member.user.tag}\`\n\n**ID:** \`${newState.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " حالة الصوت" : " Voice State",
                    value: lang === 'ar'
                        ? `\n**حالة الميوت:** ${muteStatus[lang]}\n\n**حالة الدفن:** ${deafStatus[lang]}\n\u200B`
                        : `\n**Mute Status:** ${muteStatus[lang]}\n\n**Deafen Status:** ${deafStatus[lang]}\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم التغيير بواسطة" : " Changed By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newState.guild.name} | ${shortDate}`,
                iconURL: newState.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};