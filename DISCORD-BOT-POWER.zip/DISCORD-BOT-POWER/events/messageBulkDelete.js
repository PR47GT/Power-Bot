const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'messageDeleteBulk',
    once: false,
    
    async execute(client, settings, messages) {
        try {
            const guild = messages.first().guild;
            
            const loggerName = 'messageBulkDelete';
            const loggerSettings = settings.loggers[loggerName];
            
            if (!loggerSettings.enabled) return;
            
            const logChannel = guild.channels.cache.get(loggerSettings.channelId);
            if (!logChannel) return;
            
            const fetchedLogs = await guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MessageBulkDelete });
            const deletionLog = fetchedLogs.entries.first();
            if (!deletionLog) return;
            
            const { executor } = deletionLog;
            const channel = messages.first().channel;
            
            // تحديد اللغة
            const lang = settings.botLanguage || 'ar';
            
            // تنسيق التاريخ المفصل (داخل معلومات الحذف)
            const detailedDate = new Date().toLocaleString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
                hour12: true
            });
            
            // تنسيق التاريخ المختصر (للـ Footer)
            const shortDate = new Date().toLocaleString('en-US');
            
            const titles = {
                ar: "🗑️〡تم حذف رسائل بشكل جماعي",
                en: "🗑️〡Messages Bulk Deleted"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor(loggerSettings.embedColor)
                .addFields(
                    {
                        name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                        value: lang === 'ar'
                            ? `\n**الروم:** <#${channel.id}>\n\n**اسم الروم:** \`${channel.name}\`\n\n**معرف الروم:** \`${channel.id}\`\n\u200B`
                            : `\n**Channel:** <#${channel.id}>\n\n**Channel Name:** \`${channel.name}\`\n\n**Channel ID:** \`${channel.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " عدد الرسائل" : " Messages Count",
                        value: `\`\`\`fix\n${messages.size}\n\`\`\``,
                        inline: true
                    },
                    {
                        name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                        value: lang === 'ar'
                            ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\``
                            : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\``
                    },
                    {
                        name: lang === 'ar' ? " التوقيت" : " Time",
                        value: `\`${detailedDate}\``,
                        inline: true
                    }
                )
                .setFooter({
                    text: `${guild.name} | ${shortDate}`,
                    iconURL: guild.iconURL()
                });
            
            logChannel.send({ embeds: [embed] });
        } catch (err) {}
    }
};