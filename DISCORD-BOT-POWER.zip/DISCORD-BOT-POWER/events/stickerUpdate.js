const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'stickerUpdate',
    once: false,
    
    async execute(client, settings, oldSticker, newSticker) {
        const loggerName = 'stickerUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newSticker.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        if (oldSticker.name === newSticker.name && oldSticker.description === newSticker.description) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        let changeText = '';
        if (oldSticker.name !== newSticker.name) {
            changeText += lang === 'ar'
                ? `**الاسم القديم:** \`${oldSticker.name}\`\n**الاسم الجديد:** \`${newSticker.name}\`\n\n`
                : `**Old Name:** \`${oldSticker.name}\`\n**New Name:** \`${newSticker.name}\`\n\n`;
        }
        if (oldSticker.description !== newSticker.description) {
            const oldDesc = oldSticker.description || (lang === 'ar' ? 'لا يوجد' : 'None');
            const newDesc = newSticker.description || (lang === 'ar' ? 'لا يوجد' : 'None');
            changeText += lang === 'ar'
                ? `**الوصف القديم:** \`${oldDesc}\`\n**الوصف الجديد:** \`${newDesc}\``
                : `**Old Description:** \`${oldDesc}\`\n**New Description:** \`${newDesc}\``;
        }
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await newSticker.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.StickerUpdate });
            const entry = logs.entries.find(e => e.target.id === newSticker.id);
            if (entry) {
                executor = entry.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "✏️〡تم تحديث استيكر",
            en: "✏️〡Sticker Updated"
        };
        
        const updatedText = {
            ar: "تم تحديث الاستيكر",
            en: "Sticker updated"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الاستيكر" : " Sticker Info",
                    value: lang === 'ar'
                        ? `\n**المعرف:** \`${newSticker.id}\`\n\u200B`
                        : `\n**ID:** \`${newSticker.id}\`\n\u200B`,
                    inline: false
                },
                {
                    name: lang === 'ar' ? " التغييرات" : " Changes",
                    value: changeText || updatedText[lang],
                    inline: false
                },
                {
                    name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**المعرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``,
                    inline: false
                }
            )
            .setFooter({
                text: `${newSticker.guild.name} | ${shortDate}`,
                iconURL: newSticker.guild.iconURL({ dynamic: true })
            });
        
        logChannel.send({ embeds: [embed] });
    }
};