const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'threadDelete',
    once: false,
    
    async execute(client, settings, thread) {
        const loggerName = 'threadDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = thread.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await thread.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.ThreadDelete });
            const log = logs.entries.find(e => e.target.id === thread.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🧵〡تم حذف محادثة فرعية",
            en: "🧵〡Thread Deleted"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات المحادثة" : " Thread Info",
                    value: lang === 'ar'
                        ? `\n**اسم المحادثة:** \`${thread.name}\`\n\n**المعرف:** \`${thread.id}\`\n\u200B`
                        : `\n**Thread Name:** \`${thread.name}\`\n\n**ID:** \`${thread.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الروم الأساسي" : " Parent Channel",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${thread.parentId}>\n\n**المعرف:** \`${thread.parentId}\`\n\u200B`
                        : `\n**Channel:** <#${thread.parentId}>\n\n**ID:** \`${thread.parentId}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${thread.guild.name} | ${shortDate}`,
                iconURL: thread.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};