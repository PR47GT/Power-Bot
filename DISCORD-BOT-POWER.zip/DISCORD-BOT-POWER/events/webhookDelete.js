const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'webhooksUpdate',
    once: false,

    async execute(client, settings, channel) {
        const loggerName = 'webhookDelete';
        const loggerSettings = settings[loggerName];
        if (!loggerSettings || !loggerSettings.enabled) return;

        const logChannel = channel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;

        const lang = settings.botLanguage || 'ar';

        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));

        let executor = null;
        let webhookName = null;

        try {
            const logs = await channel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.WebhookDelete });
            const log = logs.entries.find(e => Date.now() - e.createdTimestamp < 5000);
            if (!log) return; // ← إذا ما في سجل حذف، الحدث ليس حذف (قد يكون تعديل أو إنشاء)
            executor = log.executor;
            webhookName = log.target?.name;
        } catch {
            return;
        }

        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });
        const shortDate = new Date().toLocaleString('en-US');

        const titles = {
            ar: "🗑️〡تم حذف Webhook",
            en: "🗑️〡Webhook Deleted"
        };

        const executorName = executor?.username || executor?.tag || 'غير معروف';

        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الـ Webhook" : " Webhook Info",
                    value: lang === 'ar'
                        ? `\n**الاسم:** \`${webhookName || 'غير معروف'}\`\n\n**الروم:** <#${channel.id}>\n\u200B`
                        : `\n**Name:** \`${webhookName || 'Unknown'}\`\n\n**Channel:** <#${channel.id}>\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: executor
                        ? (lang === 'ar'
                            ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executorName}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                            : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executorName}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                        : (lang === 'ar' ? 'غير معروف' : 'Unknown')
                }
            )
            .setFooter({ text: `${channel.guild.name} | ${shortDate}`, iconURL: channel.guild.iconURL() });

        await logChannel.send({ embeds: [embed] });
    }
};