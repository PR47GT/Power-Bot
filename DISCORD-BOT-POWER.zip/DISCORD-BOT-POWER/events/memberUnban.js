const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'guildBanRemove',
    once: false,
    
    async execute(client, settings, ban) {
        const loggerName = 'memberUnban';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = ban.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        
        try {
            const fetchedLogs = await ban.guild.fetchAuditLogs({ limit: 1, type: AuditLogEvent.MemberBanRemove });
            const unbanLog = fetchedLogs.entries.first();
            if (unbanLog) executor = unbanLog.executor;
        } catch (err) {}
        
        // تنسيق التاريخ المفصل (داخل معلومات إزالة الباند)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "✅⇜ تم إزالة الباند عن العضو",
            en: "✅⇜ Member Unbanned"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${ban.user.id}>\n\n**اسم العضو:** \`${ban.user.tag}\`\n\n**مُعرِّف العضو:** \`${ban.user.id}\`\n\u200B`
                        : `\n**Member:** <@${ban.user.id}>\n\n**Member Name:** \`${ban.user.tag}\`\n\n**Member ID:** \`${ban.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم إزالة الباند بواسطة" : " Unbanned By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**مُعرِّف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${ban.guild.name} | ${shortDate}`,
                iconURL: ban.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};