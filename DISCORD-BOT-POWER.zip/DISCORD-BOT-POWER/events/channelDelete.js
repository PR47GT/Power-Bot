const { EmbedBuilder, AuditLogEvent, ChannelType } = require('discord.js');
const config = require('../config');

function getChannelType(type, lang) {
    const types = {
        ar: {
            [ChannelType.GuildText]: "روم كتابي",
            [ChannelType.GuildVoice]: "روم صوتي",
            [ChannelType.GuildForum]: "منتدى",
            [ChannelType.GuildAnnouncement]: "روم إعلانات",
            [ChannelType.GuildStageVoice]: "روم مسرحي",
            [ChannelType.GuildCategory]: "فئة",
        },
        en: {
            [ChannelType.GuildText]: "Text Channel",
            [ChannelType.GuildVoice]: "Voice Channel",
            [ChannelType.GuildForum]: "Forum",
            [ChannelType.GuildAnnouncement]: "Announcement",
            [ChannelType.GuildStageVoice]: "Stage",
            [ChannelType.GuildCategory]: "Category",
        }
    };
    
    return types[lang]?.[type] || (lang === 'ar' ? "غير معروف" : "Unknown");
}

module.exports = {
    name: 'channelDelete',
    once: false,
    
    async execute(client, settings, channel) {
        if (!channel.guild) return;
        
        const loggerName = 'channelDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = channel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await channel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.ChannelDelete });
            const log = logs.entries.find(e => e.target.id === channel.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🗑️〡تم حذف روم",
            en: "🗑️〡Channel Deleted"
        };
        
        const channelTypeName = getChannelType(channel.type, lang);
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                    value: lang === 'ar'
                        ? `\n**اسم الروم:** \`${channel.name}\`\n\n**معرف الروم:** \`${channel.id}\`\n\n**النوع:** \`${channelTypeName}\`\n\u200B`
                        : `\n**Channel Name:** \`${channel.name}\`\n\n**Channel ID:** \`${channel.id}\`\n\n**Type:** \`${channelTypeName}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${channel.guild.name} | ${shortDate}`,
                iconURL: channel.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};