const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'emojiDelete',
    once: false,
    
    async execute(client, settings, emoji) {
        const loggerName = 'emojiDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = emoji.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const emojiType = {
            ar: emoji.animated ? "🔄 متحرك" : "⏸️ ثابت",
            en: emoji.animated ? "🔄 Animated" : "⏸️ Static"
        };
        
        const emojiUrl = emoji.imageURL();
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await emoji.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.EmojiDelete });
            const entry = logs.entries.find(e => e.target.id === emoji.id);
            if (entry) {
                executor = entry.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🗑️〡تم حذف إيموجي",
            en: "🗑️〡Emoji Deleted"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .setThumbnail(emojiUrl)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الإيموجي" : " Emoji Info",
                    value: lang === 'ar'
                        ? `\n**الاسم:** \`${emoji.name}\`\n\n**النوع:** ${emojiType[lang]}\n\n**المعرف:** \`${emoji.id}\`\n\n**الرابط:** [اضغط هنا](${emojiUrl})\n\u200B`
                        : `\n**Name:** \`${emoji.name}\`\n\n**Type:** ${emojiType[lang]}\n\n**ID:** \`${emoji.id}\`\n\n**Link:** [Click Here](${emojiUrl})\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${emoji.guild.name} | ${shortDate}`,
                iconURL: emoji.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};