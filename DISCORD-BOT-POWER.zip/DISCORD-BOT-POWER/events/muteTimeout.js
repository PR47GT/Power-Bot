const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

const MUTED_ROLE_NAME = config.settings.mutedRoleName;

async function findExecutorForRole(guild, targetId) {
    try {
        const logs = await guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.MemberRoleUpdate });
        const entry = logs.entries.find(e => e.target.id === targetId);
        if (entry) return entry.executor;
        const logs2 = await guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.MemberUpdate });
        const entry2 = logs2.entries.find(e => e.target.id === targetId);
        return entry2?.executor || null;
    } catch (err) { return null; }
}

async function findExecutorForTimeout(guild, targetId) {
    try {
        const logs = await guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.MemberUpdate });
        const entry = logs.entries.find(e => e.target.id === targetId);
        return entry?.executor || null;
    } catch (err) { return null; }
}

module.exports = {
    name: 'guildMemberUpdate',
    once: false,
    
    async execute(client, settings, oldMember, newMember) {
        const loggerName = 'muteTimeout';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newMember.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const hadMute = oldMember.roles.cache.some(r => r.name === MUTED_ROLE_NAME);
        const hasMute = newMember.roles.cache.some(r => r.name === MUTED_ROLE_NAME);
        
        // تنسيق التاريخ المفصل (داخل معلومات الميوت)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        // ميوت كتابي
        if (!hadMute && hasMute) {
            const executor = await findExecutorForRole(newMember.guild, newMember.id);
            
            const titles = {
                ar: "🔇⇜ تم إعطاء ميوت كتابي",
                en: "🔇⇜ Text Mute Applied"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor(loggerSettings.embedColor)
                .addFields(
                    {
                        name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${newMember.id}>\n\n**الاسم:** \`${newMember.user.tag}\`\n\n**المعرف:** \`${newMember.id}\`\n\u200B`
                            : `\n**Member:** <@${newMember.id}>\n\n**Name:** \`${newMember.user.tag}\`\n\n**ID:** \`${newMember.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " تم منحه بواسطة" : " Applied By",
                        value: executor
                            ? (lang === 'ar'
                                ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                                : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                            : (lang === 'ar' ? "غير معروف" : "Unknown")
                    }
                )
                .setFooter({
                    text: `${newMember.guild.name} | ${shortDate}`,
                    iconURL: newMember.guild.iconURL()
                });
            logChannel.send({ embeds: [embed] });
            
        } else if (hadMute && !hasMute) {
            const executor = await findExecutorForRole(newMember.guild, newMember.id);
            
            const titles = {
                ar: "✅⇜ تم فك الميوت الكتابي",
                en: "✅⇜ Text Mute Removed"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor("#00FF00")
                .addFields(
                    {
                        name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${newMember.id}>\n\n**الاسم:** \`${newMember.user.tag}\`\n\n**المعرف:** \`${newMember.id}\`\n\u200B`
                            : `\n**Member:** <@${newMember.id}>\n\n**Name:** \`${newMember.user.tag}\`\n\n**ID:** \`${newMember.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " تم فكه بواسطة" : " Removed By",
                        value: executor
                            ? (lang === 'ar'
                                ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                                : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                            : (lang === 'ar' ? "غير معروف" : "Unknown")
                    }
                )
                .setFooter({
                    text: `${newMember.guild.name} | ${shortDate}`,
                    iconURL: newMember.guild.iconURL()
                });
            logChannel.send({ embeds: [embed] });
        }
        
        // ميوت مؤقت
        const oldTimeout = oldMember.communicationDisabledUntilTimestamp;
        const newTimeout = newMember.communicationDisabledUntilTimestamp;
        
        if ((!oldTimeout || oldTimeout < Date.now()) && newTimeout && newTimeout > Date.now()) {
            const executor = await findExecutorForTimeout(newMember.guild, newMember.id);
            
            const titles = {
                ar: "🔇⇜ تم إعطاء ميوت مؤقت",
                en: "🔇⇜ Timeout Applied"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor("#000000")
                .addFields(
                    {
                        name: lang === 'ar' ? "👤 معلومات العضو" : "👤 Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${newMember.id}>\n\n**الاسم:** \`${newMember.user.tag}\`\n\n**المعرف:** \`${newMember.id}\`\n\u200B`
                            : `\n**Member:** <@${newMember.id}>\n\n**Name:** \`${newMember.user.tag}\`\n\n**ID:** \`${newMember.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " تم منحه بواسطة" : " Applied By",
                        value: executor
                            ? (lang === 'ar'
                                ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\``
                                : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\``)
                            : (lang === 'ar' ? "غير معروف" : "Unknown")
                    },
                    {
                        name: lang === 'ar' ? " المدة حتى" : " Expires",
                        value: `<t:${Math.floor(newTimeout / 1000)}:R>`
                    },
                    {
                        name: lang === 'ar' ? " التوقيت" : " Time",
                        value: `\`${detailedDate}\``
                    }
                )
                .setFooter({
                    text: `${newMember.guild.name} | ${shortDate}`,
                    iconURL: newMember.guild.iconURL()
                });
            logChannel.send({ embeds: [embed] });
            
        } else if (oldTimeout && oldTimeout > Date.now() && (!newTimeout || newTimeout <= Date.now())) {
            const executor = await findExecutorForTimeout(newMember.guild, newMember.id);
            
            const titles = {
                ar: "✅〡تم فك الميوت المؤقت",
                en: "✅〡Timeout Removed"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor("#ffffff")
                .addFields(
                    {
                        name: lang === 'ar' ? "👤 معلومات العضو" : "👤 Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${newMember.id}>\n\n**الاسم:** \`${newMember.user.tag}\`\n\n**المعرف:** \`${newMember.id}\`\n\u200B`
                            : `\n**Member:** <@${newMember.id}>\n\n**Name:** \`${newMember.user.tag}\`\n\n**ID:** \`${newMember.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " تم فكه بواسطة" : " Removed By",
                        value: executor
                            ? (lang === 'ar'
                                ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                                : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                            : (lang === 'ar' ? "غير معروف" : "Unknown")
                    }
                )
                .setFooter({
                    text: `${newMember.guild.name} | ${shortDate}`,
                    iconURL: newMember.guild.iconURL()
                });
            logChannel.send({ embeds: [embed] });
        }
    }
};