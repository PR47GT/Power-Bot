const { EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require('discord.js');



// تتبع آخر حالة لسجل التدقيق لكل سيرفر
const lastAuditState = new Map();

module.exports = {
    name: 'voiceStateUpdate',

    async execute(client, settings, oldState, newState) {
        // فقط عند مغادرة الروم الصوتي كلياً (ليس انتقالاً بين رومين)
        if (!oldState.channelId || newState.channelId) return;

        const guild = oldState.guild;

        // قراءة الإعداد من settings
        const cfg = settings?.voiceDisconnect;
        if (!cfg?.enabled || !cfg?.channelId) return;

        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';

        // تأكد من صلاحية قراءة Audit Log
        const botMember = guild.members.me;
        if (!botMember?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
            console.warn('[VoiceDisconnect] ❌ البوت لا يملك صلاحية View Audit Log');
            return;
        }

        const eventTimestamp = Date.now();

        // انتظر حتى يُسجّل Discord الحدث في Audit Log
        await new Promise(r => setTimeout(r, 1500));

        let executorTag = null;
        let executorId  = null;

        try {
            const auditLogs = await guild.fetchAuditLogs({
                type: AuditLogEvent.MemberDisconnect,
                limit: 5,
            });

            const entry = auditLogs.entries.first();
            if (!entry) return;

            const lastState    = lastAuditState.get(guild.id);
            const currentCount = entry.extra?.count ?? 1;
            let isNewDisconnect = false;

            if (!lastState) {
                isNewDisconnect = Math.abs(entry.createdTimestamp - eventTimestamp) < 8000;
            } else if (entry.id !== lastState.entryId) {
                isNewDisconnect = Math.abs(entry.createdTimestamp - eventTimestamp) < 8000;
            } else if (currentCount > lastState.count) {
                isNewDisconnect = true;
            }

            if (!isNewDisconnect) return;

            // حفظ الحالة الجديدة
            lastAuditState.set(guild.id, {
                entryId:   entry.id,
                count:     currentCount,
                timestamp: entry.createdTimestamp,
            });

            if (!entry.executor) return;

            executorTag = entry.executor.tag ?? (lang === 'en' ? 'Unknown' : 'غير معروف');
            executorId  = entry.executor.id  ?? null;

        } catch (err) {
            console.error('[VoiceDisconnect] فشل جلب Audit Log:', err.message);
            return;
        }

        // جلب قناة اللوق
        const logChannel = await client.channels.fetch(cfg.channelId).catch(() => null);
        if (!logChannel) {
            console.warn('[VoiceDisconnect] ❌ لم يُعثر على قناة اللوق:', cfg.channelId);
            return;
        }

        const member     = oldState.member;
        const oldChannel = oldState.channel;
        const now        = new Date();
        const nowSeconds = Math.floor(now.getTime() / 1000);

        // ============================================================
        // النصوص حسب اللغة
        // ============================================================
        let title, memberFieldName, memberValue, voiceChannelFieldName, channelValue, kickedByFieldName, kickedByValue, timeFieldName;

        if (lang === 'en') {
            title = '🔇〡Member disconnected from voice channel';

            memberFieldName = ' Member Info';
            memberValue = [
                `**Member:** <@${oldState.id}>`,
                ``,
                `**Username:** \`${member?.user?.tag ?? 'Unknown'}\``,
                ``,
                `**User ID:** \`${oldState.id}\``,
            ].join('\n');

            voiceChannelFieldName = ' Voice Channel';
            channelValue = oldChannel
                ? [
                    `**Channel:** <#${oldChannel.id}>`,
                    ``,
                    `**Channel Name:** \`${oldChannel.name}\``,
                    ``,
                    `**Channel ID:** \`${oldChannel.id}\``,
                ].join('\n')
                : 'Unknown';

            kickedByFieldName = ' Disconnected by';
            kickedByValue = [
                `**Admin:** ${executorId ? `<@${executorId}>` : 'Unknown'}`,
                ``,
                `**Admin Name:** \`${executorTag ?? 'Unknown'}\``,
                ``,
                `**Admin ID:** \`${executorId ?? 'Unknown'}\``,
            ].join('\n');

            timeFieldName = ' Time';
        } else {
            title = '🔇〡تم قطع اتصال العضو من الروم الصوتي';

            memberFieldName = '  معلومات العضو';
            memberValue = [
                `**العضو:** <@${oldState.id}>`,
                ``,
                `**اسم العضو:** \`${member?.user?.tag ?? 'غير معروف'}\``,
                ``,
                `**معرف العضو:** \`${oldState.id}\``,
            ].join('\n');

            voiceChannelFieldName = ' روم الصوت';
            channelValue = oldChannel
                ? [
                    `**الروم:** <#${oldChannel.id}>`,
                    ``,
                    `**اسم الروم:** \`${oldChannel.name}\``,
                    ``,
                    `**معرف الروم:** \`${oldChannel.id}\``,
                ].join('\n')
                : 'غير معروف';

            kickedByFieldName = ' تم الفصل بواسطة';
            kickedByValue = [
                `**الأدمن:** ${executorId ? `<@${executorId}>` : 'غير معروف'}`,
                ``,
                `**اسم الأدمن:** \`${executorTag ?? 'غير معروف'}\``,
                ``,
                `**مُعرِّف الأدمن:** \`${executorId ?? 'غير معروف'}\``,
            ].join('\n');

            timeFieldName = ' الوقت';
        }

        const embed = new EmbedBuilder()
            .setColor(cfg.embedColor || 0xED4245)
            .setTitle(title)
            .addFields(
                { name: memberFieldName,       value: memberValue,      inline: false },
                { name: voiceChannelFieldName, value: channelValue,     inline: false },
                { name: kickedByFieldName,     value: kickedByValue,    inline: false },
                { name: timeFieldName,         value: `<t:${nowSeconds}:F>`, inline: false },
            )
            .setFooter({
                text: `${guild.name} | ${now.toLocaleDateString('en-US', { month: 'numeric', day: 'numeric', year: 'numeric' })}, ${now.toLocaleTimeString('en-US')}`,
                iconURL: guild.iconURL({ dynamic: true }) ?? undefined,
            });

        await logChannel.send({ embeds: [embed] }).catch(err => {
            console.error('[VoiceDisconnect] فشل إرسال اللوق:', err.message);
        });
    },
};
