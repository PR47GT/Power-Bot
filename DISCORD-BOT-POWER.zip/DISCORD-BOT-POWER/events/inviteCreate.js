const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'inviteCreate',
    once: false,
    
    async execute(client, settings, invite) {
        const loggerName = 'inviteCreate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = invite.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const inviter = invite.inviter;
        
        const maxUses = {
            ar: invite.maxUses === 0 ? "غير محدود" : invite.maxUses,
            en: invite.maxUses === 0 ? "Unlimited" : invite.maxUses
        };
        
        const maxAge = {
            ar: invite.maxAge === 0 ? "غير محدود" : `${invite.maxAge / 60} دقيقة`,
            en: invite.maxAge === 0 ? "Unlimited" : `${invite.maxAge / 60} minutes`
        };
        
        // تنسيق التاريخ المفصل (داخل معلومات الدعوة)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🔗〡تم إنشاء دعوة جديدة",
            en: "🔗〡New Invite Created"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " صاحب الدعوة" : " Invite Creator",
                    value: lang === 'ar'
                        ? `\n**المستخدم:** ${inviter ? `<@${inviter.id}>` : "غير معروف"}\n\n**الاسم:** \`${inviter?.tag || "غير معروف"}\`\n\n**المعرف:** \`${inviter?.id || "غير معروف"}\`\n\u200B`
                        : `\n**User:** ${inviter ? `<@${inviter.id}>` : "Unknown"}\n\n**Name:** \`${inviter?.tag || "Unknown"}\`\n\n**ID:** \`${inviter?.id || "Unknown"}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " معلومات الدعوة" : " Invite Info",
                    value: lang === 'ar'
                        ? `\n**رمز الدعوة:** \`${invite.code}\`\n\n**عدد الاستخدامات:** \`${maxUses[lang]}\`\n\n**المدة:** \`${maxAge[lang]}\`\n\u200B`
                        : `\n**Invite Code:** \`${invite.code}\`\n\n**Max Uses:** \`${maxUses[lang]}\`\n\n**Expires:** \`${maxAge[lang]}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الروم" : " Channel",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${invite.channel.id}>\n\n**اسم الروم:** \`${invite.channel.name}\`\n\n**معرف الروم:** \`${invite.channel.id}\`\n\u200B`
                        : `\n**Channel:** <#${invite.channel.id}>\n\n**Channel Name:** \`${invite.channel.name}\`\n\n**Channel ID:** \`${invite.channel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " التوقيت" : " Time",
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${invite.guild.name} | ${shortDate}`,
                iconURL: invite.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};