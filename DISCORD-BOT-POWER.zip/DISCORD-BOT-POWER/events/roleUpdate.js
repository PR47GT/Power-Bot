const { EmbedBuilder, AuditLogEvent, PermissionsBitField } = require('discord.js');
const config = require('../config');

function getPermissionNames(perms) {
    return perms.map(p => p.toLowerCase().replace(/_/g, " ").replace(/\b\w/g, l => l.toUpperCase()));
}

const lastSent = new Map();

module.exports = {
    name: 'roleUpdate',
    once: false,
    
    async execute(client, settings, oldRole, newRole) {
        const loggerName = 'roleUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = newRole.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        if (lastSent.get(newRole.id) && Date.now() - lastSent.get(newRole.id) < 2000) return;
        lastSent.set(newRole.id, Date.now());
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        const logs = await newRole.guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.RoleUpdate });
        const executor = logs.entries.first()?.executor ?? { id: "Unknown", tag: "Unknown#0000" };
        
        const oldPerms = new PermissionsBitField(oldRole.permissions.bitfield).toArray();
        const newPerms = new PermissionsBitField(newRole.permissions.bitfield).toArray();
        const added = newPerms.filter(p => !oldPerms.includes(p));
        const removed = oldPerms.filter(p => !newPerms.includes(p));
        const colorChanged = oldRole.color !== newRole.color;
        
        if (oldRole.name === newRole.name && added.length === 0 && removed.length === 0 && !colorChanged) return;
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🎖️〡تم تعديل رتبة",
            en: "🎖️〡Role Updated"
        };
        
        let fields = [];
        
        if (oldRole.name !== newRole.name) {
            fields.push({
                name: lang === 'ar' ? " تم تغيير الاسم" : " Name Changed",
                value: lang === 'ar'
                    ? `**الاسم السابق:** \`${oldRole.name}\`

                    **الاسم الجديد:** \`${newRole.name}\``

                    : `**Old Name:** \`${oldRole.name}\`

                    **New Name:** \`${newRole.name}\``
            });
        }
        if (colorChanged) {
            const oldColorHex = `#${oldRole.color.toString(16).padStart(6, '0')}`;
            const newColorHex = `#${newRole.color.toString(16).padStart(6, '0')}`;
            fields.push({
                name: lang === 'ar' ? " تم تغيير اللون" : " Color Changed",
                value: lang === 'ar'
                    ? `**اللون السابق:** \`${oldColorHex}\`

                    **اللون الجديد:** \`${newColorHex}\``

                    : `**Old Color:** \`${oldColorHex}\`

                    **New Color:** \`${newColorHex}\``
            });
        }
        if (added.length > 0) {
            fields.push({
                name: lang === 'ar' ? "✅ تم إضافة صلاحيات" : "✅ Permissions Added",
                value: "```\n" + getPermissionNames(added).join("\n") + "\n```"
            });
        }
        if (removed.length > 0) {
            fields.push({
                name: lang === 'ar' ? "❌ تم سحب صلاحيات" : "❌ Permissions Removed",
                value: "```\n" + getPermissionNames(removed).join("\n") + "\n```"
            });
        }
        fields.push({
            name: lang === 'ar' ? " معلومات الرتبة" : " Role Info",
            value: lang === 'ar'
                ? `**الرتبة:** <@&${newRole.id}>

                **اسم الرتبة:** \`${newRole.name}\`

                **معرف الرتبة:** \`${newRole.id}\``


                : `**Role:** <@&${newRole.id}>\n**Role Name:** \`${newRole.name}\`
                
                **Role ID:** \`${newRole.id}\``
        });
        fields.push({
            name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
            value: lang === 'ar'
                ? `**الادمن:** <@${executor.id}>

                **اسم الادمن:** \`${executor.tag}\`

                **معرف الادمن:** \`${executor.id}\`

                **التوقيت:** \`${detailedDate}\``

                : `**Admin:** <@${executor.id}>

                **Admin Name:** \`${executor.tag}\`

                **Admin ID:** \`${executor.id}\`

                **Time:** \`${detailedDate}\``
        });
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(fields)
            .setFooter({
                text: `${newRole.guild.name} | ${shortDate}`,
                iconURL: newRole.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};