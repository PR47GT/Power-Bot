const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'guildMemberRemove',
    once: false,
    
    async execute(client, settings, member) {
        const loggerName = 'memberLeave';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = member.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        // تنسيق التاريخ المفصل (داخل معلومات المغادرة)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "💨〡عضو غادر السيرفر",
            en: "💨〡Member Left"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${member.user.id}>\n\n**اسم العضو:** \`${member.user.tag}\`\n\n**معرّف العضو:** \`${member.user.id}\`\n\u200B`
                        : `\n**Member:** <@${member.user.id}>\n\n**Member Name:** \`${member.user.tag}\`\n\n**Member ID:** \`${member.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " وقت المغادرة" : " Leave Time",
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${member.guild.name} | ${shortDate}`,
                iconURL: member.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};