const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'threadUpdate',
    once: false,
    
    async execute(client, settings, oldThread, newThread) {
        const loggerName = 'threadUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newThread.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        let changes = [];
        
        if (oldThread.name !== newThread.name) {
            changes.push(lang === 'ar'
                ? `**تغيير اسم المحادثة**\nالاسم القديم: \`${oldThread.name}\`\nالاسم الجديد: \`${newThread.name}\``
                : `**Thread Name Changed**\nOld Name: \`${oldThread.name}\`\nNew Name: \`${newThread.name}\``);
        }
        if (oldThread.rateLimitPerUser !== newThread.rateLimitPerUser) {
            changes.push(lang === 'ar'
                ? `**تغيير وضع البطء**\nالقديم: \`${oldThread.rateLimitPerUser} ثواني\`\nالجديد: \`${newThread.rateLimitPerUser} ثواني\``
                : `**Slow Mode Changed**\nOld: \`${oldThread.rateLimitPerUser} seconds\`\nNew: \`${newThread.rateLimitPerUser} seconds\``);
        }
        if (oldThread.autoArchiveDuration !== newThread.autoArchiveDuration) {
            changes.push(lang === 'ar'
                ? `**تغيير مدة الإخفاء**\nالقديم: \`${oldThread.autoArchiveDuration} دقيقة\`\nالجديد: \`${newThread.autoArchiveDuration} دقيقة\``
                : `**Archive Duration Changed**\nOld: \`${oldThread.autoArchiveDuration} minutes\`\nNew: \`${newThread.autoArchiveDuration} minutes\``);
        }
        
        if (changes.length === 0) return;
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await newThread.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.ThreadUpdate });
            const log = logs.entries.find(e => e.target.id === newThread.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🧵〡تم تحديث محادثة فرعية",
            en: "🧵〡Thread Updated"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات المحادثة" : " Thread Info",
                    value: lang === 'ar'
                        ? `\n**المحادثة:** <#${newThread.id}>\n\n**الاسم:** \`${newThread.name}\`\n\n**المعرف:** \`${newThread.id}\`\n\u200B`
                        : `\n**Thread:** <#${newThread.id}>\n\n**Name:** \`${newThread.name}\`\n\n**ID:** \`${newThread.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " التغييرات" : " Changes",
                    value: changes.join("\n\n")
                },
                {
                    name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newThread.guild.name} | ${shortDate}`,
                iconURL: newThread.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};