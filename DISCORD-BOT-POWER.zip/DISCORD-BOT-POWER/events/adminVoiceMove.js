const { EmbedBuilder, AuditLogEvent, PermissionFlagsBits } = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    once: false,

    async execute(client, settings, oldState, newState) {
        // فقط عند الانتقال بين رومين صوتيين
        if (!oldState.channelId || !newState.channelId) return;
        if (oldState.channelId === newState.channelId) return;

        const loggerName = 'adminVoiceMove';
        const loggerSettings = settings.loggers?.[loggerName] ?? settings[loggerName];
        if (!loggerSettings?.enabled) return;

        const channel = oldState.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;

        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';

        const guild         = newState.guild;
        const eventTimestamp = Date.now();

        // تأكد من صلاحية قراءة Audit Log
        const botMember = guild.members.me;
        if (!botMember?.permissions.has(PermissionFlagsBits.ViewAuditLog)) {
            console.warn('[VoiceMove] ❌ البوت لا يملك صلاحية View Audit Log');
            return;
        }

        // انتظر حتى يُسجّل Discord الحدث في Audit Log
        await new Promise(r => setTimeout(r, 3000));

        let executorTag = null;
        let executorId  = null;

        try {
            const auditLogs = await guild.fetchAuditLogs({
                type: AuditLogEvent.MemberMove,
                limit: 10,
            });

            // ابحث عن إدخال يطابق الروم الوجهة خلال آخر 15 ثانية
            const entry = auditLogs.entries.find(e => {
                const ageMs      = Date.now() - e.createdTimestamp;
                const channelMatch = e.extra?.channel?.id === newState.channelId;
                return ageMs < 15000 && channelMatch;
            });

            if (!entry) return;

            // تجاهل إذا نقل نفسه
            if (entry.executor?.id === newState.id) return;

            executorTag = entry.executor?.tag ?? 'Unknown';
            executorId  = entry.executor?.id  ?? null;

        } catch (err) {
            console.error('[VoiceMove] فشل جلب Audit Log:', err.message);
            return;
        }

        // تنسيق التاريخ المفصل
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });

        // تنسيق التاريخ المختصر للـ Footer
        const shortDate = new Date().toLocaleString('en-US');
const oldChannel = oldState.channel;
const newChannel = newState.channel;
        const titles = {
            ar: '🔀〡تم نقل عضو إلى روم صوتي آخر',
            en: '🔀〡Member Moved to Another Voice Channel'
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[lang] || titles['ar'])
            .setColor(loggerSettings.embedColor || '#5865F2')
            .addFields(
                {
                    name: lang === 'ar' ? ' معلومات العضو' : ' Member Info',
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${newState.member.user.id}>\n\n**اسم العضو:** \`${newState.member.user.username}\`\n\n**معرف العضو:** \`${newState.member.user.id}\`\n\u200B`
                        : `\n**Member:** <@${newState.member.user.id}>\n\n**Member Name:** \`${newState.member.user.username}\`\n\n**Member ID:** \`${newState.member.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? ' الرومات الصوتية' : ' Voice Channels',
                    value: lang === 'ar'
                        ? `**روم الصوت القديم:**
                        **الروم:**  <#${oldChannel.id}>
                        **الاسم:**\` ${oldChannel.name}\`
                        **المعرف:** \`${oldChannel.id}\`

                        **روم الصوت الجديد:** 
                        **الروم:** <#${newChannel.id}>
                        **الاسم:** \`${newChannel.name}\`
                        **المعرف:** \`${newChannel.id}\`\n\u200B`
                                     
                        : `**Old Voice Channel:** 
                        **Channel:** <#${oldChannel.id}> 
                        **Name:** \`${oldChannel.name}\`
                        **ID:** \`${oldChannel.id}\`

                        **New Voice Channel:**
                        **Channel:** <#${newChannel.id}>
                        **Name:**\`${newChannel.name}\`
                        **ID:** \`${newChannel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? ' تم النقل بواسطة' : ' Moved by',
                    value: lang === 'ar'
                        ? `\n**الأدمن:** ${executorId ? `<@${executorId}>` : 'غير معروف'}\n\n**اسم الأدمن:** \`${executorTag ?? 'غير معروف'}\`\n\n**معرف الأدمن:** \`${executorId ?? 'غير معروف'}\`\n\u200B`
                        : `\n**Admin:** ${executorId ? `<@${executorId}>` : 'Unknown'}\n\n**Admin Name:** \`${executorTag ?? 'Unknown'}\`\n\n**Admin ID:** \`${executorId ?? 'Unknown'}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? 'وقت النقل ' : 'Time',
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${guild.name} | ${shortDate}`,
                iconURL: guild.iconURL()
            });

        channel.send({ embeds: [embed] });
    }
};
