const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'webhooksUpdate',
    once: false,

    async execute(client, settings, channel) {
        const loggerName = 'webhookCreate';
        // ✅ إلى هذا
const loggerSettings = settings[loggerName];
if (!loggerSettings || !loggerSettings.enabled) return;

        if (!loggerSettings.enabled) return;

        const logChannel = channel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;

        const lang = settings.botLanguage || 'ar';

        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));

        let executor = null;
        let webhookName = null;
        try {
            const logs = await channel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.WebhookCreate });
            const log = logs.entries.find(e => Date.now() - e.createdTimestamp < 5000);
            if (log) { executor = log.executor; webhookName = log.target?.name; }
            else return; // لو مو إنشاء webhook، تجاهل
        } catch { return; }

        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });
        const shortDate = new Date().toLocaleString('en-US');

        const titles = {
            ar: "🔗〡تم إنشاء Webhook جديد",
            en: "🔗〡Webhook Created"
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الـ Webhook" : " Webhook Info",
                    value: lang === 'ar'
                        ? `\n**الاسم:** \`${webhookName || 'غير معروف'}\`\n\n**الروم:** <#${channel.id}>\n\u200B`
                        : `\n**Name:** \`${webhookName || 'Unknown'}\`\n\n**Channel:** <#${channel.id}>\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الإنشاء بواسطة" : " Created By",
                    value: executor
                        ? (lang === 'ar'
                            ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                            : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                        : (lang === 'ar' ? 'غير معروف' : 'Unknown')
                }
            )
            .setFooter({ text: `${channel.guild.name} | ${shortDate}`, iconURL: channel.guild.iconURL() });

        logChannel.send({ embeds: [embed] });
    }
};
