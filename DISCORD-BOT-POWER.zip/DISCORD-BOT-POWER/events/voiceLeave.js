const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    once: false,
    
    async execute(client, settings, oldState, newState) {
        if (oldState.channel && !newState.channel) {
            const loggerName = 'voiceLeave';
            const loggerSettings = settings.loggers[loggerName];
            
            if (!loggerSettings.enabled) return;
            
            const channel = oldState.guild.channels.cache.get(loggerSettings.channelId);
            if (!channel) return;
            
            // تحديد اللغة
            const lang = settings.botLanguage || 'ar';
            
            // تنسيق التاريخ المفصل (داخل معلومات الخروج)
            const detailedDate = new Date().toLocaleString('en-US', {
                weekday: 'long',
                year: 'numeric',
                month: 'long',
                day: 'numeric',
                hour: 'numeric',
                minute: '2-digit',
                hour12: true
            });
            
            // تنسيق التاريخ المختصر (للـ Footer)
            const shortDate = new Date().toLocaleString('en-US');
            
            const titles = {
                ar: "🎧〡خروج عضو من روم صوتي",
                en: "🎧〡Member Left Voice Channel"
            };
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor(loggerSettings.embedColor)
                .addFields(
                    {
                        name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${oldState.member.user.id}>\n\n**اسم العضو:** \`${oldState.member.user.username}\`\n\n**معرف العضو:** \`${oldState.member.user.id}\`\n\u200B`
                            : `\n**Member:** <@${oldState.member.user.id}>\n\n**Member Name:** \`${oldState.member.user.username}\`\n\n**Member ID:** \`${oldState.member.user.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " الروم الصوتي" : " Voice Channel",
                        value: lang === 'ar'
                            ? `\n**الروم:** <#${oldState.channel.id}>\n\n**الاسم:** \`${oldState.channel.name}\`\n\n**المعرف:** \`${oldState.channel.id}\`\n\u200B`
                            : `\n**Channel:** <#${oldState.channel.id}>\n\n**Name:** \`${oldState.channel.name}\`\n\n**ID:** \`${oldState.channel.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " وقت الخروج" : " Leave Time",
                        value: `\`${detailedDate}\``
                    }
                )
                .setFooter({
                    text: `${oldState.guild.name} | ${shortDate}`,
                    iconURL: oldState.guild.iconURL()
                });
            
            channel.send({ embeds: [embed] });
        }
    }
};