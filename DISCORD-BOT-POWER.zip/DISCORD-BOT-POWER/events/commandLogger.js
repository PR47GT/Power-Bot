const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'interactionCreate',
    once: false,
    
    async execute(client, settings, interaction) {
        // فقط slash commands
        if (!interaction.isChatInputCommand()) return;

        const loggerName = 'commandLogger';
        const loggerSettings = settings[loggerName];
        
        if (!loggerSettings?.enabled || !loggerSettings?.channelId) return;
        
        const channel = interaction.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        // جلب معلومات الأمر
        const commandName = interaction.commandName;
        const user = interaction.user;
        const guild = interaction.guild;
        const channel_mentioned = interaction.channel;
        
        // جلب الـ options (البارامترات)
        let optionsText = '';
        if (interaction.options.data.length > 0) {
            optionsText = interaction.options.data
                .map(opt => `**${opt.name}**: ${opt.value || 'N/A'}`)
                .join('\n');
        }
        
        // تنسيق التاريخ المفصل
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "📋〡 تم استخدام أمر",
            en: "📋〡 Command Used"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor || 0x0099ff)
            .addFields(
                {
                    name: lang === 'ar' ? " الأمر" : " Command",
                    value: `\`/${commandName}\``
                },
                {
                    name: lang === 'ar' ? " معلومات المستخدم" : " User Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${user.id}>\n\n**اسم العضو:** \`${user.username}\`\n\n**معرّف العضو:** \`${user.id}\`\n\u200B`
                        : `\n**User:** <@${user.id}>\n\n**Username:** \`${user.username}\`\n\n**User ID:** \`${user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الروم" : " Channel",
                    value: lang === 'ar'
                    ? `\n**القناة:** <#${channel_mentioned.id}>\n\n**اسم القناة:** \`${channel_mentioned.name}\`\n\n**معرف القناة:** \`${channel_mentioned.id}\`\n\u200B`
                    : `\n**Channel:** <#${channel_mentioned.id}>\n\n**Channel Name:** \`${channel_mentioned.name}\`\n\n**Channel ID:** \`${channel_mentioned.id}\`\n\u200B`
                }
            )
            .setFooter({
                text: `${guild.name} | ${shortDate}`,
                iconURL: guild.iconURL()
            });
        
        // أضف الخيارات إذا كانت موجودة
        if (optionsText) {
            embed.addFields({
                name: lang === 'ar' ? " الخيارات" : " Options",
                value: optionsText
            });
        }
        
        // أضف الوقت
        embed.addFields({
            name: lang === 'ar' ? " التوقيت" : " Time",
            value: `\`${detailedDate}\``
        });
        
        try {
            await channel.send({ embeds: [embed] });
        } catch (err) {
            console.error('[CommandLogger] Error sending log:', err.message);
        }
    }
};