const { EmbedBuilder } = require('discord.js');

function timeSince(date, lang) {
    const seconds = Math.floor((Date.now() - date.getTime()) / 1000);
    
    const translations = {
        ar: {
            year: "سنة", years: "سنوات", month: "شهر", months: "أشهر",
            day: "يوم", days: "أيام", hour: "ساعة", hours: "ساعات",
            minute: "دقيقة", minutes: "دقائق", second: "ثانية", seconds: "ثواني",
            ago: "مضت"
        },
        en: {
            year: "year", years: "years", month: "month", months: "months",
            day: "day", days: "days", hour: "hour", hours: "hours",
            minute: "minute", minutes: "minutes", second: "second", seconds: "seconds",
            ago: "ago"
        }
    };
    
    const t = translations[lang] || translations.en;
    
    let interval = Math.floor(seconds / 31536000);
    if (interval >= 1) {
        return interval === 1 ? `${interval} ${t.year} ${t.ago}` : `${interval} ${t.years} ${t.ago}`;
    }
    interval = Math.floor(seconds / 2592000);
    if (interval >= 1) {
        return interval === 1 ? `${interval} ${t.month} ${t.ago}` : `${interval} ${t.months} ${t.ago}`;
    }
    interval = Math.floor(seconds / 86400);
    if (interval >= 1) {
        return interval === 1 ? `${interval} ${t.day} ${t.ago}` : `${interval} ${t.days} ${t.ago}`;
    }
    interval = Math.floor(seconds / 3600);
    if (interval >= 1) {
        return interval === 1 ? `${interval} ${t.hour} ${t.ago}` : `${interval} ${t.hours} ${t.ago}`;
    }
    interval = Math.floor(seconds / 60);
    if (interval >= 1) {
        return interval === 1 ? `${interval} ${t.minute} ${t.ago}` : `${interval} ${t.minutes} ${t.ago}`;
    }
    return seconds === 1 ? `${seconds} ${t.second} ${t.ago}` : `${seconds} ${t.seconds} ${t.ago}`;
}

module.exports = {
    name: 'guildMemberAdd',
    once: false,
    
    async execute(client, settings, member) {
        const loggerName = 'memberJoin';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = member.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const accountAge = timeSince(member.user.createdAt, lang);
        
        const createdDate = new Intl.DateTimeFormat(lang === 'ar' ? 'ar-EG' : 'en-US', {
            day: '2-digit', month: '2-digit', year: 'numeric',
            hour: '2-digit', minute: '2-digit', hour12: lang === 'ar' ? false : true
        }).format(member.user.createdAt);
        
        let inviterInfo = { tag: "Unknown", id: "Unknown", mention: "Unknown" };
        try {
            const invites = await member.guild.invites.fetch();
            const usedInvite = invites.find(inv => inv.uses > 0);
            if (usedInvite && usedInvite.inviter) {
                inviterInfo = {
                    tag: usedInvite.inviter.tag,
                    id: usedInvite.inviter.id,
                    mention: `<@${usedInvite.inviter.id}>`
                };
            }
        } catch (err) {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الانضمام)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🎉〡انضم عضو جديد",
            en: "🎉〡New Member Joined"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .setThumbnail(member.user.displayAvatarURL({ dynamic: true }))
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${member.user.id}>\n\n**اسم العضو:** \`${member.user.tag}\`\n\n**معرف العضو:** \`${member.user.id}\`\n\u200B`
                        : `\n**Member:** <@${member.user.id}>\n\n**Member Name:** \`${member.user.tag}\`\n\n**Member ID:** \`${member.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " عمر الحساب" : " Account Age",
                    value: lang === 'ar'
                        ? `\n**تاريخ الإنشاء:** \`${createdDate}\`\n\n**العمر:** \`${accountAge}\`\n\u200B`
                        : `\n**Created At:** \`${createdDate}\`\n\n**Age:** \`${accountAge}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تمت الدعوة بواسطة" : " Invited By",
                    value: lang === 'ar'
                        ? `**المستخدم:** ${inviterInfo.mention}\n\n**اسم المستخدم:** \`${inviterInfo.tag}\`\n\n**معرف المستخدم:** \`${inviterInfo.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**User:** ${inviterInfo.mention}\n\n**Username:** \`${inviterInfo.tag}\`\n\n**User ID:** \`${inviterInfo.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${member.guild.name} | ${shortDate}`,
                iconURL: member.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};