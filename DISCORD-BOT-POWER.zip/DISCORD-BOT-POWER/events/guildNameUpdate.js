const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildUpdate',
    once: false,
    
    async execute(client, settings, oldGuild, newGuild) {
        if (oldGuild.name === newGuild.name) return;
        
        const loggerName = 'guildNameUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newGuild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await newGuild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.GuildUpdate });
            const log = logs.entries.find(e => e.target.id === newGuild.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🔄〡تم تحديث إعدادات الخادم",
            en: "🔄〡Server Settings Updated"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " تفاصيل الخادم" : " Server Details",
                    value: lang === 'ar'
                        ? `\n**الاسم السابق:** \`${oldGuild.name}\`\n\n**الاسم الجديد:** \`${newGuild.name}\`\n\n**معرف الخادم:** \`${newGuild.id}\`\n\u200B`
                        : `\n**Old Name:** \`${oldGuild.name}\`\n\n**New Name:** \`${newGuild.name}\`\n\n**Server ID:** \`${newGuild.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newGuild.name} | ${shortDate}`,
                iconURL: newGuild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};