const { EmbedBuilder, AuditLogEvent, StickerFormatType } = require('discord.js');

module.exports = {
    name: 'stickerDelete',
    once: false,
    
    async execute(client, settings, sticker) {
        const loggerName = 'stickerDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = sticker.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const stickerType = {
            ar: sticker.format === StickerFormatType.PNG ? '📷 PNG (ثابت)' :
                sticker.format === StickerFormatType.APNG ? '🖼️ APNG (متحرك)' :
                sticker.format === StickerFormatType.Lottie ? '🎨 Lottie (متحرك)' : '📷 صورة',
            en: sticker.format === StickerFormatType.PNG ? '📷 PNG (Static)' :
                sticker.format === StickerFormatType.APNG ? '🖼️ APNG (Animated)' :
                sticker.format === StickerFormatType.Lottie ? '🎨 Lottie (Animated)' : '📷 Image'
        };
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await sticker.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.StickerDelete });
            const entry = logs.entries.find(e => e.target.id === sticker.id);
            if (entry) {
                executor = entry.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🗑️〡تم حذف استيكر",
            en: "🗑️〡Sticker Deleted"
        };
        
        const noDescription = {
            ar: "لا يوجد وصف",
            en: "No description"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الاستيكر المحذوف" : " Deleted Sticker Info",
                    value: lang === 'ar'
                        ? `\n**الاسم:** \`${sticker.name}\`\n\n**النوع:** ${stickerType[lang]}\n\n**المعرف:** \`${sticker.id}\`\n\n**الوصف:** ${sticker.description || noDescription[lang]}\n\u200B`
                        : `\n**Name:** \`${sticker.name}\`\n\n**Type:** ${stickerType[lang]}\n\n**ID:** \`${sticker.id}\`\n\n**Description:** ${sticker.description || noDescription[lang]}\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${sticker.guild.name} | ${shortDate}`,
                iconURL: sticker.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};