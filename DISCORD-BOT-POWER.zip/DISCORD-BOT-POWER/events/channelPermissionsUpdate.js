const { EmbedBuilder, AuditLogEvent, PermissionsBitField, ChannelType } = require('discord.js');
const config = require('../config');

function getChannelType(type, lang) {
    const types = {
        ar: {
            [ChannelType.GuildText]: "روم كتابي",
            [ChannelType.GuildVoice]: "روم صوتي",
            [ChannelType.GuildCategory]: "فئة",
            [ChannelType.GuildAnnouncement]: "روم إعلانات",
            [ChannelType.GuildStageVoice]: "روم مسرحي",
            [ChannelType.GuildForum]: "منتدى",
        },
        en: {
            [ChannelType.GuildText]: "Text Channel",
            [ChannelType.GuildVoice]: "Voice Channel",
            [ChannelType.GuildCategory]: "Category",
            [ChannelType.GuildAnnouncement]: "Announcement",
            [ChannelType.GuildStageVoice]: "Stage",
            [ChannelType.GuildForum]: "Forum",
        }
    };
    
    return types[lang]?.[type] || (lang === 'ar' ? "غير معروف" : "Unknown");
}

const permCache = new Map();

module.exports = {
    name: 'channelUpdate',
    once: false,
    
    async execute(client, settings, oldChannel, newChannel) {
        if (!oldChannel.guild) return;
        
        const loggerName = 'channelPermissionsUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newChannel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        let changes = "";
        
        newChannel.permissionOverwrites.cache.forEach((newPerm, id) => {
            const oldPerm = oldChannel.permissionOverwrites.cache.get(id);
            const oldAllow = new PermissionsBitField(oldPerm?.allow || 0n).toArray();
            const newAllow = new PermissionsBitField(newPerm.allow).toArray();
            const oldDeny = new PermissionsBitField(oldPerm?.deny || 0n).toArray();
            const newDeny = new PermissionsBitField(newPerm.deny).toArray();
            
            const addedAllow = newAllow.filter(p => !oldAllow.includes(p));
            const addedDeny = newDeny.filter(p => !oldDeny.includes(p));
            const removed = [...oldAllow, ...oldDeny].filter(p => !newAllow.includes(p) && !newDeny.includes(p));
            
            if (addedAllow.length) changes += `\`\`\`diff\n${addedAllow.map(p => `+ ${p}`).join("\n")}\n\`\`\`\n`;
            if (addedDeny.length) changes += `\`\`\`diff\n${addedDeny.map(p => `- ${p}`).join("\n")}\n\`\`\`\n`;
            if (removed.length) changes += `\`\`\`\n${removed.join("\n")}\n\`\`\`\n`;
        });
        
        if (!changes.trim()) return;
        
        const last = permCache.get(newChannel.id);
        if (last === changes) return;
        permCache.set(newChannel.id, changes);
        setTimeout(() => permCache.delete(newChannel.id), 4000);
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime + 400));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await newChannel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.ChannelOverwriteUpdate });
            const log = logs.entries.find(e => e.target.id === newChannel.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🔒〡تم تحديث صلاحيات الروم",
            en: "🔒〡Channel Permissions Updated"
        };
        
        const channelTypeName = getChannelType(newChannel.type, lang);
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${newChannel.id}>\n\n**اسم الروم:** \`${newChannel.name}\`\n\n**معرف الروم:** \`${newChannel.id}\`\n\n**النوع:** \`${channelTypeName}\`\n\u200B`
                        : `\n**Channel:** <#${newChannel.id}>\n\n**Channel Name:** \`${newChannel.name}\`\n\n**Channel ID:** \`${newChannel.id}\`\n\n**Type:** \`${channelTypeName}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " التغييرات" : " Changes",
                    value: changes.slice(0, 1000) || (lang === 'ar' ? "لا توجد تغييرات" : "No changes")
                },
                {
                    name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newChannel.guild.name} | ${shortDate}`,
                iconURL: newChannel.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};