const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'voiceStateUpdate',
    once: false,
    
    async execute(client, settings, oldState, newState) {
        if (!oldState.channelId && newState.channelId) return;
        if (oldState.channelId && !newState.channelId) return;
        if (oldState.channelId === newState.channelId) return;
        
        const loggerName = 'voiceChannelSwitch';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = newState.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        // تنسيق التاريخ المفصل (داخل معلومات التبديل)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🔊〡تم تبديل الروم الصوتي",
            en: "🔊〡Voice Channel Switched"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${newState.member.user.id}>\n\n**اسم العضو:** \`${newState.member.user.tag}\`\n\n**معرّف العضو:** \`${newState.member.user.id}\`\n\u200B`
                        : `\n**Member:** <@${newState.member.user.id}>\n\n**Member Name:** \`${newState.member.user.tag}\`\n\n**Member ID:** \`${newState.member.user.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " روم الصوت القديم" : " Old Voice Channel",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${oldState.channel.id}>\n\n**الاسم:** \`${oldState.channel.name}\`\n\n**المعرّف:** \`${oldState.channel.id}\`\n\u200B`
                        : `\n**Channel:** <#${oldState.channel.id}>\n\n**Name:** \`${oldState.channel.name}\`\n\n**ID:** \`${oldState.channel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " روم الصوت الجديد" : " New Voice Channel",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${newState.channel.id}>\n\n**الاسم:** \`${newState.channel.name}\`\n\n**المعرّف:** \`${newState.channel.id}\`\n\u200B`
                        : `\n**Channel:** <#${newState.channel.id}>\n\n**Name:** \`${newState.channel.name}\`\n\n**ID:** \`${newState.channel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " وقت التبديل" : " Switch Time",
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newState.guild.name} | ${shortDate}`,
                iconURL: newState.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};