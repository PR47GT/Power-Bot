const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildMemberUpdate',
    once: false,
    
    async execute(client, settings, oldMember, newMember) {
        const loggerName = 'roleAdd';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const addedRoles = newMember.roles.cache.filter(r => !oldMember.roles.cache.has(r.id));
        if (addedRoles.size === 0) return;
        
        const logChannel = newMember.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        // تنسيق التاريخ المفصل (داخل معلومات إضافة الرتبة)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "✅〡تم إعطاء رتبة لشخص",
            en: "✅〡Role Added"
        };
        
        const selfText = {
            ar: "العضو نفسه",
            en: "The Member Themself"
        };
        
        for (const [roleId, role] of addedRoles) {
            await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
            
            let executor = { id: newMember.id, tag: newMember.user.tag };
            let isSelf = true;
            
            try {
                const logs = await newMember.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MemberRoleUpdate });
                const log = logs.entries.find(entry =>
                    entry.target.id === newMember.id &&
                    entry.changes.some(c => c.key === `$add`) &&
                    Date.now() - entry.createdTimestamp < 5000
                );
                if (log && log.executor.id !== newMember.id) {
                    executor = log.executor;
                    isSelf = false;
                }
            } catch {}
            
            const embed = new EmbedBuilder()
                .setTitle(titles[lang])
                .setColor(loggerSettings.embedColor)
                .addFields(
                    {
                        name: lang === 'ar' ? "معلومات العضو" : " Member Info",
                        value: lang === 'ar'
                            ? `\n**العضو:** <@${newMember.id}>\n\n**اسم العضو:** \`${newMember.user.tag}\`\n\n**معرف العضو:** \`${newMember.id}\`\n\u200B`
                            : `\n**Member:** <@${newMember.id}>\n\n**Member Name:** \`${newMember.user.tag}\`\n\n**Member ID:** \`${newMember.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " الرتبة المعطاة" : " Role Given",
                        value: lang === 'ar'
                            ? `\n**الرتبة:** <@&${role.id}>\n\n**اسم الرتبة:** \`${role.name}\`\n\n**معرف الرتبة:** \`${role.id}\`\n\u200B`
                            : `\n**Role:** <@&${role.id}>\n\n**Role Name:** \`${role.name}\`\n\n**Role ID:** \`${role.id}\`\n\u200B`
                    },
                    {
                        name: lang === 'ar' ? " تم إعطاء الرتبة بواسطة" : " Role Given By",
                        value: isSelf
                            ? selfText[lang]
                            : (lang === 'ar'
                                ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**مُعرِّف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                                : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                    }
                )
                .setFooter({
                    text: `${newMember.guild.name} | ${shortDate}`,
                    iconURL: newMember.guild.iconURL({ dynamic: true })
                });
            
            logChannel.send({ embeds: [embed] });
        }
    }
};