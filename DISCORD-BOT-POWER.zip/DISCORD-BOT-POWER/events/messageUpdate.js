const { EmbedBuilder } = require('discord.js');

module.exports = {
    name: 'messageUpdate',
    once: false,
    
    async execute(client, settings, oldMessage, newMessage) {
        if (!newMessage.guild) return;
        if (oldMessage.content === newMessage.content) return;
        
        const loggerName = 'messageUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newMessage.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const user = newMessage.author;
        const username = user ? user.tag : (lang === 'ar' ? "غير معروف" : "Unknown");
        const userid = user ? user.id : (lang === 'ar' ? "غير معروف" : "Unknown");
        
        let oldContent = lang === 'ar' ? "`.`" : "`.`";
        if (oldMessage.content && oldMessage.content.trim() !== "") {
            oldContent = `\`\`\`${oldMessage.content.slice(0, 1000)}\`\`\``;
        }
        
        let newContent = lang === 'ar' ? "`.`" : "`.`";
        if (newMessage.content && newMessage.content.trim() !== "") {
            newContent = `\`\`\`${newMessage.content.slice(0, 1000)}\`\`\``;
        }
        
        // تنسيق التاريخ المفصل (داخل معلومات التعديل)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "✏️〡تم تعديل رسالة",
            en: "✏️〡Message Edited"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " صاحب الرسالة" : " Message Author",
                    value: lang === 'ar'
                        ? `\n**الشخص:** <@${userid}>\n\n**اسم الشخص:** \`${username}\`\n\n**معرف الشخص:** \`${userid}\`\n\u200B`
                        : `\n**User:** <@${userid}>\n\n**Username:** \`${username}\`\n\n**User ID:** \`${userid}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الرسالة قبل التعديل" : " Before Edit",
                    value: oldContent.length > 1024 ? oldContent.slice(0, 1021) + "..." : oldContent
                },
                {
                    name: lang === 'ar' ? " الرسالة بعد التعديل" : " After Edit",
                    value: newContent.length > 1024 ? newContent.slice(0, 1021) + "..." : newContent
                },
                {
                    name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${newMessage.channel.id}>\n\n**اسم الروم:** \`${newMessage.channel.name}\`\n\n**معرف الروم:** \`${newMessage.channel.id}\`\n\u200B`
                        : `\n**Channel:** <#${newMessage.channel.id}>\n\n**Channel Name:** \`${newMessage.channel.name}\`\n\n**Channel ID:** \`${newMessage.channel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " التوقيت" : " Time",
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newMessage.guild.name} | ${shortDate}`,
                iconURL: newMessage.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};