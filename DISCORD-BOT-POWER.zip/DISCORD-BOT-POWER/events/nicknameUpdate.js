const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildMemberUpdate',
    once: false,
    
    async execute(client, settings, oldMember, newMember) {
        if (oldMember.nickname === newMember.nickname) return;
        
        const loggerName = 'nicknameUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = newMember.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const oldName = oldMember.nickname || oldMember.user.username;
        const newName = newMember.nickname || newMember.user.username;
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: newMember.id, tag: newMember.user.tag };
        let isSelf = true;
        
        try {
            const logs = await newMember.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MemberUpdate });
            const log = logs.entries.find(entry => entry.target.id === newMember.id && Date.now() - entry.createdTimestamp < 5000);
            if (log && log.executor.id !== newMember.id) {
                executor = log.executor;
                isSelf = false;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التغيير)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "✏️〡تم تغيير اسم عضو",
            en: "✏️〡Nickname Changed"
        };
        
        const selfText = {
            ar: " الشخص نفسه",
            en: " The Member Themself"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${newMember.id}>\n\n**اسم العضو:** \`${newMember.user.tag}\`\n\n**معرف العضو:** \`${newMember.id}\`\n\u200B`
                        : `\n**Member:** <@${newMember.id}>\n\n**Member Name:** \`${newMember.user.tag}\`\n\n**Member ID:** \`${newMember.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الاسم السابق" : " Old Nickname",
                    value: `\`\`\`${oldName}\`\`\``
                },
                {
                    name: lang === 'ar' ? " الاسم الجديد" : " New Nickname",
                    value: `\`\`\`${newName}\`\`\``
                },
                {
                    name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
                    value: isSelf
                        ? selfText[lang]
                        : (lang === 'ar'
                            ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                            : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                }
            )
            .setFooter({
                text: `${newMember.guild.name} | ${shortDate}`,
                iconURL: newMember.guild.iconURL()
            });
        
        channel.send({ embeds: [embed] });
    }
};