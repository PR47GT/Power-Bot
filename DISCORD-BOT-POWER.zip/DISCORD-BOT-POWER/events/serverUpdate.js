const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'guildUpdate',
    once: false,

    async execute(client, settings, oldGuild, newGuild) {
        const descChanged = oldGuild.description !== newGuild.description;
        const rulesChanged = oldGuild.rulesChannelId !== newGuild.rulesChannelId;
        if (!descChanged && !rulesChanged) return;

        const loggerName = 'serverUpdate';
        const loggerSettings = settings[loggerName]; // ✅ الإصلاح هنا

        if (!loggerSettings || !loggerSettings.enabled) return;

        const channel = newGuild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;

        const lang = settings.botLanguage || 'ar';

        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));

        let executor = null;
        try {
            const logs = await newGuild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.GuildUpdate });
            const log = logs.entries.find(e => Date.now() - e.createdTimestamp < 5000);
            if (log) executor = log.executor;
        } catch {}

        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long', year: 'numeric', month: 'long',
            day: 'numeric', hour: 'numeric', minute: '2-digit', hour12: true
        });
        const shortDate = new Date().toLocaleString('en-US');

        const titles = {
            ar: "📋〡تم تحديث معلومات السيرفر",
            en: "📋〡Server Info Updated"
        };

        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor);

        if (descChanged) {
            embed.addFields(
                {
                    name: lang === 'ar' ? " الوصف السابق" : " Old Description",
                    value: `\`\`\`${oldGuild.description || (lang === 'ar' ? 'لا يوجد' : 'None')}\`\`\``
                },
                {
                    name: lang === 'ar' ? " الوصف الجديد" : " New Description",
                    value: `\`\`\`${newGuild.description || (lang === 'ar' ? 'لا يوجد' : 'None')}\`\`\``
                }
            );
        }

        if (rulesChanged) {
            embed.addFields({
                name: lang === 'ar' ? " روم القواعد" : " Rules Channel",
                value: lang === 'ar'
                    ? `السابق: ${oldGuild.rulesChannelId ? `<#${oldGuild.rulesChannelId}>` : 'لا يوجد'}\nالجديد: ${newGuild.rulesChannelId ? `<#${newGuild.rulesChannelId}>` : 'لا يوجد'}`
                    : `Before: ${oldGuild.rulesChannelId ? `<#${oldGuild.rulesChannelId}>` : 'None'}\nAfter: ${newGuild.rulesChannelId ? `<#${newGuild.rulesChannelId}>` : 'None'}`
            });
        }

        const executorName = executor?.username ?? executor?.tag ?? (lang === 'ar' ? 'غير معروف' : 'Unknown');

        embed.addFields({
            name: lang === 'ar' ? " تم التحديث بواسطة" : " Updated By",
            value: executor
                ? (lang === 'ar'
                    ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executorName}\`\n\n**المعرف:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                    : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executorName}\`\n\n**ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``)
                : (lang === 'ar' ? 'غير معروف' : 'Unknown')
        });

        embed.setFooter({ text: `${newGuild.name} | ${shortDate}`, iconURL: newGuild.iconURL() });

        await channel.send({ embeds: [embed] });
    }
};