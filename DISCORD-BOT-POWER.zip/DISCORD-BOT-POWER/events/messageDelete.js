const { EmbedBuilder, AuditLogEvent } = require('discord.js');

module.exports = {
    name: 'messageDelete',
    once: false,
    
    async execute(client, settings, message) {
        if (!message.guild) return;
        
        const loggerName = 'messageDelete';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = message.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const user = message.author;
        const username = user ? user.tag : (lang === 'ar' ? "غير معروف" : "Unknown");
        const userid = user ? user.id : (lang === 'ar' ? "غير معروف" : "Unknown");
        
        let content = lang === 'ar' ? "`.`" : "`.`";
        if (message.content && message.content.trim() !== "") {
            content = `\`\`\`${message.content.slice(0, 1000)}\`\`\``;
        }
        
        let executor = { tag: username, id: userid };
        try {
            const logs = await message.guild.fetchAuditLogs({ limit: 10, type: AuditLogEvent.MessageDelete });
            const log = logs.entries.find(entry =>
                entry.extra.channel.id === message.channel.id &&
                entry.target.id === message.author?.id &&
                Date.now() - entry.createdTimestamp < 15000
            );
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات الحذف)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🗑️〡تم حذف رسالة",
            en: "🗑️〡Message Deleted"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " صاحب الرسالة" : " Message Author",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${userid}>\n\n**اسم العضو:** \`${username}\`\n\n**معرف العضو:** \`${userid}\`\n\u200B`
                        : `\n**Member:** <@${userid}>\n\n**Member Name:** \`${username}\`\n\n**Member ID:** \`${userid}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " تم الحذف بواسطة" : " Deleted By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**الاسم:** \`${executor.tag}\`\n\n**المعرف:** \`${executor.id}\`\n\u200B`
                        : `**Admin:** <@${executor.id}>\n\n**Name:** \`${executor.tag}\`\n\n**ID:** \`${executor.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " محتوى الرسالة" : " Message Content",
                    value: content.length > 1024 ? content.slice(0, 1021) + "..." : content
                },
                {
                    name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${message.channel.id}>\n\n**اسم الروم:** \`${message.channel.name}\`\n\n**معرف الروم:** \`${message.channel.id}\`\n\u200B`
                        : `\n**Channel:** <#${message.channel.id}>\n\n**Channel Name:** \`${message.channel.name}\`\n\n**Channel ID:** \`${message.channel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " التوقيت" : " Time",
                    value: `\`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${message.guild.name} | ${shortDate}`,
                iconURL: message.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};