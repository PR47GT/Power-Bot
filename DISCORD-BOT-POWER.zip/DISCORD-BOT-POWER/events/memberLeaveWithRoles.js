const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

function getMemberDuration(joinedAt, lang) {
    const now = new Date();
    const joined = new Date(joinedAt);
    const diffMs = now - joined;
    const days = Math.floor(diffMs / 86400000);
    const hours = Math.floor((diffMs % 86400000) / 3600000);
    const minutes = Math.floor((diffMs % 3600000) / 60000);
    
    const units = {
        ar: { day: "يوم", days: "أيام", hour: "ساعة", hours: "ساعات", minute: "دقيقة", minutes: "دقائق" },
        en: { day: "day", days: "days", hour: "hour", hours: "hours", minute: "minute", minutes: "minutes" }
    };
    
    const t = units[lang] || units.en;
    
    const dayText = days === 1 ? `${days} ${t.day}` : `${days} ${t.days}`;
    const hourText = hours === 1 ? `${hours} ${t.hour}` : `${hours} ${t.hours}`;
    const minuteText = minutes === 1 ? `${minutes} ${t.minute}` : `${minutes} ${t.minutes}`;
    
    return { days, hours, minutes, text: `${dayText}, ${hourText}, ${minuteText}` };
}

async function wasKicked(member) {
    try {
        const logs = await member.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MemberKick });
        const kickLog = logs.entries.find(entry => entry.target.id === member.id);
        if (!kickLog || !kickLog.executor) return false;
        return Date.now() - kickLog.createdAt.getTime() < config.settings.kickDetectionTime;
    } catch (err) { return false; }
}

module.exports = {
    name: 'guildMemberRemove',
    once: false,
    
    async execute(client, settings, member) {
        const loggerName = 'memberLeaveWithRoles';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const channel = member.guild.channels.cache.get(loggerSettings.channelId);
        if (!channel) return;
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        const isKicked = await wasKicked(member);
        const duration = getMemberDuration(member.joinedAt, lang);
        const roles = member.roles.cache.filter(role => role.name !== '@everyone');
        const rolesCount = roles.size;
        const sortedRoles = roles.sort((a, b) => b.position - a.position);
        
        let rolesText = '';
        sortedRoles.forEach(role => { rolesText += `${role}\n`; });
        if (rolesText === '') {
            rolesText = lang === 'ar' ? 'لا يوجد رولات' : 'No roles';
        }
        
        let title = {
            ar: "🚪〡عضو غادر السيرفر",
            en: "🚪〡Member Left"
        };
        let color = loggerSettings.embedColor;
        let kickInfo = null;
        
        if (isKicked) {
            const logs = await member.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.MemberKick });
            const kickLog = logs.entries.find(entry => entry.target.id === member.id);
            if (kickLog && kickLog.executor) {
                title = {
                    ar: "👢⇜ تم طرد عضو من السيرفر",
                    en: "👢⇜ Member Kicked"
                };
                color = "#FF0000";
                kickInfo = kickLog;
            }
        }
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const embed = new EmbedBuilder()
            .setColor(color)
            .setTitle(title[lang])
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات العضو" : " Member Info",
                    value: lang === 'ar'
                        ? `\n**العضو:** <@${member.id}>\n\n**الاسم:** \`${member.user.tag}\`\n\n**المعرف:** \`${member.id}\`\n\u200B`
                        : `\n**Member:** <@${member.id}>\n\n**Name:** \`${member.user.tag}\`\n\n**ID:** \`${member.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " إحصائيات" : " Statistics",
                    value: lang === 'ar'
                        ? `\n**عدد الرتب:** ${rolesCount}\n\n**مدة البقاء:** \`${duration.text}\`\n\u200B`
                        : `\n**Roles Count:** ${rolesCount}\n\n**Stay Duration:** \`${duration.text}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " الرتب التي كان يمتلكها" : " Roles He Had",
                    value: rolesText.length > 1024 ? rolesText.slice(0, 1021) + "..." : rolesText
                },
{
    name: lang === 'ar' ? " وقت المغادرة" : " Leave Time",
    value: lang === 'ar'
        ? `**تاريخ الانضمام:** <t:${Math.floor(new Date(member.joinedAt) / 1000)}:F>\n**وقت المغادرة:** <t:${Math.floor(Date.now() / 1000)}:F>`
        : `**Joined At:** <t:${Math.floor(new Date(member.joinedAt) / 1000)}:F>\n**Left At:** <t:${Math.floor(Date.now() / 1000)}:F>`
},
                {
                    name: lang === 'ar' ? " عدد الأعضاء" : " Member Count",
                    value: lang === 'ar'
                        ? `**المتبقي:** ${member.guild.memberCount} عضو`
                        : `**Remaining:** ${member.guild.memberCount} members`
                }
            )
            .setFooter({
                text: `${member.guild.name} | ${shortDate}`,
                iconURL: member.guild.iconURL()
            });
        
        if (kickInfo) {
            embed.addFields({
                name: lang === 'ar' ? " تم الطرد بواسطة" : " Kicked By",
                value: lang === 'ar'
                    ? `**الأدمن:** <@${kickInfo.executor.id}>\n\n**الاسم:** \`${kickInfo.executor.tag}\`\n\n**المعرف:** \`${kickInfo.executor.id}\``
                    : `**Admin:** <@${kickInfo.executor.id}>\n\n**Name:** \`${kickInfo.executor.tag}\`\n\n**ID:** \`${kickInfo.executor.id}\``
            });
            if (kickInfo.reason) {
                embed.addFields({
                    name: lang === 'ar' ? " سبب الطرد" : " Kick Reason",
                    value: `\`\`\`${kickInfo.reason}\`\`\``
                });
            }
        }
        
        channel.send({ embeds: [embed] });
    }
};