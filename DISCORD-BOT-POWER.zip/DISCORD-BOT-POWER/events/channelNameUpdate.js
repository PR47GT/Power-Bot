const { EmbedBuilder, AuditLogEvent } = require('discord.js');
const config = require('../config');

module.exports = {
    name: 'channelUpdate',
    once: false,
    
    async execute(client, settings, oldChannel, newChannel) {
        if (oldChannel.name === newChannel.name) return;
        
        const loggerName = 'channelNameUpdate';
        const loggerSettings = settings.loggers[loggerName];
        
        if (!loggerSettings.enabled) return;
        
        const logChannel = newChannel.guild.channels.cache.get(loggerSettings.channelId);
        if (!logChannel) return;
        
        // تحديد اللغة
        const lang = settings.botLanguage || 'ar';
        
        await new Promise(r => setTimeout(r, config.settings.auditLogWaitTime));
        
        let executor = { id: "Unknown", tag: "Unknown#0000" };
        try {
            const logs = await newChannel.guild.fetchAuditLogs({ limit: 5, type: AuditLogEvent.ChannelUpdate });
            const log = logs.entries.find(e => e.target.id === newChannel.id && Date.now() - e.createdTimestamp < 5000);
            if (log) {
                executor = log.executor;
            }
        } catch {}
        
        // تنسيق التاريخ المفصل (داخل معلومات التحديث)
        const detailedDate = new Date().toLocaleString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            hour: 'numeric',
            minute: '2-digit',
            hour12: true
        });
        
        // تنسيق التاريخ المختصر (للـ Footer)
        const shortDate = new Date().toLocaleString('en-US');
        
        const titles = {
            ar: "🔄〡تم تحديث الروم",
            en: "🔄〡Channel Updated"
        };
        
        const embed = new EmbedBuilder()
            .setTitle(titles[lang])
            .setColor(loggerSettings.embedColor)
            .addFields(
                {
                    name: lang === 'ar' ? " معلومات الروم" : " Channel Info",
                    value: lang === 'ar'
                        ? `\n**الروم:** <#${newChannel.id}>\n\n**اسم الروم:** \`${newChannel.name}\`\n\n**معرف الروم:** \`${newChannel.id}\`\n\u200B`
                        : `\n**Channel:** <#${newChannel.id}>\n\n**Channel Name:** \`${newChannel.name}\`\n\n**Channel ID:** \`${newChannel.id}\`\n\u200B`
                },
                {
                    name: lang === 'ar' ? " قبل" : " Before",
                    value: `\`\`\`${oldChannel.name}\`\`\``
                },
                {
                    name: lang === 'ar' ? " بعد" : " After",
                    value: `\`\`\`${newChannel.name}\`\`\``
                },
                {
                    name: lang === 'ar' ? " تم التعديل بواسطة" : " Updated By",
                    value: lang === 'ar'
                        ? `**الادمن:** <@${executor.id}>\n\n**اسم الادمن:** \`${executor.tag}\`\n\n**معرف الادمن:** \`${executor.id}\`\n\n**التوقيت:** \`${detailedDate}\``
                        : `**Admin:** <@${executor.id}>\n\n**Admin Name:** \`${executor.tag}\`\n\n**Admin ID:** \`${executor.id}\`\n\n**Time:** \`${detailedDate}\``
                }
            )
            .setFooter({
                text: `${newChannel.guild.name} | ${shortDate}`,
                iconURL: newChannel.guild.iconURL()
            });
        
        logChannel.send({ embeds: [embed] });
    }
};